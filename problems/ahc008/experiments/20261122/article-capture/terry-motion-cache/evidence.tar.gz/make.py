"""Immutable ordered neighbor cache for same-room TERRY forecasts."""
from pathlib import Path
import sys,hashlib
a,b=map(Path,sys.argv[1:])
d=a.read_bytes()
assert hashlib.sha256(d).hexdigest()=='71b0edebbf87e873543f6438786d68d8b1130ff69975605318ed8b18507fdad7'
s=d.decode()
p='using Retention=std::vector<std::array<int,30>>;'
assert s.count(p)==1
s=s.replace(p,'''struct RetentionNeighbors {
 struct Row {std::array<uint16_t,4> cells; uint8_t degree;};
 std::array<Row,V> table;
 void prepare(const Mask& walls){
  for(int p=0;p<V;++p){
   auto& row=table[p];row.degree=0;
   for(int q:nb[p])if(q>=0&&!walls[q])row.cells[row.degree++]=uint16_t(q);
  }
 }
 void random(Pet& p,Pcg& rng)const{
  const auto& r=table[p.pos];
  if(r.degree)p.pos=r.cells[choose_small(rng,r.degree)];
 }
 void goal(Pet& p,const State& s,HumanDistances& ds,Pcg& rng)const{
  int t=p.target, m=int(s.people.size());
  if(t<0||t>=m||ds.at(t)[p.pos]<=0||ds.at(t)[p.pos]>=INF){
   int n=0;
   for(int i=0;i<m;++i){const int d=ds.at(i)[p.pos];n+=(d>0&&d<INF);}
   if(n==0){p.target=-1;random(p,rng);return;}
   do{t=choose_word(rng,m);}while(ds.at(t)[p.pos]<=0||ds.at(t)[p.pos]>=INF);
  }
  p.target=t;
  const auto& d=ds.at(t);
  const auto& row=table[p.pos];
  int choices[4],count=0;
  for(int j=0;j<row.degree;++j){int q=row.cells[j];if(d[q]<d[p.pos])choices[count++]=q;}
  if(count)p.pos=choices[choose_small(rng,count)];
  if(p.pos==s.people[t])p.target=-1;
  random(p,rng);
  if(p.pos==s.people[t])p.target=-1;
 }
};
using Retention=std::vector<std::array<int,30>>;''')
old=' Retention result(rooms); HumanDistances ds{s,next};'
assert s.count(old)==1
s=s.replace(old,' Retention result(rooms); HumanDistances ds{s,next};\n RetentionNeighbors adjacency;bool ready=false;')
old='  if(room<0||room>=rooms)continue;\n  for(int trial'
assert s.count(old)==1
s=s.replace(old,'  if(room<0||room>=rooms)continue;\n  if(!ready){adjacency.prepare(next);ready=true;}\n  for(int trial')
old='    if(p.type==4)model_dog(p,s,next,ds,rng,false);\n    else for(int k=0;k<(p.type==5?2:p.type);++k)random_step(p,next,rng);'
assert s.count(old)==1
s=s.replace(old,'    if(p.type==4)adjacency.goal(p,s,ds,rng);\n    else for(int k=0;k<(p.type==5?2:p.type);++k)adjacency.random(p,rng);')
b.write_text(s)
