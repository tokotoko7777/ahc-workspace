# Freeze before equal default-clock comparison

Exactly same independent TERRY method, compare frozen faithful 54f2b1ec
against cumulative faster d14f6471 (ETA-zero miss bypass + static ordered
forecast adjacency). Same absolute t275 budget in both. No workload caps,
case-specific routing, seeds or policy selection. Measure actual score,
full, useful, residual, action/rollout counts and maximum serial tester wall.
Full speed equivalence already separately verified under fixed work; here
any differences may be the t275 time arriving earlier, not a changed plan.

First separately compare original practice100, then fresh uniform100 from
100 deterministic SHA seed derivations under
`ahc008/20261123/terry-cache-default/holdout/0…99`. Manifest frozen before
observing either. Same cases between arms, two datasets not combined.
Require no full/useful regression on either for calling the faster
version the new reference. For score update, require actually improved
reported practice score and no lower fresh score. A timing-driven
single-board increase is a recorded result but not proof of reliably
stronger policy. No main/rank claim. If practice or fresh worse, retain
previous scoring reference; speed result remains exact under fixed work.
