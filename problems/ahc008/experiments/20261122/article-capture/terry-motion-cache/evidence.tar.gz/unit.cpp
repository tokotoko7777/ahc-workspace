#define terry_exact_motion previous_motion
#include "../ahc008_terry_exact_root/motion.hpp"
#undef terry_exact_motion
#define main integrated_main
#include "submission.private.cpp"
#undef main
#include <iostream>
int main(){
 using namespace terry_exact_motion;
 std::mt19937_64 split(20261123);
 for(int f=0;f<128;++f){
  previous_motion::State a;State b;std::array<int,V> ids;
  for(int p=0;p<V;++p){a.walls[p]=b.walls[p]=((split()>>44)&7)<2;ids[p]=int(split()%9)-2;}
  auto vacant=[&]{int p;do{p=split()%V;}while(a.walls[p]);return p;};
  for(int i=0;i<7;++i){int j=vacant();a.people.push_back(j);b.people.push_back(j);}
  std::vector<int> alive;
  for(int i=0;i<17;++i){int p=vacant(),ty=1+(i+f)%5;a.pets.push_back({p,ty,-1});
   b.pets.push_back({p,ty,-1});alive.push_back(i);}
  previous_motion::Pcg r0(f+42);Pcg r1(f+42);
  auto u=previous_motion::retention(a,a.walls,ids,6,alive,r0);
  auto v=retention(b,b.walls,ids,6,alive,r1);
  assert(u==v&&r0.s==r1.s);
 }
 std::cout<<"128 complete distributions and final RNG states equal\n";
}
