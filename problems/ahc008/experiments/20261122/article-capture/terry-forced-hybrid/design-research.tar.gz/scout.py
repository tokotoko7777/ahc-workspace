"""Only public generated seed stream and certified factual prefix through t275."""
import hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
X=D/'dev'; H=R/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark_cases import run
NS='ahc008-clean-catch-hybrid-v1'
def sha(s):return hashlib.sha256(s).hexdigest()
def seed(panel,i):return int.from_bytes(hashlib.sha256(f'{NS}:{panel}:{i}'.encode()).digest()[:8],'little')
def short_prefix(b):
    a=b.decode().splitlines();assert len(a)==275
    assert all(all(c in '.UDLRudlr' for c in k) and len(k)==len(a[0]) for k in a)
    return sha('::'.join(a).encode())
def prefix(stage,raw,d):
    tools=R/'ahc008_focus_assets/tools/target/release'
    log=d/'audit'
    out,err,code,wall=run([str(tools/'tester'),'env','AHC008_TERMINAL_K8='+str(log),
        str(D/'observer'),'--pairs=0',f'--terminal={stage}'],raw,3.5 if stage=='scout' else 8)
    assert code==1 and err==b'Your program has terminated unexpectedly on turn 276\nScore = 0\n',(stage,code,err)
    v=log.read_text().splitlines();assert len(v)==1+(8 if stage=='shadow' else 0)
    return short_prefix(out),int(v[0]),[list(map(int,l.split()))for l in v[1:]],wall
def main():
    X.mkdir(); (X/'selected').mkdir()
    s=[seed('dev',i)for i in range(1024)];assert len(set(s))==1024
    seedfile=X/'seeds.txt';seedfile.write_text(''.join(f'{x}\n'for x in s))
    gen=R/'ahc008_focus_assets/tools/target/release/gen'
    subprocess.run([str(gen),str(seedfile)],cwd=X,check=True,timeout=45)
    retained=[];seen=set();scout=[]
    with tempfile.TemporaryDirectory() as d:
        for i in range(len(s)):
            p=X/'in'/f'{i:04d}.txt';raw=p.read_bytes();idh=sha(raw)
            assert idh not in seen;seen.add(idh)
            a,num,_,w=prefix('scout',raw,Path(d))
            scout.append(dict(stream_index=i,sha256=idh,prefix_sha=a,target_count=num))
            if num:
                name=f'{len(retained):04d}.txt';shutil.copyfile(p,X/'selected'/name)
                retained.append(dict(case=name,stream_index=i,seed=s[i],sha256=idh,prefix_sha=a,target_count=num))
            if len(retained)==100:break
    manifest=dict(namespace=NS,reserve_namespace=f'{NS}:fresh-confirm',max_stream=1024,seedlist=sha(seedfile.read_bytes()),
        selected=retained,scouted=scout,eligible_complete=len(retained)==100)
    (X/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(len(scout),len(retained))
    if len(retained)!=100:raise SystemExit('insufficient locked pre-t275 eligible support; stop')
if __name__=='__main__':main()
