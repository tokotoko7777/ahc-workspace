from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
s=(D.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
put('int main(int argc,char** argv){','''
namespace terry_exact_root {
std::pair<int,int64_t> exact_immediate(const State& s){
 std::array<int,V> g;g.fill(-1);
 int sizes[10]{},animals[10]{},cnt=0,live=0;
 for(int start:s.people)if(g[start]<0){
  int q[V],n=1;q[0]=start;g[start]=cnt;
  for(int i=0;i<n;++i)for(int p:nb[q[i]])if(p>=0&&!s.walls[p]&&g[p]<0){g[p]=cnt;q[n++]=p;}
  sizes[cnt++]=n;
 }
 for(auto p:s.pets)if(g[p.pos]>=0){++animals[g[p.pos]];++live;}
 int64_t total=0;
 for(int h:s.people)total+=int64_t(sizes[g[h]])<<(s.pets.size()-animals[g[h]]);
 return {live,total};
}
bool safe_cmd(const State&s,const std::string& a){
 return sanitize(s,std::vector<char>(a.begin(),a.end()))==a;
}
}
int main(int argc,char** argv){''')
put(' int map=-1,cap=100000,limit_ms=2670;',' int map=-1,cap=100000,limit_ms=2670;\n std::string phase;')
put('  else if(s.starts_with("--ms="))limit_ms=std::stoi(s.substr(5));','''
  else if(s.starts_with("--ms="))limit_ms=std::stoi(s.substr(5));
  else if(s.starts_with("--terminal="))phase=s.substr(11);''')
put(' NormalCount metrics;Decision d;', ''' NormalCount metrics;Decision d;
 std::optional<Normal> clean; std::vector<int> overrides;''')
put('  if(turn==275)d=decide(s,policy,cap,stop);','''  if(turn==275){
   if(cap!=0)return 2;
   if(phase=="scout"){
    const char* path=std::getenv("AHC008_TERMINAL_K8");if(!path)return 2;
    std::ofstream o(path);
    o<<terry_partition::majorityPets(s.walls,s.people,pet_cells(s)).size()<<'\\n';
    return 0;
   }
   if(phase!="chase"&&phase!="hybrid")return 2;
   if(phase=="hybrid")clean.emplace(policy);
   d.chose=true;
  }''')
put('  people_step(s,command);','''  if(turn>=275&&phase=="hybrid"){
   Normal branch=*clean; const auto trial=branch.step(s,turn);
   if(trial!=command&&safe_cmd(s,trial)&&safe_cmd(s,command)){
    State n=s,c=s;people_step(n,trial);people_step(c,command);
    const auto base=exact_immediate(s);
    const auto normal=exact_immediate(n),chase_now=exact_immediate(c);
    if(normal.first<base.first && normal.first<=chase_now.first && normal.second>chase_now.second){
     command=trial;overrides.push_back(turn);
    }
   }
  }
  people_step(s,command);''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* path=std::getenv("AHC008_HYBRID_EVENTS")){
  std::ofstream e(path);
  for(int t:overrides)e<<t<<' ';
 }
'''+a)
(D/'observer.private.cpp').write_text(s)
