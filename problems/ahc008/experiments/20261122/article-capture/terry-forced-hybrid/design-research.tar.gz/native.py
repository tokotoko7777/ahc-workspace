"""Context baseline only: actual unmodified native f83, verified complete."""
import collections,json,re,sys,tempfile
from pathlib import Path
from scout import D,R,X,run,sha,short_prefix
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood
tools=R/'ahc008_focus_assets/tools/target/release'
solver=R/'ahc008_terry_split_bound/solve'
sel=json.loads((X/'manifest.json').read_text())['selected'];assert len(sel)==100
out=[]
for r in sel:
 name=r['case']; raw=(X/'selected'/name).read_bytes();assert sha(raw)==r['sha256']
 with tempfile.TemporaryDirectory() as d:
  d=Path(d); tel=d/'metrics';act=d/'actions';tape=d/'tape'
  a,e,c,w=run([str(tools/'tester'),'env','AHC008_TERRY_EXACT_LOG='+str(tel),str(solver)],raw,5)
  score=re.fullmatch(rb'Score = (\d+)\s*',e);assert c==0 and score
  assert short_prefix(b'\n'.join(a.splitlines()[:275])+b'\n')==r['prefix_sha']
  act.write_bytes(a)
  assert run([str(tools/'tester'),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(act),str(tape)],raw,12)[:3]==(a,e,c)
  tr=tape.read_text().splitlines()
  sc=replay(raw.decode(),tr,a.decode().splitlines(),detailed=True)[0]
  v=list(map(int,tel.read_text().split()));assert len(v)==15 and sc==v[-1]==int(score[1]) and v[13] in (0,1)
  _,hist,_=observed(raw,tr);ps,hs,ws=hist[300]
  op=ALL^sum(B[idx(q)]for q in ws);reach=flood(sum({B[idx(q)]for q in hs}),op);res=sum(bool(reach&B[idx(q)])for q in ps)
  area=sum(flood(B[idx(q)],op).bit_count()for q in hs)
  out.append(dict(case=name,input_sha=r['sha256'],prefix_sha=r['prefix_sha'],commands_sha=sha(a),mode=v[13],
      score=sc,full=int(res==0),useful300=int(res==0 and area>=300*len(hs)),final_residual=res,wall=w))
  (X/'native.json').write_text(json.dumps(out,indent=2)+'\n')
  print(name,flush=True)
