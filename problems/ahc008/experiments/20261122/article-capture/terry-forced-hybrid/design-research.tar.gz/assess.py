import collections,csv,json
from pathlib import Path
D=Path(__file__).resolve().parent;X=D/'dev'
sel=json.loads((X/'manifest.json').read_text())['selected']
nat={x['case']:x for x in json.loads((X/'native.json').read_text())}
pairs=collections.defaultdict(dict)
for row in csv.DictReader((X/'forced.csv').open()):
    assert row['arm'] not in pairs[row['case']]
    pairs[row['case']][row['arm']]=row
assert len(sel)==len(nat)==len(pairs)==100
rows=[]; exploratory=[]
for p in sel:
    name=p['case'];n=nat[name];c,h=(pairs[name][a]for a in ('v25','terry_independent'))
    assert p['sha256']==n['input_sha']==c['input_sha']==h['input_sha']
    assert p['prefix_sha']==n['prefix_sha']==c['prefix_sha']==h['prefix_sha']
    assert not c['override_turns']
    events=list(map(int,h['override_turns'].split()))
    assert events==sorted(set(events)) and all(275<=e<300 for e in events)
    assert bool(events)==(c['commands_sha']!=h['commands_sha'])
    keys=('score','full','useful300','final_residual')
    if n['mode']:
        assert n['commands_sha']==c['commands_sha']
        assert all(n[k]==int(c[k])for k in keys)
    common=dict(case=name,events=events,native_chase=bool(n['mode']))
    h_metrics={k:int(h[k])for k in keys}
    rows.append(dict(common,native={k:n[k]for k in keys},tested=h_metrics if n['mode'] else {k:n[k]for k in keys}))
    if not n['mode']:exploratory.append(dict(common,hybrid=h_metrics))
def tally(rows):
    b={k:sum(x['native'][k]for x in rows)for k in ('score','full','useful300','final_residual')}
    h={k:sum(x['tested'][k]for x in rows)for k in b}
    l=sum(x['native']['full']>x['tested']['full']for x in rows)
    return dict(n=len(rows),base=b,hybrid=h,score_delta=h['score']-b['score'],individual_full_to_miss=l,
        metric_gate=500*(h['score']-b['score'])>=b['score'] and h['full']>=b['full'] and h['useful300']>=b['useful300']
        and h['final_residual']<=b['final_residual'] and l==0)
primary=[x for x in rows if x['native_chase']]
s=tally(primary); all_=tally(rows)
nevents=sum(len(x['events'])for x in primary); boards=sum(bool(x['events'])for x in primary)
out=dict(native_chase_subset=s,stock_choice_preserving_all=all_,override_events=nevents,affected_boards=boards,
    gate=nevents>=5 and boards>=4 and s['metric_gate'] and all_['metric_gate'])
(X/'report.json').write_text(json.dumps(dict(summary=out,rows=rows,forced_only_normal_boards=exploratory),indent=2)+'\n')
print(json.dumps(out))
