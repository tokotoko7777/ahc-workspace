# AHC008 five-worker portfolio holdout

These 100 independent official generator seeds are fixed before running the
new portfolio. The policy is exact v7 when M=5, exact v24 otherwise.
The rule is informed by the former practice and independent100 cohort
aggregates; neither provides a new validation result for the rule.

Compare both arms on all 100 untouched cases. Before seeing results, useful
promotion requires a net score gain, no decrease in all-clear or clear at
human floor ≥300, and branch/output verification. Report the M=5 subset
separately; high-worker cases should reproduce v24 actions except explicit
late wall-clock audit if any. No following adjustments fitted to this suite.
