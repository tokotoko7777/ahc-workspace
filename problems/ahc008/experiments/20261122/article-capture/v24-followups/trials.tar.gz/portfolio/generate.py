"""Combine the two pinned, bundled own solvers into a one-file M=5 portfolio."""
import argparse
import hashlib
from pathlib import Path
import re

DEFAULT7 = Path(__file__).resolve().parent.parent / "ahc008_integrated_v7/integrated.cpp"
DEFAULT24 = Path(__file__).resolve().parent.parent / "ahc008_terry_same_geometry/hybrid/source-release/frozen.cpp"
HASH7 = "65ef9c66a898ccd564d3874de5bcc422962ffe444da2511d057bf9a73ada364b"
HASH24 = "7ae8fc4c25a5b69c448682b62c428fb73f83b7a2d826003f07b2ea173be06639"
ORIGINAL_HEADER = """  int n,m,r,c,t;cin>>n; pets.resize(n);
  for(auto &p:pets){cin>>r>>c>>t;p={pos(r-1,c-1),t};}
  cin>>m; humans.resize(m); workers.resize(m);
  for(int& p:humans){cin>>r>>c;p=pos(r-1,c-1);}"""
INJECTED_HEADER = """  pets.resize(prelude.n);
  for(int i=0;i<prelude.n;++i){
   const auto &p=prelude.pets[i];
   pets[i]={pos(p[0]-1,p[1]-1),p[2]};
  }
  humans.resize(prelude.m); workers.resize(prelude.m);
  for(int i=0;i<prelude.m;++i){
   const auto &p=prelude.humans[i];
   humans[i]=pos(p[0]-1,p[1]-1);
  }"""
SUPPORT = """
namespace portfolio {
struct Header {
    int n=0,m=0;
    std::array<std::array<int,3>,20> pets{};
    std::array<std::array<int,2>,10> humans{};
};
bool read(Header& h){
    if(!(std::cin>>h.n) || h.n<10 || h.n>20)return false;
    for(int i=0;i<h.n;++i)for(int& x:h.pets[i])
        if(!(std::cin>>x))return false;
    if(!(std::cin>>h.m) || h.m<5 || h.m>10)return false;
    for(int i=0;i<h.m;++i)for(int& x:h.humans[i])
        if(!(std::cin>>x))return false;
    return true;
}
}
"""
TAIL = """
int main(int argc,char** argv){
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    portfolio::Header prelude;
    if(!portfolio::read(prelude))return 0;
    if(prelude.m==5)return path7::run(argc,argv,prelude);
    return path24::run(argc,argv,prelude);
}
"""
def substitute(s,old,new):
    if s.count(old)!=1: raise ValueError("Pinned conversion anchor missing or repeated: "+old)
    return s.replace(old,new,1)
def source(file,checksum,namespace):
    raw=file.read_bytes()
    observed=hashlib.sha256(raw).hexdigest()
    if observed!=checksum:raise ValueError(f"Source hash mismatch: {file} ({observed})")
    s=raw.decode()
    includes=re.findall(r"^\s*#include\s+(<[^>]+>)[ \t]*$",s,re.M)
    s=re.sub(r"^\s*#include\s+<[^>]+>[ \t]*\n","\n",s,flags=re.M)
    if re.search(r"^\s*#include",s,re.M):raise ValueError("Unexpected remaining include")
    # Each separate frozen file owns its preprocessor definitions, including
    # the standard include guards in its bundled workspace headers.
    macros=sorted(set(re.findall(r"^#define\s+(\w+)",s,re.M)))
    s=substitute(s,"void init(int argc,char** argv) {","void init(int argc,char** argv,const ::portfolio::Header& prelude) {")
    s=substitute(s,ORIGINAL_HEADER,INJECTED_HEADER)
    s=substitute(s,"int main(int argc,char**argv){\n ios::sync_with_stdio(false);cin.tie(nullptr);",
                 "int run(int argc,char**argv,const ::portfolio::Header& prelude){")
    s=substitute(s,"Game g;g.init(1,argv);","Game g;g.init(1,argv,prelude);")
    # A renamed main no longer has main's implicit return 0.
    s=s.rstrip()
    if not s.endswith("\n}"):raise ValueError("Unexpected end")
    s=s[:-1]+" return 0;\n}"
    push="".join(f'#pragma push_macro("{m}")\n' for m in macros)
    pop="".join(f'#pragma pop_macro("{m}")\n' for m in reversed(macros))
    return includes,push+f"namespace {namespace} {{\n"+s+f"\n}} // namespace {namespace}\n"+pop

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--v7",type=Path,default=DEFAULT7)
    p.add_argument("--v24",type=Path,default=DEFAULT24)
    p.add_argument("--output",type=Path,default=Path("submission.cpp"))
    a=p.parse_args()
    ia,b=source(a.v7,HASH7,"path7")
    ic,d=source(a.v24,HASH24,"path24")
    headers="".join("#include "+h+"\n" for h in sorted(set(ia+ic)))
    body=("// AHC008 portfolio: v7 only if M=5, otherwise v24.\n"
          +"// v7 sha256 "+HASH7+"\n// v24 sha256 "+HASH24+"\n"
          +'#pragma GCC optimize("O3")\n'
          +headers+SUPPORT+b+d+TAIL)
    a.output.write_text(body)
    print(hashlib.sha256(a.output.read_bytes()).hexdigest(),a.output)
if __name__=="__main__":
    main()
