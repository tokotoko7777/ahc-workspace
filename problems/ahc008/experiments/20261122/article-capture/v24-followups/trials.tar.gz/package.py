"""Create compact generated-source/replay archives from already measured AHC008 A/Bs."""
from pathlib import Path
import csv,io,gzip,shutil,json,hashlib,difflib
d=Path('ahc008_v24_followups')
base=Path('ahc008_terry_same_geometry/hybrid/source-release/frozen.cpp').read_text().splitlines(keepends=True)
fields='case model input_sha256 actions_sha256 prefix100 score wall_sec all_clear final_reachable final_exact4 mean_human_floor captures terry stages halfclose solo rail residual_turn100 residual_turn160 residual_turn225 residual_turn275'.split()
for name,src,groups in [
 ('edge','ahc008_v24_edge_solo',['dev30']),
 ('late-rail','ahc008_v24_late_rail',['dev30']),
 ('momentum','ahc008_v24_momentum',['dev30']),
 ('opening','ahc008_v24_opening_match',['practice100','independent100']),
 ('portfolio','ahc008_v24_five_portfolio',['paired100']),
 ('five-floor','ahc008_v24_five_floor',['dev30']),
 ('half-close','ahc008_v24_half_close',['dev30']),
 ('m5-retention','ahc008_v24_five_retention',['dev30']),
 ('m5-extend','ahc008_v24_five_extend',['dev30']),
]:
 p=Path(src); o=d/name;o.mkdir(exist_ok=True)
 for g in groups:
  data=p/f'{g}.csv'
  if not data.exists():continue
  r=list(csv.DictReader(data.open()))
  assert len(r) in [60,200],(name,g,len(r))
  f=io.StringIO();w=csv.DictWriter(f,fields,extrasaction='ignore',lineterminator='\n')
  w.writeheader();w.writerows(r);(o/f'{g}.csv.gz').write_bytes(gzip.compress(f.getvalue().encode(),mtime=0))
 if name=='portfolio':
  shutil.copyfile(p/'generate.py',o/'generate.py')
  for f in ['seeds.txt','input-hashes.txt','PREDECLARED.md']:shutil.copyfile(p/'independent-seed3'/f,o/f)
  shutil.copyfile(p/'branch-verification.json',o/'branch-verification.json')
 else:
  s=p/'solve.cpp'
  (o/'from-v24.patch').write_text(''.join(difflib.unified_diff(base,s.read_text().splitlines(keepends=True),fromfile='solve-v24.cpp',tofile=f'{name}.cpp')))
  (o/'source.sha256').write_text(hashlib.sha256(s.read_bytes()).hexdigest()+'\n')
if Path('ahc008_v24_five_retention/m5-dev30/manifest.json').exists():
 shutil.copyfile('ahc008_v24_five_retention/m5-dev30/manifest.json',d/'M5-development-inputs.json')
