#pragma once
namespace compact_chase {
struct Arc{int a,b,c;};
class Dinic {
    struct Edge{int to,rev,cap;};
    std::vector<int> row,next,level,queue;
    std::vector<Edge> edges;
    int dfs(int u,int t,int cap){
        if(u==t)return cap;
        for(int& j=next[u];j<row[u+1];++j){
            auto& e=edges[j];
            if(!e.cap || level[e.to]!=level[u]+1)continue;
            int got=dfs(e.to,t,std::min(cap,e.cap));
            if(got){e.cap-=got;edges[e.rev].cap+=got;return got;}
        }
        return 0;
    }
public:
    Dinic(int n,const std::vector<Arc>& arcs):row(n+1),next(n),level(n),queue(n),edges(2*arcs.size()){
        for(auto [a,b,c]:arcs){++row[a+1];++row[b+1];}
        for(int u=0;u<n;++u)row[u+1]+=row[u];
        std::copy_n(row.begin(),n,next.begin());
        for(auto [a,b,c]:arcs){
            int j=next[a]++,k=next[b]++;
            edges[j]={b,k,c}; edges[k]={a,j,0};
        }
    }
    int flow(int s,int t){
        int value=0;
        for(;;){
            std::fill(level.begin(),level.end(),-1);
            level[s]=0;queue[0]=s;
            for(int i=0,n=1;i<n;++i){
                int u=queue[i],d=level[u]+1;
                for(int j=row[u];j<row[u+1];++j){
                    auto e=edges[j];
                    if(e.cap&&level[e.to]<0){level[e.to]=d;queue[n++]=e.to;}
                }
            }
            if(level[t]<0)return value;
            std::copy_n(row.begin(),level.size(),next.begin());
            for(int x;(x=dfs(s,t,INT_MAX));)value+=x;
        }
    }
    bool side(int v)const{return level[v]>=0;}
};
struct Tag {};
}
namespace terry_partition {
template<bool Raw=false>
inline Shape compactShape(const Board& walls,const Board& roads,std::span<const int> crew,
                          std::span<const int> targets,int turn,std::vector<char>* raw=nullptr){
    Shape ans;
    ans.targetCount=targets.size();
    ans.meetingRadius=deadlineRadius(turn);
    if(targets.empty()){if constexpr(Raw)raw->clear();return ans;}
    constexpr int inf=100000000;
    std::array<int,size> v;v.fill(-1);
    int n=0;
    for(int p=0;p<size;++p)if(!walls[p]){v[p]=n;n+=2;}
    int dep=n,src=dep+targets.size(),snk=src+1;
    std::vector<compact_chase::Arc> arcs;
    arcs.reserve(5*(n/2)+roads.count()+crew.size()+14*targets.size());
    Board occupied,reachable,direct;
    for(int h:crew){
        occupied.set(h);
        auto d=distances(walls,h);
        for(int p=0;p<size;++p)if(d[p]>=0&&d[p]<=ans.meetingRadius)reachable.set(p);
    }
    auto add=[&](int a,int b,int c){arcs.push_back({a,b,c});};
    for(int p=0;p<size;++p)if(v[p]>=0)add(v[p],v[p]+1,reachable[p]&&!occupied[p]?5:inf);
    auto source=[&](int p){
        for(int a:targets)if(mDist(a,p)<=1)return;
        ++ans.sourceMass;
        if(v[p]>=0)add(src,v[p],1);
        else if constexpr(Raw)direct.set(p);
    };
    for(int p=0;p<size;++p)if(roads[p])source(p);
    for(int h:crew)source(h);
    int prize=(ans.sourceMass+int(targets.size())-1)/int(targets.size());
    for(int j=0;j<int(targets.size());++j){
        auto d=distances(walls,targets[j]);
        for(int p=0;p<size;++p)if(v[p]>=0&&d[p]>=0&&d[p]<=2)add(v[p]+1,dep+j,inf);
        add(dep+j,snk,prize);
    }
    for(int p=0;p<size;++p)if(v[p]>=0)
        for(int z:neighbors(p))if(z>=0&&v[z]>=0)add(v[p]+1,v[z],inf);
    compact_chase::Dinic f(snk+1,arcs);
    ans.flowValue=f.flow(src,snk);
    for(int p=0;p<size;++p){
        if(v[p]<0){ans.evasion.set(p);continue;}
        bool in=f.side(v[p]),out=f.side(v[p]+1);
        if(in!=out)ans.walls.push_back(p);
        if(!in||in!=out)ans.evasion.set(p);
    }
    if constexpr(Raw){
        int oldDep=2*padded;
        raw->assign(oldDep+targets.size()+2,0);
        auto oldNode=[](int p){return 2*((p/side+1)*P+p%side+1);};
        for(int p=0;p<size;++p){
            int old=oldNode(p);
            if(v[p]>=0){
                (*raw)[old]=f.side(v[p]);(*raw)[old+1]=f.side(v[p]+1);
                if(f.side(v[p]+1)){
                    int r=p/side,c=p%side;
                    if(!r)(*raw)[old-2*P]=1;
                    if(r==side-1)(*raw)[old+2*P]=1;
                    if(!c)(*raw)[old-2]=1;
                    if(c==side-1)(*raw)[old+2]=1;
                }
            }else{
                bool seen=direct[p];
                for(int z:neighbors(p))if(z>=0&&v[z]>=0&&f.side(v[z]+1))seen=true;
                (*raw)[old]=seen;
            }
        }
        for(int j=0;j<=snk-dep;++j)(*raw)[oldDep+j]=f.side(dep+j);
    }
    return ans;
}
}
