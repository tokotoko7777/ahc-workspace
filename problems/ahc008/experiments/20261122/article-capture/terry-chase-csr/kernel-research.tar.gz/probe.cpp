#include <bits/stdc++.h>
#define main stock_unused_main
#include "stock.instrumented.inc"
#undef main
namespace p=terry_partition;
using p::Board;
using S=terry_exact_root::State;
using Cost=terry_exact_ties::MinCostFlow<int,int>;
using Old=MaxFlow<int>;
struct OldRaw:Old{
    using Old::Old;
    static inline std::vector<char> side;
    std::vector<char> min_cut(int s)const{return side=Old::min_cut(s);}
};
struct F{int id,turn,map;Board roads,legal;S state;std::vector<int> pets,tar;};
bool same(const p::Shape& x,const p::Shape& y){
    return std::tie(x.walls,x.evasion,x.targetCount,x.sourceMass,x.flowValue,x.meetingRadius)==
           std::tie(y.walls,y.evasion,y.targetCount,y.sourceMass,y.flowValue,y.meetingRadius);
}
void finish(F& f){
    assert(!f.state.people.empty());
    for(int v:f.pets)f.state.pets.push_back({v,1,-1});
    for(int v:f.pets)assert(!f.state.walls[v]);
    for(int v:f.state.people)assert(!f.state.walls[v]);
    f.legal=terry_exact_root::can_place(f.state);
    f.tar=p::majorityPets(f.state.walls,f.state.people,f.pets);
}
std::vector<int> read(std::istream& in){
    int n;in>>n;assert(in&&n>=0&&n<=900);
    std::vector<int> a(n);
    for(int& v:a){in>>v;assert(in&&v>=0&&v<900);}
    return a;
}
void write(std::ofstream& o,const std::vector<int>& a){o<<' '<<a.size();for(int x:a)o<<' '<<x;}
std::vector<int> cells(Board b){std::vector<int>a;for(int i=0;i<900;++i)if(b[i])a.push_back(i);return a;}
Board board(const std::vector<int>& a){Board b;for(int x:a)b.set(x);return b;}
auto load(const char* path,bool synth){
    std::vector<F>a;std::ifstream in(path); assert(in);
    F f;
    while(in>>f.id>>f.turn>>f.map){
        f.state={};f.state.people=read(in);f.pets=read(in);f.state.walls=board(read(in));
        f.roads=synth?board(read(in)):terry_exact_maps::terrain(f.map).aisleCells;
        finish(f); a.push_back(f);
    }
    assert(in.eof()&&a.size()==(synth?300:175));
    return a;
}
void freezeSynthetic(){
    std::mt19937 gen(0xc9227431u);
    auto r=[&](unsigned n){return gen()%n;};
    std::ofstream o("synthetic.txt");assert(o);
    for(int id=0;id<300;++id){
        int style=id%10,turn=255+id%45,m=5+id%6,n=1+id%10;
        Board b,road;
        for(int v=0;v<900;++v){
            int x=v/30,y=v%30;
            unsigned coin=r(100);
            bool w=style==0?false:style==1?coin<3:style==2?coin<14:style==3?coin<38:
                   style==4?coin<59:style==5?(x%4==0&&(y!=1&&y!=28)):
                   style==6?(y%5==0&&x%9!=0):style==7?(x%2&&y%2):
                   style==8?(x>=3&&x<=26&&y>=3&&y<=26):coin<24;
            b.set(v,w);
            road.set(v,style==0?false:style==9?true:style==6?y%5==0:r(100)<unsigned(10+6*style));
        }
        auto floor=cells(~b);
        std::vector<int> crew,pets;
        for(int j=0;j<m;++j)crew.push_back(j&&id%3==0?crew[0]:floor[r(floor.size())]);
        for(int j=0;j<n;++j)pets.push_back(id%4==0?crew[0]:floor[r(floor.size())]);
        o<<id<<' '<<turn<<" -1";write(o,crew);write(o,pets);write(o,cells(b));write(o,cells(road));o<<'\n';
    }
}
void small(){
    std::mt19937 rng(0xedcc981u);
    for(int i=0;i<16000;++i){
        int n=2+rng()%8,k=rng()%(2*n*n),s=0,t=n-1;
        std::vector<compact_chase::Arc> arcs;
        for(int j=0;j<k;++j)arcs.push_back({int(rng()%n),int(rng()%n),int(rng()%9)});
        int best=INT_MAX,both=(1<<n)-1;
        for(int mask=1;mask<(1<<t);mask+=2){
            int value=0;
            for(auto [a,b,c]:arcs)if((mask>>a&1)&&!(mask>>b&1))value+=c;
            if(value<best){best=value;both=mask;}else if(value==best)both&=mask;
        }
        compact_chase::Dinic graph(n,arcs);
        assert(graph.flow(s,t)==best);
        for(int j=0;j<n;++j)assert(graph.side(j)==bool(both>>j&1));
    }
}
template<bool New> auto shape(const F& f){
    const auto& s=f.state;
    if constexpr(New)return p::compactShape(s.walls,f.roads,s.people,f.tar,f.turn);
    else return p::shape<Old>(s.walls,f.roads,s.people,f.tar,f.turn);
}
template<bool New> auto act(const F& f,p::ChaseReport* d=nullptr){
    const auto& s=f.state;
    return p::executeChase<std::conditional_t<New,compact_chase::Tag,Old>,Cost>(
        s.walls,f.roads,s.people,f.pets,f.turn,f.legal,d);
}
auto clean(const F& f,const std::string& a){
    return terry_exact_root::sanitize(f.state,std::vector<char>(a.begin(),a.end()));
}
void verify(const std::vector<F>& fs,const char* label){
    int active=0,flow=0,planned=0,moved=0,duplicates=0,roadwalls=0;
    for(const F& f:fs){
        OldRaw::side.clear();
        const auto& s=f.state;
        const auto x=p::shape<OldRaw>(s.walls,f.roads,s.people,f.tar,f.turn);
        std::vector<char> side;
        const auto y=p::compactShape<true>(s.walls,f.roads,s.people,f.tar,f.turn,&side);
        if(side!=OldRaw::side||!same(x,y)){
            std::cerr<<"shape parity "<<label<<' '<<f.id<<' '<<f.turn<<'\n';
            std::abort();
        }
        p::ChaseReport a,b;
        auto sa=act<false>(f,&a),sb=act<true>(f,&b);
        assert(sa==sb&&clean(f,sa)==clean(f,sb)&&same(a.cut,b.cut)&&a.matching==b.matching&&
               a.oldScore==b.oldScore&&a.newScore==b.newScore);
        active+=!f.tar.empty();flow+=(x.flowValue>0);planned+=!x.walls.empty();
        moved+=sa.find_first_not_of('.')!=std::string::npos;
        duplicates+=std::set<int>(s.people.begin(),s.people.end()).size()!=s.people.size();
        roadwalls+=(s.walls&f.roads).any();
    }
    std::cout<<"parity "<<label<<" n="<<fs.size()<<" active="<<active<<" pos_flow="<<flow
             <<" nonempty_cut="<<planned<<" active_action="<<moved<<" overlap_crew="<<duplicates
             <<" overlap_road_wall="<<roadwalls<<std::endl;
}
uint64_t digest(const p::Shape& x){
    return x.flowValue+7*x.sourceMass+19*x.evasion.count()+x.walls.size();
}
uint64_t digest(const std::string& x){
    uint64_t z=0;for(unsigned char c:x)z=z*131+c;return z;
}
double cpu(){
    timespec n{}; assert(clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&n)==0);
    return n.tv_sec+n.tv_nsec*1e-9;
}
template<bool New,bool Act> auto batch(const std::vector<F>& fs){
    uint64_t z=0;const auto t=cpu();
    for(const auto& f:fs){
        if constexpr(Act)z=z*31+digest(clean(f,act<New>(f)));
        else z=z*31+digest(shape<New>(f));
    }
    return std::pair{cpu()-t,z};
}
template<bool Act> double timePanel(const std::vector<F>& fs,const char* label){
    double so=0,sn=0;
    for(int k=0;k<8;++k){
        std::pair<double,uint64_t>a,b;
        if(k%2){b=batch<true,Act>(fs);a=batch<false,Act>(fs);}
        else{a=batch<false,Act>(fs);b=batch<true,Act>(fs);}
        assert(a.second==b.second);so+=a.first;sn+=b.first;
        std::cout<<std::fixed<<std::setprecision(8)<<"pair "<<label<<' '<<(Act?"action":"shape")
                 <<' '<<k<<' '<<a.first<<' '<<b.first<<' '<<a.second<<'\n';
    }
    double ratio=sn/so;
    std::cout<<"total "<<label<<' '<<(Act?"action":"shape")<<' '<<so<<' '<<sn<<' '<<ratio<<std::endl;
    return ratio;
}
int main(int argc,char** argv){
    if(argc==2&&std::string_view(argv[1])=="--freeze"){freezeSynthetic();return 0;}
    assert(argc==1);
    small();std::cout<<"brute_canonical=16000 ok"<<std::endl;
    auto real=load("real.txt",false),synth=load("synthetic.txt",true);
    verify(real,"real");verify(synth,"synthetic");
    timePanel<false>(real,"real");timePanel<false>(synth,"synthetic");
    double r=timePanel<true>(real,"real"),s=timePanel<true>(synth,"synthetic");
    std::cout<<"gate "<<(r<=.9&&s<=.9?"PASS":"REJECT")<<std::endl;
}
