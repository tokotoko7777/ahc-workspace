from pathlib import Path
import hashlib,json,sys
D=Path(__file__).resolve().parent
W=D.parent
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
stock=W/'ahc008_terry_split_bound/solve.private.cpp'
assert sh(stock)=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
R=W/'ahc008_terry_chase_cut_ties'
H=W/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark import replay
from guarded_entry_trace import observed
assert sh(R/'manifest.json')=='4f92bb7fa8a6ef0b3ce68f028084974d11d34463bf9a21db985d36b4d544b17b'
r=json.loads((R/'report.json').read_text())
def vec(seq):
    a=[30*x+y for x,y in seq]
    return ' '.join(map(str,[len(a),*a]))
old=[list(map(int,line.split())) for line in (R/'snapshots.txt').read_text().splitlines()]
maps={a[0]:a[2] for a in old}
rebuilt=[]
for k in r['tapes']:
    if not k['chase']:continue
    i=k['board']
    a=R/'tapes'/f'{i:04d}.actions'
    t=a.with_suffix('.trace')
    f=R/'in'/f'{i:04d}.txt'
    for p,name in [(a,'commands_sha'),(t,'trace_sha'),(f,'input_sha')]:
        assert sh(p)==k[name]
    commands=a.read_text().splitlines()
    assert replay(f.read_text(),t.read_text().splitlines(),commands,detailed=True)[0]==k['score']
    _,history,_=observed(f.read_bytes(),t.read_text().splitlines())
    for turn in range(275,300):
        pets,humans,walls=history[turn]
        rebuilt.append(f'{i} {turn} {maps[i]} {vec(humans)} {vec(pets)} {vec(sorted(walls))}')
assert [list(map(int,l.split())) for l in rebuilt]==old and len(old)==175 and len(maps)==7
(D/'real.txt').write_text('\n'.join(rebuilt)+'\n')
s=stock.read_text()
needle='template<class MaxNetwork,class CostNetwork>'
assert s.count(needle)==1
# Close the stock namespace around isolated candidate code. Only dispatch for the candidate tag.
s=s.replace(needle,'}\n#include "csr.hpp"\nnamespace terry_partition {\n'+needle)
needle='auto cut=shape<MaxNetwork>(walls,configuredRoads,people,targets,turn);'
assert s.count(needle)==1
s=s.replace(needle,'''auto cut=[&] {
        if constexpr(std::is_same_v<MaxNetwork,compact_chase::Tag>)
            return compactShape(walls,configuredRoads,people,targets,turn);
        else return shape<MaxNetwork>(walls,configuredRoads,people,targets,turn);
    }();''')
(D/'stock.instrumented.inc').write_text(s)
print(f'real={sh(D/"real.txt")} provenance={sh(R/"report.json")} snapshots={len(old)}')
