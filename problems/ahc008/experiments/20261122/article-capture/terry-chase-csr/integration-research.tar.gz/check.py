"""Report all measured metrics; marker only upon both-panel admission."""
import csv,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent
mode=sys.argv[1]
assert mode in ('fixed','native')
def read(p):
    rows=list(csv.DictReader(p.open()))
    assert len(rows)==200 and len({(x['arm'],x['case']) for x in rows})==200
    return rows
panels={}
for panel in ('practice','fresh'):
    if not (D/f'{panel}.{mode}.csv').is_file():break
    rows=read(D/f'{panel}.{mode}.csv')
    if mode=='fixed':
        base,fast=([r for r in rows if r['arm']==k] for k in ('baseline','fast'))
        assert [x['case'] for x in base]==[x['case'] for x in fast]
        assert all(all(a[k]==b[k] for k in ('draws','score','action_hash')) for a,b in zip(base,fast))
        def metric(sel):
            a,b=([r for r in X if sel(r)] for X in (base,fast))
            assert len(a)==len(b)>0
            A,B=(sum(int(r['cpu_us']) for r in x) for x in (a,b))
            return dict(n=len(a),base_us=A,candidate_us=B,saving=1-B/A)
        total=metric(lambda r:True);heavy=metric(lambda r:int(r['draws'])>0)
        max_wall=[max(float(x['wall']) for x in k) for k in (base,fast)]
        panels[panel]=dict(total=total,virtual_heavy=heavy,no_rollouts=metric(lambda r:int(r['draws'])==0),
                           max_wall=max_wall,passes=(total['saving']>=.02 and heavy['saving']>=.10 and max(max_wall)<2.95))
    else:
        base,fast=([r for r in rows if r['arm']==k] for k in ('v25','terry_independent'))
        values={k:[sum(int(d[k]) for d in s) for s in (base,fast)] for k in ('score','full','useful300')}
        max_wall=[max(float(x['wall']) for x in k) for k in (base,fast)]
        assert [x['input_sha'] for x in base]==[x['input_sha'] for x in fast]
        diffs=[]
        for a,b in zip(base,fast):
            assert a['case']==b['case']
            ta,tb=a['telemetry'].split(),b['telemetry'].split()
            assert len(ta)==len(tb)==15 and ta[-1]==a['score'] and tb[-1]==b['score'] and ta[0]==tb[0]
            diffs.append(dict(case=a['case'],pairs=[int(ta[10]),int(tb[10])],modes=[int(ta[13]),int(tb[13])],
                              scores=[int(a['score']),int(b['score'])],changed=a['commands_sha']!=b['commands_sha']))
        passed=max(max_wall)<2.95 and all(b>=a for a,b in values.values())
        if panel=='practice':passed&=values['score'][1]>=6152805559
        panels[panel]=dict(**values,max_wall=max_wall,passes=passed,
                           pairs=[sum(y['pairs'][j] for y in diffs) for j in range(2)],
                           mode_flips=[y for y in diffs if y['modes'][0]!=y['modes'][1]],
                           score_losses=[y for y in diffs if y['scores'][1]<y['scores'][0]],
                           changed=[y for y in diffs if y['changed']])
passed=len(panels)==2 and all(x['passes'] for x in panels.values())
print(json.dumps(dict(panels=panels,passed=passed),indent=2))
if passed:(D/f'{mode}.PASS').touch()
raise SystemExit(not passed)
