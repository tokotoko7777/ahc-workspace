# Accepted f83fd834 literal Chase CSR: fixed then native gate

Only replaces the shape backend inside the sole literal Chase instantiation.
Clock starts/deadline, move selection/matching/sanitization, pair caps, RNG,
I/O, all atlas and non-Chase policy are unchanged. CSR implementation
identical to detached PASS. Candidate source
`9ba280d498e2fde5e33004d3d5102a930576a385b372ae35d5d829194a683509`.
No binaries or private raw source/model are intended for publication.

Fixed: accepted distributed100 and preexisting independent default-fresh100,
per-case cap from the f83fd834 default accepted ledger, paired serial and
alternating arm order; leave the stock native safety deadline as-is, never get
credit if it interrupts capped work. Both arms must reproduce the accepted
full action SHA and official score on all 200 cases. Require process CPU
sum down at least 2% for each complete panel and 10% for each predeclared
virtual-heavy (positive paired-cap) stratum, with local tester wall below
2.95 seconds. Fixed counts: distributed 14 positive/673 pairs; fresh 17
positive/944 pairs. No native phase if fails or is interrupted.

Native, only after a recorded fixed PASS (and coordinator clearance):
same distributed and fresh panels paired serial alternating, no extra
parameters and stock native 2670ms. Require official tester, playback and
independent replay exact for each run; on each cohort both full and
useful-300 counts and total score nonlower than contemporaneous stock.
Worst tester wall across either arm <2.95 s. Additionally candidate
distributed score must be >=6,152,805,559 (accepted historical floor).
Capture and report every changed output/mode flip/score loss per case.
Time-based mode flips are not themselves acceptance, nor disqualifying
in isolation; no clock/cap/seed tuning or repeat based on results.
If this native gate fails, keep accepted native f83 and preserve only the
verified fixed-work speed result.

Commands from workspace (bash; separate phases):
`bash ahc008_terry_chase_csr_integrate/run.sh compile`,
then separately `.../run.sh fixed`, then `.../run.sh native` if admitted.
Inputs in fixed are authenticated against immutable accepted-ledger hashes;
native runs only after fixed PASS with same explicit physical directories.
Two original exact-bench arms are named v25 and terry_independent in legacy
output, meaning f83 baseline and CSR candidate respectively.
