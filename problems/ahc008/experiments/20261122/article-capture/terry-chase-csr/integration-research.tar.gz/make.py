"""Local only. Insert frozen CSR at sole Chase routing call, no other changes."""
from hashlib import sha256
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
S=R/'ahc008_terry_split_bound'
M=R/'ahc008_terry_chase_csr'
def sh(b):return sha256(b).hexdigest()
s=(S/'solve.private.cpp').read_bytes()
assert sh(s)=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
hashes={name:h for h,name in map(str.split,(M/'SOURCE.sha256').read_text().splitlines())}
h=(M/'csr.hpp').read_bytes()
assert sh(h)==hashes['csr.hpp']
s=s.decode()
def replace(old,new):
    global s
    assert s.count(old)==1
    s=s.replace(old,new)
replace('#pragma GCC optimize("O3")','#pragma GCC optimize("O3")\n#include <climits>\n#include <type_traits>')
name='template<class MaxNetwork,class CostNetwork>'
replace(name,'}\n'+h.decode().removeprefix('#pragma once\n')+'\nnamespace terry_partition {\n'+name)
name='auto cut=shape<MaxNetwork>(walls,configuredRoads,people,targets,turn);'
replace(name,'''auto cut=[&] {
        if constexpr(std::is_same_v<MaxNetwork,compact_chase::Tag>)
            return compactShape(walls,configuredRoads,people,targets,turn);
        else return shape<MaxNetwork>(walls,configuredRoads,people,targets,turn);
    }();''')
replace('executeChase<MaxFlow<int>,terry_exact_ties::MinCostFlow<int,int>>',
        'executeChase<compact_chase::Tag,terry_exact_ties::MinCostFlow<int,int>>')
(D/'solve.private.cpp').write_text(s)
# Existing exact official playback/independent replay bench, alternating paired order.
b=(R/'ahc008_terry_exact_root/bench.py').read_text()
b=b.replace('for f in paths:','for i,f in enumerate(paths):')
x=" for arm,cmd,extra in [('v25',a.baseline,a.baseline_arg),('terry_independent',a.candidate,a.candidate_arg)]:"
assert b.count(x)==1
b=b.replace(x," pair=[('v25',a.baseline,a.baseline_arg),('terry_independent',a.candidate,a.candidate_arg)]\n for arm,cmd,extra in (pair if i%2==0 else pair[::-1]):")
(D/'bench_native.py').write_text(b)
