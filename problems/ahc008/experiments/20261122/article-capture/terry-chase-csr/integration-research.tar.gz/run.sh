#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=ahc008_terry_chase_csr_integrate
R=ahc008_terry_split_bound
F=ahc008_terry_first_chase_reuse/default-fresh100
P=ahc008_focus_solver/problems/ahc008
T=ahc008_focus_assets/tools/target/release/tester
A=ahc008_focus_assets/tools/in
export PYTHONPATH="$PWD/ahc008_integrated_v11:$PWD/$P/experiments/20261122:$PWD/$P:$PWD/ahc008_bridge_audit"
sha256sum -c "$D/FROZEN.sha256"
case "${1:-}" in
compile)
  test ! -e "$D/baseline" && test ! -e "$D/candidate"
  g++ -std=gnu++23 "$R/solve.private.cpp" -o "$D/baseline"
  g++ -std=gnu++23 "$D/solve.private.cpp" -o "$D/candidate"
  sha256sum "$D/baseline" "$D/candidate" > "$D/BIN.sha256"
  ;;
fixed)
  sha256sum -c "$D/BIN.sha256"
  test ! -e "$D/practice.fixed.csv" && test ! -e "$D/fresh.fixed.csv"
  for panel in practice fresh; do
    I=$A; if [[ $panel = fresh ]]; then I=$F/in; fi
    python ahc008_terry_speed/bench.py "$T" "$I" "$R/$panel.default.csv" \
      "$D/baseline" "$D/candidate" "$D/$panel.fixed.csv" > "$D/$panel.fixed.log" 2>&1
  done
  python "$D/check.py" fixed | tee "$D/fixed.json"
  ;;
native)
  sha256sum -c "$D/BIN.sha256"
  test -e "$D/fixed.PASS"
  test ! -e "$D/practice.native.csv" && test ! -e "$D/fresh.native.csv"
  for panel in practice fresh; do
    I=$A; if [[ $panel = fresh ]]; then I=$F/in; fi
    python "$D/bench_native.py" "$P" "$T" "$D/baseline" "$D/candidate" \
      "$I" "$D/$panel.native.csv" --n 100 > "$D/$panel.native.log" 2>&1
  done
  python "$D/check.py" native | tee "$D/native.json"
  ;;
*) exit 2;;
esac
