"""Exact geometric cap swap fixture; no solver/tester, no outcomes."""
import re,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
sys.path.insert(0,str(R/'ahc008_focus_solver/problems/ahc008/experiments/20261122'))
from stochastic_lock_audit import ALL,B,ADJ,wave,flood,cells

def mask(xs):return sum({B[p] for p in xs})
def md(a,b):return abs(a//30-b//30)+abs(a%30-b%30)
def maps():
    string=(R/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
    out=[]
    for i,g in enumerate(re.split(r'// map \d\s*\n',string)[:-1]):
        cols=list(map(int,re.search(r'\{\s*\{([0-9,]+)\},',g)[1].split(',')))
        rows=re.findall(r'\{((?:0x[0-9a-f]+u,){4}0x[0-9a-f]+u)\}',g)
        assert len(rows)==5
        vals=[[int(z[:-1],16) for z in r.split(',')] for r in rows]
        planned=doors=0
        for r in range(30):
            pat=0 if r==0 else 1 if r%2==0 else 3 if r%4==3 else 4 if i==4 and r%8==5 else 2
            x,a,b,c,d=vals[pat]; planned|=x<<(r*30);doors|=(a|b|c|d)<<(r*30)
        aisles=mask(r*30+c for r in range(30) for c in cols)
        out.append((planned,doors,aisles))
    assert [a.bit_count() for a,_,_ in out]==[335,290,260,233,284]
    return out
def rooms():
    out=[{} for _ in range(5)]
    for l in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        m,id,a,b,*p=map(int,l.split())
        out[m][id]=dict(body=mask(p),left=a,right=b,gates=tuple(g for g in (a,b) if g>=0),
                         stances=tuple(q for q in ((a-1 if a>=0 else -1),(b+1 if b>=0 else -1)) if q>=0))
    return out

def split(op):
    while op:
        low=op&-op
        p=flood(low,op);op^=p
        yield p

def reachable_checks(w0,w1,gates,anchors):
    if anchors&w1:return False
    for m in (0,*[B[g] for g in cells(gates)]):
        for p in split(ALL^(w0|m)):
            selected=anchors&p
            if selected.bit_count()>1:
                if selected&~flood(selected&-selected,ALL^(w1|m)):return False
    return True

def snake_candidate(w, gates, aisles, cap):
    # Exact normal work route coverage is not certified here. A sufficient
    # easy-service indication is a vertical stock sweep stance adjacent to
    # cap; that stance is explicitly in the snake because cap is planned.
    for r in (cap//30-1,cap//30+1):
        if not 0<=r<30 or r%4!=1 or (w|gates|aisles)&B[r*30+29]:continue
        stance=30*r+cap%30
        if not (w|gates)&B[stance]:
            return stance
    return None

def verify(w0,w,gates,aisles,rms,mods):
    opened=ALL^(w|gates)
    ext=flood(aisles,opened)
    if ext&aisles!=aisles:return False
    found=0
    for id,r in rms.items():
        body=r['body']
        if id in mods:
            keep,rem,cap=mods[id];body=keep
            if ((r['body']&~keep&~B[cap])|B[rem])&~ext:return False
        if body&~opened:return False
        if flood(body&-body,opened)!=body:return False
        found|=body
    # Ensure no new unscored phantom: a remaining fragment must be exactly
    # some pre-existing unnamed physical component, not a new orphan.
    originalParts=set(split(ALL^(w0|gates)))
    if any(p not in originalParts for p in split(opened&~ext&~found)):return False
    return True

def check(mapid,w,gates,aisles,rms):
    cnt={k:0 for k in ('rooms','pairs','shrink','parity','scope','anchors')}
    choices=[]
    anchors=aisles|mask(p for r in rms.values() for p in r['stances'])
    for id,r in rms.items():
        b=r['body']
        if len(r['gates'])!=1 or b.bit_count()<5:continue
        cnt['rooms']+=1
        g=r['gates'][0]
        inward=next((p for p in ADJ[g] if B[p]&b),None)
        # Nominal gate is directed horizontally in the original map.
        inward=g+(1 if r['left']>=0 else -1)
        if inward not in ADJ[g] or not b&B[inward]:continue
        for rem in cells(w&wave(b)):
            for cap in cells(b&~B[inward]):
                cnt['pairs']+=1
                changed=(w^B[rem])|B[cap]
                body=flood(B[inward],ALL^(changed|gates))
                if body&~b or b.bit_count()-body.bit_count()<2:continue
                cnt['shrink']+=1
                cols={(p//30+p%30)&1 for p in cells(body) if md(g,p)>=2}
                if len(cols)!=2:continue
                cnt['parity']+=1
                if not verify(w,changed,gates,aisles,rms,{id:(body,rem,cap)}):continue
                cnt['scope']+=1
                if not reachable_checks(w,changed,gates,anchors):continue
                cnt['anchors']+=1
                gain=b.bit_count()-body.bit_count()
                at=snake_candidate(changed,gates,aisles,cap)
                choices.append(((-gain,id,rem,cap),body,at))
    selected=[]; blocked=0; final=w; mods={}
    for key,body,at in sorted(choices):
        ng,id,remove,cap=key
        impact=rms[id]['body']|B[remove]|mask(rms[id]['stances'])|mask(rms[id]['gates'])
        if impact&blocked:continue
        proposed=(final^B[remove])|B[cap]; new={**mods,id:(body,remove,cap)}
        if not verify(w,proposed,gates,aisles,rms,new) or not reachable_checks(w,proposed,gates,anchors):continue
        selected.append(dict(gain=-ng,id=id,removed=remove,cap=cap,body=list(cells(body)),snake_explicit_build_stance=at))
        blocked|=impact;final=proposed;mods=new
    return dict(map=mapid,stages=cnt,best_count=len(choices),selected=selected,
                summed_floor_cap=sum(q['gain'] for q in selected))

def main():
    catalog=rooms()
    print(json.dumps([check(i,*args,catalog[i]) for i,args in enumerate(maps())],indent=2))
if __name__=='__main__':main()
