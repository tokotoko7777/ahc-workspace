# One inward cap / one planned X removal
Using only original terrain and room catalog, consider each named one-mouth
physical body of at least 5 cells, exactly one adjacent planned X removed
and one old body cell capped. Keep every original gate and exterior actor
stance. With all predeclared gates virtually closed, its new body must be a
strict subset losing at least two cells and have one build-safe pet position
per checkerboard parity. Other named rooms are unchanged and abandoned open
tail and released planned X must connect to original exterior; no phantom
components. For full-open and every same individual stock gate action, old
aisle/actor connectivity cannot decrease. Inspect stock snake cap service
without treating feasible static service as real actions. No live runs.

Stable deterministic maximum-local-gain disjoint rule: descending removed-body
area, then own room ID, removed tile, cap tile. Take a candidate only if its
entire local affected mask is disjoint from earlier entries and the union
passes the identical checks. No outcome-guided choice. Consider factual
held100 use only if there are structural survivors with enough floor
capacity; predeclared ≥4 achievable floor cells per held case on average.
