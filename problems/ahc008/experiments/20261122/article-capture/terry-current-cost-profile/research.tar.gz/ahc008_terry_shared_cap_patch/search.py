"""Deterministic static patch triage only."""
from itertools import combinations
from pathlib import Path
import json,sys
D=Path(__file__).resolve().parent
sys.path.insert(0,str(D.parent/'ahc008_terry_inward_cap_swap'))
from static import maps,rooms,mask,md,split,reachable_checks,ALL,B,ADJ,wave,flood,cells

def assess(t,rms, old, selected):
    w0,gates,aisles=t; allgate=w0|gates
    w=old[0]; plans=old[1]
    masks=(ALL^(w|gates),ALL^allgate)
    ext=flood(aisles,masks[0])
    now=0
    for id,r in rms.items():
        if id in plans:
            body=plans[id]
        else:body=r['body']
        at=body&-body
        if not at&masks[0] or flood(at,masks[0])!=body:return False
        now|=body
    for rem,cap,i,j in selected:
        former=(rms[i]['body']|rms[j]['body']|rem)&~(plans[i]|plans[j]|cap)
        if former&~ext:return False
    oldparts=set(split(masks[1]))
    return all(p in oldparts for p in split(masks[0]&~ext&~now))

def mine(t,rms):
    w,gates,aisles=t
    anchors=aisles|mask(p for r in rms.values() for p in r['stances'])
    ids=[id for id,r in rms.items() if len(r['gates'])==1]
    pairmeta=[]
    for i,j in combinations(ids,2):
        x,y=rms[i],rms[j]
        bx,by=x['body'],y['body']
        shared=wave(bx)&wave(by)&w
        if shared:
            upper=(bx|by).bit_count()-4
            pairmeta.append((i,j,shared,upper))
    bound=sum(z[3] for z in pairmeta if z[3]>0)
    menu=[]
    counts=dict(pairs=len(pairmeta),upper_positive=sum(z[3]>0 for z in pairmeta),tested=0,
                parity=0,positive=0,scope=0,anchors=0)
    owns=mask(anchors_i for r in rms.values() for anchors_i in r['stances'])
    for i,j,shared,upper in pairmeta:
        if upper<=0:continue
        x,y=rms[i],rms[j]
        u=x['body']|y['body']
        g0=x['gates'][0]; g1=y['gates'][0]
        a0=g0+(1 if x['left']>=0 else -1);a1=g1+(1 if y['left']>=0 else -1)
        if not x['body']&B[a0] or not y['body']&B[a1]:continue
        ext_candidates=w&wave(u)
        cap_candidates=u&~(B[a0]|B[a1]|owns)
        p0=mask(z for z in cells(u|ext_candidates) if ((z//30+z%30)&1)==0)
        p1=(u|ext_candidates)^p0
        good0=~(B[g0]|wave(B[g0]));good1=~(B[g1]|wave(B[g1]))
        for k in (1,2):
            for removed in combinations(cells(ext_candidates),k):
                rem=mask(removed)
                if not shared&rem:continue
                for l in range(k+1):
                    if u.bit_count()-6+k-l<=0:continue
                    for adds in combinations(cells(cap_candidates),l):
                        cap=mask(adds)
                        counts['tested']+=1
                        new=(w^rem)|cap;op=ALL^(new|gates)
                        a=flood(B[a0],op)
                        if a&B[a1] or a&~(u|rem) or a==x['body']:continue
                        if not a&good0&p0 or not a&good0&p1:continue
                        b=flood(B[a1],op)
                        if b&~(u|rem) or b==y['body']:continue
                        if not b&good1&p0 or not b&good1&p1:continue
                        counts['parity']+=1
                        gain=k-l+u.bit_count()-(a|b).bit_count()
                        if gain<=0:continue
                        counts['positive']+=1
                        if not assess(t,rms,(new,{i:a,j:b}),[(rem,cap,i,j)]):continue
                        counts['scope']+=1
                        if not reachable_checks(w,new,gates,anchors):continue
                        counts['anchors']+=1
                        menu.append(((-gain,i,j,removed,adds),a,b,u|rem))
    got=[];seen=0; walls=w; plans={}; selections=[]
    for (ng,i,j,removed,adds),a,b,support in sorted(menu):
        if seen&support:continue
        rem,cap=mask(removed),mask(adds)
        hyp=(walls^rem)|cap
        next_plan={**plans,i:a,j:b}; nextsel=selections+[(rem,cap,i,j)]
        if not assess(t,rms,(hyp,next_plan),nextsel) or not reachable_checks(w,hyp,gates,anchors):continue
        got.append(dict(gain=-ng,i=i,j=j,removed=removed,added=adds,body0=list(cells(a)),body1=list(cells(b))))
        seen|=support; walls=hyp;plans=next_plan;selections=nextsel
    # Ignoring simultaneous compatibility, each room can participate in at
    # most one selected pair. Sum its maximal incident gain /2 is a valid
    # fractional upper on any truly disjoint menu, stronger than sum-all.
    ub={}
    for (ng,i,j,*_),_,_,_ in menu:
        for z in (i,j):ub[z]=max(ub.get(z,0),-ng)
    return dict(counts=counts,preflight_loose_bound=bound,disjoint_upper=sum(ub.values())/2,
                selected_total=sum(q['gain']for q in got),chosen=got)

if __name__=='__main__':
    print(json.dumps([dict(map=i,**mine(t,r)) for i,(t,r) in enumerate(zip(maps(),rooms()))],indent=2))
