# Two-room shared-wall patch
Only pairs of original named one-mouth rooms sharing at least one original X
that touches both bodies. Necessary difference from previous one-room swap:
at least one deleted X is shared, and both nominated room footprints change.
Keep every original gate/actor stance. Fixed local patch is old union of the
pair's two bodies plus all original X cardinal-adjacent to either old body.
Add 0–2 walls on old body cells, remove 1–2 X (at least one shared), never add
more than removed, total toggles ≤4. No target/stance changes. Both rooms
remain distinct with gate-safe endpoints of each parity. All other named
footprints unchanged. Old body floor no longer in the two rooms and deleted
walls not in new bodies must be reachable from the original exterior. No
new phantom component. Existing old exterior and all original guard/aisle
anchor connectivity must survive with all gates open and after ANY one
original gate wall. Gain is reduction in planned walls plus decrease in
total occupied capture floor if both new shapes are sealed.

Derived admissible preflight bound: safe parity forces minimum three floor
cells per one-mouth connected body (the cell next to the gate is unsafe,
and both safe endpoints cannot be the same cell). Combined floor ≥6 and
planned X saving ≤2. Do not enumerate pair if its area−6+2 ≤0. No candidate
metadata derived from tapes. Rank by descending gain, then original IDs,
removed and installed coordinates. Greedy disjoint affected sets, reverify
combined geometry. Report no outcomes, and do not widen menu after detection.
