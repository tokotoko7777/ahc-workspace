"""Emit literally unclaimed actors before idle without modifying action outputs."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def put(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int poly_mask_turn=-1;\ninline std::vector<std::pair<int,unsigned>> poly_masks;\n'+s[i:]
a='   const auto before=counter?action:std::vector<char>{};'
put(a,'''
   if(poly_mask_turn>=0){
    unsigned msk=0;
    for(int j=0;j<(int)action.size();++j)if(!action[j])msk|=1u<<j;
    if(msk)poly_masks.emplace_back(poly_mask_turn,msk);
   }
'''+a)
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn<275&&std::getenv("AHC008_POLY_MASK_OUT"))poly_mask_turn=turn;
'''+a+'''
  poly_mask_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* p=std::getenv("AHC008_POLY_MASK_OUT")){
   std::ofstream f(p);for(auto [t,v]:poly_masks)f<<t<<' '<<v<<'\\n';
 }
'''+a)
(d/'masks.private.cpp').write_text(s)
