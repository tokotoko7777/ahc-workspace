"""Validate exact stock prefixes and generate true unused actor masks, no tester."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile

D=Path(__file__).resolve().parent
R=D.parent
P=R/'ahc008_terry_hunt_wall_audit'
INPUTS=R/'ahc008_terry_incoming_shadow/held100/in'
def sha(raw):return hashlib.sha256(raw).hexdigest()
recs=json.loads((P/'recordings.json').read_text())
if isinstance(recs,dict):
    print('keys',recs.keys())
    recs=recs.get('tapes',recs.get('records',recs.get('rows')))
assert isinstance(recs,list) and len(recs)==100
(D/'masks').mkdir(exist_ok=True)
for z in recs:
    f=z['case']
    raw=(INPUTS/f).read_bytes()
    action=(P/'tapes'/f).with_suffix('.actions').read_bytes()
    tape=(P/'tapes'/f).with_suffix('.trace').read_bytes()
    assert sha(raw)==z['input_sha'] and sha(action)==z['commands_sha'] and sha(tape)==z['trace_sha']
    ptr=raw.decode().splitlines(); n=int(ptr[0]);m=int(ptr[n+1])
    trace=tape.decode().splitlines()
    o=(D/'masks'/f).with_suffix('.txt')
    rr=subprocess.run([str(D/'mask-observer'),'--pairs=0'],text=True,capture_output=True,check=True,timeout=8,
       input='\n'.join(ptr[:n+2+m]+trace[1::2])+'\n',env=dict(os.environ,AHC008_POLY_MASK_OUT=str(o)))
    assert rr.stdout.splitlines()[:275]==action.decode().splitlines()[:275], f
    assert o.exists()
    print(f,sha(o.read_bytes()),flush=True)
