"""Read-only enumeration on certified stock tapes, no solver execution."""
import collections, json, sys
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import sha, case_history, command_effect, step, snapshot, B, ALL, mask, cells, flood, wave
from analyze import terrain
P=R/'ahc008_terry_hunt_wall_audit'
ADJ=tuple(wave(b) for b in B)

def bodies(seed, opened, eligible, workers):
    """Force every open, unbuildable vertex adjacent to a proposed body."""
    seen=set()
    def rec(body):
        if body in seen or body&workers:return
        seen.add(body)
        while True:
            front=wave(body)&opened&~body
            if front&workers:return
            mandatory=front&~eligible
            if not mandatory:break
            body|=mandatory
            if body.bit_count()>4 or body in seen:return
            seen.add(body)
        yield body,front
        if body.bit_count()==4:return
        for j in cells(front):
            yield from rec(body|B[j])
    return rec(B[seed])

def legal_actors(pets,hum,spare,w,doors,newhum):
    forbid=w|doors|mask(hum)|mask(newhum)
    for q in pets:forbid|=B[q]|ADJ[q]
    opts=collections.defaultdict(list)
    for actor in cells(spare):
        q=hum[actor]
        for c in 'urdl':
            dst=step(q,c)
            if dst is not None and not (forbid&B[dst]):opts[dst].append((actor,c))
    return opts

def select(front,choices):
    q=list(cells(front))
    if len(q)==1:return [choices[q[0]][0]]
    if len(q)==2:
        return next(([a,b]for a in choices[q[0]] for b in choices[q[1]] if a[0]!=b[0]),None)
    return None

def unchanged_pairs(old,new):
    return all(old[i]!=old[j] or new[i]==new[j]
               for i in range(len(old)) for j in range(i))

def read_masks(path,m):
    rows={}
    for line in path.read_text().splitlines():
        t,s=map(int,line.split())
        assert 0<=t<275 and t not in rows and 0<s<1<<m
        rows[t]=s
    return rows

def audit(rec,doors,stats):
    name=rec['case']
    kinds,hist,cmds=case_history(rec)
    rows=read_masks((D/'masks'/name),len(hist[0][1]))
    all_witness=[]; stats['spare_mask_turns']+=len(rows)
    for t,spare in sorted(rows.items()):
        pts,hum,w=hist[t]
        _,nh,nw=hist[t+1]
        spare &= sum(1<<i for i,c in enumerate(cmds[t]) if c=='.')
        if not spare:continue
        assert command_effect(hum,w,pts,cmds[t])==(nw,nh)
        opts=legal_actors(pts,hum,spare,nw,doors,nh)
        if not opts:continue
        eligible=mask(opts)
        opened=ALL^nw; workers=mask(nh)
        domain=eligible
        # Any body cell is at most four open edges from some added frontier wall.
        for _ in range(4):domain=(domain|wave(domain))&opened
        if not any(B[p]&domain for p in pts):continue
        oldid, reach, people_union=snapshot(nw,nh,pts)
        seen=set()
        for i,p in enumerate(pts):
            if not B[p]&domain&people_union:continue
            for body,front in bodies(p,opened,eligible,workers):
                if (body,front) in seen or not 1<=front.bit_count()<=2:continue
                seen.add((body,front))
                commands=select(front,opts)
                if not commands:continue
                c=list(cmds[t])
                for j,d in commands:
                    assert c[j]=='.'
                    c[j]=d
                alt=command_effect(hum,w,pts,c)
                assert alt==(nw|front,nh)
                newid,newreach,_=snapshot(alt[0],nh,pts)
                assert not oldid&~newid
                if not unchanged_pairs(reach,newreach):
                    stats['worker_split_rejected']+=1;continue
                newly=sum(B[j] for j,q in enumerate(pts) if body&B[q] and (newid&~oldid)&B[j])
                assert newly and newly&B[i]
                assert flood(B[p],ALL^alt[0])==body
                all_witness.append((t,body,front,newly))
    # Chronological first factual isolate for each candidate pet, with stock
    # cost equal to its resulting actual connected area + newly built boundary.
    comparison={}
    if all_witness:
        missing=set(i for _,_,_,new in all_witness for i in cells(new))
        for t in range(min(z[0] for z in all_witness),300):
            pts,_,w=hist[t]; _,h,nw=hist[t+1]
            ids,_,_=snapshot(nw,h,pts)
            for i in list(missing.intersection(cells(ids))):
                component=flood(B[pts[i]],ALL^nw)
                boundary=wave(component)&(nw&~w)
                if boundary:
                    comparison[i]=(t,component,boundary)
                missing.remove(i)
            if not missing:break
    time_count=sum(x[3].bit_count() for x in all_witness)
    unique=set((b,f,i) for _,b,f,new in all_witness for i in cells(new))
    # Greedy chronological only: avoid double-credit for either one new fill,
    # one later stock room fill, or an animal shared by alternative fills.
    used_pet=set(); used_stock=set(); used_new=set(); gains=[]
    for t,b,f,new in sorted(all_witness):
        for i in cells(new):
            if i in used_pet or i not in comparison or (b,f) in used_new:continue
            s,ob,of=comparison[i]
            if s<=t or (s,ob,of) in used_stock:continue
            used_pet.add(i);used_stock.add((s,ob,of));used_new.add((b,f))
            delta=(ob.bit_count()+of.bit_count())-(b.bit_count()+f.bit_count())
            gains.append(dict(t=t,pet=i,body=list(cells(b)),walls=list(cells(f)),
                              stock_t=s,stock_body=ob.bit_count(),stock_walls=list(cells(of)),delta=delta))
            break
    return dict(time_fills=time_count,unique_fills=len(unique),
                unique_enclosures=len({(b,f)for b,f,i in unique}),gains=gains,
                witnesses=[dict(turn=t,body=list(cells(b)),walls=list(cells(f)),pets=list(cells(new)))
                           for t,b,f,new in all_witness])

def main():
    recs=json.loads((P/'recordings.json').read_text()); assert len(recs)==100
    maps=terrain(); stats=collections.Counter(); results={}
    pin=dict(line.split() for line in (D/"masks_manifest.log").read_text().splitlines()); assert len(pin)==100
    for record in recs:
        assert sha(D/"masks"/record["case"])==pin[record["case"]]
        a=audit(record,maps[record['map']][1],stats)
        if a['unique_fills']:results[record['case']]=a
    summary=dict(unique_fills=sum(a['unique_fills']for a in results.values()),
                 unique_enclosures=sum(a['unique_enclosures']for a in results.values()),
                 time_fills=sum(a['time_fills']for a in results.values()),
                 boards=len(results),positive_gain=sum(max(0,p['delta'])for a in results.values() for p in a['gains']),
                 signed_gain=sum(p['delta']for a in results.values()for p in a['gains']),stats=dict(stats))
    summary['pass']=summary['unique_fills']>=20 and summary['boards']>=12 and summary['positive_gain']>=100
    (D/'report.json').write_text(json.dumps(dict(summary=summary,cases=results),indent=2)+'\n')
    print(json.dumps(summary))
if __name__=='__main__':main()
