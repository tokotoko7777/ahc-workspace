# Measurement-only profile of the accepted post-arrival solver

On frozen accepted incoming held100 fixed separate strata (>0 recorded
late pairs vs none), uniformly deterministic first up-to16 by
hash(namespace+input SHA), require at least12 in each before summary.
Same exact accepted complete output SHA and official score, no changed
trajectory, bounded external process and explicit known pairing count
to avoid overriding runtime in the accepted source. Capture excluded
unprofiled I/O; exclusive stopwatch share only, not end-to-end CPU.
Instrument accepted wide phases separately plus arrival histogram,
both neighbor preparation calls and other entrant overhead. This only
guides engineering, never score/model selection or actual paired cap.
