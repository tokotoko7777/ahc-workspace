"""Opt-in exact-work opaque-kernel phase weights; no live policy changes."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def edit(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
def scope(k,a):
    edit(a,a+'\n   ahc008_cost_profile::Scope phase(ahc008_cost_profile::'+k+');')
a='#pragma GCC optimize("O3")'
edit(a,a+'\n'+(d/'profile.hpp').read_text().replace('#pragma once\n',''))
scope('Normal',' std::string step(const State& s,int turn,NormalCount* counter=nullptr){')
scope('BuildPlan','inline Split initialize(const Layout& l,const std::vector<int>& people){')
scope('BuildStep',' Turn act_literal(const Board& wall,const std::vector<int>& h,const std::vector<int>& pet,\n                  const Board& veto={}){')
scope('Staff','                     const std::vector<Queue>& q){')
scope('Geometry','      const Mask& projected,const std::vector<int>& people){')
scope('Arts',' const Mask& arts(const terrain_lib::Terrain& t,const Mask& projected){')
scope('Retention','                           const std::vector<int>& alive,Pcg& rng, std::vector<ShortTap>* tap=nullptr) {')
scope('ExactMass','std::array<uint64_t,3> mass(const Table& adj,const Labels& labels,int start,int room,int speed) {')
scope('Hunt','    const std::vector<Room>& rooms, const std::array<bool,900>& canNext) {')
scope('Idle','inline void idle_phase(const State& s,const std::vector<int>& columns,std::vector<char>& action){')
scope('Chase','std::string chase(const State& s,const terrain_lib::Terrain& layout,int turn){')
a=s.index('inline Shape shape(')
b=s.index('{',a)+1
s=s[:b]+'\n ahc008_cost_profile::Scope phase(ahc008_cost_profile::Shape);'+s[b:]
scope('ActualMotion','template<class RNG> void actual_motion(State& s,RNG& rng){')
scope('Score','inline int score(const State& s){')
scope('Rollouts','Decision decide(const State& live,Normal& ordinary,int cap,Clock::time_point stop){')
scope('Neighborhood',' void prepare(const Mask& walls){')
a=s.index('std::vector<Entry> terminal_histogram(')
b=s.index('{',a)+1
s=s[:b]+'\n    ahc008_cost_profile::Scope phase(ahc008_cost_profile::Histogram);'+s[b:]
a='     std::vector<int> outside;'
edit(a,'    { ahc008_cost_profile::Scope phase(ahc008_cost_profile::Arrival);\n'+a)
a='    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));'
edit(a,'    }\n'+a)

edit(' const auto stop=started+std::chrono::milliseconds(limit_ms);','''
 const bool profiling=std::getenv("AHC008_COST_PROFILE");
 if(profiling&&cap==100000)return 2;
 const auto stop=profiling?Clock::time_point::max():started+std::chrono::milliseconds(limit_ms);''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
edit(a,' ahc008_cost_profile::write();\n'+a)
(d/'observer.private.cpp').write_text(s)
