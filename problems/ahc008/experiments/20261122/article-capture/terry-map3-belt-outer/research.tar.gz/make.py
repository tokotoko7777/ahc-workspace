"""Frozen relay-corrected belt -> keep the rightmost original paired bank."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_map3_belt/relay.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='71c76fba12798b2d7d2b86a9e0963b868eb4f497eb8ce620873b36b3bab03f79'
a='inline constexpr int pruneMinCol=20;'
assert s.count(a)==1
(d/'live.private.cpp').write_text(s.replace(a,'inline constexpr int pruneMinCol=27;'))
