# Independent boundary-only geometry fallback, preregistered before relay outcome

The 27 prior fresh full-clear map3 tapes used c>=27 old edge solos
38 times, at most three times on any board. In contrast the full
right-bay c>=20 replacement removes 140 factual capture episodes,
including the 102 paired-bank ones. Preserve that c20/c25 pair
network and every original column <27. Replace only the rightmost
c>=27 strip with the same four vertical four-cell slots and same
corrected relay. Instead of 67, save exactly nine planned X:
same 20 belt cells, now erase only 29 planned stock cells. No change
to pursuit coefficients or slots, task queues, runtime deadline,
map classifier, or role permissions. This was chosen from independent
historical factual load, not current alternative score results.

If the c>=20 corrected layout fails its paired gate, first certify
static unaffected room footprints/doors and retained stances under
original individual gate closures using the provided check, plus
the four exact bodies/approach/build stances; then repeat the same
synthetic dry gate (>=36/40 all20 installed by 133, no loss on
retained walls). If either fails, no live. If passed, on new
unfiltered dev100 demand ≥0.1% total gain, all official valid and
independently replayed, max tester <2.95s, no raw/useful full drops
overall or for map3, and mean human floor gain at least 3 tiles in
map3 common clears. Repeat unchanged on independent holdout100 and
then official practice100 only after each pass. No interpreting
generated tests as historical judge outcomes, no main merge.
