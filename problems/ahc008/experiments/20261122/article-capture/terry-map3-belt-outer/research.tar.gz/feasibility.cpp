#pragma GCC optimize("O3")
#include "belt.hpp"
#include <cassert>
#include <iostream>
#include <queue>
#include <map>
using namespace terry_map3_belt;
std::vector<int> cells(const Board& b){std::vector<int> v;for(int p=0;p<V;p++)if(b[p])v.push_back(p);return v;}
Board footprint(const Board& walls,int p){
 auto s=labels(walls); assert(!walls[p]); Board q;
 for(int v=0;v<V;v++)if(s.labels[p]==s.labels[v])q.set(v);
 return q;
}
Board classified(const Rooms& R,int id,const Board& doors){
 Board m;
 for(int p=0;p<V;p++)if(R.ids[p]==id&&!doors[p])m.set(p);
 return m;
}
int route(Board walls,const Layout& lyt,int begin,int lo,int hi){
 int actor=begin,total=0;
 auto walk=[&](int goal){
  const Board before=walls;
  std::array<int,V> prev,q;
  prev.fill(-1);int n=1;prev[actor]=actor;q[0]=actor;
  for(int i=0;i<n&&prev[goal]<0;i++)for(int p:adjacent(q[i]))
   if(p>=0&&!walls[p]&&prev[p]<0){prev[p]=q[i];q[n++]=p;}
  assert(prev[goal]>=0&&!walls[goal]);
  int p=goal;while(p!=actor){++total;p=prev[p];}
  actor=goal;
  assert(walls==before);
 };
 for(int k=lo;k<=hi;k++)for(auto job:lyt.slots[k].jobs){
  walk(job.stand);
  auto ns=adjacent(actor);assert(std::find(ns.begin(),ns.end(),job.wall)!=ns.end());
  assert(!walls[job.wall]);
  walls.set(job.wall);++total;
  assert(footprint(walls,actor)[cell(0,backbone)]);
 }
 walk(cell(actor/W,backbone));
 return total;
}
int main(){
 const auto& base=terrain(sourceMap);
 const auto l=layout();
 const auto nw=l.intendedWalls();
 assert(l.erased.count()==29&&l.added.count()==20);
 assert(base.plannedWalls.count()==233&&nw.count()==224);
 assert(l.stock.aisleCells==base.aisleCells);
 for(int r=0;r<W;r++)assert(l.stock.constructionRow(r)==base.constructionRow(r));
 for(int r=0;r<W;r++)for(int c=0;c<pruneMinCol;c++){
  int p=cell(r,c);
  assert(base.cells[p]==l.stock.cells[p]);
  assert(base.doorCells[p]==l.stock.doorCells[p]&&base.plannedWalls[p]==nw[p]);
 }
 std::vector<int> humans{cell(0,0)};
 auto ro=classify(base,base.plannedWalls,{},humans);
 auto rn=classify(l.stock,nw,{},humans);
 const Board prunedRegion=[](){Board b;for(int r=0;r<W;r++)for(int c=pruneMinCol;c<W;c++)b.set(cell(r,c));return b;}();
 int keep=0,retired=0,ungated=0;
 std::vector<std::pair<int,int>> idMap;
 std::vector<std::pair<int,int>> stanceAnchors;
 for(int i=0;i<ro.count();i++){
  auto z=ro.rooms[i];
  auto b=classified(ro,i,base.doorCells);
  if(z.left<0&&z.right<0){ungated++;continue;}
  assert(b.any());
  auto x=b;
  if(z.left>=0)x.set(z.left);
  if(z.right>=0)x.set(z.right);
  if((x&prunedRegion).any()){
   assert((x&~prunedRegion).none());
   retired++;continue;
  }
  int example=cells(b)[0];
  int id=rn.ids[example];assert(id>=0&&id<rn.count());
  auto other=rn.rooms[id];
  assert(b==classified(rn,id,l.stock.doorCells));
  assert(z.left==other.left&&z.right==other.right&&z.size==other.size);
  idMap.push_back({i,id});++keep;
  std::vector<int> gates,stands;
  if(z.left>=0){gates.push_back(z.left);stands.push_back(z.left-1);}
  if(z.right>=0){gates.push_back(z.right);stands.push_back(z.right+1);}
  for(int q:stands){
   assert(base.aisle(q)&&!nw[q]);
   stanceAnchors.push_back({q,cell(0,q%W)});
  }
  // Check every original one-mouth closure and double seal, not just IDs.
  for(int mask=1;mask<(1<<int(gates.size()));mask++){
   auto w0=base.plannedWalls,w1=nw;
   for(int i=0;i<int(gates.size());++i)if(mask>>i&1){
    w0.set(gates[i]);w1.set(gates[i]);
   }
   auto f0=footprint(w0,example), f1=footprint(w1,example);
   assert((f0&~prunedRegion)==(f1&~prunedRegion));
   if(mask==(1<<int(gates.size()))-1)assert(f0==b&&f1==b);
   for(int q:stands){
    auto top=cell(0,q%W);
    assert(footprint(w0,q)[top]&&footprint(w1,q)[top]);
   }
  }
 }
 std::cout<<"Old rooms kept="<<keep<<", retired="<<retired<<", ungated="<<ungated<<"\n";
 assert(keep+retired+ungated==ro.count()&&keep==rn.count());
 // Every retained stance-to-original-lane relation remains under ANY one
 // original configured closure, including the right-side gates not reused.
 for(int g:cells(base.doorCells)){
  auto w0=base.plannedWalls,w1=nw;
  w0.set(g);if(l.stock.doorCells[g])w1.set(g);
  auto a=labels(w0),b=labels(w1);
  for(auto [s,t]:stanceAnchors){
   assert(a.labels[s]>=0&&b.labels[s]>=0);
   assert(a.labels[s]==a.labels[t]&&b.labels[s]==b.labels[t]);
   for(int p:cells(base.aisleCells))assert((a.labels[s]==a.labels[p])==(b.labels[s]==b.labels[p]));
  }
 }
 auto sealed=nw;
 for(auto x:l.slots){
  assert(footprint(nw,cells(x.body)[0])[cell(0,backbone)]);
  assert(footprint(nw,x.stance)[cell(0,backbone)]);
  auto one=nw;one.set(x.mouth);
  assert(footprint(one,cells(x.body)[0])==x.body);
  assert(footprint(one,x.stance)[cell(0,backbone)]);
  sealed.set(x.mouth);
 }
 auto exterior=footprint(sealed,cell(0,backbone));
 for(auto x:l.slots){
  assert(footprint(sealed,cells(x.body)[0])==x.body);
  assert(exterior[x.stance]);
 }
 for(int r=0;r<W;r++)for(int c:{19,26,27})assert(exterior[cell(r,c)]);
 // Build from any starting row of existing c26. Each worker gets a nested
 // task interval on the new side, but never permanently owns any lane.
 int wa=0,wb=0,serial=0;
 for(int r=0;r<W;r++){
  wa=std::max(wa,route(l.stock.plannedWalls,l,cell(r,backbone),0,1));
  wb=std::max(wb,route(l.stock.plannedWalls,l,cell(r,backbone),2,3));
  serial=std::max(serial,route(l.stock.plannedWalls,l,cell(r,backbone),0,3));
 }
 std::cout<<"Net X saved "<<l.erased.count()-l.added.count()<<"; worst no-pet 2-slot worker "
          <<wa<<'/'<<wb<<", serial "<<serial<<"\n";
}
