#define main submission_main
#include "live.private.cpp"
#undef main
#include <algorithm>
#include <numeric>
#include <random>
#include <cstdio>

int main(){
 using namespace terry_exact_root;
 constexpr int ns=40;
 std::mt19937 rng(6651801);
 int beltFull=0, stockLoss=0; long sumBuilt=0;
 for(int q=0;q<ns;++q){
  const int m=7+q%4;
  std::array<int,V> initial; std::iota(initial.begin(),initial.end(),0);
  std::shuffle(initial.begin(),initial.end(),rng);
  State s,t;
  s.people.assign(initial.begin(),initial.begin()+m); t=s;
  const auto& a=terrain_lib::terrain(3);
  const auto& alt=belt_pilot::geometry();
  const auto clone=s.people;
  Normal old(a,s), newer(alt.stock,t,&alt);
  for(int turn=0;turn<133;++turn){
   const auto x=old.step(s,turn), y=newer.step(t,turn);
   assert(x.size()==clone.size()&&y.size()==clone.size());
   people_step(s,x);people_step(t,y);
  }
  const int built=(t.walls&alt.added).count();
  const int missing=(s.walls&alt.stock.plannedWalls&~t.walls).count();
  printf("%d,%d,%d,%d,%zu,%zu\n",q,m,built,missing,
    (s.walls&a.plannedWalls).count(),(t.walls&alt.stock.plannedWalls).count());
  beltFull+=built==20;stockLoss+=missing>0; sumBuilt+=built;
 }
 printf("complete=%d/%d stockLoss=%d/%d meanBuilt=%.3f passed=%d\n",
   beltFull,ns,stockLoss,ns,double(sumBuilt)/ns,beltFull>=36&&stockLoss==0);
}
