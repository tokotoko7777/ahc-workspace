import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_motion_cache/submission.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='d14f6471e5f64bf4a936f8cf27a0f585136a53e13f3e4a27af9fa21f6427b49c'
def put(token,f):
 global s
 assert s.count(token)==1,token
 s=s.replace(token,f(token))
s=s.replace('namespace terry_exact_root {','''namespace terry_exact_root {
  inline int idle_entry_audit_turn=-1;
  inline std::vector<std::string> idle_entry_audit_rows;
''',1)
put('   idle_phase(s,terrain->aisleColumns,action);',lambda x:'''
   std::string idle_flags;
   if(idle_entry_audit_turn>=0)for(char a:action)idle_flags+=a?'0':'1';
'''+x+'''
   if(idle_entry_audit_turn>=0){
    std::string post;
    for(size_t i=0;i<action.size();++i)post+=idle_flags[i]=='1'?(action[i]?action[i]:'.'):'-';
    idle_entry_audit_rows.push_back(std::to_string(idle_entry_audit_turn)+" "+idle_flags+" "+post);
   }
''')
put('  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);',lambda x:'''
  if(turn<275&&std::getenv("AHC008_TERRY_IDLE_ENTRY_AUDIT"))idle_entry_audit_turn=turn;
'''+x+'''
  idle_entry_audit_turn=-1;
''')
put(' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){',lambda x:'''
 if(const char* path=std::getenv("AHC008_TERRY_IDLE_ENTRY_AUDIT")){
  std::ofstream f(path);
  for(const auto& line:idle_entry_audit_rows)f<<line<<'\\n';
 }
'''+x)
(d/'audit.private.cpp').write_text(s)
