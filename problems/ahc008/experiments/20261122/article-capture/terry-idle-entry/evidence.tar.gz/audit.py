"""Factual one/two-step anticipatory route replacing only original stage4 work."""
import collections,csv,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,flat,flood,near,observed,replay,wave
catalog=collections.defaultdict(dict)
for row in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
    m,room,left,right,*ps=map(int,row.split())
    if (left>=0)!=(right>=0) and 1<=len(ps)<=4:
        g=left if left>=0 else right
        catalog[m][g]=(room,bitmask(ps),'r' if left>=0 else 'l')
def audit(q):
    f=q['case'];mid=int(q['telemetry'].split()[0])
    raw=(R/'ahc008_focus_assets/tools/in'/f).read_bytes()
    tp=R/'ahc008_terry_scaffold_audit/tapes'/f
    out=tp.with_suffix('.actions').read_bytes();stock=out.decode().splitlines()
    tr=tp.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==q['input_sha']
    assert hashlib.sha256(out).hexdigest()==q['commands_sha']
    assert replay(raw.decode(),tr,stock,detailed=True)[0]==int(q['score'])
    inp=raw.decode().splitlines();n=int(inp[0]);m=int(inp[n+1])
    with tempfile.TemporaryDirectory() as d:
        lg=Path(d)/'out'
        z=subprocess.run([str(D/'audit'),'--pairs=0'],input='\n'.join(inp[:n+2+m]+tr[1::2])+'\n',text=True,capture_output=True,
           check=True,env=dict(os.environ,AHC008_TERRY_IDLE_ENTRY_AUDIT=str(lg)))
        assert z.stdout.splitlines()[:275]==stock[:275]
        infos={}
        for row in lg.read_text().splitlines():
            tm,flag,pa=row.split()
            assert len(flag)==len(pa)==m
            infos[int(tm)]=(flag,pa)
    kinds,history,_=observed(raw,tr)
    state=[(list(map(flat,ps)),list(map(flat,hs)),bitmask(map(flat,ws))) for ps,hs,ws in history]
    reaches=[flood(bitmask(h),ALL^w) for _,h,w in state]
    actual_catch=[bitmask(p)&reaches[t]&~reaches[t+1] for t,(p,_,_) in enumerate(state[:-1])]
    caught={i:t for t,i,_,_ in (map(int,e.split(':')) for e in q['captures'].split(';') if e)}
    stat=collections.Counter(); witnesses=[]; joined=set();credited={1:set(),2:set()}
    for t in range(1,275):
        if t not in infos:continue
        p,h,w=state[t]; _,ha,wa=state[t+1]
        a=bitmask(p);hum=bitmask(h);ban=a|wave(a)|w|hum|wa
        for gate,(room,body,cmd) in catalog[mid].items():
            if not (a&body&reaches[t]) or body&(w|hum) or B[gate]&ban:continue
            if flood(body&-body,ALL^(w|B[gate]))!=body:continue
            if flood(body&-body,ALL^(wa|B[gate]))!=body:continue
            animal={i for i,x in enumerate(p) if B[x]&body&reaches[t] and B[x]&reaches[t+1]}
            if not animal:continue
            goal=near(gate,'L' if cmd=='r' else 'R')
            if goal is None:continue
            for d in (1,2):
                if t<d or t-d not in infos:continue
                entrants={i for i in animal if not B[state[t-d][0][i]]&body}
                if not entrants:continue
                stat[f'ready_entrant_events_h{d}']+=1
                for i in range(m):
                    if h[i]==goal or infos[t][0][i]!='1' or stock[t][i].islower():continue
                    if any(s not in infos or infos[s][0][i]!='1' or stock[s][i].islower() for s in range(t-d,t)):continue
                    start=state[t-d][1][i]
                    if start%30!=goal%30:continue
                    if not 1<=abs(start//30-goal//30)<=d:continue
                    local=start; commands=[]; safe=True
                    for s in range(t-d,t):
                        nxt=local+30*((goal>local)-(goal<local)); _, hh, ww=state[s+1]
                        if B[local]&ww or B[nxt]&ww:
                            safe=False;break
                        ah=hh.copy();ah[i]=nxt
                        if flood(bitmask(ah),ALL^ww)&actual_catch[s]:
                            safe=False;break
                        commands.append('D' if nxt>local else 'U' if nxt<local else '.')
                        local=nxt
                    if not safe or local!=goal:continue
                    before=h.copy();before[i]=local
                    if B[gate]&bitmask(before):continue
                    after=ha.copy();after[i]=goal
                    tmp=wa|B[gate]
                    if bitmask(after)&tmp:continue
                    root=flood(bitmask(after),ALL^tmp)
                    if body&root or root&actual_catch[t]:continue
                    key=(t,gate)
                    if key in credited[d]:continue
                    credited[d].add(key);joined.add(key)
                    stat[f'available_h{d}']+=1
                    stat[f'applied_distinct_pet_event_h{d}']+=len(entrants)
                    is_changing_idle=any(stock[s][i]!=alt for s,alt in zip(range(t-d,t),commands))
                    assert is_changing_idle
                    witnesses.append(dict(t=t,gate=gate,room=room,lag=d,actor=i,body=body.bit_count(),
                        entrant=sorted(entrants),kinds={j:kinds[j] for j in entrants},
                        did_stock_later_catch={j:caught.get(j) for j in entrants},
                        stock_approach=''.join(stock[s][i] for s in range(t-d,t)),new_approach=''.join(commands),
                        stock_then=stock[t][i],new_then=cmd))
    stat['available_unique_events']=len(joined)
    return dict(case=f,map=mid,stats=stat,witnesses=witnesses)
def main():
    out=[];total=collections.Counter()
    for q in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open()):
        if q['arm']!='terry_independent':continue
        r=audit(q);out.append(r);total.update(r['stats'])
    assert len(out)==100
    print(json.dumps(dict(cases=len(out),total=total,board_counts=collections.Counter(
      k for row in out for k,v in row['stats'].items() if v),details=out),indent=2))
if __name__=='__main__':main()
