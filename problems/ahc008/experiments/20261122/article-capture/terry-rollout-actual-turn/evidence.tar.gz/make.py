"""One change: simulate virtual chase's actual time, not a frozen turn 275."""
from pathlib import Path
import hashlib,sys
a,b=map(Path,sys.argv[1:])
data=a.read_bytes()
assert hashlib.sha256(data).hexdigest()=='54f2b1ecc90820fcc5c99bc4e3cb8ddfe06c5952bf45851bf9d1a21e49341ae9'
old='   people_step(t,chase(t,*ordinary.terrain,275));actual_motion(t,b);'
new='   people_step(t,chase(t,*ordinary.terrain,turn));actual_motion(t,b);'
s=data.decode()
assert s.count(old)==1
b.write_text(s.replace(old,new))
