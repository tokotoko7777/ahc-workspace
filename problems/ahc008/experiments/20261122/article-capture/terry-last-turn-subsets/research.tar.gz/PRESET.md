# Signed last-turn wall-subset screen

Use exactly the previously accepted incoming held100 stock audit recordings,
inputs at `ahc008_terry_incoming_shadow/held100/in`, tapes and manifest at
`ahc008_terry_hunt_wall_audit`. This is old accepted stock support, not a new
holdout or current adopted-solver estimate. Every input/action/trace hash
and both the official score in its signed ledger and the independent
counterfactual scorer on the unedited turn must agree. No new tester run.

Before zero-based action 299, fix actual human and pet state. Keep all
original movement commands. Enumerate subsets of the at most ten DISTINCT
previously open cells actually walled in that action. Omitting a target
turns all original simultaneous placements to that target into waits.
Duplicate actors and attempted re-walls are tracked separately; they
cannot create independent graph alternatives. No new walls or moves.

Use exact components after simultaneous human moves and proposed wall
subset, evaluated against current actual pet positions: every ensuing pet
microstep must stay in its current component, hence final score and each
reachable pet-ID set are exact without assuming final pet positions. A
qualifying option strictly increases exact mean effective scored floor,
and strictly increases official rounded score, keeps full and useful
status no worse, and must preserve each worker's exact pet-ID set. With
fixed worker endpoints and no wall additions, reachable sets can only
increase, so equal per-worker pet sets certify no contagion and score
is linear in retained area at fixed penalties. Rank by exact effective
floor, then official score, then omitted wall count and row-major tuple.

Frozen gate: at least five improved boards AND at least 20 summed exact
effective-floor tiles across all 100. Report all full/useful states, signed
support and duplicate/same-geometry counts. For useful clear use exact
pet-free mean floor >=300. No production change or benchmark.

Only if subsets have too little support, propose separately (do not run)
a last-turn one-worker move alternative or small joint local movement
scan. Fix other workers' actions, use only actually walkable adjacent
destinations after retained walls, measure exact same-pet/score dominance;
allowing moves changes comparability and is not part of this gate.
