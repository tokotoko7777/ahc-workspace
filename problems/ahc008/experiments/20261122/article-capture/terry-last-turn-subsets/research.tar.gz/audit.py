"""No solver or tester: signed exact last-turn placement subsets."""
import collections as C
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

D=Path(__file__).resolve().parent
R=D.parent
I=R/'ahc008_terry_incoming_shadow/held100/in'
T=R/'ahc008_terry_hunt_wall_audit'
E=R/'ahc008_focus_solver/problems/ahc008/experiments/20261122'
sys.path.insert(0,str(E))
from guarded_entry_trace import observed,STEPS
from stochastic_lock_audit import ALL,B,idx,flood,wave

def mask(points):
    return sum(B[q] for q in set(points))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def shift(pos,ch):
    u,v=STEPS[ch.upper()]
    r,c=divmod(pos,30)
    assert 0<=r+u<30 and 0<=c+v<30
    return (r+u)*30+c+v

def inspect(wall,people,pets):
    cuts=[]
    ids=[]
    area=0
    eff=Fraction(0)
    unrounded=0.
    for h in people:
        assert not wall&B[h]
        found=next(((comp,pets0) for comp,pets0 in cuts if comp&B[h]),None)
        if found is None:
            comp=flood(B[h],ALL^wall)
            pets0=sum(1<<i for i,p in enumerate(pets) if comp&B[p])
            cuts.append((comp,pets0))
        else:
            comp,pets0=found
        n=comp.bit_count();c=pets0.bit_count()
        ids.append(pets0)
        area+=n
        eff+=Fraction(n,1<<c)
        unrounded+=(n/900.)*2.0**(-c)
    e=eff/len(people)
    area=Fraction(area,len(people))
    x=1e8*unrounded/len(people)
    score=math.floor(x)+(x-math.floor(x)>=.5)
    full=not any(ids)
    return e,score,tuple(ids),full,full and area>=300,area

def board(rec,history,commands):
    p,h,w=history[299]
    p1,h1,w1=history[300]
    p,h,w=list(map(idx,p)),list(map(idx,h)),mask(map(idx,w))
    p1,h1,w1=list(map(idx,p1)),list(map(idx,h1)),mask(map(idx,w1))
    start=mask(h);pm=mask(p);no=pm|wave(pm)|start
    goals=h[:]; jobs=C.defaultdict(list); rewall=0
    for i,char in enumerate(commands[299]):
        if char=='.':continue
        dst=shift(h[i],char)
        if char.isupper():
            goals[i]=dst
        elif not w&B[dst]:
            assert not no&B[dst]
            jobs[dst].append(i)
        else:
            rewall+=1
    locations=sorted(jobs);allwalls=mask(locations)
    assert goals==h1 and w|allwalls==w1 and not mask(goals)&w1
    assert len(locations)<=10
    old=inspect(w1,h1,p)
    real=inspect(w1,h1,p1)
    assert old==real
    assert old[1]==rec['score'] and old[3]==bool(rec['actual_full'])
    N=len(locations)
    best=None; safe=0; beats=0
    for bits in range(1,1<<N):
        omitted=tuple(p for k,p in enumerate(locations) if bits>>k&1)
        new=inspect(w1^mask(omitted),h1,p)
        assert all(ev&now==ev for ev,now in zip(old[2],new[2]))
        if new[2]!=old[2]:continue
        assert new[3]>=old[3] and new[4]>=old[4]
        safe+=1
        if new[0]<=old[0] or new[1]<=old[1]:continue
        beats+=1
        key=(new[0],new[1],len(omitted),tuple(-p for p in omitted))
        if best is None or key>best[0]:
            best=(key,new,omitted)
    found=best is not None
    delta=best[1][0]-old[0] if found else Fraction(0)
    return delta,dict(case=rec['case'],map=rec['map'],
        stock_full=old[3],stock_useful=old[4],stock_score=old[1],
        distinct_walls=N,rewalls=rewall,
        duplicate_job_targets=sum(len(v)>1 for v in jobs.values()),
        duplicate_actor_actions=sum(len(v)-1 for v in jobs.values()),
        subsets=(1<<N)-1,same_id_subsets=safe,improving_subsets=beats,
        removed=list(best[2]) if found else [],
        changed_worker_ids=sorted(i for q in best[2] for i in jobs[q]) if found else [],
        effective_gain=str(delta),score_gain=best[1][1]-old[1] if found else 0)

def main():
    ledger=json.loads((T/'recordings.json').read_text())
    assert len(ledger)==100 and len({r['case'] for r in ledger})==100
    rows=[];total=Fraction(0)
    for r in ledger:
        f=I/r['case']; stem=(T/'tapes'/r['case']).with_suffix('')
        a=stem.with_suffix('.actions'); z=stem.with_suffix('.trace')
        assert [sha(q) for q in (f,a,z)]==[r[k] for k in ('input_sha','commands_sha','trace_sha')]
        actions=a.read_text().splitlines()
        tr=z.read_text().splitlines()
        assert len(actions)==300 and actions==tr[::2] and len(tr)==600
        _,history,_=observed(f.read_bytes(),tr)
        gain,result=board(r,history,actions)
        rows.append(result);total+=gain
    n=sum(bool(q['removed']) for q in rows)
    sums={k:sum(r[k] for r in rows) for k in (
        'stock_full','stock_useful','distinct_walls','rewalls','duplicate_job_targets',
        'duplicate_actor_actions','subsets','same_id_subsets','improving_subsets','score_gain')}
    print(json.dumps(dict(n=len(rows),improved_boards=n,effective_gain=str(total),
                           gate=(n>=5 and total>=20),counts=sums,rows=rows),indent=2))

if __name__=='__main__':
    main()
