// Standalone pure public-state selector. Frozen menu is static geometry.
namespace optional_x_once {
constexpr int XN=900;
using Walls=std::bitset<XN>;
struct Choice { int cell=-1; unsigned actors=0; };
inline int dest(int p,char d){
 const int c=p%30;
 switch(d){
 case 'L':case 'l':return c?p-1:-1;
 case 'R':case 'r':return c<29?p+1:-1;
 case 'U':case 'u':return p>=30?p-30:-1;
 case 'D':case 'd':return p<870?p+30:-1;
 default:return -1;
 }
}
inline constexpr auto edge=[]{
 std::array<std::array<int,4>,XN> r{};
 for(int p=0;p<XN;p++)r[p]={p%30?p-1:-1,p%30<29?p+1:-1,p>=30?p-30:-1,p<870?p+30:-1};
 return r;
}();
struct Links {
 std::array<unsigned,10> pet{},crew{};
 unsigned union_pet=0;
 bool operator==(const Links&)const=default;
};
inline Links links(const Walls& w,const std::vector<int>& h,const std::vector<int>& p){
 Links a;
 std::array<int,XN> seen;seen.fill(-1);
 std::array<unsigned,10> inside{};
 int q[XN];int m=0;
 for(int at:h)if(seen[at]<0){
  int n=1;q[0]=at;seen[at]=m;
  for(int i=0;i<n;i++)for(int z:edge[q[i]])if(z>=0&&!w[z]&&seen[z]<0){seen[z]=m;q[n++]=z;}
  ++m;
 }
 for(int i=0;i<int(p.size());i++)if(seen[p[i]]>=0)inside[seen[p[i]]]|=1u<<i;
 for(int i=0;i<int(h.size());i++){
  a.pet[i]=inside[seen[h[i]]];a.union_pet|=a.pet[i];
  for(int j=0;j<i;j++)if(seen[h[i]]==seen[h[j]])a.crew[i]|=1u<<j;
 }
 return a;
}
inline bool within6(int root,const Walls& w,const std::vector<int>& p,unsigned reach){
 Walls wanted,seen;
 for(int i=0;i<int(p.size());i++)if(reach>>i&1U)wanted.set(p[i]);
 if(!wanted.any())return false;
 int q[XN]={root};int n=1;seen[root]=true;
 if(wanted[root])return true;
 int start=0;
 for(int d=0;d<6;d++){
  const int e=n;
  for(int i=start;i<e;i++)for(int z:edge[q[i]])if(z>=0&&!seen[z]&&!w[z]){
   if(wanted[z])return true;
   seen[z]=true;q[n++]=z;
  }
  start=e;
 }
 return false;
}
inline Choice choose(int t,const Walls& actual,const std::vector<int>& staff,
                     const std::vector<int>& pets,std::string_view cmd,int map){
 if(t>=160)return {};
 assert(map>=0&&map<5&&staff.size()==cmd.size()&&staff.size()<=10&&pets.size()<=20);
 std::array<int,10> build{},candidates{};
 build.fill(-1);int n=0;
 Walls projected=actual;
 for(int i=0;i<int(staff.size());i++)if(cmd[i]>='a'&&cmd[i]<='z'){
  const int q=dest(staff[i],cmd[i]);build[i]=q;
  if(q<0)continue;
  projected.set(q);
  if(!actual[q]&&MENU[map][q])candidates[n++]=q;
 }
 if(!n)return {};
 auto end=staff;
 for(int i=0;i<int(end.size());i++)if(cmd[i]>='A'&&cmd[i]<='Z'){
  end[i]=dest(staff[i],cmd[i]);if(end[i]<0)return {};
 }
 std::sort(candidates.begin(),candidates.begin()+n);
 const auto baseline=links(projected,end,pets);
 for(int k=0;k<n;k++){
  const int q=candidates[k];
  if(k&&candidates[k-1]==q)continue;
  Walls skip=projected;skip.reset(q);
  if(within6(q,skip,pets,baseline.union_pet))continue;
  if(!(links(skip,end,pets)==baseline))continue;
  unsigned actor=0;for(int i=0;i<int(end.size());i++)if(build[i]==q)actor|=1u<<i;
  return {q,actor};
 }
 return {};
}
}
