"""Serial native paired gate, no solver execution unless explicitly invoked."""
import csv,hashlib,json,re,subprocess,sys,tempfile
from fractions import Fraction as F
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
P=R/'ahc008_terry_x_exact_replay'
H=R/'ahc008_focus_solver/problems/ahc008'
A=R/'ahc008_focus_assets/tools'
N=R/'ahc008_terry_virtual_chase_absorb'
sys.path[:0]=[str(P),str(H),str(H/'experiments/20261122')]
import replay as Q
from benchmark_cases import run
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import idx
def digest(b):return hashlib.sha256(b).hexdigest()
LEDGER='0bd17793a6742076fc9a8aecb755162e87560cea1a83daa152e602751a1615e0'
GEN='39150ebab394c3e35b0bc845d73fe7908ca1a3d7220830af068d958f30f558ff'
LABEL='AHC008/x-once/a237/independent/frozen/v1/'
def seeds():
    return [str(int.from_bytes(hashlib.sha256(f'{LABEL}{i:03d}'.encode()).digest()[:8],'big'))
            for i in range(100)]
def independent(practice, prior):
    assert prior['pass_gate'] and prior['panel']=='practice'
    g=A/'target/release/gen'; assert digest(g.read_bytes())==GEN
    folder=D/'independent'
    folder.mkdir() # never overwrite / regenerate after examining outcomes
    f=folder/'seeds.txt'; f.write_text('\n'.join(seeds())+'\n')
    subprocess.run([str(g),str(f)],cwd=folder,timeout=20,check=True)
    path=folder/'in'
    excluded={r['input_sha'] for r in practice}
    excluded|={r['input_sha'] for r in json.loads((Q.T/'recordings.json').read_text())}
    for hist in (N/'practice.native.csv',N/'fresh.native.csv'):
        with hist.open() as f: excluded|={r['input_sha'] for r in csv.DictReader(f)}
    rows=[dict(case=p.name,input_sha=digest(p.read_bytes())) for p in sorted(path.glob('*.txt'))]
    assert len(rows)==len({x['input_sha'] for x in rows})==100
    assert not excluded&{x['input_sha'] for x in rows}
    (folder/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
    return path,rows
def arm(raw,exe,role):
    with tempfile.TemporaryDirectory() as tmp:
        q=Path(tmp); actions=q/'actions'; trace=q/'trace'; tel=q/'solver'; skip=q/'skip'
        ca=['env','AHC008_TERRY_EXACT_LOG='+str(tel),'AHC008_X_ONCE_LOG='+str(skip),str(exe)]
        o,e,rc,tm=run([str(Q.J),*ca],raw,4.5)
        m=re.fullmatch(rb'Score = (\d+)\s*',e)
        assert rc==0 and m and tm<2.95,(role,tm,e)
        val=int(m[1]); actions.write_bytes(o)
        rr,re_,rx,_=run([str(Q.J),sys.executable,str(H/'benchmark_cases.py'),
                          '--playback',str(actions),str(trace)],raw,12.0)
        assert (rr,re_,rx)==(o,e,rc)
        cmds=o.decode().splitlines(); tr=trace.read_text().splitlines()
        assert len(cmds)==300 and replay(raw.decode(),tr,cmds,detailed=True)[0]==val
        kinds,hist,_=observed(raw,tr)
        hist=[(list(map(idx,p)),list(map(idx,h)),Q.mask(map(idx,w))) for p,h,w in hist]
        p,h,w=hist[-1]
        end=Q.finish(w,h,p)
        live=list(map(int,tel.read_text().split()))
        assert len(live)==15 and live[-1]==val
        changed=list(map(int,skip.read_text().split())) if role=='candidate' else None
        if changed is not None:
            t,cell,who,reinstalled,final=changed
            if t<0:assert changed==[-1,-1,0,-1,0]
            else:
                assert 0<=t<160 and who>0 and not hist[t+1][2]&Q.bit(cell)
                hit=next((i for i in range(t+1,300) if hist[i+1][2]&Q.bit(cell)),-1)
                assert (hit,int(bool(w&Q.bit(cell))))==(reinstalled,final)
        caught={}
        for t,(p,h,w) in enumerate(hist):
            area=Q.flood(Q.mask(h),Q.ALL^w)
            for i,x in enumerate(p):
                if i not in caught and not area&Q.bit(x):
                    caught[i]=[t,kinds[i],Q.flood(Q.bit(x),Q.ALL^w).bit_count()]
        return dict(score=val,end=end,wall=tm,telemetry=live,skip=changed,
                    cmdsha=digest(o),captures=caught),cmds,hist

def main(panel):
    assert panel in ('practice','independent')
    for p,d in Q.PINS.items():assert digest(p.read_bytes())==d
    led=N/'practice.native.csv'; assert digest(led.read_bytes())==LEDGER
    with led.open() as f: practice=[r for r in csv.DictReader(f) if r['arm']=='terry_independent']
    assert len(practice)==len({r['case'] for r in practice})==100
    if panel=='practice': path=A/'in';rows=practice
    else: path,rows=independent(practice,json.loads((D/'practice.result.json').read_text()))
    out=[]
    opts=[set(map(int,x.split(','))) if x else set() for x in Q.menus()]
    arms=[('baseline',D/'baseline'),('candidate',D/'candidate')]
    for i,r in enumerate(rows):
        raw=(path/r['case']).read_bytes(); assert digest(raw)==r['input_sha']
        a={}
        for name,exe in (arms if i%2==0 else arms[::-1]):a[name]=arm(raw,exe,name)
        (b,cb,hb),(c,cc,hc)=a['baseline'],a['candidate']
        assert b['telemetry'][0]==c['telemetry'][0]
        assert panel!='practice' or b['telemetry'][0]==int(r['map'])
        t,q,who,reinst,final=c['skip']
        if t<0:
            # Normal-only prefix, before late native variable rollout count.
            assert cb[:275]==cc[:275] and hb[:276]==hc[:276]
        else:
            assert cb[:t]==cc[:t] and hb[:t+1]==hc[:t+1]
            p,h,w=hb[t]
            event=Q.choose(t,w,h,p,cb[t],opts[c['telemetry'][0]])
            assert event==(q,cc[t]) and who==sum(1<<i for i,(x,y) in enumerate(zip(cb[t],cc[t])) if x!=y)
        delta=F(c['end']['floor'])-F(b['end']['floor'])
        rr=dict(case=r['case'],input_sha=r['input_sha'],baseline=b,candidate=c,floor_delta=str(delta))
        out.append(rr)
        print(r['case'],flush=True)
    lossf=sum(r['baseline']['end']['full'] and not r['candidate']['end']['full'] for r in out)
    lossu=sum(r['baseline']['end']['useful'] and not r['candidate']['end']['useful'] for r in out)
    common=[r for r in out if all(r[k]['end']['full'] for k in ('baseline','candidate'))]
    floors=sum(F(r['floor_delta']) for r in common)
    worse4=sum(F(r['floor_delta']) < -4 for r in common)
    score=sum(r['candidate']['score']-r['baseline']['score'] for r in out)
    count=sum(r['candidate']['skip'][0]>=0 for r in out)
    kept=sum(r['candidate']['skip'][0]>=0 and not r['candidate']['skip'][-1] and F(r['floor_delta'])>=1
             for r in common)
    pass_gate=lossf==lossu==worse4==0 and floors>0 and score>0 and count>=20 and kept>=5
    z=dict(panel=panel,n=len(out),raw_losses=lossf,useful_losses=lossu,
      both_full=len(common),max_bad_bothfull_floor=worse4,bothfull_floor_total=str(floors),
      score_delta=score,triggers=count,retained_positive=kept,pass_gate=pass_gate,rows=out)
    (D/(panel+'.result.json')).write_text(json.dumps(z,indent=2)+'\n')
    print(json.dumps({k:x for k,x in z.items() if k!='rows'}))
    if not pass_gate:raise SystemExit(3)
if __name__=='__main__':
    main(sys.argv[1])
