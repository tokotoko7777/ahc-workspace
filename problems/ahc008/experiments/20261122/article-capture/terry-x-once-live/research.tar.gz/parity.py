"""Read old signed inputs only; compare same pure selector at every t<160."""
from pathlib import Path
from hashlib import sha256
import json,subprocess,sys
D=Path(__file__).resolve().parent;R=D.parent
P=R/'ahc008_terry_x_exact_replay'
assert sha256((P/'result.jsonl').read_bytes()).hexdigest()=='ad460c43a7a64bd10b3095046c074545b9362567891fd65d369d7411f9046519'
sys.path.insert(0,str(P))
import replay as Q
for path,digest in Q.PINS.items():assert Q.digest(path.read_bytes())==digest
sys.path.insert(0,str(Q.T))
from analyze import observed
from stochastic_lock_audit import idx
with (P/'result.jsonl').open() as fp:
    assert json.loads(fp.readline())==dict(parity=100,board_scores=100,opponent_lines=30000)
    expected={r['case']:r for r in json.load(fp)['rows']}
rows=json.loads((Q.T/'recordings.json').read_text())
assert len(rows)==len(expected)==100
menus=[set(map(int,m.split(','))) if m else set() for m in Q.menus()]
inp=[]; gold=[]; first=[]; golden=[]
for r in rows:
    key=r['case']; b=(Q.T/'tapes'/key).with_suffix('.actions')
    i,a,z=[p.read_bytes() for p in (Q.I/key,b,b.with_suffix('.trace'))]
    assert [Q.digest(p) for p in (i,a,z)]==[r[k] for k in ('input_sha','commands_sha','trace_sha')]
    act=a.decode().splitlines();tr=z.decode().splitlines()
    assert len(act)==300 and len(tr)==600 and tr[::2]==act
    _,H,_=observed(i,tr)
    sel=None
    m=r['map']
    for t,(p,h,w) in enumerate(H[:160]):
        p,h,w=list(map(idx,p)),list(map(idx,h)),Q.mask(map(idx,w))
        hit=Q.choose(t,w,h,p,act[t],menus[m])
        if hit is None: out=(-1,0)
        else:
            q,new=hit
            out=(q,sum(1<<i for i,(a,b) in enumerate(zip(act[t],new)) if a!=b))
            if sel is None:sel=(t,*out)
        gold.append(out)
        inp.append(' '.join(map(str,(t,m,len(p),len(h),format(w,'0900b'),act[t],*p,*h))))
    ref=expected[key].get('omit')
    assert (sel is None)==(ref is None)
    if ref:assert sel[:2]==(ref['t'],ref['omit']) and sel[2]>0
    first.append(sel)
got=subprocess.run([str(D/'selector_driver')],input='\n'.join(inp)+'\n',text=True,capture_output=True,timeout=30,check=True)
assert [tuple(map(int,s.split())) for s in got.stdout.splitlines()]==gold
assert sum(x is not None for x in first)==82
print(json.dumps(dict(signed_boards=100,rows=len(gold),first_omit=82,never_omit=18,pass_gate=True)))
