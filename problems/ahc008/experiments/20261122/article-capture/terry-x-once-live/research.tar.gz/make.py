"""Assemble local candidate and independent pure selector driver, no compiler."""
from pathlib import Path
from hashlib import sha256
import sys
D=Path(__file__).resolve().parent; R=D.parent
source=R/'ahc008_terry_virtual_chase_absorb/candidate.private.cpp'
P=R/'ahc008_terry_x_exact_replay'
assert sha256(source.read_bytes()).hexdigest()=='a237f7986e03ba94e98cfb6f1d2059f50d87305f6c8a82b1fa6d4ccd5f013f22'
assert sha256((P/'replay.py').read_bytes()).hexdigest()=='13009b7efacbf777154199d0e38659f6a14a578548fdaeb18aee1df8f4b3adc5'
sys.path.insert(0,str(P))
import replay
for path,digest in replay.PINS.items():assert replay.digest(path.read_bytes())==digest
raw=replay.menus()
# Each bitset string has highest cell first; only these static terrain constants
# enter the solver. No action/tape/result iterator ever touches the assembly.
m=[''.join(str(int(i in idx)) for i in range(899,-1,-1))
   for idx in (set(map(int,s.split(','))) if s else set() for s in raw)]
menu='static const std::array<std::bitset<900>,5> MENU={'+','.join('std::bitset<900>("'+s+'")' for s in m)+'};\n'
selector=(D/'selector.inc').read_text().replace('namespace optional_x_once {','namespace optional_x_once {\n'+menu,1)
a=source.read_text()
def one(h):
    assert a.count(h)==1
    return h
a=a.replace(one('int main(int argc,char** argv){'),selector+'\nint main(int argc,char** argv){')
a=a.replace(one(' NormalCount metrics;Decision d;'),''' NormalCount metrics;Decision d;
 int skip_turn=-1,skip_cell=-1,first_reinstall=-1;
 unsigned skip_actors=0;''')
anchor='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);\n  people_step(s,command);'
a=a.replace(one(anchor),'''  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);
  if(skip_cell<0&&turn<160){
   std::vector<int> ps;ps.reserve(s.pets.size());
   for(const auto& p:s.pets)ps.push_back(p.pos);
   const auto hit=optional_x_once::choose(turn,s.walls,s.people,ps,command,map);
   if(hit.cell>=0){
    skip_turn=turn;skip_cell=hit.cell;skip_actors=hit.actors;
    for(int i=0;i<int(command.size());i++)if(skip_actors>>i&1U)command[i]='.';
   }
  }
  people_step(s,command);
  if(skip_cell>=0&&first_reinstall<0&&s.walls[skip_cell])first_reinstall=turn;''')
end=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
a=a.replace(one(end),''' if(const char* p=std::getenv("AHC008_X_ONCE_LOG")){
  std::ofstream f(p);
  f<<skip_turn<<' '<<skip_cell<<' '<<skip_actors<<' '<<first_reinstall<<' '
   <<(skip_cell>=0&&s.walls[skip_cell])<<'\\n';
 }
'''+end)
(D/'candidate.private.cpp').write_text(a)
(D/'selector_driver.cpp').write_text('#pragma GCC optimize("O3")\n#include <bits/stdc++.h>\n'+selector+
'''int main(){
 std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
 int t,k,n,m;std::string w,cmd;
 while(std::cin>>t>>k>>n>>m>>w>>cmd){
  std::vector<int> p(n),h(m);
  for(auto& a:p)std::cin>>a;
  for(auto& a:h)std::cin>>a;
  auto x=optional_x_once::choose(t,std::bitset<900>(w),h,p,cmd,k);
  std::cout<<x.cell<<' '<<x.actors<<'\\n';
 }
}
''')
print('selected menus', [s.count('1') for s in m])
