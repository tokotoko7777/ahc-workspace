# a237 one-X native-adaptation contrast: frozen, not run

Baseline exact selected a237f7986e03ba94e98cfb6f1d2059f50d87305f6c8a82b1fa6d4ccd5f013f22.
Only one outer driver hook immediately after the sanitized real command
and before people_step+stdout. Do not change virtual trajectories, clocks,
distribution, public observations, RNG, construction planner or Normal /
Chase internals. Plan consumes its proposed work bit as usual and physical
State receives only the final submitted string, so next turns adapt normally
to the open tile and live judge replies. No special restoration or forbidden
wall: legitimate later stock rebuilds are allowed and tracked exactly.
Skip only once per case; never change non-target commands that turn. Every
removed target placement becomes wait. This does not claim future safety.

## Non-native preflight
Same topology menu and exact public predicate as frozen signed audit
13009b7e…: first row-major eligible target at earliest t<160, identical
per-human reachable pet ID sets and crew connectivity, all still reachable
pets >6 actual graph steps from candidate in skip projection. Pure C++
takes (turn, public walls/people/pets, finalized command, semantic map).
No seed/input hashing, archived results, or paper cases in live source.
The C++ check reorders equivalent conjuncts for cheap prefilter. Additional
cost up to two 900-site BFS component passes per distinct eligible candidate,
and radius-6 BFS; only on early live placement turns until once trigger.

A separate detached driver uses only older signed observations, no actual
solver, judge, or scorer. Verify case/input/action/tape hashes then compare
16,000 selector turn/target/actor-mask results against the frozen Python
projector and 82 first omit turns and addresses/18 none against old exact
official replay receipts. This checks translation, not adaptive quality.
Never use this roster in live code.

## Native admission then independent panel
After parity passes and explicit clearance, serial alternate a237 and
candidate ordering per case, same native flags, neither deadline nor
rollout limit altered. First panel exact official practice inputs and
order from the pinned native a237 practice receipt. Require every arm
official legal (300 lines), playback byte+score match and independent
score match, strict <2.95 s wall, no divergence in any command/pet/crew
state before trigger (all 275 Normal turns if untriggered), and same
sanitized trigger action apart from exact omitted actor mask. Verify any
later rebuild from actual final trace, not claimed by proposal. Keep
actual map, cut/rollout/mode telemetry, first catch details, full/useful
and floor. Report native late-clock variations separately for untriggered.

Gate per panel: aggregate score delta >0, no per-board raw full or useful
loss (thus no count loss), useful = full and mean floor ≥300, no
both-full case mean floor drop >4, aggregate both-full floor delta >0,
at least 20 actual triggers and at least 5 triggered both-full boards
with target never reinstalled and mean floor gain ≥1. Any failure stops;
no tuning/retry or independent testing for a failed practice. Output
diffs not adoption by themselves, and ≤1 direct wall cell gain/case.
Any approved adoption would be a separate decision.

Independent board seeds are committed now, not generated: first 8
bytes big-endian of SHA256(ASCII
`AHC008/x-once/a237/independent/frozen/v1/{i:03d}`) for i=0..99 in index
order. After practice passes, only after separate clearance, generate
using pinned official gen and assert exactly 100 unique hashes and
none in practice/older signed/accepted native fresh matrices. Never
change roster or reuse for tuning; generator seeds unavailable to
both live arms. No system tests.

After separate approval only:
```sh
D=ahc008_terry_x_once_live
python3 "$D/make.py"
g++ -std=gnu++23 "$D/selector_driver.cpp" -o "$D/selector_driver"
python3 "$D/parity.py"
# Only after parity + individual stage clearance.
g++ -std=gnu++23 ahc008_terry_virtual_chase_absorb/candidate.private.cpp -o "$D/baseline"
g++ -std=gnu++23 "$D/candidate.private.cpp" -o "$D/candidate"
python3 "$D/native.py" practice
# Only if practice passes and new approval arrives.
python3 "$D/native.py" independent
```
Keep assembled private source, signed old test state, seeds, real tapes,
temporary judge files and binaries local. Portable archive excludes them.
