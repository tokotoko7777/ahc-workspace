from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=raw.decode();wd=Path(__file__).parent
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
h=(wd.parent/'ahc008_v25_midpoint_certificate/midpoint.hpp').read_text().replace('#pragma once\n','')
rep('struct Game {',h+'\nstruct Game {')
f=(wd.parent/'ahc008_v25_midpoint_live/live.inc').read_text()
begin=f[:f.index(' void midpointImmediate(')]
end=f[f.index(' void midpointPaths('):f.index(' void midpointSelect(')]
rep(' string integratedBankPlan(){',begin+end+(wd/'audit.inc').read_text()+' string integratedBankPlan(){')
rep('   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;','''   if(midSpareOn&&m==5&&!terryBuild.inConstruction(turn)&&!partial)
    midSpareObserve(jobs,paths,ready,enabled,build,moveTo,usedPeople,shut);
   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;''')
rep('   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);\n  }\n  return act;','''   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);
  }
  if(!midSparePending.empty())midSpareAfter(usedPeople);
  return act;''')
rep("  cout<<g.act<<'\\n'<<flush;","  if(g.midSpareOn)g.midSpareFinal();\n  cout<<g.act<<'\\n'<<flush;")
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* p=getenv("AHC008_MIDPOINT_SPARE_LOG")){
  ofstream f(p);f<<g.midSpareLog.str();
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
