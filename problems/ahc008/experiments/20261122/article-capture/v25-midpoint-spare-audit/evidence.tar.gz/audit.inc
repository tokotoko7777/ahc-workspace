 bool midSpareOn=getenv("AHC008_MIDPOINT_SPARE_LOG")!=nullptr;
 vector<MidpointJob> midSparePending;
 bitset<V> midSpareBusy;
 string midSpareBase;
 ostringstream midSpareLog;
 void midSpareObserve(const vector<vector<BankJob>>& bank,const array<BankPath,10>& path,
       const vector<int>& ready,const vector<int>& enabled,const bitset<V>& build,
       const bitset<V>& moved,const bitset<V>& used,const bitset<terry_lane::MaxTubes>& shut){
  auto packed=packBankJobs(bank,2);
  if(packed.size()>1){midSpareLog<<turn<<" full\n";return;}
  auto available=used,now=moved;
  optional<BankJob> base;
  midSpareBase=act;
  if(!packed.empty()){
   base=packed.front();auto z=*base;
   available[z.a]=available[z.b]=true;
   const auto& t=banks[z.tube];
   for(auto [i,goal]:{pair{z.a,t.l},pair{z.b,t.h}}){
    int p=path[i].step[goal];
    if(p>=0&&!build[p])now[p]=true,midSpareBase[i]=MOVE[dir(humans[i],p)];
   }
  }
  if(available.count()>3){midSpareLog<<turn<<" exhausted\n";return;}
  midpointInit();
  vector<MidpointJob> options;
  int hi=0;
  midpointPaths(ready,enabled,build,now,available,shut,options,hi);
  auto in=[&](int p,int k){
   const auto& x=banks[k];
   return p>=0&&(p==x.g||p==x.k||find(x.inner.begin(),x.inner.end(),p)!=x.inner.end());
  };
  if(base){
   const auto z=*base;
   auto& x=banks[z.tube];
   int a=path[z.a].step[x.l],b=path[z.b].step[x.h];
   erase_if(options,[&](auto u){
    auto g=midGroups[u.group];
    auto gone=shut;
    if(!terryRoad.protects(z.tube,gone))return true;
    gone[z.tube]=true;
    for(int k:{g.a,g.b})
     if(k==z.tube||in(a,k)||in(b,k)||in(u.s,z.tube)||in(u.t,z.tube)||
        !terryRoad.protects(k,gone))return true;
    return false;
   });
  }
  erase_if(options,[](auto x){return x.s<0&&x.t<0;});
  midSpareLog<<turn<<" spare "<<packed.size()<<' '<<options.size()<<'\n';
  if(options.empty())return;
  hi=0;for(auto z:options)hi=max(hi,z.eta);
  const auto prior=mcDogs();
  const auto sample=terry_mc::sample_paths(mcState(),terrySim,64,hi,&prior);
  midpointValues(sample,options);
  midSparePending=move(options);
 }
 void midSpareAfter(const bitset<V>& used){midSpareBusy=used;}
 void midSpareFinal(){
  if(midSparePending.empty())return;
  for(auto z:midSparePending){
   bool empty=act[z.a]=='.'&&act[z.b]=='.';
   bool busy=midSpareBusy[z.a]||midSpareBusy[z.b];
   bool conflict=false,baseKept=true;
   for(int i=0;i<5;i++){
    if(i!=z.a&&i!=z.b&&midSpareBase[i]!='.'&&act[i]!=midSpareBase[i])baseKept=false;
    if(act[i]=='.')continue;
    int q=nb[humans[i]][string_view("UDLR").find(toupper(act[i]))];
    const auto& p=midGroups[z.group];
    if(q==z.s||q==z.t||q==p.l||q==p.r)conflict=true;
    for(int k:{p.a,p.b}){
     auto& x=banks[k];
     if(q==x.g||q==x.k||find(x.inner.begin(),x.inner.end(),q)!=x.inner.end())conflict=true;
    }
   }
   midSpareLog<<turn<<" alt "<<z.group<<' '<<z.a<<' '<<z.b<<' '<<z.eta<<' '<<z.s<<' '<<z.t<<' '
      <<z.value<<' '<<busy<<' '<<empty<<' '<<conflict<<' '<<baseKept<<' '<<act<<'\n';
  }
  midSparePending.clear();
 }
