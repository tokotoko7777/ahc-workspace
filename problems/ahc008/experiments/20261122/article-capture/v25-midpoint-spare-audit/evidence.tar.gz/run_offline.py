"""Original-policy offline stdin replay; never invokes the interactive tester."""
import argparse,collections,csv,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ahc008_focus_solver/problems/ahc008'))
from benchmark import replay

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for x in ('binary','ledger','inputs','tapes'):p.add_argument(x,type=Path)
    args=p.parse_args()
    rows=[q for q in csv.DictReader(args.ledger.open()) if q['model']=='baseline']
    assert len(rows)==30
    scores=collections.Counter()
    out={}
    with tempfile.TemporaryDirectory() as tmp:
        for ref in rows:
            c=ref['case']
            source=(args.inputs/c).read_bytes()
            assert hashlib.sha256(source).hexdigest()==ref['input_sha256']
            old=(args.tapes/c).with_suffix('.actions').read_bytes()
            assert hashlib.sha256(old).hexdigest()==ref['actions_sha256']
            trace=(args.tapes/c).with_suffix('.trace').read_text().splitlines()
            stock=old.decode().splitlines()
            assert len(stock)==300
            score,*_=replay(source.decode(),trace,stock,detailed=True)
            assert score==int(ref['score'])
            audit_file=Path(tmp)/c
            lines=source.splitlines()
            n=int(lines[0]);m=int(lines[n+1]);assert m==5
            public=b'\n'.join(lines[:n+m+2])+b'\n'
            stdin=public+('\n'.join(trace[1::2])+'\n').encode()
            res=subprocess.run([str(args.binary.resolve())],input=stdin,capture_output=True,
                env=dict(os.environ,AHC008_MIDPOINT_SPARE_LOG=str(audit_file)),check=True)
            current=res.stdout.decode().splitlines()
            assert len(current)==300
            first=next((t for t,(a,b) in enumerate(zip(stock,current,strict=True)) if a!=b),300)
            scores['full_exact']+=first==300
            if first!=300:
                scores['differing']+=1
            counts=collections.Counter()
            turns=collections.defaultdict(set)
            examples={}
            for line in audit_file.read_text().splitlines():
                t,kind,*x=line.split();t=int(t)
                if t>=first:continue
                turns[kind].add(t)
                if kind=='spare':
                    stock,geo=map(int,x)
                    if geo:
                        turns['physical_moves'].add(t)
                        turns[f'physical_stock{stock}'].add(t)
                elif kind=='alt':
                    group,a,b,eta,s,u=map(int,x[:6])
                    score=float(x[6])
                    busy,wait,conflict,same=map(int,x[7:11])
                    if not wait:
                        turns['would_override_issued'].add(t)
                        turns['paid_relay_brace_or_forecast' if busy else 'other_final_move_or_standby'].add(t)
                    if busy and wait:turns['would_override_paid_hold'].add(t)
                    if conflict or not same:turns['conflicting_or_old_changed'].add(t)
                    if not busy and wait and not conflict and same:
                        turns['strict_spare'].add(t)
                        example=dict(t=t,group=group,actors=[a,b],eta=eta,
                           steps=[s,u],projected=score,old=x[11])
                        if t not in examples or score>examples[t]['projected']:
                            examples[t]=example
            counts.update({k:len(v) for k,v in turns.items()})
            scores.update(counts)
            out[c]=dict(first_divergence=None if first==300 else first,counts=counts,
                examples=examples)
    boards={k:sum(v['counts'].get(k,0)>0 for v in out.values()) for k in scores}
    gate=sum(v['counts'].get('strict_spare',0)>=3 for v in out.values())
    print(json.dumps(dict(cases=len(rows),totals=scores,board_counts=boards,
       boards_with_three_spare_turns=gate,pass_gate=gate>=6,by_case=out),indent=2))
if __name__=='__main__':main()
