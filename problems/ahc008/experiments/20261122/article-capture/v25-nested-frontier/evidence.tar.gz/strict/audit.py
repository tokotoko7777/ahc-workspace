"""Offline two-cut stepped edge-frontier feasibility on unchanged v25-fast2 tapes."""
import argparse,csv,hashlib,itertools,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood

def cells(m):
    while m:
        b=m&-m
        yield b.bit_length()-1
        m^=b
def mask(q):return sum({B[p] for p in q})
def pos(r,c):return r*30+c
def grid(p):return divmod(p,30)
def md(a,b):return sum(abs(x-y) for x,y in zip(grid(a),grid(b)))
ADJ=[tuple(q for q in (p-30,p+30,p-1,p+1) if 0<=q<900 and md(p,q)==1) for p in range(900)]
NO_LEFT=ALL^mask(range(0,900,30));NO_RIGHT=ALL^mask(range(29,900,30))
def neighbors(m):return ((m<<30)|(m>>30)|((m&NO_LEFT)>>1)|((m&NO_RIGHT)<<1))&ALL

def rails(p,h):
    best=-1e10;choice=None
    for z in (0,1):
        for a in (4,8,12):
            value=0.
            def bp(r,c):return pos(c,r) if z else pos(r,c)
            for q in p:
                r,c=grid(q)
                if z:r,c=c,r
                if not 2<=r<=26:continue
                d=min(abs(c-(a+7*j+k)) for j in range(2) for k in range(2,6))
                value+=1./(1.+.8*d)
            for j in range(3):value-=.045*min(md(q,bp(14,a+7*j)) for q in h)
            if value>best:best,choice=value,(z,a)
    z,a=choice
    def bp(r,c):return pos(c,r) if z else pos(r,c)
    tubes=[]
    for j in range(2):
        for r in range(3,28,2):
            c=a+7*j
            footprint=mask(bp(r,k) for k in range(c,c+8))
            braces=mask(bp(r+d,c+k) for k in range(2,6) for d in (-1,1))
            tubes.append((footprint,braces))
    return choice,tubes

# Fixed catalog: fixed endpoint intervals, one two/three-cell depth
# change (at 1/3,1/2,2/3), and four edge orientations. No case IDs.
def templates():
    intervals=((0,10),(0,15),(0,20),(0,25),(0,29),(5,20),(5,25),
               (5,29),(10,25),(10,29),(15,29),(20,29))
    for edge in range(4):
        def trans(x,y):
            return (pos(x,y),pos(29-x,y),pos(y,x),pos(y,29-x))[edge]
        for lo,hi in intervals:
            for d,e in itertools.product((3,5,7,9,11,13),(0,2,-2,3,-3)):
                if not 2<=d+e<=15:continue
                fractions=(2,) if not e else (1,2,3)
                for f in fractions:
                    split=lo+(hi-lo+1)*f//4
                    region=mask(trans(x,y) for y in range(lo,hi+1)
                            for x in range(d+(e if y>=split else 0)))
                    yield (edge,lo,hi,d,e,split),region
CATALOG=tuple(templates())

def route_candidates(open_,stance,targets,limit):
    """Constructive assignment resource: each worker builds at most one per stage."""
    reach=[{p:0} for p in stance]
    for d,p in zip(reach,stance):
        queue=[p]
        for q in queue:
            if d[q]>=limit:continue
            for a in ADJ[q]:
                if open_&B[a] and a not in d:d[a]=d[q]+1;queue.append(a)
    return [tuple(sorted((r.get(a,999),i,a) for i,r in enumerate(reach)
                    for a in ADJ[q] if r.get(a,999)<=limit)) for q in targets]

def crew_plans(open_,h,cols,limit):
    rows=route_candidates(open_,h,cols,limit)
    def dfs(j,used,at,task):
        if j==len(rows):
            yield tuple(at),tuple(task)
            return
        for d,i,a in rows[j]:
            if used>>i&1:continue
            moved=at.copy();moved[i]=a
            yield from dfs(j+1,used|1<<i,moved,task+[(i,cols[j],a,d)])
    return dfs(0,0,list(h),[])

def open_legal(w,p,h):
    ban=mask(p)|mask(h)
    ban|=neighbors(mask(p))
    return not bool(w&ban)

def audit(w,p,h,post,tubes):
    op=ALL^w
    old=flood(B[h[0]],op)
    if any(not old&B[q] for q in h):return dict(disjoint_start=True)
    protect=0
    for body,braces in tubes:
        if w&braces==braces and not w&body and old&body==body:protect|=body
    floor=max(300,(3*old.bit_count()+3)//4)
    # Geometry first; dedup actual pending masks. Fixed 24 candidates per edge
    # after ranking by pending job count first, projected occupied-pose count
    # second, then retained area. No future tape poses in this selection.
    byedge={}
    for key,region in CATALOG:
        outside=op&~region
        seam=op&region&neighbors(outside)
        if not 1<=seam.bit_count()<=5 or seam&protect:continue
        if any(seam&B[q] for q in h):continue
        keep=flood(B[h[0]],op^seam)
        if keep.bit_count()<floor or (protect|mask(h))&~keep:continue
        lost=old&~(keep|seam)
        if not lost:continue
        hits=sum(bool(lost&B[q]) for q in p)
        byedge.setdefault(key[0],{}).setdefault(seam,(seam,keep,key,hits))
    sel=[]
    for choices in byedge.values():
        sel.extend(sorted(choices.values(),key=lambda x:(x[0].bit_count(),-x[3],-x[1].bit_count(),x[2]))[:24])
    counts=dict(catalog_geometry=len(sel),nested=0,scheduled=0,factual_pair=0,single_full=0)
    witness=[]
    single=set()
    p1,p2=post
    for cut,keep,key,_ in sel:
        captured1={i for i,q in enumerate(p1) if (old&~keep&~cut)&B[q]}
        # Possibility on observed first stage animals, with our projected
        # board and actual t160 humans. No factual future wall/worker inputs.
        first_possible=bool(captured1 and open_legal(cut,p1,h))
        rem1={i for i,q in enumerate(p1) if keep&B[q]}
        if first_possible and not rem1 and next(crew_plans(keep,h,list(cells(cut)),7),None) is not None:
            single.add(key)
        for cut2,rawkeep,key2,_ in sel:
            shared=cut&cut2
            if not shared or keep==rawkeep or rawkeep&~keep:continue
            pending=cut2&~cut
            if not pending:continue
            final=flood(B[h[0]],op&~(cut|cut2))
            if final.bit_count()<floor or (protect|mask(h))&~final or final==keep:continue
            counts['nested']+=1
            if not first_possible:continue
            # Animals on hypothetical first walls, or first-detached pets
            # factually recrossing that wall sequence, invalidate compatibility
            # of this tape with the deliberately fixed staged board.
            if any((cut|pending)&B[q] for q in p2):continue
            if any(keep&B[p2[i]] for i in captured1):continue
            captured2={i for i in rem1 if (keep&~(final|pending))&B[p2[i]]}
            if not captured2:continue
            if any((neighbors(mask(p2))|mask(p2))&B[q] for q in cells(pending)):continue
            for h1,jobs1 in crew_plans(final,h,list(cells(cut)),7):
                if not open_legal(cut,p1,h1):continue
                second=next(crew_plans(final,h1,list(cells(pending)),7),None)
                if second is None:continue
                h2,jobs2=second
                if not open_legal(pending,p2,h2):continue
                counts['scheduled']+=1
                counts['factual_pair']+=1
                witness.append(dict(first=key,second=key2,placed1=jobs1,placed2=jobs2,
                    shared=list(cells(shared)),retained=[keep.bit_count(),final.bit_count()],
                    pets1=sorted(captured1),pets2=sorted(captured2),
                    remaining=sum(bool(final&B[q]) for q in p2)))
                break
    counts['single_full']=len(single)
    counts['single_only']=bool(single and not witness)
    return dict(**counts,protected=protect.bit_count(),witnesses=witness[:8])

def run():
    ap=argparse.ArgumentParser(description=__doc__)
    for s in ('ledger','inputs','tapes'):ap.add_argument(s,type=Path)
    a=ap.parse_args()
    rows=[r for r in csv.DictReader(a.ledger.open()) if r['model']=='baseline']
    assert len(rows)==30 and all(r['humans']=='5' for r in rows)
    out={}
    for r in rows:
        case=r['case'];inp=(a.inputs/case).read_bytes()
        assert hashlib.sha256(inp).hexdigest()==r['input_sha256']
        raw=(a.tapes/case).with_suffix('.actions').read_bytes()
        assert hashlib.sha256(raw).hexdigest()==r['actions_sha256']
        cmd=raw.decode().splitlines()
        tape=(a.tapes/case).with_suffix('.trace').read_text().splitlines()
        score,*_=replay(inp.decode(),tape,cmd,detailed=True);assert score==int(r['score'])
        _,hist,_=observed(inp,tape)
        if int(r['reported_release'])!=160:
            out[case]={'inactive_release':int(r['reported_release'])}
            continue
        _,tubes=rails(list(map(idx,hist[0][0])),list(map(idx,hist[0][1])))
        p,h,w=hist[160]
        out[case]=audit(mask(map(idx,w)),tuple(map(idx,p)),tuple(map(idx,h)),
                 [tuple(map(idx,hist[t][0])) for t in (168,176)],tubes)
    count=lambda k:sum(bool(v.get(k)) for v in out.values())
    print(json.dumps(dict(boards=len(out),release160=30-count('inactive_release'),
           catalog_geometry_boards=count('catalog_geometry'),nested_boards=count('nested'),
           factual_pair_boards=count('factual_pair'),single_full_boards=count('single_full'),
           single_only_boards=count('single_only'),pass_gate=count('factual_pair')>=5,by_case=out),indent=2))
if __name__=='__main__':run()
