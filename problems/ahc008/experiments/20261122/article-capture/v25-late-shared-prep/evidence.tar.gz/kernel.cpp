#pragma GCC optimize("O3")
#include <bits/stdc++.h>
#include "lastcap_catalog.inc"
using namespace std;
using namespace lastcap;
int crewETA(const Planner::Shape& s,const vector<int>& h,const vector<int>& needs){
 if(needs.empty()||needs.size()>5)return -1;
 array<BFS,5> nav;
 for(int i=0;i<5;i++)if(!nav[i].run(h[i],s.can))return -1;
 array<int,32> dp;dp.fill(INF);dp[0]=0;
 for(unsigned mask=0;mask<32;mask++)if(dp[mask]<INF){
  unsigned j=popcount(mask);
  if(j>=needs.size())continue;
  for(int i=0;i<5;i++)if(!(mask>>i&1))
   for(int p:neighbors(needs[j]))if(p>=0&&nav[i].d[p]>=0){
    int v=mask|1<<i;
    dp[v]=min(dp[v],max(dp[mask],nav[i].d[p]));
   }
 }
 int best=INF;
 for(unsigned m=0;m<32;m++)if(size_t(popcount(m))==needs.size())best=min(best,dp[m]);
 return best==INF?-1:best;
}
int main(){
 ios::sync_with_stdio(false);cin.tie(nullptr);
 int count;cin>>count;
 while(count--){
  string id,cmd;int turn,n;cin>>id>>turn>>n>>cmd;
  Board w{},roads{},retreat{},root{};
  vector<int> h(5);vector<Pet> p(n);
  for(int& a:h)cin>>a;
  for(auto& a:p)cin>>a.p>>a.t;
  for(int i=0;i<V;i++){int x;cin>>x;w[i]=x;}
  int k;cin>>k;vector<int> protectedRoad(k);
  for(int& q:protectedRoad)cin>>q;
  BFS basin;int size=basin.run(h[0],Planner::walkable(w));
  for(int p=0;p<V;p++)root[p]=basin.d[p]>=0;
  for(int q:protectedRoad)if(root[q])roads[q]=1;
  retreat[h[0]]=1;
  int rem=0;for(auto q:p)rem+=root[q.p];
  if(size<300||rem<1||rem>2||any_of(h.begin(),h.end(),[&](int x){return !root[x];}))continue;
  Planner gen;vector<Planner::Shape> found;
  gen.search(turn,w,root,size,h,p,roads,found);
  if(roads!=retreat)gen.search(turn,w,root,size,h,p,retreat,found);
  map<vector<int>,Planner::Shape> unique;
  for(auto& s:found)if(s.kept>=300&&s.trapped==rem&&s.cut.size()>=2&&s.cut.size()<=6)
   unique.emplace(s.cut,s);
  int pair=0,shares=0,prep=0,route=0,blockedVariant=0,bothClear=0,strict=0,strictAsBuilt=0,strictDiffer=0;
  const auto occ=Planner::occupied(h,p);
  auto baselineGrid=w;
  auto afterH=h;
  vector<int> physicalWall(5,-1);
  for(int i=0;i<5;i++)if(cmd[i]!='.'){
   int d=string_view("UDLR").find(toupper(cmd[i]));
   int q=neighbors(h[i])[d];
   if(islower(cmd[i]))physicalWall[i]=q,baselineGrid[q]=1;
   else afterH[i]=q;
  }
  string witness;
  for(auto ai=unique.begin();ai!=unique.end();++ai)for(auto bi=next(ai);bi!=unique.end();++bi){
   const auto& a=ai->second;const auto& b=bi->second;
   vector<int> ab,ba,common;
   set_difference(a.cut.begin(),a.cut.end(),b.cut.begin(),b.cut.end(),back_inserter(ab));
   set_difference(b.cut.begin(),b.cut.end(),a.cut.begin(),a.cut.end(),back_inserter(ba));
   set_intersection(a.cut.begin(),a.cut.end(),b.cut.begin(),b.cut.end(),back_inserter(common));
   if(ab.empty()||ba.empty())continue;
   ++pair;
   if(common.empty())continue;
   ++shares;
   for(int pre:common)if(!w[pre]&&!occ[pre]){
    int actor=-1;
    for(int i=0;i<5;i++)if(a.can[h[i]]&&b.can[h[i]]&&
       find(h.begin(),h.end(),pre)==h.end()&&dist1(h[i],pre)==1){actor=i;break;}
    if(actor<0)continue;
    ++prep;
    // Certify the common wall itself does not disconnect people or trap
    // anybody from either eventual retained-side route.
    auto prepWorld=w;prepWorld[pre]=1;
    BFS after;after.run(h[0],Planner::walkable(prepWorld));
    if(any_of(h.begin(),h.end(),[&](int q){return after.d[q]<0;}))continue;
    vector<int> qa,qb;
    for(int q:a.cut)if(!prepWorld[q])qa.push_back(q);
    for(int q:b.cut)if(!prepWorld[q])qb.push_back(q);
    const int ta=crewETA(a,h,qa),tb=crewETA(b,h,qb);
    // 1 issued prep action + max 6 moves + 1 atomic seal. Check deadline.
    if(min(ta,tb)<0||max(ta,tb)>6||turn+1+max(ta,tb)>=300)continue;
    ++route;
    bool al=none_of(qa.begin(),qa.end(),[&](int q){return occ[q];});
    bool bl=none_of(qb.begin(),qb.end(),[&](int q){return occ[q];});
    if(al&&bl)++bothClear;
    if(al!=bl)++blockedVariant;
    // Stronger proof: preserve all original nonwait commands within issuance.
    // Model its exact other walls/moves, then recompute rather than assume
    // both candidate branches still work after this physical step.
    int actualActor=-1, idleActor=-1;
    for(int j=0;j<5;j++)if(dist1(h[j],pre)==1){
     if(physicalWall[j]==pre)actualActor=j;
     if(cmd[j]=='.')idleActor=j;
    }
    if(actualActor>=0||idleActor>=0){
     Board actualPrep=baselineGrid;actualPrep[pre]=1;
     auto A=a,B=b;
     BFS shared;shared.run(afterH[0],Planner::walkable(actualPrep));
     bool allRemain=true;
     for(auto q:p)if(root[q.p]&&(actualPrep[q.p]||shared.d[q.p]<0))allRemain=false;
     if(allRemain&&none_of(afterH.begin(),afterH.end(),[&](int q){return actualPrep[q]||shared.d[q]<0;})&&
        Planner::certify(A,actualPrep,afterH,p,root)&&Planner::certify(B,actualPrep,afterH,p,root)&&
        A.kept>=300&&B.kept>=300&&A.trapped==rem&&B.trapped==rem){
      vector<int> aa,bb;
      for(int q:A.cut)if(!actualPrep[q])aa.push_back(q);
      for(int q:B.cut)if(!actualPrep[q])bb.push_back(q);
      int da=crewETA(A,afterH,aa),db=crewETA(B,afterH,bb);
      if(aa!=bb&&min(da,db)>=0&&max(da,db)<=6&&turn+1+max(da,db)<300){
       ++strict;strictAsBuilt+=actualActor>=0;
       auto now=Planner::occupied(afterH,p);
       bool acl=none_of(aa.begin(),aa.end(),[&](int q){return now[q];});
       bool bcl=none_of(bb.begin(),bb.end(),[&](int q){return now[q];});
       strictDiffer+=acl!=bcl;
      }
     }
    }
    if(witness.empty()||al!=bl){
     ostringstream o;
     auto emit=[&](const vector<int>& q){
      for(size_t i=0;i<q.size();i++)o<<(i?"|":"")<<q[i];
     };
     o<<pre<<':'<<actor<<':'<<ta<<':'<<tb<<':'<<al<<':'<<bl<<':';emit(qa);o<<':';emit(qb);
     witness=o.str();
    }
   }
  }
  cout<<id<<' '<<turn<<' '<<rem<<' '<<found.size()<<' '<<unique.size()<<' '
      <<pair<<' '<<shares<<' '<<prep<<' '<<route<<' '<<bothClear<<' '<<blockedVariant<<' '<<strict<<' '<<strictAsBuilt<<' '<<strictDiffer
      <<' '<<(witness.empty()?"-":witness)<<'\n';
 }
}
