import argparse,collections,csv,hashlib,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'ahc008_v25_nested_frontier_audit')]
from audit import rails,mask,ALL,B,flood,idx
from benchmark import replay
from guarded_entry_trace import observed

KEYS='case turn residual candidates useful no_subset_pair common current_prep staffed both_unblocked different_block strict strict_stock_wall strict_different_block witness'.split()
def main():
    ap=argparse.ArgumentParser()
    for x in ('kernel','ledger','inputs','tapes'):ap.add_argument(x,type=Path)
    x=ap.parse_args()
    rows=[q for q in csv.DictReader(x.ledger.open()) if q['model']=='baseline']
    assert len(rows)==30
    out={r['case']:[] for r in rows}
    entered=set()
    lines=[]
    for ref in rows:
        case=ref['case'];raw=(x.inputs/case).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==ref['input_sha256']
        a=(x.tapes/case).with_suffix('.actions').read_bytes()
        assert hashlib.sha256(a).hexdigest()==ref['actions_sha256']
        cmd=a.decode().splitlines()
        tape=(x.tapes/case).with_suffix('.trace').read_text().splitlines()
        score,*_=replay(raw.decode(),tape,cmd,detailed=True)
        assert score==int(ref['score'])
        types,history,_=observed(raw,tape)
        (z,offset),_=rails(list(map(idx,history[0][0])),list(map(idx,history[0][1])))
        def bp(r,c):return c*30+r if z else r*30+c
        protect=sorted(set(bp(r,c) for c in range(offset,offset+15,7) for r in range(30))|
                       set(bp(r,c) for r in (0,29) for c in range(offset,offset+15)))
        last_good=False
        for t in range(225,290):
            p,h,w=history[t]
            p,h,w=list(map(idx,p)),list(map(idx,h)),set(map(idx,w))
            root=flood(B[h[0]],ALL^mask(w))
            rem=sum(bool(root&B[a]) for a in p)
            good=1<=rem<=2 and root.bit_count()>=300 and all(root&B[a] for a in h)
            if not good:
                last_good=False
                continue
            entered.add(case)
            if not last_good or (t-225)%4==0:
                lines.append((f'{case} {t} {len(types)} {cmd[t]}',' '.join(map(str,h)),
                              ' '.join(f'{q} {k}' for q,k in zip(p,types,strict=True)),
                              ' '.join(str(int(j in w)) for j in range(900)),
                              str(len(protect))+' '+' '.join(map(str,protect))))
            last_good=True
    ran=subprocess.run([str(x.kernel.resolve())],input=str(len(lines))+'\n'+
                       '\n'.join(s for row in lines for s in row)+'\n',
                       capture_output=True,text=True,check=True)
    parsed=0
    totals=collections.Counter();boards=collections.defaultdict(set)
    for row in ran.stdout.splitlines():
        z=dict(zip(KEYS,row.split(),strict=True));parsed+=1
        for k in KEYS[1:-1]:
            z[k]=int(z[k])
            if z[k]:boards[k].add(z['case'])
            totals[k]+=z[k]
        out[z['case']].append(z)
    assert parsed==len(lines)
    print(json.dumps(dict(cases=len(rows),eligible_cases=len(entered),samples=parsed,
        distinct_boards={k:len(v) for k,v in boards.items()},
        totals={k:v for k,v in totals.items() if k not in ('turn','residual')},
        by_case=out),indent=2))
if __name__=='__main__':main()
