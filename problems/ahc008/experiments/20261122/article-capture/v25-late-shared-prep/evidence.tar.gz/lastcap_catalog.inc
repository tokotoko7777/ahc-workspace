namespace lastcap {
constexpr int S=30,V=900,INF=100000000;
using Board=std::array<unsigned char,V>;
struct Pet{int p,t;};
inline std::array<int,4> neighbors(int p){return {p>=S?p-S:-1,p+S<V?p+S:-1,p%S?p-1:-1,p%S<S-1?p+1:-1};}
inline int dist1(int a,int b){return std::abs(a/S-b/S)+std::abs(a%S-b%S);}
inline int direction(int a,int b){auto z=neighbors(a);return int(std::find(z.begin(),z.end(),b)-z.begin());}
inline constexpr char MOVE[]="UDLR",BUILD[]="udlr";
struct BFS{
 std::array<int,V> d,first;
 int run(int src,const Board& can){
  d.fill(-1);first.fill(-1);if(!can[src])return 0;
  std::array<int,V> q;int n=1;q[0]=src;d[src]=0;
  for(int i=0;i<n;++i)for(int x:neighbors(q[i]))if(x>=0&&can[x]&&d[x]<0){
   d[x]=d[q[i]]+1;first[x]=i?first[q[i]]:x;q[n++]=x;
  }
  return n;
 }
};
struct Flow{
 struct Edge{int to,rev,cap;};
 std::vector<std::vector<Edge>> g;
 std::vector<int> d,at;
 explicit Flow(int n):g(n),d(n),at(n){}
 void add(int u,int v,int c){g[u].push_back({v,int(g[v].size()),c});g[v].push_back({u,int(g[u].size())-1,0});}
 void levels(int s){
  std::fill(d.begin(),d.end(),-1);std::vector<int> q{s};d[s]=0;
  for(size_t i=0;i<q.size();++i)for(auto e:g[q[i]])if(e.cap&&d[e.to]<0){d[e.to]=d[q[i]]+1;q.push_back(e.to);}
 }
 int send(int u,int t,int n){
  if(u==t)return n;
  for(int &j=at[u];j<(int)g[u].size();++j){
   auto &e=g[u][j];
   if(e.cap&&d[e.to]==d[u]+1){
    if(int k=send(e.to,t,std::min(n,e.cap))){e.cap-=k;g[e.to][e.rev].cap+=k;return k;}
   }
  }
  return 0;
 }
 int maxflow(int s,int t){
  int v=0;
  while(v<INF){levels(s);if(d[t]<0)break;std::fill(at.begin(),at.end(),0);
   while(v<INF){int f=send(s,t,INF-v);if(!f)break;v+=f;}}
  return v;
 }
};
struct Config{
 int start=146, maxAttempt=48, maxTotal=96, maxWalls=30, minArea=185;
 int retry=5, finalWait=9, maxPet=2;
};
struct Planner{
 Config cfg{};
 struct Shape{std::vector<int> cut;Board can{};int kept=0,trapped=0,cost=0;double value=-1;};
 Shape active;
 int began=-1, deadline=-1, total=0, retryAt=0, finalSince=-1;
 int attempts=0, actions=0, placed=0, closes=0, escapes=0, lanePlans=0, retreatPlans=0, protectionTier=0;
 std::array<int,10> pref{};
 Planner(){pref.fill(-1);}
 void reset(int turn){active={};began=-1;finalSince=-1;retryAt=turn+cfg.retry;pref.fill(-1);}
 static Board walkable(const Board& wall){Board b{};for(int p=0;p<V;++p)b[p]=!wall[p];return b;}
 static Board occupied(const std::vector<int>& humans,const std::vector<Pet>& pets){
  Board b{};
  for(auto a:pets){b[a.p]=1;for(int q:neighbors(a.p))if(q>=0)b[q]=1;}
  for(int h:humans)b[h]=1;
  return b;
 }
 static bool certify(Shape& z,const Board& wall,const std::vector<int>& humans,const std::vector<Pet>& pets,const Board& root){
  z.can=walkable(wall);for(int p:z.cut)z.can[p]=0;
  BFS b;z.kept=b.run(humans[0],z.can);
  for(int h:humans)if(b.d[h]<0)return false;
  for(int p=0;p<V;++p)if(b.d[p]<0)z.can[p]=0;
  z.trapped=0;
  for(auto a:pets)if(root[a.p]){
   if(std::find(z.cut.begin(),z.cut.end(),a.p)!=z.cut.end())return false;
   z.trapped+=!z.can[a.p];
  }
  if(!z.trapped)return false;
  for(int p:z.cut)if(!wall[p]){
   bool stance=false;for(int q:neighbors(p))if(q>=0&&z.can[q])stance=true;
   if(!stance)return false;
  }
  return true;
 }
 Shape search(int turn,const Board& wall,const Board& main,int size,
              const std::vector<int>& humans,const std::vector<Pet>& pets,const Board& protect,std::vector<Shape>& catalog){
  auto blocked=occupied(humans,pets);
  std::vector<BFS> ds(humans.size());
  auto open=walkable(wall);
  for(size_t i=0;i<humans.size();++i)ds[i].run(humans[i],open);
  std::array<int,V> eta;eta.fill(90);
  for(int p=0;p<V;++p)if(main[p])for(int q:neighbors(p))if(q>=0&&main[q])for(auto &b:ds)
    if(b.d[q]>=0)eta[p]=std::min(eta[p],b.d[q]);
  std::vector<int> ap;
  for(auto a:pets)if(main[a.p])ap.push_back(a.p);
  Shape best;
  const int n=ap.size(),H=humans.size(),horizon=std::min({299-turn,cfg.maxAttempt,cfg.maxTotal-total});
  if(horizon<2)return best;
  Board protectedNow=protect;
  for(int h:humans)protectedNow[h]=1;
  for(int subset=1;subset<(1<<n);++subset)for(int core:{1,2,3})for(int loss:{1,4}){
   if(n==2&&subset==3&&dist1(ap[0],ap[1])>15)continue;
   std::array<int,V> dist;dist.fill(100);
   for(int p=0;p<V;++p)for(int j=0;j<n;++j)if(subset>>j&1)
    dist[p]=std::min(dist[p],dist1(p,ap[j]));
   const int R=core+5;
   constexpr int s=V*2,t=V*2+1;
   Flow f(t+1);
   bool possible=true;
   for(int p=0;p<V;++p)if(main[p]&&dist[p]<R){
    if(dist[p]<=core&&protectedNow[p])possible=false;
    bool border=false;
    for(int q:neighbors(p))if(q>=0&&main[q]&&dist[q]>=R)border=true;
    const int cost=(protectedNow[p]||dist[p]<=core||eta[p]+2>=horizon)?INF:31+eta[p]*3+blocked[p]*6;
    f.add(p*2,p*2+1,cost);
    f.add(s,p*2,loss);
    if(border||protectedNow[p])f.add(s,p*2+1,INF),f.add(s,p*2,INF);
    if(dist[p]<=core)f.add(p*2,t,INF),f.add(p*2+1,t,INF);
    for(int q:neighbors(p))if(q>=0&&main[q]&&dist[q]<R)f.add(p*2+1,q*2,INF);
   }
   if(!possible||f.maxflow(s,t)>=INF)continue;
   Shape z;
   for(int p=0;p<V;++p)if(main[p]&&dist[p]<R&&f.d[p*2]>=0&&f.d[p*2+1]<0)z.cut.push_back(p);
   if(z.cut.empty()||int(z.cut.size())>cfg.maxWalls||!certify(z,wall,humans,pets,main))continue;
   int required=std::min(cfg.minArea,size*7/10);
   if(z.kept<required||z.kept*100<size*(z.trapped==1?65:45))continue;
   int far=0,near=0,left=0;
   for(int p:z.cut){far=std::max(far,eta[p]);near+=eta[p];left+=blocked[p];}
   int dur=far+2+int((z.cut.size()*2+H-1)/H)+left/2;
   if(dur>=horizon)continue;
   z.cost=dur;
   z.value=(double(z.kept*(1<<z.trapped))-size)/(1.+.045*dur+.034*z.cut.size()+.012*near);
   catalog.push_back(z);
   if(z.value>best.value)best=std::move(z);
  }
  return best;
 }
};
}
