from pathlib import Path
import hashlib,sys
src=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(src).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=src.decode()
a=s.index('namespace lastcap {')
b=s.index('\n#include <array>\nnamespace terry_maps::weights',a)
q=s[a:b]
assert q.count('const std::vector<Pet>& pets,const Board& protect){')==1
q=q.replace('const std::vector<Pet>& pets,const Board& protect){',
            'const std::vector<Pet>& pets,const Board& protect,std::vector<Shape>& catalog){')
assert q.count('   if(z.value>best.value)best=std::move(z);')==1
q=q.replace('   if(z.value>best.value)best=std::move(z);',
            '   catalog.push_back(z);\n   if(z.value>best.value)best=std::move(z);')
q=q[:q.index(' std::optional<std::string> plan(')]+'};\n}\n'
Path(sys.argv[2]).write_text(q)
