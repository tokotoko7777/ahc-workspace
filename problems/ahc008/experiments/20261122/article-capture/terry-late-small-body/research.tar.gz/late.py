"""Bounded retrospective actual late Chase closure geometry and actor paths."""
import collections,itertools,json,sys
from fractions import Fraction as F
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import observed,idx,mask,cells,sha,B,ALL,wave,snapshot,command_effect,flood,step
DIR='URDL'
def evaluate_value(reach,pets):
 return F(sum(a.bit_count()<<(len(pets)-sum(bool(a&B[q])for q in pets))for a in reach),len(reach)*(1<<len(pets)))
def no_split(o,n):
 return all(o[i]!=o[j] or n[i]==n[j]for i in range(len(o))for j in range(i))
def shape(tiles):
 rr,cc=zip(*(divmod(p,30) for p in cells(tiles)))
 n=tiles.bit_count()
 return (n==4 and ((max(rr)==min(rr)) or (max(cc)==min(cc)))) or (3<=n<=4 and (max(rr)-min(rr)+1)*(max(cc)-min(cc)+1)>n)
def bodies(seed,required,opened):
 seen={seed};queue=[seed]
 for body in queue:
  front=wave(body)&opened&~body
  if not required&~body and shape(body)and 1<=front.bit_count()<=2:yield body,front
  if body.bit_count()==4:continue
  for q in cells(front):
   z=body|B[q]
   if z not in seen:queue.append(z);seen.add(z)
def actor_paths(actor,start,end,H,C,role,old_touch,stats):
 states=[(H[start][1][actor],'')]
 for t in range(start,end):
  p,h,w=H[t];nw=H[t+1][2];cmd=C[t][actor]
  allowed=not cmd.islower() and ((role[t][actor]<0 and cmd=='.') or
               (role[t][actor]>=0 and bool(old_touch&B[role[t][actor]])))
  new=[]
  for q,s in states:
   if not allowed:
    if q!=h[actor]:stats['protected_pose']+=1;continue
    dst=H[t+1][1][actor]
    new.append((dst,s+cmd));continue
   for c in '.'+DIR:
    g=q if c=='.'else step(q,c)
    if g is not None and not nw&B[g]:new.append((g,s+c))
    else:stats['wall_path']+=1
  states=new
 return states
def event(t,pet_id,H,C,role,stats):
 p,h,w=H[t]; sw,sh=command_effect(h,w,p,C[t]);assert (sw,sh)==(H[t+1][2],H[t+1][1])
 old_id,old_reach,_=snapshot(sw,sh,p); pre=snapshot(w,h,p)[0]
 assert old_id&B[pet_id] and not pre&B[pet_id]
 large=flood(B[p[pet_id]],ALL^sw)
 assert large.bit_count()>8
 taken=(old_id&~pre)&sum(B[i]for i,q in enumerate(p)if large&B[q]); assert taken
 needed=mask(p[i]for i in cells(taken)); touch=(sw&~w)&wave(large)
 if not touch:raise AssertionError('new isolation without touching closure')
 builders={i for i,c in enumerate(C[t])if c.islower() and touch&B[step(h[i],c)]}
 free=sorted(builders|{i for i,m in enumerate(role[t])if m<0 and C[t][i]=='.'})
 surviving=sw^touch
 z0=evaluate_value(old_reach,p)
 all_shapes=list(bodies(needed&-needed,needed,ALL^surviving))
 stats['physical_shapes']+=len(all_shapes)
 if not all_shapes:return []
 variants=[]
 for lead in (0,2,3):
  if t-lead<275:continue
  paths={i:actor_paths(i,t-lead,t,H,C,role,touch,stats)for i in free}
  by=collections.defaultdict(list)
  for i,z in paths.items():
   for q,s in z:
    for c in DIR:
     ne=step(q,c)
     if ne is not None:by[ne].append((i,s,c.lower()))
  best=None
  for body,front in all_shapes:
   if front&w or wave(body)&~(body|surviving)!=front:continue
   options=[by[q]for q in cells(front)]
   if not all(options):continue
   for combo in itertools.product(*options):
    if len({i for i,s,c in combo})!=len(combo):continue
    owners={i:s for i,s,c in combo}; pose=H[t-lead][1].copy(); conflict=False
    for ix in range(lead):
     u=t-lead+ix;pu,hu,wu=H[u]
     old=command_effect(hu,wu,pu,C[u]);assert old==(H[u+1][2],H[u+1][1])
     alt=list(C[u])
     for i,s in owners.items():alt[i]=s[ix]
     move=command_effect(pose,wu,pu,alt)
     if not move or move[0]!=old[0]:
      stats['first_path_conflict_h'+str(lead)]+=1;conflict=True;break
     oi,orr,_=snapshot(old[0],old[1],pu);ni,nrr,_=snapshot(move[0],move[1],pu)
     if oi!=ni or any(a&~b for a,b in zip(orr,nrr)):
      stats['prep_connectivity_or_id']+=1;conflict=True;break
     pose=move[1]
    if conflict:continue
    cmd=list(C[t])
    for i in builders:cmd[i]='.'
    for i,_,c in combo:cmd[i]=c
    alt=command_effect(pose,w,p,cmd)
    if not alt or alt[0]!=(surviving|front):
     stats['closure_blocked']+=1;continue
    nw,nh=alt
    if flood(needed&-needed,ALL^nw)!=body:continue
    ids,nr,_=snapshot(nw,nh,p)
    if ids!=old_id:stats['closure_isolate_mismatch']+=1;continue
    if not no_split(old_reach,nr):stats['closure_split']+=1;continue
    gain=evaluate_value(nr,p)-z0
    if gain<=0:stats['no_gain']+=1;continue
    rank=(gain,-body,-front,tuple(combo))
    if best is None or rank>best[0]:
     best=(rank,dict(h=lead,turn=t,head_ids=list(cells(taken)),large=large.bit_count(),tiny=list(cells(body)),exact_gain=str(gain),
          unweighted_gain=str(F(sum(x.bit_count()-y.bit_count()for x,y in zip(nr,old_reach)),len(h))),
          old_walls=list(cells(touch)),new_walls=list(cells(front)),roles=combo))
  if best:variants.append(best[1])
 return variants

def main():
 out={}
 for panel,expected,inp in [('practice',8,R/'ahc008_focus_assets/tools/in'),
             ('fresh',11,R/'ahc008_terry_first_chase_reuse/default-fresh100/in')]:
  P=D/(panel+'-late');rows=json.loads((P/'recordings.json').read_text());assert len(rows)==expected
  stats=collections.Counter();found={}; labels=[]
  for rec in rows:
   name=rec['case'];raw=inp/name;a=(P/name).with_suffix('.actions');ta=a.with_suffix('.trace');rl=a.with_suffix('.roles')
   assert [sha(z)for z in (raw,a,ta,rl)]==[rec[z]for z in ('input_sha','commands_sha','trace_sha','roles_sha')]
   tape=ta.read_text().splitlines();c=a.read_text().splitlines();assert tape[::2]==c
   kinds,history,_=observed(raw.read_bytes(),tape)
   H=[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w)))for p,h,w in history]
   role={}
   for line in rl.read_text().splitlines():
    t,*who=map(int,line.split()); assert t not in role and len(who)==len(H[0][1])
    role[t]=who
   assert sorted(role)==list(range(275,300))
   assert len(rec['oversized'])==1
   t,i,k,large=map(int,rec['oversized'][0].split(':'))
   assert kinds[i]==k
   p,h,w=H[t-1]
   assert flood(B[p[i]],ALL^H[t][2]).bit_count()==large
   data=event(t-1,i,H,c,role,stats)
   labels.append(dict(case=name,turn=t-1,body=large,focal=i,replacement=bool(data)))
   if data:
    found[name]=dict(earliest=data[0],all_variants=data)
    stats['earliest_H'+str(data[0]['h'])+'_witness']+=1
    for d in data:stats['any_H'+str(d['h'])+'_witness']+=1
  gain=sum((F(x['earliest']['exact_gain'])for x in found.values()),F())
  out[panel]=dict(denominator=100,signed_boards=expected,witnesses=len(found),gain=str(gain),stats=dict(stats),cases=found,labels=labels)
 e=sum(z['witnesses']for z in out.values());g=sum(F(z['gain'])for z in out.values())
 r=dict(panels=out,pooled_diagnostic=dict(witnesses=e,boards=e,gain=str(g),mechanism_support=e>=5 and g>=20))
 (D/'late-report.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({p:{k:v for k,v in z.items()if k not in ('cases','labels')}for p,z in out.items()}))
 print(r['pooled_diagnostic'])
if __name__=='__main__':main()
