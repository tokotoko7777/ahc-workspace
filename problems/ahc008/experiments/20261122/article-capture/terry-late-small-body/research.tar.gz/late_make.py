from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
s=(D.parent/'ahc008_terry_virtual_chase_absorb/candidate.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='a237f7986e03ba94e98cfb6f1d2059f50d87305f6c8a82b1fa6d4ccd5f013f22'
a=' const auto stop=started+std::chrono::milliseconds(limit_ms);'
assert s.count(a)==1
s=s.replace(a,''' if(!std::getenv("AHC008_OVERSIZE_FIXED")||cap>10000)return 2;
 const auto stop=Clock::time_point::max();''')
(D/'replay.private.cpp').write_text(s)
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
assert s.count(a)==1,a
s=s.replace(a,'''  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);
  if(d.chose&&turn>=275){
   const char* p=std::getenv("AHC008_LATER_ROLES");if(!p)return 2;
   std::ofstream f(p,std::ios::app);
   terry_partition::ChaseReport detail;
   auto z=terry_partition::executeChase<MaxFlow<int>,terry_exact_ties::MinCostFlow<int,int>>(
    s.walls,cfg.aisleCells,s.people,pet_cells(s),turn,can_place(s),&detail);
   if(sanitize(s,std::vector<char>(z.begin(),z.end()))!=command)return 3;
   f<<turn;
   for(int i=0;i<m;++i)f<<' '<<(i<(int)detail.matching.size()?detail.matching[i]:-1);
   f<<'\\n';
  }''')
(D/'late.private.cpp').write_text(s)
