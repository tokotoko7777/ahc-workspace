"""One isolated five-worker-only trajectory count change."""
from pathlib import Path
import sys,hashlib
p,out=map(Path,sys.argv[1:])
data=p.read_bytes()
assert hashlib.sha256(data).hexdigest() in (
 '63cbdc9dbbd630d2836d7a77a7dff37af7d44e95aba56d42cd4000cdb2428619',
 '333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345')
text=data.decode()
a='const auto pathsMC=terry_mc::sample_paths(mcState(),terrySim,64,maxEta,&prior);'
b='const auto pathsMC=terry_mc::sample_paths(mcState(),terrySim,m==5?128:64,maxEta,&prior);'
assert text.count(a)==1
out.write_text(text.replace(a,b))
