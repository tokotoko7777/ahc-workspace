Before results: compare 64 vs128 shared guard trajectories for five
workers only against whichever exact speed baseline is adopted before
this candidate. The first 64 trajectory trial number/RNG draws are
unchanged; other budgets, geometry and M≠5 policy unchanged. No adaptive
trigger or raising of deadlines. Generate 100 newest M5 cases by official
generator: first 100 M=5 from decimal unsigned seeds from the first eight
SHA-256 digest bytes of:
ahc008-m5-guard128-confirm-20261122-v1: + decimal index 0..1199.
Use first30 as sequential pilot, remaining70 not treated as independently
reserved if any target settings tuned from pilot. Report actual early
four-cell isolation by100/160, full/useful≥300, score and runtime.
Pilot needs all legal+replay, max tester elapsed ≤2.25s, and no raw/useful
clear regression with actual early four-cell gains and score increase.
Full100 needs score/useful strictly improve and raw not fall; separately
confirm two fixed broad100s and a new appropriate M5 set before changing
research baseline. Reject rather than tune on same sample.
If the 30-case pilot passes, run an entirely separate 100-case held
stream using the same generator and a different salt ending
ahc008-m5-guard128-held-20261122-v1:. The first stream's remaining cases
are not used to decide promotion. Freeze source before running held.
