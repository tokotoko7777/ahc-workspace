#pragma GCC optimize("O3")
#include "terrain.hpp"
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include <iostream>
#include <numeric>
#include <random>
using namespace terry_exact_maps;
namespace e=exact_build;
using std::vector;
e::Layout cv(const Terrain& s){
 e::Layout y;for(int p=0;p<V;++p)y.ascii[p]=char(s.cells[p]);
 y.aisleRows=s.aisleRows;y.aisleCols=s.aisleColumns;return y;
}
struct Route{
 int estimate=e::INF;vector<vector<int>> orders;
};
struct Instance{
 Terrain t=terry_mixed_short::make();
 e::Board forbidden{};
 vector<e::BFS> paths=vector<e::BFS>(V);
 vector<int> sites, lane=vector<int>(V,-1);
 vector<vector<int>> jobs=vector<vector<int>>(V);
 vector<vector<int>> order;
 Instance(){
  auto z=labels(t.plannedWalls);int main=z.labels[t.aisleColumns[0]];
  for(int p=0;p<V;++p)forbidden[p]=z.labels[p]!=main;
  for(int p=0;p<V;++p)if(!forbidden[p]){
   paths[p].run(p,forbidden);
   std::pair<int,int> best{e::INF,-1};
   for(int c:t.aisleColumns)for(int r=0;r<W;++r)
    best=std::min(best,std::pair{paths[p].d[cell(r,c)],c});
   lane[p]=best.second;assert(lane[p]>=0);
  }
  const auto ad=[&](int p){int n=0;for(int q:adjacent(p))n+=q>=0&&t.planned(q);return n;};
  for(int w=0;w<V;++w)if(t.planned(w)){
   int winner=-1;std::tuple<int,int,int,int> best{e::INF,0,0,V};
   for(int p:adjacent(w))if(p>=0&&!forbidden[p]){
    int score=e::INF;for(int r=0;r<W;++r)score=std::min(score,paths[p].d[cell(r,lane[p])]);
    auto k=std::tuple{score,-ad(p),!(p/W&1),p};
    if(k<best){best=k;winner=p;}
   }
   assert(winner>=0);if(jobs[winner].empty())sites.push_back(winner);
   jobs[winner].push_back(w);
  }
  for(int mirror=0;mirror<4;++mirror){
   auto seq=sites;
   auto rank=[&](int p){
    int i=std::find(t.aisleColumns.begin(),t.aisleColumns.end(),lane[p])-t.aisleColumns.begin();
    if(mirror&1)i=3-i;
    int dy=((i&1)^bool(mirror&2))?29-p/W:p/W;
    int dx=(dy&1)?29-p%W:p%W;
    return std::tuple{i,dy,dx};
   };
   std::sort(seq.begin(),seq.end(),[&](int a,int b){return rank(a)<rank(b);});
   order.push_back(seq);
  }
 }
 // Deterministic shortest extraction to final-open region; run this first
 // while no construction issued, then never traverse a future wall/orphan.
 vector<int> extract(vector<int>& h) const {
  vector<int> turns(h.size());
  for(size_t i=0;i<h.size();++i)if(forbidden[h[i]]){
   e::BFS b;b.run(h[i],{});
   std::pair<int,int> best{e::INF,V};
   for(int p=0;p<V;++p)if(!forbidden[p])best=std::min(best,std::pair{b.d[p],p});
   assert(best.first<e::INF);
   int p=h[i];
   for(int k=0;k<best.first;++k){e::BFS bfs;bfs.run(p,{});p=bfs.first[best.second];assert(p>=0);}
   assert(p==best.second);h[i]=p;turns[i]=best.first;
  }
  return turns;
 }
 Route solve(const vector<int>& h)const{
  int M=h.size(),L=sites.size(),N=1<<M;
  Route result;
  for(const auto& seq:order){
   vector<int> length(L+1);
   for(int j=0;j<L;++j)length[j+1]=length[j]+jobs[seq[j]].size()+(j?paths[seq[j-1]].d[seq[j]]:0);
   struct Pr{int from=-1,i=-1;bool fw=true;};
   vector<int> dp(N*(L+1),e::INF);
   vector<Pr> prev(dp.size());
   dp[0]=0;
   auto index=[&](int k,int j){return k*(L+1)+j;};
   for(int k=0;k<N-1;++k)for(int j=0;j<L;++j)if(dp[index(k,j)]<e::INF)
    for(int r=j+1;r<=std::min(L,j+2*L/M);++r){
     int cost=length[r]-length[j]-(j?paths[seq[j-1]].d[seq[j]]:0);
     for(int i=0;i<M;++i)if(!(k>>i&1)){
      int da=paths[h[i]].d[seq[j]],db=paths[h[i]].d[seq[r-1]];
      bool fw=da<=db;
      int z=std::max(dp[index(k,j)],cost+std::min(da,db)),q=index(k|1<<i,r);
      if(z<dp[q]){dp[q]=z;prev[q]={j,i,fw};}
     }
    }
   if(dp.back()>=result.estimate)continue;
   result={dp.back(),vector<vector<int>>(M)};
   for(int k=N-1,b=L;k;){
    auto x=prev[index(k,b)];assert(x.from>=0);
    auto& r=result.orders[x.i];r.assign(seq.begin()+x.from,seq.begin()+b);
    if(!x.fw)std::reverse(r.begin(),r.end());
    k^=1<<x.i;b=x.from;
   }
  }
  return result;
 }
 int execute(vector<int> h,const Route& r)const{
  if(r.estimate>=e::INF)return e::INF;
  vector<int> j(h.size()),built(h.size());
  Board w;
  int turn=0;
  for(;w!=t.plannedWalls&&turn<500;++turn){
   auto next=h;int progress=0;
   for(size_t i=0;i<h.size();++i){
    if(j[i]==int(r.orders[i].size()))continue;
    int target=r.orders[i][j[i]],p=h[i];
    if(p!=target){next[i]=paths[p].first[target];assert(next[i]>=0&&!forbidden[next[i]]);}
    else{
     int g=jobs[target][built[i]++];
     assert(!w[g]&&t.planned(g)&&e::md(p,g)==1);
     assert(std::find(h.begin(),h.end(),g)==h.end());
     w[g]=true;
     if(built[i]==int(jobs[target].size())){built[i]=0;++j[i];}
    }
    ++progress;
   }
   assert(progress>0);
   for(int p:next)assert(!w[p]&&!forbidden[p]);
   h.swap(next);
  }
  assert(w==t.plannedWalls&&turn==r.estimate);
  return turn;
 }
};
std::pair<int,int> exec_stock(e::Crew s,vector<int> h,const Terrain& t){
 e::Board w{};
 for(int time=0;time<500;++time){
  int filled=0;for(int p=0;p<V;++p)filled+=w[p]&&t.planned(p);
  if(filled==int(t.plannedWalls.count()))return {time,filled};
  auto change=s.act_literal(w,h,{});
  for(int i=0;i<int(h.size());++i){
   char op=change.action[i];
   if(op=='.')continue;
   int dir=std::find(std::begin(e::Move),std::end(e::Move),op)-e::Move;
   if(dir<4){int p=adjacent(h[i])[dir];assert(p>=0&&!change.walls[p]);h[i]=p;}
  }
  if(w==change.walls&&change.action.find_first_not_of('.')==std::string::npos)return {e::INF,filled};
  w=change.walls;
 }
 int filled=0;for(int p=0;p<V;++p)filled+=w[p]&&t.planned(p);
 return {e::INF,filled};
}
int main(){
 Instance x;auto& base=terrain(2);
 std::mt19937 rng(7124151); vector<int> order(V),deltas,actual;std::iota(order.begin(),order.end(),0);
 for(int m=8;m<=10;++m)for(int n=0;n<12;++n){
  std::shuffle(order.begin(),order.end(),rng);
  vector<int> h(order.begin(),order.begin()+m),new_h=h;
  e::Crew stock;assert(stock.init(cv(base),h));
  auto [oldt,filled]=exec_stock(stock,h,base);
  auto prefix=x.extract(new_h);
  int enter=*std::max_element(prefix.begin(),prefix.end());
  auto r=x.solve(new_h);auto t=x.execute(new_h,r)+enter;
  std::cout<<m<<' '<<n<<' '<<stock.planned<<' '<<r.estimate<<' '<<enter<<' '<<t<<' '<<oldt<<' '<<filled<<'\n'<<std::flush;
  assert(t<e::INF);deltas.push_back(t-stock.planned);
  if(oldt<e::INF)actual.push_back(t-oldt);
 }
 auto ag=[](auto x){std::sort(x.begin(),x.end());return (x[(x.size()-1)/2]+x[x.size()/2])/2.;};
 std::cout<<"Median vs nominal stock "<<ag(deltas)<<"; same dry execution comparison "<<ag(actual)<<" n="<<actual.size()<<'\n';
}
