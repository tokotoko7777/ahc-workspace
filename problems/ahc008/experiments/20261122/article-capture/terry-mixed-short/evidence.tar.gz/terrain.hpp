#pragma once
#include "../ahc008_terry_exact_maps/terrain.hpp"
namespace terry_mixed_short {
using namespace terry_exact_maps;
struct Prison {Board body; int left=-1,right=-1;};
inline bool pairRow(int r){return r==7||r==15||r==23;}
inline Terrain make(std::vector<Prison>* specs=nullptr){
 Terrain z;z.aisleColumns={3,11,19,27};
 for(int r=0;r<W;++r){
  // Preserve ordinary mod-4 sweep rows. An added odd-row cap can only be
  // built from the same row, so mark its cap rows as sweeps too.
  bool sweep=(r%4==1)||((r&1)&&3<=r&&r<=27&&!pairRow(r));
  if(r&1)z.aisleRows.push_back(r);
  for(int c=0;c<W;++c)z.cells[cell(r,c)]=r&1?(sweep?Marker::Sweep:Marker::Room):Marker::Open;
 }
 auto wall=[&](int r,int c){const int p=cell(r,c);z.cells[p]=Marker::Wall;z.plannedWalls[p]=true;};
 auto mkdoor=[&](int p,Marker mark){if(p>=0){z.cells[p]=mark;z.doorCells[p]=true;}};
 auto room=[&](int r,int lo,int hi,int l,int h){
  const int a=l<0?-1:cell(r,l),b=h<0?-1:cell(r,h);
  mkdoor(a,b<0?Marker::LeftOne:Marker::LeftTwo);
  mkdoor(b,a<0?Marker::RightOne:Marker::RightTwo);
  Prison q{{},a,b};
  for(int c=lo;c<=hi;++c){wall(r-1,c);wall(r+1,c);q.body[cell(r,c)]=true;}
  if(specs)specs->push_back(q);
 };
 for(int r=3;r<=27;r+=2){
  room(r,0,1,-1,2);
  for(int a:{3,11,19}){
   if(pairRow(r))room(r,a+2,a+6,a+1,a+7);
   else{
    room(r,a+2,a+3,a+1,-1);
    room(r,a+5,a+6,-1,a+7);
    wall(r,a+4);
   }
  }
 }
 for(int r=0;r<W;++r)for(int c:z.aisleColumns){
  int p=cell(r,c);
  assert(!z.planned(p)&&!z.doorCells[p]);
  z.aisleCells[p]=true;z.cells[p]=Marker::Aisle;
 }
 return z;
}
}
