#include "terrain.hpp"
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include <iostream>
#include <numeric>
#include <random>
using namespace terry_exact_maps;
using namespace terry_mixed_short;
using std::cout;
exact_build::Layout cv(const Terrain& s){
 exact_build::Layout y;
 for(int p=0;p<V;++p)y.ascii[p]=char(s.cells[p]);
 y.aisleRows=s.aisleRows;y.aisleCols=s.aisleColumns;return y;
}
static Board mask(int a){Board r;r[a]=1;return r;}
static Board component(const Components& x,int c){Board b;for(int p=0;p<V;++p)if(x.labels[p]==c)b[p]=true;return b;}
int main(){
 std::vector<Prison> rooms;
 const auto t=make(&rooms);
 assert(t.plannedWalls.count()==244&&t.doorCells.count()==91&&rooms.size()==82);
 auto open=labels(t.plannedWalls),shut=labels(t.plannedWalls|t.doorCells);
 Board exterior=component(shut,shut.labels[cell(0,t.aisleColumns.front())]),allRooms;
 assert((t.aisleCells&~exterior).none());
 for(const auto& q:rooms){
  int s=-1;
  for(int p=0;p<V;++p)if(q.body[p]){
   if(s<0)s=p;
   assert(open.labels[p]==open.labels[cell(0,t.aisleColumns.front())]);
  }
  assert(component(shut,shut.labels[s])==q.body);
  assert((q.body&allRooms).none());allRooms|=q.body;
  for(int p:{q.left,q.right})if(p>=0){
   Board subset=t.doorCells;subset[p]=false;
   auto one=labels(t.plannedWalls|subset);
   assert(one.labels[s]==one.labels[cell(0,t.aisleColumns.front())]);
  }
 }
 const Rooms dynamic=classify(t,t.plannedWalls,{}, {cell(0,t.aisleColumns.front())});
 assert(dynamic.count()==int(rooms.size()));
 for(const auto& q:rooms){
  int id=-1;for(int p=0;p<V;++p)if(q.body[p]){
   if(id<0)id=dynamic.ids[p];
   assert(id==dynamic.ids[p]);
  }
  auto d=dynamic.rooms.at(id);
  assert(d.left==q.left&&d.right==q.right&&d.size==int(q.body.count())+(q.left>=0)+(q.right>=0));
 }
 const auto& base=terrain(2);
 auto old_open=labels(base.plannedWalls),old_closed=labels(base.plannedWalls|base.doorCells);
 int b0=old_closed.labels[cell(0,base.aisleColumns.front())];
 Board main2=component(old_closed,b0);
 Board orphan=~(t.plannedWalls|t.doorCells|exterior|allRooms);
 cout<<"new walls "<<t.plannedWalls.count()<<", doors "<<t.doorCells.count()<<", exact body rooms "<<rooms.size()
     <<", closed exterior "<<exterior.count()<<", orphan floor "<<orphan.count()<<", stock map2 closed exterior "<<main2.count()<<'\n';
 // Nominal distance from a cell in truly open board to a gate-legal
 // interior tile; captures no live path/forecast semantics.
 std::vector<int> near(V,999), queue;
 for(const auto& q:rooms)for(int p=0;p<V;++p)if(q.body[p]){
  bool ok=true;
  for(int g:{q.left,q.right})if(g>=0&&(mask(g)[p]||exact_build::md(g,p)==1))ok=false;
  if(ok&&near[p]){near[p]=0;queue.push_back(p);}
 }
 for(size_t i=0;i<queue.size();++i)for(int p:adjacent(queue[i]))if(p>=0&&near[p]==999){
  near[p]=near[queue[i]]+1;queue.push_back(p);
 }
 cout<<"nearest safe center open-grid distances mean "<<std::accumulate(near.begin(),near.end(),0)/900.
     <<" max "<<*std::max_element(near.begin(),near.end())<<" left/right max ";
 for(int c:{0,29}){int h=0;for(int r=0;r<W;++r)h=std::max(h,near[cell(r,c)]);cout<<h<<' ';}cout<<'\n';
 std::mt19937 rng(7124151);
 std::vector<int> order(V),deltas;std::iota(order.begin(),order.end(),0);
 auto a=cv(base),b=cv(t);
 for(int m=8;m<=10;++m)for(int n=0;n<12;++n){
  std::shuffle(order.begin(),order.end(),rng);
  std::vector<int> h(order.begin(),order.begin()+m);
  auto old=exact_build::initialize(a,h),now=exact_build::initialize(b,h);
  assert(old.makespan<exact_build::INF&&now.makespan<exact_build::INF);
  Board jobs;int duplicated=0,future_wall_stances=0,orphan_stances=0;
  for(const auto& q:now.q)for(auto job:q){
   if(job.mask&&t.planned(job.at))++future_wall_stances;
   if(job.mask&&orphan[job.at])++orphan_stances;
   for(int d=0;d<4;++d)if(job.mask>>d&1){
    int p=adjacent(job.at)[d];assert(p>=0&&t.planned(p));
    duplicated+=jobs[p];jobs[p]=true;
   }
  }
  deltas.push_back(now.makespan-old.makespan);
  cout<<m<<' '<<n<<' '<<old.makespan<<' '<<now.makespan<<' '<<jobs.count()<<' '<<duplicated
      <<' '<<future_wall_stances<<' '<<orphan_stances<<'\n';
 }
 std::sort(deltas.begin(),deltas.end());
 cout<<"median paired nominal difference "<<(deltas[17]+deltas[18])*0.5<<'\n';
}
