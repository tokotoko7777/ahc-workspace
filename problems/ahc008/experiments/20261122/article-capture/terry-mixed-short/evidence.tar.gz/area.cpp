#include "terrain.hpp"
#include <tuple>
#include <iostream>
#include <numeric>
#include <random>
using namespace terry_exact_maps;
int main(){
 const auto base=terrain(2),alt=terry_mixed_short::make();
 std::mt19937 gen(92640);
 for(const Terrain* layout:{&base,&alt}){
  const auto& t=*layout;int anchor=cell(0,t.aisleColumns[0]);
  std::vector<int> gates;
  for(int p=0;p<V;++p)if(t.doorCells[p])gates.push_back(p);
  auto assess=[&](const Board& w){
   auto c=labels(w);int floor=0,orphan=0;
   std::vector<int> count(c.count,0),d;
   std::vector<bool> road(c.count,false);
   for(int p=0;p<V;++p)if(c.labels[p]>=0){++count[c.labels[p]];if(t.aisle(p))road[c.labels[p]]=true;}
   for(int k=0;k<c.count;++k)if(road[k])d.push_back(count[k]);else if(count[k]==1)++orphan;
   return std::tuple{count[c.labels[anchor]],orphan,d};
  };
  std::cout<<(layout==&base?"stock":"mixed")<<'\n';
  for(int i=0;i<2;++i){
   auto [a,o,d]=assess(i?t.plannedWalls|t.doorCells:t.plannedWalls);
   std::cout<<(i?"sealed":"open")<<" anchor "<<a<<" road comps";
   for(int x:d)std::cout<<' '<<x;
   std::cout<<" orphan_singletons "<<o<<'\n';
  }
  std::vector<int> a,served,multi;
  for(int rep=0;rep<200;++rep){
   std::shuffle(gates.begin(),gates.end(),gen);
   Board w=t.plannedWalls;
   for(int i=0;i<20;++i)w[gates[i]]=true;
   auto [x,o,d]=assess(w);a.push_back(x);
   served.push_back(std::accumulate(d.begin(),d.end(),0));
   multi.push_back(int(d.size()));
  }
  auto show=[&](auto z){
   std::sort(z.begin(),z.end());
   std::cout<<z.front()<<' '<<(z[99]+z[100])*0.5<<' '<<z.back()<<' '<<std::accumulate(z.begin(),z.end(),0)/200.<<'\n';
  };
  std::cout<<"random20 anchor min median max mean ";show(a);
  std::cout<<"random20 all road cells min median max mean ";show(served);
  std::cout<<"random20 component count min median max mean ";show(multi);
  auto rooms=classify(t,t.plannedWalls,{}, {anchor});
  std::vector<std::vector<int>> proper;
  for(const auto& room:rooms.rooms){
   std::vector<int> gates_of_room;
   if(room.left>=0)gates_of_room.push_back(room.left);
   if(room.right>=0)gates_of_room.push_back(room.right);
   if(!gates_of_room.empty())proper.push_back(gates_of_room);
  }
  a.clear();served.clear();
  for(int rep=0;rep<200;++rep){
   std::shuffle(proper.begin(),proper.end(),gen);
   Board w=t.plannedWalls;
   for(int i=0;i<15;++i)for(int gate:proper[i])w[gate]=true;
   auto [x,o,d]=assess(w);
   if(d.size()!=1)continue;
   a.push_back(x);
  }
  std::cout<<"random15 rooms connected draws "<<a.size()<<'\n';
  if(!a.empty()){
   std::sort(a.begin(),a.end());size_t n=a.size();
   std::cout<<"random15 room connected area min median max mean "<<a.front()<<' '
    <<(a[(n-1)/2]+a[n/2])*0.5<<' '<<a.back()<<' '<<std::accumulate(a.begin(),a.end(),0)/double(n)<<'\n';
  }

 }
}
