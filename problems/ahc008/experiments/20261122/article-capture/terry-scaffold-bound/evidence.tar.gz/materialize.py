"""Optional *future* official recording only; never run during another timed batch."""
import argparse,csv,hashlib,json,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
H=ROOT/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark_cases import run
from benchmark import replay

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('tester','solver','inputs','ledger','output'):p.add_argument(k,type=Path)
    p.add_argument('--case',action='append',default=[])
    p.add_argument('--default-clock',action='store_true',help='No logged --pairs=N cap')
    a=p.parse_args()
    rows=[v for v in csv.DictReader(a.ledger.open()) if v['arm']=='terry_independent'
          and (not a.case or v['case'] in a.case)]
    a.output.mkdir(parents=True,exist_ok=True)
    omitted={}
    for r in rows:
        name=r['case'];case=(a.inputs/name).read_bytes()
        assert hashlib.sha256(case).hexdigest()==r['input_sha']
        count=int(r['telemetry'].split()[10])
        opts=[] if a.default_clock else [f'--pairs={count}']
        out,err,rc,_=run([str(a.tester.resolve()),str(a.solver.resolve()),*opts],case,4.5)
        if (rc!=0 or err.strip()!=f"Score = {r['score']}".encode()
            or hashlib.sha256(out).hexdigest()!=r['commands_sha']):
            omitted[name]=dict(score_report=err.decode(errors='replace').strip(),rc=rc,pair_cap=count,
                   output_sha=hashlib.sha256(out).hexdigest())
            print('not exact',name,flush=True)
            continue
        with tempfile.TemporaryDirectory() as d:
            tp=Path(d)/'case.actions';tr=Path(d)/'case.trace';tp.write_bytes(out)
            q,e,c,_=run([str(a.tester.resolve()),sys.executable,str(H/'benchmark_cases.py'),
                         '--playback',str(tp),str(tr)],case,12.0)
            assert (q,e,c)==(out,err,rc)
            score,*_=replay(case.decode(),tr.read_text().splitlines(),out.decode().splitlines(),detailed=True)
            assert score==int(r['score'])
            for v in (tp,tr):
                (a.output/Path(name).with_suffix(v.suffix)).write_bytes(v.read_bytes())
            print('exact',name,flush=True)
    print(json.dumps(dict(requested=len(rows),not_exact=omitted),indent=2))
if __name__=='__main__':main()
