"""Exact achievable score from irreversible 'stop all commands once whole' rule.
Requires matching factual transcripts, never modifies or reruns a solver.
"""
import argparse,csv,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ahc008_focus_solver/problems/ahc008/experiments/20261122'))
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood
def execute(ledger,inputs,tapes):
 rows=[x for x in csv.DictReader(ledger.open()) if x['arm']=='terry_independent']
 details=[]
 for x in rows:
  raw=(inputs/x['case']).read_bytes();stem=Path(x['case']).stem
  assert hashlib.sha256(raw).hexdigest()==x['input_sha']
  assert hashlib.sha256((tapes/(stem+'.actions')).read_bytes()).hexdigest()==x['commands_sha']
  _,hist,_=observed(raw,(tapes/(stem+'.trace')).read_text().splitlines())
  if x['full']=='0':continue
  def state(t):
   ps,hs,ws=hist[t]
   p=sum({B[idx(q)] for q in ps});h=sum({B[idx(q)] for q in hs})
   w=ALL^sum(B[idx(q)] for q in ws)
   return not bool(flood(h,w)&p),h,w,hs
  a,b=0,300
  while a<b:
   m=(a+b)//2
   if state(m)[0]:b=m
   else:a=m+1
  yes,_,w,hs=state(a)
  assert yes
  raw_score=round(1e8*sum(flood(B[idx(h)],w).bit_count()/900 for h in hs)/len(hs))
  cur=int(x['score']);d=raw_score-cur
  assert d>=0,d
  details.append(dict(case=x['case'],turn=a,walls_after=len(hist[300][2])-len(hist[a][2]),score_delta=d))
 return dict(full=len(details),improved=sum(x['score_delta']>0 for x in details),delta=sum(x['score_delta'] for x in details),
             boards_with_later_walls=sum(x['walls_after']>0 for x in details),details=details)
if __name__=='__main__':
 p=argparse.ArgumentParser()
 for n in ('ledger','inputs','tapes'):p.add_argument(n,type=Path)
 args=p.parse_args()
 print(json.dumps(execute(args.ledger,args.inputs,args.tapes),indent=2))
