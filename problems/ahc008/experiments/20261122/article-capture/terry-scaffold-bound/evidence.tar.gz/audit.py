"""Offline noncausal upper and constructive lower bounds for unused walls."""
import argparse,csv,collections,hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
H=ROOT/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood,wave
from benchmark import replay

def cells(mask):
    while mask:
        low=mask&-mask;mask^=low;yield low.bit_length()-1
def bitmask(q):
    return sum({B[i] for i in q})
def planned_masks(path):
    # Read semantic numeric wall masks (not raw reference/art). Physical
    # row expansion mirrors the independently fingerprinted terrain helper.
    rows=[]
    for group in re.split(r'// map \d\s*\n',path.read_text())[:-1]:
        first=[int(q,16) for q in re.findall(r'\{(0x[0-9a-f]+)u,',group)]
        assert len(first)==5
        combined=0
        for r in range(30):
            c=0 if r==0 else 1 if not r%2 else 3 if r%4==3 else 4 if len(rows)==4 and r%8==5 else 2
            combined|=first[c]<<(30*r)
        rows.append(combined)
    assert [r.bit_count() for r in rows]==[335,290,260,233,284]
    return rows

def labels(open_):
    rest=open_; dst={}
    parts=[]
    while rest:
        q=flood(rest&-rest,rest)
        for p in cells(q):dst[p]=len(parts)
        parts.append(q)
        rest^=q
    return dst,parts

def area(wall,people,animals):
    # Decode independent human groups; the score for a full state counts
    # each original person's own (possibly distinct) component once.
    op=ALL^wall; left=bitmask(people);union=0;u=0
    while left:
        comp=flood(left&-left,op)
        left &= ~comp;union|=comp
        u+=comp.bit_count()*sum(bool(B[h]&comp) for h in people)
    safe=not (union&animals)
    return safe,u,union.bit_count(),union

def candidates(mask):
    """Maximal horizontal runs intersected with real installed planned X."""
    for r in range(30):
        j=0
        while j<30:
            if not mask&B[r*30+j]:
                j+=1;continue
            i=j
            while j<30 and mask&B[r*30+j]:j+=1
            yield bitmask(r*30+k for k in range(i,j))

def inspect(wall,planned,people,petList,hist):
    animals=bitmask(petList)
    baseline=area(wall,people,animals)
    assert baseline[0]
    op=ALL^wall;x=wall&planned;installed=x.bit_count()
    ids,parts=labels(op)
    components_with_pets={ids[p] for p in petList}
    components_with_people={ids[q] for q in people}
    assert components_with_people.isdisjoint(components_with_pets)
    solo_human=0;unsafe=0;safe=0
    singles=[]
    for p in cells(x):
        touched={ids[q] for q in cells(wave(B[p])&op)}
        # Exact monotonic separator certificate: adding a single new
        # vertex joins precisely the existing open components it touches.
        cannot=bool(touched&components_with_people and touched&components_with_pets)
        if cannot:
            unsafe|=B[p];continue
        safe|=B[p]
        practical=bool(touched and touched<=components_with_people)
        if practical:solo_human|=B[p]
        test=area(wall^B[p],people,animals)
        assert test[0]
        if test[1]>baseline[1]:
            singles.append(dict(cell=p,extra_total_human_area=test[1]-baseline[1],only_human_neighbors=practical))
    assert unsafe.bit_count()+safe.bit_count()==installed
    # All cells unsafe in isolation are provably mandatory in any safe
    # simultaneous removal. Open all the rest for a relaxed UPPER bound.
    upper=area(wall^safe,people,animals)
    assert upper[1]>=baseline[1]
    # Evaluate maximal horizontal planned runs on the exact final original
    # board, and then construct one safe subset by monotonic repeated removal.
    valid_groups=[]
    groups=list(candidates(x))
    for g in groups:
        if g.bit_count()<2 or g&unsafe:continue
        z=area(wall^g,people,animals)
        if z[0] and z[1]>baseline[1]:
            valid_groups.append(dict(cells=list(cells(g)),extra_total_human_area=z[1]-baseline[1],
                only_human_neighbors=not (wave(g)&op&~baseline[3])))
    removed=solo_human
    assert area(wall^removed,people,animals)[0]
    for g in sorted(groups,key=lambda m:(m.bit_count(),m)):
        if not g&unsafe and area(wall&~(removed|g),people,animals)[0]:removed|=g
    for p in cells(safe&~removed):
        g=removed|B[p]
        if area(wall&~g,people,animals)[0]:removed=g
    achieved=area(wall^removed,people,animals)
    assert achieved[0] and 0<=removed.bit_count()<=safe.bit_count()
    assert baseline[1]<=achieved[1]<=upper[1]
    work_turn={}
    prev=0
    for t,(_,_,blocked) in enumerate(hist):
        w=bitmask(map(idx,blocked))
        for p in cells((w^prev)&x):
            if w&B[p]:work_turn[p]=t
        prev=w
    return dict(baseline_mean=baseline[1]/len(people),installed=installed,
       unsafe_single=unsafe.bit_count(),safe_single=safe.bit_count(),
       human_only_single=solo_human.bit_count(),gainful_single=len(singles),
       single_witness=singles[:8],profitable_safe_horizontal_runs=len(valid_groups),
       horizontal_witness=valid_groups[:8],removed_certified=removed.bit_count(),
       removed_certified_built_by100=sum(work_turn[p]<=100 for p in cells(removed)),
       removed_certified_built_by160=sum(work_turn[p]<=160 for p in cells(removed)),
       certified_mean=achieved[1]/len(people),upper_mean=upper[1]/len(people),
       upper_is_actually_pet_free=upper[0],
       certified_extra_mean=(achieved[1]-baseline[1])/len(people),
       upper_extra_mean=(upper[1]-baseline[1])/len(people))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('ledger','inputs','tapes'):p.add_argument(k,type=Path)
    p.add_argument('--allow-missing',action='store_true')
    a=p.parse_args()
    maps=planned_masks(ROOT/'ahc008_terry_exact_maps/terrain_data.inc')
    rows=[x for x in csv.DictReader(a.ledger.open()) if x['arm']=='terry_independent']
    out={};omitted={}
    for ref in rows:
        n=ref['case']
        f=(a.tapes/n).with_suffix('.actions')
        t=(a.tapes/n).with_suffix('.trace')
        if not f.is_file() or not t.is_file():
            if not a.allow_missing:raise FileNotFoundError(f'{f} or {t}')
            omitted[n]='no_matching_tape';continue
        data=(a.inputs/n).read_bytes()
        assert hashlib.sha256(data).hexdigest()==ref['input_sha']
        actions=f.read_bytes();assert hashlib.sha256(actions).hexdigest()==ref['commands_sha']
        cmd=actions.decode().splitlines();trace=t.read_text().splitlines()
        score,*_=replay(data.decode(),trace,cmd,detailed=True);assert score==int(ref['score'])
        _,hist,_=observed(data,trace)
        animals,people,walls=hist[-1]
        people=list(map(idx,people));animals=list(map(idx,animals));walls=bitmask(map(idx,walls))
        assert area(walls,people,bitmask(animals))[0]==bool(int(ref['full']))
        if not int(ref['full']):continue
        expected=int(ref['telemetry'].split()[0])
        plan=maps[expected]
        assert (walls&plan).bit_count()==int(ref['telemetry'].split()[2])
        out[n]=dict(map=expected,official_factual_score=score,
            **inspect(walls,plan,people,animals,hist))
    results={}
    if out:
        for k in ('baseline_mean','certified_mean','upper_mean','installed','unsafe_single','safe_single',
                  'human_only_single','gainful_single','profitable_safe_horizontal_runs','removed_certified',
                  'removed_certified_built_by100','removed_certified_built_by160'):
            results[k]=sum(d[k] for d in out.values())/len(out)
        # Not a legal score; because every certified result remains pet-free,
        # this is the raw sum of the unrounded exact area-vs-score relaxation.
        results['certified_counterfactual_score_delta_unrounded']=sum(r['certified_extra_mean'] for r in out.values())*1e8/900
        results['upper_counterfactual_score_delta_unrounded']=sum(r['upper_extra_mean'] for r in out.values())*1e8/900
    print(json.dumps(dict(ledger_cases=len(rows),full_cases_analyzed=len(out),omitted=omitted,
               averages=results,by_case=out),indent=2))
if __name__=='__main__':main()
