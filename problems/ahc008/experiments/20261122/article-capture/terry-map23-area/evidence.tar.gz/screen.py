"""Frozen prelude-only eligibility; no contestant, judge, or outcomes."""
import argparse,collections,hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'ahc008_terry_exact_selector'),str(R/'ahc008_terry_scaffold_audit')]
from verify import eval_reference
from audit import planned_masks,cells

NS='ahc008-terry-map23-neartie-v1'
LIMIT=4096
GAP=.04
SLOWDOWN=2
LANES={2:(4,11,18,25),3:(0,6,13,19,26)}
SIZE=900
NEI=[tuple(q for q in (p-30,p+30,p-1,p+1)
      if 0<=q<900 and abs(q//30-p//30)+abs(q%30-p%30)==1) for p in range(900)]
def seed(panel,i):
    return int.from_bytes(hashlib.sha256(f'{NS}:{panel}:{i}'.encode()).digest()[:8],'little')

def prelude(raw):
    n,*_=map(int,raw.splitlines()[0].split())
    parts=raw.splitlines()
    count=[0]*5
    for line in parts[1:n+1]:
        _,_,k=map(int,line.split());count[k-1]+=1
    m=int(parts[n+1])
    h=[]
    for line in parts[n+2:n+2+m]:
        r,c=map(int,line.split());h.append((r-1)*30+c-1)
    # Any later private tester metadata goes unused.
    return m,count,h

def lane_eta(h,wall,columns):
    rows=[]
    for start in h:
        # Like original Nav, a worker may leave a cell that will become a wall.
        d=[999]*SIZE;d[start]=0;q=[start]
        for p in q:
            for v in NEI[p]:
                if v not in wall and d[v]==999:d[v]=d[p]+1;q.append(v)
        rows.append([min(d[r*30+c] for r in range(30) if r*30+c not in wall) for c in columns])
    dp={0:0}
    for j in range(len(columns)):
        nex={}
        for mask,old in dp.items():
            for i in range(len(h)):
                q=mask|1<<i
                if q==mask:continue
                x=max(old,rows[i][j])
                if x<nex.get(q,999):nex[q]=x
        dp=nex
    return min(dp.values(),default=999)

def inputs_manifest(gen,out,panel):
    out.mkdir(parents=True,exist_ok=True)
    seed_list=out/'seeds.txt'
    want=''.join(f'{seed(panel,i)}\n' for i in range(LIMIT))
    if seed_list.exists():assert seed_list.read_text()==want
    else:seed_list.write_text(want)
    if gen is None:return
    subprocess.run([str(gen.resolve()),str(seed_list.resolve())],cwd=out,
                   stdout=subprocess.DEVNULL,check=True)
def threshold_rule(y,c2,c3):
    return 0. <= y[2]-y[3] <= GAP and c3<999 and c3<=c2+SLOWDOWN

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('out',type=Path)
    p.add_argument('--panel',choices=['dev','fresh-confirm'],default='dev')
    p.add_argument('--generator',type=Path,help='Run official case generator only when serial slot free')
    p.add_argument('--seeds-only',action='store_true')
    a=p.parse_args()
    inputs_manifest(None if a.seeds_only else a.generator,a.out,a.panel)
    if a.seeds_only:return
    data=R/'ahc008_terry_exact_selector/weights.private.inc'
    w=[float.fromhex(x) for x in re.findall(r'-?0x[0-9a-f]+\.[0-9a-f]+p[+-][0-9]+',data.read_text())]
    assert len(w)==3589
    layouts=planned_masks(R/'ahc008_terry_exact_maps/terrain_data.inc')
    walls={g:set(cells(layouts[g])) for g in LANES}
    rows=[];stage=collections.Counter();seen=set()
    for i in range(LIMIT):
        f=a.out/'in'/f'{i:04d}.txt'
        raw=f.read_bytes();m,kind,humans=prelude(raw)
        file_sha=hashlib.sha256(raw).hexdigest()
        assert file_sha not in seen;seen.add(file_sha)
        stage['generated']+=1
        if m not in (7,8):continue
        stage['humans7or8']+=1
        best,y=eval_reference(w,(m,*kind))
        if best!=2:continue
        stage['stock_map2']+=1
        gap=y[2]-y[3]
        if not 0<=gap<=GAP:continue
        stage['raw_gap_pass']+=1
        c2=lane_eta(humans,walls[2],LANES[2]);c3=lane_eta(humans,walls[3],LANES[3])
        if not threshold_rule(y,c2,c3):continue
        stage['eligible']+=1
        rows.append(dict(source=f.name,stream_index=i,seed=seed(a.panel,i),sha256=file_sha,
                   humans=m,species=kind,gap_2_minus_3=gap,eta_2=c2,eta_3=c3))
    n=30 if a.panel=='dev' else 100
    chosen=rows[:n] if len(rows)>=n else []
    if chosen:
        selected=a.out/'selected'
        selected.mkdir(exist_ok=True)
        for i,row in enumerate(chosen):
            case=f'{i:04d}.txt'
            row['case']=case
            shutil.copyfile(a.out/'in'/row['source'],selected/case)
    q=dict(namespace=NS,panel=a.panel,limit=LIMIT,
           max_raw_gap=GAP,extra_landing_moves_allowed=SLOWDOWN,prelude_only=True,
           seedlist_sha=hashlib.sha256((a.out/'seeds.txt').read_bytes()).hexdigest(),
           require_eligible=n,screen_counts=dict(stage),selected=chosen,eligible=rows)
    (a.out/'manifest.json').write_text(json.dumps(q,indent=2)+'\n')
    print(json.dumps({k:v for k,v in q.items() if k not in ('eligible','selected')},indent=2))
if __name__=='__main__':main()
