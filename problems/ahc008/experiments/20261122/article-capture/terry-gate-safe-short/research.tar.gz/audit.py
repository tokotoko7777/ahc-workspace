"""Evaluate detached proposals; never execute alternative trajectories."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

D=Path(__file__).resolve().parent
R=D.parent
P=R/'ahc008_terry_chase_cut_ties'
sys.path[:0]=[str(R/'ahc008_terry_inward_gates'),str(R/'ahc008_terry_passive_exact_short')]
from screen import ALL,B,bitmask,flat,flood,near,observed,replay,wave

def projected(p,h,w,command):
    ban=bitmask(h+p)|wave(bitmask(p))|w
    after=[];new=0
    for x,c in zip(h,command,strict=True):
        q=x if c=='.' else near(x,c.upper())
        assert q is not None
        if c.islower():
            assert not B[q]&(ban|new)
            new |=B[q];after.append(x)
        else:after.append(q)
    assert not bitmask(after)&(w|new)
    return flood(bitmask(after),ALL^(w|new))

def sha(data):
    return hashlib.sha256(data).hexdigest()

meta=json.loads((P/'manifest.json').read_text())
ledger=json.loads((P/'report.json').read_text())['tapes']
if isinstance(ledger,list):
    ledger={'%04d.txt'%x['board']:x for x in ledger}
rows=[]
for f,hsh in sorted(meta['input'].items()):
    raw=(P/'in'/f).read_bytes()
    a=(P/'tapes'/f).with_suffix('.actions').read_bytes()
    tape=(P/'tapes'/f).with_suffix('.trace').read_bytes()
    ref=ledger[f]
    assert sha(raw)==hsh and sha(a)==ref['commands_sha'] and sha(tape)==ref['trace_sha']
    actions=a.decode().splitlines()
    trace=tape.decode().splitlines()
    assert replay(raw.decode(),trace,actions,detailed=True)[0]==ref['score']
    lines=raw.decode().splitlines()
    n=int(lines[0]);m=int(lines[n+1])
    with tempfile.TemporaryDirectory() as tmp:
        out=Path(tmp)/'out'
        result=subprocess.run([str(D/'audit'),'--pairs=0'],
            input='\n'.join(lines[:n+2+m]+trace[1::2])+'\n',
            text=True,capture_output=True,check=True,timeout=6,
            env=dict(os.environ,AHC008_TERRY_GATE_AUDIT=str(out)))
        assert result.stdout.splitlines()[:275]==actions[:275], f
        log=out.read_text().splitlines()
    kinds,hist,_=observed(raw,trace)
    acc=collections.Counter()
    altered=[]
    for line in log:
        t,old,new,bins,denied=line.split()
        t=int(t); assert old==actions[t]
        acc.update(bins=int(bins),removed_exact_units=int(denied))
        if old==new:
            continue
        pp,hh,ww=hist[t]
        p=list(map(flat,pp)); h=list(map(flat,hh)); w=bitmask(map(flat,ww))
        before=flood(bitmask(h),ALL^w)
        def captured(command):
            after=projected(p,h,w,command)
            return {i for i,z in enumerate(p) if B[z]&before and not B[z]&after}
        c0,c1=captured(old),captured(new)
        after0=projected(p,h,w,old).bit_count()
        after1=projected(p,h,w,new).bit_count()
        acc.update(changed=1,gained=len(c1-c0),lost=len(c0-c1),area_delta=after1-after0)
        altered.append(dict(turn=t,old=old,new=new,old_ids=sorted(c0),new_ids=sorted(c1),
            old_reachable_union=after0,new_reachable_union=after1))
    rows.append(dict(case=f,stats=acc,altered=altered))
counts=collections.Counter()
for r in rows:
    counts.update(r['stats'])
boards=sum(bool(r['altered']) for r in rows)
assert len(rows)==60
print(json.dumps(dict(n=len(rows),counts=counts,changed_boards=boards,
    gate=boards>=12 and counts['changed']>=20 and counts['lost']<=counts['gained'],rows=rows),
    indent=2))
