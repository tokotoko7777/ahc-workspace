"""Frozen accepted h123 -> short exact contribution discounted by own gate veto."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_passive_exact_short/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
def swap(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
swap('template<class Table,class Labels>','template<class Table,class Labels,class Blocking>')
swap('int start,int room,int speed) {','int start,int room,int speed,const Blocking& unsafe) {')
swap('if(labels[p]==room)g+=prev->weight[p];','if(labels[p]==room&&!unsafe[p])g+=prev->weight[p];')
a='struct ShortTap {'
swap(a,'''// Only lookups that match the given room label are made by exact mass.
template<class Rooms>
Mask self_veto_mask(const Rooms& rooms) {
 Mask unsafe;
 for(int i=0;i<rooms.count();++i){
  const auto& r=rooms.rooms[i];
  for(int g:{r.left,r.right})if(g>=0){
   if(rooms.ids[g]==i)unsafe.set(g);
   for(int p:nb[g])if(p>=0&&rooms.ids[p]==i)unsafe.set(p);
  }
 }
 return unsafe;
}
'''+a)
swap('const std::vector<int>& alive,Pcg& rng, std::vector<ShortTap>* tap=nullptr)',
     'const std::vector<int>& alive,Pcg& rng,const Mask& unsafe,std::vector<ShortTap>* tap=nullptr)')
swap('initial.pos,room,initial.type);', 'initial.pos,room,initial.type,unsafe);')
swap(' Mask actual_walls, projected_walls, articulation_walls, articulation;',
     ' Mask actual_walls, projected_walls, articulation_walls, articulation, room_unsafe;')
a='   rooms=terrain_lib::classify_from(t,actual,projected,actual_labels,major);'
swap(a,a+'\n   room_unsafe=self_veto_mask(rooms);')
swap('geometry.count(),alive,rng,&tap);', 'geometry.count(),alive,rng,topology.room_unsafe,&tap);')
(d/'live.private.cpp').write_text(s)
