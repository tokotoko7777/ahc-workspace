# Preset after detached audit, before any official live variant
Compare solely the altered endpoint rule on 100 newly generated
unfiltered dev cases, then (only on pass) 100 separately precommitted
holdout cases, then (only if both pass) official distributed practice100.
Exactly identical input, default 2670ms budget, sequential alternating
runs. All official tester and playback, independent scores. Each panel
requires ≥0.1% higher total, nondecreasing full and useful full count,
max local tester wall <2.95s, and all legal. No horizon/species/geometry
changes, no fallback per case, no tuning from intermediate scores. If
the frozen rule fails, reject it, without reusing either panel to
calibrate choices. Practice is not historical judge and no rank claim.
