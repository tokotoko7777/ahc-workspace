"""Two selectors on an accepted exact-short factual tape; always output old."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_passive_exact_short/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
def put(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
def append(a,b):
    put(a,a+b)
p='namespace terry_exact_root {'
i=s.index(p)+len(p)
s=s[:i]+'\ninline int gate_audit_turn=-1;\ninline std::vector<std::string> gate_audit_rows;\n'+s[i:]
a=s.index('template<class Table,class Labels>')
b=s.index('\n}\n}',a)+2
block=s[a:b]
safe=block.replace('class Labels>','class Labels,class Safe>').replace('mass(const Table&','safe_mass(const Table&').replace('int speed)', 'int speed,const Safe& safe)').replace('labels[p]==room','labels[p]==room&&safe(p)')
s=s[:b]+'\n'+safe+s[b:]
append(' std::array<uint64_t,3> exact{};', '\n std::array<uint64_t,3> placeable{};')
put('std::vector<ShortTap>* tap=nullptr)', 'std::vector<ShortTap>* tap=nullptr,const std::vector<std::pair<int,int>>* gates=nullptr)')
append('    for(int q=0;q<3;++q)(*tap)[room].exact[q]+=z[q];','''
    if(gates){
     auto [l,r]=(*gates)[room];
     auto notNear=[](int p,int gate) {
      if(gate<0)return true;
      if(gate==p)return false;
      for(int v:nb[gate])if(v==p)return false;
      return true;
     };
     auto keep=[&](int p){return notNear(p,l)&&notNear(p,r);};
     const auto w=terry_exact_short_mass::safe_mass(adjacency.table,ids,initial.pos,room,initial.type,keep);
     for(int q=0;q<3;++q){assert(w[q]<=z[q]);(*tap)[room].placeable[q]+=w[q];}
    }
''')
put('    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng,&tap);','''
    const bool record=gate_audit_turn>=0;
    std::vector<std::pair<int,int>> gates;
    if(record){gates.reserve(geometry.count());for(const auto& g:geometry.rooms)gates.emplace_back(g.left,g.right);}
    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng,&tap,record?&gates:nullptr);''')
append('    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));','''
    if(record){
     auto mod=rooms;
     int changed_bins=0;
     uint64_t denied=0;
     for(int i=0;i<int(mod.size());++i)if(mod[i].area)
      for(int q=0;q<3;++q)if(tap[i].exact[q]!=tap[i].placeable[q]){
       ++changed_bins;denied+=tap[i].exact[q]-tap[i].placeable[q];
       mod[i].override_short[q]=correctedCount(freqs[i][q+1],tap[i].sampled[q],tap[i].placeable[q]);
      }
     if(changed_bins){
      const auto alt=hunt::choose(s.people,booked,mod,bits_to_array(actual & ~builds & ~moves));
      auto issue=[&](const auto& js){
       auto b=booked;auto a=action;
       hunt::emit(s.people,js,legal,b);
       for(int i=0;i<m;++i)if(b[i])a[i]=*b[i];
       idle_phase(s,terrain->aisleColumns,a);
       return sanitize(s,a);
      };
      const auto old=issue(jobs),newer=issue(alt);
      gate_audit_rows.push_back(std::to_string(gate_audit_turn)+" "+old+" "+newer+
         " "+std::to_string(changed_bins)+" "+std::to_string(denied));
     }
    }
''')
p0='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(p0,'''  if(turn<275&&std::getenv("AHC008_TERRY_GATE_AUDIT"))gate_audit_turn=turn;
'''+p0+'''
  gate_audit_turn=-1;''')
p0=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(p0,''' if(const char* path=std::getenv("AHC008_TERRY_GATE_AUDIT")){
   std::ofstream f(path);
   for(const auto& row:gate_audit_rows)f<<row<<'\\n';
 }
'''+p0)
(d/'audit.private.cpp').write_text(s)
