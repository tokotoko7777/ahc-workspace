"""Fresh serial A/B panels; write both seed lists before either is tested."""
import hashlib
from pathlib import Path
import subprocess
import sys

d=Path(__file__).resolve().parent
g=d.parent/'ahc008_focus_assets/tools/target/release/gen'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
for panel in ('dev100','held100'):
    z=d/panel; z.mkdir(exist_ok=True)
    seeds=[int.from_bytes(hashlib.sha256(f'ahc008/20261123/terry-passive-safe-body-v1/{panel}/{i}'.encode()).digest()[:8],
           'little') for i in range(100)]
    assert len(set(seeds))==100
    seedfile=z/'seeds.txt'
    expected=''.join(f'{s}\n' for s in seeds)
    if seedfile.exists(): assert seedfile.read_text()==expected
    else: seedfile.write_text(expected)
    print(panel,sha(seedfile))
    if sys.argv[1:]==[panel]:
        subprocess.run([str(g),str(seedfile)],cwd=z,check=True)
        ins=sorted(z.glob('in/*.txt'))
        assert len(ins)==100
        text=''.join(f'{sha(p)}  in/{p.name}\n' for p in ins)
        manifest=z/'SHA256SUMS'
        if manifest.exists(): assert manifest.read_text()==text
        else: manifest.write_text(text)
