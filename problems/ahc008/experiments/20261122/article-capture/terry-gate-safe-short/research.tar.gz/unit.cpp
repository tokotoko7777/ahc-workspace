#define main submission_main
#include "live.private.cpp"
#undef main
#include <random>
#include <cstdio>

int main() {
 using namespace terry_exact_root;
 namespace tm=terry_exact_short_mass;
 std::mt19937 rng(809215);
 for(int t=0;t<400;++t){
  // Make small components embedded in the 30x30 board. Each sample is
  // independent: random walls, multiple labels including -1, shuffled gates.
  const int r=rng()%26, c=rng()%26;
  Mask walls; walls.set();
  terrain_lib::Rooms rooms; rooms.ids.fill(-1); rooms.rooms.resize(3);
  auto pos=[&](int j) {return (r+j/5)*30+c+j%5;};
  for(int j=0;j<25;++j) if(rng()%4) {
   walls.reset(pos(j));rooms.ids[pos(j)]=int(rng()%4)-1;
  }
  for(auto& g:rooms.rooms){g.left=pos(rng()%25);g.right=rng()%2?pos(rng()%25):-1;}
  const Mask unsafe=self_veto_mask(rooms);
  auto safe_boot=[&](int p,int id){
    for(int g:{rooms.rooms[id].left,rooms.rooms[id].right})
     if(g>=0&&std::abs(g/30-p/30)+std::abs(g%30-p%30)<=1)return false;
    return true;
  };
  for(int j=0;j<V;++j) if(rooms.ids[j]>=0) assert(!unsafe[j]==safe_boot(j,rooms.ids[j]));
  const int start=pos(rng()%25), id=int(rng()%3), speed=1+rng()%3;
  RetentionNeighbors neighbors; neighbors.prepare(walls);
  const auto got=tm::mass(neighbors.table,rooms.ids,start,id,speed,unsafe);
  std::array<uint64_t,3> want{};
  auto visit=[&](auto&& self,int at,int step,uint64_t weight)->void{
   if(step>0&&step%speed==0&&rooms.ids[at]==id&&safe_boot(at,id))
    want[step/speed-1]+=weight*tm::pow12[9-step];
   if(step==3*speed)return;
   int next[4],n=0; for(auto q:nb[at])if(q>=0&&!walls[q])next[n++]=q;
   if(!n)self(self,at,step+1,weight*12);
   else for(int j=0;j<n;++j)self(self,next[j],step+1,weight*(12/n));
  };
  visit(visit,start,0,1);
  assert(want==got);
 }
 std::puts("400 randomized safe endpoint masks and exhaustive weighted path enumerations matched");
}
