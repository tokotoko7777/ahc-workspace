# Passive short forecast: individual safe occupancy
Use accepted exact-short h1–3 on stock fresh dev60 prefixes through t274.
Change only cows/pigs/rabbits already in the candidate room, counting
endpoints outside that room's gate cells and orthogonal neighbors.
This is an expected individually placeable count, not a prediction of
other pets blocking a gate, human collisions, animal entries, construction
differences or future actions. Same path model, RNG, h0 and h≥4,
can_place, and actual stock action stream.

Compare detached choice, emit, idle and sanitizer from the same state.
Require ≥20 changed commands across ≥12 boards, and total loss of
immediately caught animals (ID sets) no larger than additions. This
only gates a later independent official A/B; does not measure score or
the counterfactual value of movement. No tuning from this audit. Verify
all 275 action prefix bytes for each of the 60 hashed observed tapes.
