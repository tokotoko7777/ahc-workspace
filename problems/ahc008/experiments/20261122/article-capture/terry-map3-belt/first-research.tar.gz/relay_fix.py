"""Fixed-placement unit prototype, not timed/adopted during initial pilot."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d/'live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='d1dad06c5fcabb05188ecfacb98aa3ef1a9b6f3c4390f0536ce997bc4c54896b'
def edit(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
a='  auto stage=crew.act_literal(actual_array,s.people,ps);'
edit(a,a+'''
  std::array<char,10> deferredRelay{};
  if(belt.layout&&stage.staffing.cols.size()==s.people.size()){
   for(int i=0;i<int(s.people.size());++i){
    // act_literal only books relay for an empty original queue. The
    // belt has first refusal on this worker if its assigned basis is
    // c26. Other original workers/axes and real tasks are untouched.
    if(s.people[i]%30>26&&stage.staffing.cols[i]==26&&crew.q[i].empty()&&
       stage.booked[i]&&move_dir(stage.action[i])>=0){
     deferredRelay[i]=stage.action[i];stage.booked[i]=0;stage.action[i]='.';
    }
   }
  }
''')
a='   if(belt.layout)belt.hunt(s,builds,moves,geometry.participates,action);'
edit(a,a+'''
   if(belt.layout)for(int i=0;i<m;++i)if(!action[i]&&deferredRelay[i])
    action[i]=deferredRelay[i];
''')
(d/'relay.private.cpp').write_text(s)
