#pragma once
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <array>
#include <vector>

namespace terry_map3_belt {
using namespace terry_exact_maps;
inline constexpr int sourceMap=3;
inline constexpr int pruneMinCol=20;
inline constexpr int backbone=26, workspace=27, brace=28, rail=29;
inline constexpr std::array<int,4> mouthRows{1,8,15,22};
struct WallJob { int stand, wall; };
struct Slot {
 int mouth,stance;
 Board body;
 std::array<WallJob,5> jobs;
};
struct Layout {
 Terrain stock;
 std::array<Slot,4> slots;
 Board erased,added;
 Board intendedWalls()const{return stock.plannedWalls|added;}
};
inline Layout layout(){
 Layout L;
 const auto& base=terrain(sourceMap);
 L.stock=base;
 for(int r=0;r<W;r++)for(int c=pruneMinCol;c<W;c++){
  const int p=cell(r,c);
  if(base.planned(p))L.erased.set(p);
  L.stock.plannedWalls.reset(p);
  L.stock.doorCells.reset(p);
  // Preserve the "|", and keep exact snake sweep-row sentinels.
  L.stock.cells[p]=base.aisle(p)?Marker::Aisle:
                       base.constructionRow(r)?Marker::Sweep:Marker::Open;
 }
 for(int i=0;i<int(mouthRows.size());i++){
  int r=mouthRows[i];
  auto& x=L.slots[i];
  x.mouth=cell(r,rail);x.stance=cell(r-1,rail);
  for(int j=0;j<4;j++){
   int s=r+1+j;
   x.body.set(cell(s,rail));
   x.jobs[j]={cell(s,workspace),cell(s,brace)};
  }
  x.jobs[4]={cell(r+5,brace),cell(r+5,rail)};
  for(auto j:x.jobs)L.added.set(j.wall);
 }
 return L;
}
}
