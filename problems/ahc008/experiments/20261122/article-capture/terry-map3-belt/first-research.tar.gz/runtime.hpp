#pragma once
// Folded into the independent faithful solver's root namespace.
namespace belt_pilot {
using terry_map3_belt::Layout;
using terry_map3_belt::Slot;
using terry_map3_belt::cell;
using exact_build::direction;
using exact_build::Move;
using exact_build::Put;
inline const Layout& geometry(){
 static const auto x=terry_map3_belt::layout();
 return x;
}
struct Policy{
 const Layout* layout=nullptr;
 std::array<int,2> workers{-1,-1};
 bool complete(const Slot& p,const exact_build::Board& walls)const{
   for(auto j:p.jobs)if(!walls[j.wall])return false;
   return true;
 }
 void construct(const State& state,int turn,const exact_build::Crew& crew,exact_build::Turn& stage){
  if(!layout||turn>=133)return;
  const auto can=can_place(state);
  const int m=state.people.size();
  std::array<int,2> first{-1,-1};
  for(int g=0;g<2;++g){
   for(int k=0;k<10;++k){auto j=layout->slots[2*g+k/5].jobs[k%5];
    if(!stage.walls[j.wall]){first[g]=k;break;}
   }
   if(first[g]<0)workers[g]=-1;
  }
  std::array<exact_build::BFS,10> dist;
  std::array<bool,10> loaded{};
  auto path=[&](int i)->const exact_build::BFS&{
     if(!loaded[i]){loaded[i]=true;dist[i].run(state.people[i],stage.walls);}
     return dist[i];
  };
  for(int it=0;it<2;++it){
   auto best=std::tuple{exact_build::INF,2,10};
   for(int g=0;g<2;++g)if(first[g]>=0&&workers[g]<0){
    auto j=layout->slots[2*g+first[g]/5].jobs[first[g]%5];
    for(int i=0;i<m;++i)if(crew.q[i].empty()&&i!=workers[1-g]){
     const int d=path(i).d[j.stand];
     // Conservative no-pet allowance from first job for walking between
     // the remaining stances and returning to the ordinary lanes.
     if(d<exact_build::INF&&turn+d+27<=133)
      best=std::min(best,std::tuple{d,g,i});
    }
   }
   auto [d,g,i]=best;
   if(d>=exact_build::INF)break;
   workers[g]=i;
  }
  for(int g=0;g<2;++g){
   const int i=workers[g],k=first[g];
   if(i<0||k<0||!crew.q[i].empty())continue;
   auto j=layout->slots[2*g+k/5].jobs[k%5];
   const int p=state.people[i];
   stage.booked[i]=1;stage.action[i]='.';
   if(p==j.stand){
    if(can[j.wall]&&!stage.moves[j.wall]&&!stage.walls[j.wall]){
     stage.action[i]=Put[direction(p,j.wall)];
     stage.walls[j.wall]=1;
    }
   }else{
    const auto& d=path(i);
    if(d.d[j.stand]<exact_build::INF){
     const int q=d.first[j.stand];
     // The new side is unobstructed except the traces of the two
     // builders; reject a step into a simultaneous planned wall.
     if(q>=0&&!stage.walls[q]){
      stage.moves[q]=1;stage.action[i]=Move[direction(p,q)];
     }
    }
   }
  }
 }
 void hunt(const State& state,const Mask& walls,const Mask& moves,const Mask& live,std::vector<char>& actions)const{
  if(!layout)return;
  const auto can=can_place(state);
  exact_build::Board w;
  for(int p=0;p<V;++p)w[p]=walls[p];
  struct Job{int rank,distance,index,who;char command;};
  std::vector<Job> jobs;
  std::array<exact_build::BFS,10> dist;
  std::array<bool,10> loaded{};
  for(int k=0;k<4;++k){
   const auto& slot=layout->slots[k];
   if(w[slot.mouth]||!complete(slot,w))continue;
   bool humanInside=false;
   for(int p:state.people)humanInside|=slot.body[p];
   if(humanInside)continue;
   int inside=0,near=0;
   for(const auto& pet:state.pets){
    if(!live[pet.pos])continue;
    if(slot.body[pet.pos])++inside;
    else if(!walls[pet.pos]){
     const int d=exact_build::md(pet.pos,slot.mouth);
     if(d<=3)near+=2;
     else if(d<=6)++near;
    }
   }
   if(!inside&&!near)continue;
   for(int i=0;i<(int)state.people.size();++i){
    if(actions[i]||state.people[i]%30<26)continue;
    if(!loaded[i]){loaded[i]=true;dist[i].run(state.people[i],w);}
    const int d=dist[i].d[slot.stance];
    if(d>=exact_build::INF)continue;
    if(d==0&&inside&&can[slot.mouth]&&!moves[slot.mouth])
     jobs.push_back({100000+inside,0,k,i,'d'});
    else if(d==0)
     jobs.push_back({(12*inside+near)*100,0,k,i,'.'});
    else{
     const int p=state.people[i],q=dist[i].first[slot.stance];
     if(q<0)continue;
     jobs.push_back({(12*inside+near)*100/(d+1),d,k,i,Move[direction(p,q)]});
    }
   }
  }
  std::sort(jobs.begin(),jobs.end(),[](const Job& a,const Job& b){
   return std::tuple(-a.rank,a.distance,a.index,a.who)<std::tuple(-b.rank,b.distance,b.index,b.who);
  });
  std::array<bool,4> assigned{};
  for(auto j:jobs)if(!actions[j.who]&&!assigned[j.index]){
   assigned[j.index]=true;
   actions[j.who]=j.command;
  }
 }
};
}
