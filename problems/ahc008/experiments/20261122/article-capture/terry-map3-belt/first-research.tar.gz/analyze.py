"""Aggregate overall, affected-map and unaffected-map results for the frozen A/B."""
import csv
from collections import Counter
import hashlib
from pathlib import Path
import statistics
import sys

p=Path(sys.argv[1])
data={}
for r in csv.DictReader(p.open()):
    data.setdefault(r['case'],{})[r['arm']]=r
if len(data)!=100:
    raise SystemExit(f'incomplete: only {len(data)}/100')
pair=[]
actual_sha={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
    for p in (p.parent/'in').glob('*.txt')}
assert len(actual_sha)==100
for name,arms in sorted(data.items()):
    old,new=arms['v25'],arms['terry_independent']
    assert old['input_sha']==new['input_sha']==actual_sha[name]
    a,b=old['telemetry'].split(),new['telemetry'].split()
    assert len(a)==15 and len(b) in (15,17)
    assert a[0]==b[0]
    assert int(a[-1])==int(old['score']) and int(b[-1])==int(new['score'])
    assert (len(b)==17)==(a[0]=='3')
    pair.append((old,new,a,b))
def s(xs,k,i):
    return sum(int(x[i][k]) for x in xs)
def analyze(name,xs):
    a,b=(s(xs,'score',i) for i in (0,1))
    full=[x for x in xs if x[0]['full']==x[1]['full']=='1']
    attrs={f'{label}': [s(xs,label,i) for i in (0,1)] for label in
        ('score','full','useful300','final_residual','exact4_100','exact4_160','exact4_final')}
    record=dict(panel=name,n=len(xs), change_pct=100*(b-a)/a,**attrs,
        common_full=len(full),common_full_floor_gain=statistics.mean(float(x[1]['mean_human_area'])-float(x[0]['mean_human_area']) for x in full) if full else None,
        max_tester=[max(float(x[i]['wall']) for x in xs)for i in (0,1)],
        wins_ties_losses=[sum(f(int(x[1]['score'])-int(x[0]['score'])) for x in xs)for f in (lambda x:x>0,lambda x:x==0,lambda x:x<0)],
        late_mode_flips=sum(x[2][13]!=x[3][13]for x in xs),
        different_actions=sum(x[0]['commands_sha']!=x[1]['commands_sha']for x in xs))
    if name=='map3':
        record.update(added_walls=dict(sorted(Counter(int(x[3][14])for x in xs).items())),
            sealed_mouths=dict(sorted(Counter(int(x[3][15])for x in xs).items())),
            average_actual_planned_saved=statistics.mean(int(x[2][2])-int(x[3][2])for x in xs),
            cases_with_useful_clear_loss=[x[0]['case'] for x in xs if x[0]['useful300']=='1' and x[1]['useful300']=='0'])
    return record
import json
print(json.dumps([analyze('all',pair),analyze('map3',[x for x in pair if x[2][0]=='3']),analyze('others',[x for x in pair if x[2][0]!='3'])],indent=2))
