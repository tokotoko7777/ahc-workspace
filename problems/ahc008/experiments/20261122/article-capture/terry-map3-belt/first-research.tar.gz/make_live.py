"""Freeze source5 faithful+h123 -> only map3 new boundary belt."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_passive_exact_short/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
def edit(x,y):
    global s
    assert s.count(x)==1,x
    s=s.replace(x,y)
def pure(p):
    return '\n'.join(x for x in (d/p).read_text().splitlines() if not x.startswith('#pragma once') and not x.startswith('#include "'))
# The existing faithful source already declares the independent map types.
a='struct NormalCount{'
spot=s.index(a)
endroot=s.rfind('namespace terry_exact_root {',0,spot)
assert endroot!=-1
s=s[:endroot]+pure('belt.hpp')+'\n'+s[endroot:]
edit(a,pure('runtime.hpp')+'\n'+a)
a=' TopologyMemo topology;'
edit(a,a+'\n belt_pilot::Policy belt;')
edit('Normal(const terrain_lib::Terrain& layout,const State& state):terrain(&layout),rng(42){',
     'Normal(const terrain_lib::Terrain& layout,const State& state,const terry_map3_belt::Layout* layoutBelt=nullptr):terrain(&layout),rng(42){\n  belt.layout=layoutBelt;')
a='  auto stage=crew.act_literal(actual_array,s.people,ps);'
edit(a,a+'\n  if(belt.layout)belt.construct(s,turn,crew,stage);')
a='   const auto before=counter?action:std::vector<char>{};'
edit(a,'   if(belt.layout)belt.hunt(s,builds,moves,geometry.participates,action);\n'+a)
edit(' const auto& cfg=terrain_lib::terrain(map);\n Normal policy(cfg,s);',
     ' const auto* belt=map==3?&belt_pilot::geometry():nullptr;\n const auto& cfg=belt?belt->stock:terrain_lib::terrain(map);\n Normal policy(cfg,s,belt);')
a="  f<<map<<' '<<cfg.plannedWalls.count()<<' '<<(cfg.plannedWalls&s.walls).count()<<' '"
edit(a,'''  const auto plannedWalls=belt?belt->intendedWalls():cfg.plannedWalls;
  f<<map<<' '<<plannedWalls.count()<<' '<<(plannedWalls&s.walls).count()<<' ' '''.rstrip())
a="    <<metrics.idle_walks<<' '<<d.pairs<<' '<<d.normal<<' '<<d.chase_sum<<' '<<d.chose<<' '<<score(s)<<'\\n';"
edit(a,'''    <<metrics.idle_walks<<' '<<d.pairs<<' '<<d.normal<<' '<<d.chase_sum<<' '<<d.chose;
  if(belt){
   int closed=0;
   for(const auto& p:belt->slots)closed+=s.walls[p.mouth];
   f<<' '<<(belt->added&s.walls).count()<<' '<<closed;
  }
  f<<' '<<score(s)<<'\\n';
''')
(d/'live.private.cpp').write_text(s)
