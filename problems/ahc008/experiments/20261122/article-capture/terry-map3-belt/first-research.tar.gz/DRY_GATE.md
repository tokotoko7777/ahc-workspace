# Belt static-to-live gate
This is separately frozen map3 only: all other maps take their old
behavior. Pruned right bay c>=20 and four geometrically certified
vertical four-cell edge slots, net planned walls 233→166. Same original
map selection, inherited horizontal original queue and capture stages,
additional right-build stances with no overwriting nonempty queues,
two temporary workers maximum and stop building by 133. Existing road
26 reaches worker exits; new solo capture proposals use only unclaimed
people at columns 26–29. Each slot needs all five physical walls and
a legal mouth closure. Forecast for admission is merely inside/near
vs path length, not reuse of observed future, and has no tuned values.

Before live, run 40 deterministic synthetic no-pet staffings (10 for
each M7/8/9/10, independent of case data). The alternative must build
all 20 belt walls by 133 in >=36 of 40, and never leave a retained planned
X unbuilt if it was built by stock. This only certifies access/workload;
it cannot certify capture reliability. Historical old retired region
had >4 distinct full traps used in 17/27 cases, so capture risk is high.
Dry failure rejects the prototype as frozen, not the geometry.

Live test, only on dry pass: independent unfiltered matched 100, default
budget, no seed- or id-specific choices; both require official legality,
official and independent exact replay, max tester <2.95s, >=0.1% higher
total and no decline in whole panel raw/useful clear count. Require >=35
mean human floor gain among common full map3 cases and no decline in raw
or useful map3 full count. If passed, repeat frozen on separately
precommitted held100 and then official practice100. Loss rejects, do
not retune assignments or left/right choice using scores. Map3 exposure
reported separately; all duration measurements exclusive/serial.
