"""Measure actual first-split use of the map3 retired bay. No solver runs."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import sys
P=Path(__file__).resolve().parent
R=P.parent
D=R/'ahc008_terry_chase_cut_ties'
A=R/'ahc008_terry_final_area_budget'
S=R/'ahc008_terry_exact_selector'
sys.path[:0]=[str(R/'ahc008_focus_solver/problems/ahc008/experiments/20261122'),str(S)]
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,flood,idx,wave,cells
from verify import eval_reference

def mask(ps):
    return sum({B[i] for i in ps})
def sha(content):
    return hashlib.sha256(content).hexdigest()

def main():
    retired_mask=mask(i for i in range(900) if i%30>=20)
    stock={}
    for line in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        m,r,l,g,*p=map(int,line.split())
        if m==3 and p and all(q%30>=20 for q in [*p, *[z for z in (l,g) if z>=0]]):
            stock[mask(p)]=(r,l,g)
    assert len(stock)==30
    full=json.loads((A/'fresh60.json').read_text())
    selection={int(r['case']):r['map'] for r in full['rows']}
    weights=list(map(float.fromhex,re.findall(r'-?0x[0-9a-f]+\.[0-9a-f]+p[+-][0-9]+',(S/'weights.private.inc').read_text())))
    assert len(weights)==3589
    events=[];maps=Counter();totalHeads=0
    for case in json.loads((D/'report.json').read_text())['tapes']:
        i=case['board']; stem=f'{i:04d}'
        raw=(D/'in'/f'{stem}.txt').read_bytes()
        if i not in selection:
            z=raw.splitlines(); n=int(z[0]); m=int(z[1+n]); ct=[0]*5
            for p in z[1:n+1]:ct[int(p.split()[2])-1]+=1
            selection[i]=eval_reference(weights,(m,*ct))[0]
        if selection[i]!=3:continue
        actions=(D/'tapes'/f'{stem}.actions').read_bytes()
        trace=(D/'tapes'/f'{stem}.trace').read_bytes()
        assert sha(raw)==case['input_sha'] and sha(actions)==case['commands_sha'] and sha(trace)==case['trace_sha']
        kinds,h,_=observed(raw,trace.decode().splitlines())
        assert len(h)==301
        assert trace.decode().splitlines()[::2]==actions.decode().splitlines()
        maps[str(i)]+=1;totalHeads+=len(kinds)
        captured=set()
        oldWalls=0
        for t,(animals,staff,walls) in enumerate(h):
            wm=mask(map(idx,walls))
            people=mask(map(idx,staff))
            reached=flood(people,ALL^wm)
            caught=[j for j,p in enumerate(animals) if j not in captured and not (reached&B[idx(p)])]
            comps={}
            for j in caught:
                rm=flood(B[idx(animals[j])],ALL^wm)
                comps.setdefault(rm,[]).append(j)
            for rm,jj in comps.items():
                newrim=wave(rm)&(wm^oldWalls)
                event={
                    'case':i,'turn_0based_action':t-1,'animals':jj,'species':[kinds[j] for j in jj],
                    'area':rm.bit_count(),'new_wall_cells':list(cells(newrim)),
                    'retired_region':bool(rm&retired_mask and not rm&~retired_mask),
                    'straddles':bool(rm&retired_mask and rm&~retired_mask),
                    'exact_removed_stock_room':stock.get(rm),
                }
                assert t>0 and newrim
                events.append(event)
            captured.update(caught)
            oldWalls=wm
    def report(q):
        return {
            'heads':sum(len(x['animals']) for x in q),
            'events':len(q),'cases':len({x['case'] for x in q}),
            'by_species':dict(Counter(k for x in q for k in x['species'])),
            'by_phase':{
                str(k):sum(len(x['animals']) for x in q if a<=x['turn_0based_action']<b)
                for (k,a,b) in (('0–132',0,133),('133–274',133,275),('275–299',275,300))
            },
            'median_turn':sorted(x['turn_0based_action'] for x in q)[len(q)//2] if q else None
        }
    def put(criteria):
        return report([x for x in events if criteria(x)])
    print(json.dumps({
      'selected_map3_boards':len(maps),'heads_initial':totalHeads,
      'all':report(events),'retired_physical_region':put(lambda x:x['retired_region']),
      'exact_retired_stock_room':put(lambda x:x['exact_removed_stock_room'] is not None),
      'other_retired_region':put(lambda x:x['retired_region'] and x['exact_removed_stock_room'] is None),
      'straddling_region':put(lambda x:x['straddles']),
      'events':events
    },indent=2))
if __name__=='__main__':main()
