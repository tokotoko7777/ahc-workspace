# Fixed controller handoff, preregistered before first pilot result

The first belt implementation selected only unclaimed guards. Static
inspection shows that after an unclaimed guard takes the first step
from c26 into c27, optional stock relaying to c26 can book the same
guard, preventing the next approach step. This is distinct from
construction and from trap capacity. Test a fixed-board fixture
with all intended walls built, the lane slots occupied, one legal
target inside pocket one, and no pet motion. No official test input
or score was used to design this fixture.

The narrow fix postpones only an empty-queue c26 return relay for an
actor currently on c27–29; the new guard stage has first refusal and
the actor returns to its original relay if no belt job is selected.
Actual stock builds, other aisle duties, geometry, clock and
control unchanged. Precondition: original fixture oscillates or
fails to close, revised fixture closes and preserves legality.
Never edit the initial pilot files/binary. If a separately executed
live trial is worthwhile, use fresh unfiltered dev100, appropriate
independent holdout100, same adoption gates as DRY_GATE. Do not
adjust extent or thresholds using first live results.
