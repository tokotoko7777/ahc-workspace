# AHC008 map3 outer-bay replacement: static geometry only

This directory owns a standalone, deterministic layout generator and static feasibility fixture. No frozen solver, existing artifact or live tester was changed or run. This is not an adopted variant.

```sh
g++ -std=c++23 -Wall -Wextra -pedantic ahc008_terry_map3_belt/feasibility.cpp -o /tmp/terry-map3-belt
/tmp/terry-map3-belt
```

## Fixed geometry

In the existing faithful map3 (0-based numbering), preserve every cell at column <20, all five aisle markers, and the original construction row sentinels. Retire all original room bodies and gates in columns ≥20: rightmost paired bank (old doors at c20/c25) and outer right solos (doors at c27). Remove their 87 fence cells. Four fixed belt slots at c29, gate rows s=1,8,15,22, have body rows s+1 through s+4. Each uses the physical board edge as one side, an existing-free exterior approach at r=s−1, and only five newly planned cells: four braces c28 and a terminal cap at (s+5,29). Preparation totals 166 instead of 233 (net −67). Each full belt lock adds one wall with a single actor, as opposed to a staff pair. The belt does not alter effective tile roles of the retained original rooms; these rooms are identified by original numeric ID mapped to its corresponding new numeric ID.

Two views are deliberate: `layout().stock` is the original semantic configuration pruned at c20, for original room/planner and sweep ownership. `layout().intendedWalls()` is the fully prepared physical mask, including the two builders' optional belt jobs. Do not feed vertical doors into the old horizontal marker system. A slot is dynamically ready only after its five real walls exist and its open mouth floods both to the exact four cells and out to original exterior; after a gate is built, exact body and no employee inside must be rechecked.

The static audit verified 45 retained rooms with exact physical footprint, doors and original single-/double-closure envelopes outside the retired domain, and 30 retired rooms. Under any one original gate closure, every retained exterior stance's connectivity to every original aisle cell is unchanged; one retired gate is treated as absent on the new board. Each belt gate yields exactly four cells and all four may close while old c19/c26 and stock work column c27 remain exterior-connected. Partial work never blocks c26, c27 or any stock aisle. More heavy simultaneous original closures may join previously disconnected aisle components via the right open band. No claim of stock live-capture behavior or pet-routing monotonicity.

## Construction and possible integration

Each slot uses four braces built from work column c27, and its cap built sideways from an unblocked c28 stance. BFS fixture walks and builds legally starting at any row of c26 under the pruned completed stock walls, then returns to c26. Independent top/bottom assignment (slots 0–1 / 2–3) takes `27 + abs(entry_row−2)` / `27 + abs(entry_row−16)` turns. Worst arbitrary-row cost is 54 / 43. A single actor doing all four is at most 82, or 55 from the closest row. Assert that every step/build stance remains attached to c26. Never infer these timings under real pet blockers, other stock actions, or distant queue exits.

Proposed narrow integration: at most two already-released stock construction workers temporarily assigned fixed upper/lower belt routes from c26; no added worker or permanent lane-owner change. Enforce outside paths via c27 (only enter c28 for one's own cap), route owners with disjoint bounds, and a fixed new-stage deadline at 133 (not a hard stock deadline). A worker remains stock if their exact approach+work+return lower bound cannot fit with a predeclared stall margin. Do not cancel an ordinary closure or make a simultaneous conflict; conservative final batch sanitizer still applies. A slot with incomplete braces never enters capture assignment. Handle the vertical slots as explicit separate single-mouth descriptors; there is no unsupported mutation of the original horizontal gate semantics. Main road list retains all five | columns, so endgame flow objective remains structurally available, but changed floor graph and animal trajectories can make its effectiveness worse.

Reject if staffing frequently cannot finish or if the new open bay accumulates reachable animals. Only after static pass evaluate a predeclared fresh selected-map3 cohort with identical other policy; require at least 60 fewer actual planned X on average, no loss of complete or useful (≥300 floor) clears, +35 common-clear retained cells, and higher total score. Geometry savings alone are not a GO signal.

## Factual interception load on the original bay

```sh
python ahc008_terry_map3_belt/retired_captures.py > ahc008_terry_map3_belt/retired_captures.json
```

This is a read of existing fresh60 tapes, **not** a simulation or comparison. It verifies every selected input/command/trace hash against the earlier official run, then records each pet's first post-action disconnection from all employees with the actual physical component and freshly built boundary cells. Count only fully contained components; no split spans the retired boundary in this set.

All 404 heads in the 27 map3 cases are ultimately isolated. The retired c≥20 bay accounts for 145 first-isolated heads in 142 events on 26 boards. Of these, 143 heads in 140 events use a body identical to a retired stock room; 96 heads before action 133, 46 between 133 and 274, and one from 275 onward (all zero-based). Species: 32 cows, 26 pigs, 39 rabbits, 22 dogs, 24 cats. The two remaining captures in the bay are late pigs isolated in dynamically formed nonstock rooms. By original room type, the rightmost paired bank accounts for 105 heads in 102 separate events, including 45 dog/cat heads. Old edge solos account for 38 captures in 38 events (14 cows, 9 pigs, 14 rabbits, one cat).

Four replacement slots have a factual interception-volume challenge: 17/27 original boards had over four separate retired-stock capture events, maximum nine; six crossed four before action 133. If each replacement slot only catches one head, even four successful new seals on every board cannot directly cover 41 of the original distinct retired-stock capture episodes. This is not a proof those heads would be missed: the replacement can change paths, feed retained rooms, achieve multi-head seals, or redirect endgame. Old edge solos alone never needed more than three distinct seals per board, but changing just those rooms saves only about nine planned walls and cannot meet the −60 X design threshold.
