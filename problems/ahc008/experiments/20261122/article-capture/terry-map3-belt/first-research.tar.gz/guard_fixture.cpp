#define main archive_submission_main
#ifdef RELAY_FIX
#include "relay.private.cpp"
#else
#include "live.private.cpp"
#endif
#undef main
#include <cstdio>

int main(){
 using namespace terry_exact_root;
 const auto& b=belt_pilot::geometry();
 State s;
 s.walls=b.intendedWalls();
 // One worker assigned to each lane; the c26 guard starts at exactly the
 // mouth row minus one on its original lane. Other lanes are untouched.
 for(int c : b.stock.aisleColumns)s.people.push_back(c==26?c:14*30+c);
 const int h=int(std::find(s.people.begin(),s.people.end(),26)-s.people.begin());
 assert(h<(int)s.people.size());
 s.pets.push_back({4*30+29,1,-1});  // stays fixed for 6 human-only turns
 Normal p(b.stock,s,&b);for(auto& q:p.crew.q)q.clear();
 for(int t=140;t<146;++t){
  const auto a=p.step(s,t);
  printf("%d guard=%d,%d %c\n",t,s.people[h]/30,s.people[h]%30,a[h]);
  people_step(s,a);
 }
 const bool caught=s.walls[b.slots[0].mouth];
 printf("gate_closed=%d\n",caught);
#ifdef RELAY_FIX
 assert(caught);
#else
 assert(!caught);
#endif
}
