from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent;R=D.parent
def checked(p,h):
 b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==h;return b.decode()
ref=R/'ahc008_terry_map1_reflect_dry/screen.cpp'
base=R/'ahc008_terry_virtual_chase_absorb/candidate.private.cpp'
frozen={name:sha for sha,name in (x.split()for x in (ref.parent/'FROZEN.sha256').read_text().splitlines())}
body=checked(ref,frozen['screen.cpp'])
s=checked(base,'a237f7986e03ba94e98cfb6f1d2059f50d87305f6c8a82b1fa6d4ccd5f013f22')
body=body[body.index('using namespace exact_build;'):body.index('int main(){')]
assert body.count('Report simulate(')==1
# Keep frozen readiness math; only add an absolute stop/fallback path.
body=body.replace('const Board& final){\n Board w{};Crew c;Report z;', 'const Board& final,std::chrono::steady_clock::time_point deadline){\n Board w{};Crew c;Report z;')
body=body.replace(' for(int t=0;t<160;++t){',' for(int t=0;t<160;++t){\n  if(std::chrono::steady_clock::now()>=deadline){++z.bad;return z;}')
body=body.replace(' return z;\n}', ' if(std::chrono::steady_clock::now()>=deadline)++z.bad;\n return z;\n}')
api='''
struct Choice{Report old,mapped;int sites=0,earlier4=0;bool chosen=false;};
Choice choose(const std::vector<int>& human,std::chrono::steady_clock::time_point deadline){
 const auto& raw=terry_exact_maps::terrain(1);
 Layout l;l.aisleCols=raw.aisleColumns;l.aisleRows=raw.aisleRows;
 Board final{};
 for(int i=0;i<V;++i){l.ascii[i]=char(raw.cells[i]);final[i]=raw.plannedWalls[i];}
 auto rm=rooms(l,final);Choice out;out.sites=rm.size();
 out.old=simulate(l,rm,human,final,deadline);
 if(out.old.bad||out.old.walls<0||out.old.handoff<0)return out;
 auto h=human;for(int& p:h)p=reflect(p);
 out.mapped=simulate(l,rm,h,final,deadline);
 if(out.mapped.bad||out.mapped.walls<0||out.mapped.handoff<0)return out;
 for(int i=0;i<out.sites;++i)out.earlier4+=out.old.first[i]-out.mapped.first[i]>=4;
 out.chosen=out.mapped.handoff<=out.old.handoff&&out.mapped.total>out.old.total&&out.earlier4>=2;
 return out;
}
'''
header='namespace map1_reflect_readiness {\n'+body+api+'}\n'
(D/'readiness.inc').write_text(header)
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
put('int main(int argc,char** argv){',header+'\nint main(int argc,char** argv){')
put(' if(map<0)map=terry_exact_selector::choose(m,counts);',''' const auto stop=started+std::chrono::milliseconds(limit_ms);
 const int learnt=terry_exact_selector::choose(m,counts);
 if(map<0)map=learnt;
 bool reflected=false;
 if(learnt==1&&map==1){
  reflected=map1_reflect_readiness::choose(s.people,stop).chosen;
  if(reflected){
   for(auto& p:s.pets)p.pos=map1_reflect_readiness::reflect(p.pos);
   for(int& h:s.people)h=map1_reflect_readiness::reflect(h);
  }
 }
''')
put(' NormalCount metrics;Decision d;\n const auto stop=started+std::chrono::milliseconds(limit_ms);',' NormalCount metrics;Decision d;')
put("  std::cout<<command<<'\\n'<<std::flush;","  if(reflected)for(char& c:command)c=map1_reflect_readiness::invert(c);\n  std::cout<<command<<'\\n'<<std::flush;")
put("for(char ch:str){int k=move_dir(ch);","for(char ch:str){int k=move_dir(reflected?map1_reflect_readiness::invert(ch):ch);")
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* path=std::getenv("AHC008_REFLECTION_LOG")){
  std::ofstream f(path);
  f<<reflected<<'\\n';
 }
'''+a)
(D/'integrated.private.cpp').write_text(s)
