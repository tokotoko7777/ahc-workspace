import csv,hashlib,io,json,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent
rows=[]
for m in (5,6):
 for k in range(18):
  h=[];j=0
  while len(h)<m:
   u=int.from_bytes(hashlib.sha256(f'ahc008-map1-north-south-dry-v1:{m}:{k}:{j}'.encode()).digest()[:8],'little');j+=1
   if u<2**64-2**64%900 and u%900 not in h:h.append(u%900)
  rows.append(str(m)+' '+' '.join(map(str,h)))
feed=('\n'.join(rows)+'\n').encode();(D/'fixtures.txt').write_bytes(feed)
r=subprocess.run([str(D/'screen')],input=feed,capture_output=True,check=True,timeout=100)
(D/'screen.csv').write_bytes(r.stdout)
x=[{k:int(v)for k,v in q.items()}for q in csv.DictReader(io.StringIO(r.stdout.decode()))]
assert len(x)==36 and [r['case']for r in x]==list(range(36))
valid=lambda r: not(r['old_bad'] or r['new_bad']) and min(r['old_all'],r['new_all'],r['old_handoff'],r['new_handoff'])>0
y=[r for r in x if valid(r) and r['new_handoff']<=r['old_handoff'] and r['new_auc']>r['old_auc'] and r['earlier4']>=2]
g=dict(arms_simulated=72,valid_pairs=sum(map(valid,x)),selected=len(y),
   distinct_board_sites=sum(r['earlier4']for r in y),positive_net_site_turns=sum(r['new_auc']-r['old_auc']for r in y),
   single_delta=sum(r['new_solo']-r['old_solo']for r in y),dual_delta=sum(r['new_pair']-r['old_pair']for r in y),
   selected_m5=sum(r['m']==5 for r in y),selected_m6=sum(r['m']==6 for r in y),fixture_sha=hashlib.sha256(feed).hexdigest())
g['passed']=g['valid_pairs']==36 and g['selected']>=8 and g['distinct_board_sites']>=16 and g['positive_net_site_turns']>=64
(D/'report.json').write_text(json.dumps(g,indent=2)+'\n')
print(json.dumps(g))
