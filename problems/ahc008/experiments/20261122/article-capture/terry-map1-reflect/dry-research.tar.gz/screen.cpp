#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <iostream>
using namespace exact_build;
char invert(char c){
 switch(c){case 'U':return 'D';case 'D':return 'U';case 'u':return 'd';case 'd':return 'u';default:return c;}
}
int reflect(int p){return (29-p/30)*30+p%30;}
struct Room{std::vector<int> dots,gates,stances;};
bool gate(char c){return c=='('||c==')'||c=='<'||c=='>';}
std::vector<Room> rooms(const Layout& l,const Board& final){
 auto closed=final;
 for(int p=0;p<V;++p)if(gate(l.ascii[p]))closed[p]=1;
 Board seen=closed;std::vector<Room> out;
 for(int p=0;p<V;++p)if(!seen[p]){
  BFS b;b.run(p,closed);bool road=false;Room r;
  for(int q=0;q<V;++q)if(b.d[q]<INF){seen[q]=1;road|=l.ascii[q]=='|';r.dots.push_back(q);}
  if(road||r.dots.size()>4)continue;
  for(int q:r.dots)for(int v:nb(q))if(v>=0&&gate(l.ascii[v])&&std::find(r.gates.begin(),r.gates.end(),v)==r.gates.end())r.gates.push_back(v);
  if(r.gates.empty()||r.gates.size()>2)continue;
  bool safe=false;
  for(int q:r.dots)if(std::none_of(r.gates.begin(),r.gates.end(),[&](int g){return md(g,q)<=1;}))safe=true;
  if(!safe)continue;
  std::sort(r.gates.begin(),r.gates.end());
  for(int g:r.gates){
   int stance=g+((l.ascii[g]=='('||l.ascii[g]=='<')?-1:1);
   if(l.ascii[stance]!='|')std::abort();
   r.stances.push_back(stance);
  }
  out.push_back(r);
 }
 return out;
}
struct Report{int handoff=-1,walls=-1,bad=0,total=0,solo=0,pair=0;std::vector<int> first;};
Report simulate(const Layout& l,const std::vector<Room>& rm,std::vector<int> h,const Board& final){
 Board w{};Crew c;Report z;z.first.assign(rm.size(),160);
 if(!c.init(l,h)){++z.bad;return z;}
 for(int t=0;t<160;++t){
  auto turn=c.act_literal(w,h,{});
  if(t>=80){
   std::vector<BFS> distances(h.size());for(int i=0;i<(int)h.size();++i)if(!turn.booked[i])distances[i].run(h[i],w);
   for(int k=0;k<(int)rm.size();++k){
    const auto& r=rm[k]; auto closed=w;bool valid=true; unsigned roles[2]={};
    for(int g:r.gates){if(w[g]||std::find(h.begin(),h.end(),g)!=h.end())valid=false;closed[g]=1;}
    if(!valid||std::any_of(h.begin(),h.end(),[&](int q){return std::find(r.dots.begin(),r.dots.end(),q)!=r.dots.end();}))continue;
    for(int j=0;j<(int)r.stances.size();++j)
     for(int i=0;i<(int)h.size();++i)if(!turn.booked[i]&&h[i]%30==r.stances[j]%30&&distances[i].d[r.stances[j]]<=3)roles[j]|=1u<<i;
    bool ready=roles[0]&&(r.gates.size()==1||(roles[1]&&std::popcount(roles[0]|roles[1])>=2));
    if(!ready)continue;
    BFS f;f.run(r.dots[0],closed);
    int size=std::count_if(f.d.begin(),f.d.end(),[](auto x){return x<INF;});
    if(size!=(int)r.dots.size()||std::any_of(r.dots.begin(),r.dots.end(),[&](int p){return f.d[p]>=INF;}))continue;
    z.first[k]=std::min(z.first[k],t);
    ++z.total;if(r.gates.size()==1)++z.solo;else ++z.pair;
   }
  }
  auto nxt=h;
  for(int i=0;i<(int)h.size();++i){
   char a=turn.action[i];auto it=std::find(Move,Move+4,a);
   if(it!=Move+4){int p=nb(h[i])[it-Move];if(p<0||w[p]){++z.bad;return z;}nxt[i]=p;}
  }
  for(int i=0;i<(int)h.size();++i){
   char a=turn.action[i];auto it=std::find(Put,Put+4,a);
   if(it!=Put+4){
    int p=nb(h[i])[it-Put];
    if(p<0||w[p]||!final[p]||std::find(h.begin(),h.end(),p)!=h.end()||std::find(nxt.begin(),nxt.end(),p)!=nxt.end()){++z.bad;return z;}
    w[p]=1;
   }else if(a!='.'&&std::find(Move,Move+4,a)==Move+4){++z.bad;return z;}
  }
  h=std::move(nxt);
  if(w==final){
   if(z.walls<0)z.walls=t+1;
   std::array<int,3> q{};bool all=true;
   for(int p:h){
    auto it=std::find(l.aisleCols.begin(),l.aisleCols.end(),p%30);
    if(it==l.aisleCols.end())all=false;else ++q[it-l.aisleCols.begin()];
   }
   std::sort(q.begin(),q.end());
   if(z.handoff<0&&all&&q==(h.size()==5?std::array<int,3>{1,2,2}:std::array<int,3>{2,2,2}))z.handoff=t+1;
  }
 }
 return z;
}
int main(){
 for(char c:std::string(".URDLurdl"))if(invert(invert(c))!=c)return 3;
 for(int p=0;p<V;++p){
  if(reflect(reflect(p))!=p)return 3;
  for(int a=0;a<4;++a){
   int next=nb(p)[a];auto j=std::find(Move,Move+4,invert(Move[a]))-Move;
   if((next<0?-1:reflect(next))!=nb(reflect(p))[j]||invert(Put[a])!=Put[j])return 3;
  }
 }
 const auto& raw=terry_exact_maps::terrain(1);
 Layout l;l.aisleCols=raw.aisleColumns;l.aisleRows=raw.aisleRows;
 Board final{};
 for(int i=0;i<V;++i){l.ascii[i]=char(raw.cells[i]);final[i]=raw.plannedWalls[i];}
 auto rm=rooms(l,final);
 std::cout<<"case,m,sites,old_all,new_all,old_handoff,new_handoff,old_bad,new_bad,old_auc,new_auc,old_solo,new_solo,old_pair,new_pair,earlier4\n";
 for(int k=0;k<36;++k){
  int m;std::cin>>m;if(m!=(k<18?5:6))return 2;
  std::vector<int> h(m);for(int& p:h)std::cin>>p;
  auto a=simulate(l,rm,h,final);for(int& p:h)p=reflect(p);
  auto b=simulate(l,rm,h,final);int early=0;
  for(int i=0;i<(int)rm.size();++i)early+=a.first[i]-b.first[i]>=4;
  std::cout<<k<<','<<m<<','<<rm.size()<<','<<a.walls<<','<<b.walls<<','<<a.handoff<<','<<b.handoff<<','<<a.bad<<','<<b.bad<<','<<a.total<<','<<b.total<<','<<a.solo<<','<<b.solo<<','<<a.pair<<','<<b.pair<<','<<early<<'\n';
 }
}
