import csv,hashlib,io,json,statistics,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent/'ahc008_terry_map1_reflect_dry'
fixture=(R/'fixtures.txt').read_bytes()
assert hashlib.sha256(fixture).hexdigest()=='086b2f9816cf5b278fb2899b08e6e48dc136f87418683d5d5639956db7c39225'
old=[{k:int(v)for k,v in row.items()}for row in csv.DictReader((R/'screen.csv').open())]
r=subprocess.run([str(D/'probe')],input=fixture,capture_output=True,check=True,timeout=80)
(D/'probe.csv').write_bytes(r.stdout)
a=[line.split(',')for line in r.stdout.decode().splitlines()]
assert len(a)==len(old)==36
wall=[];cpu=[];chosen=0
for x,v in zip(a,old):
 assert len(x)==19
 fields=list(v.values())
 assert list(map(int,x[:16]))==fields,(x,v)
 expected=not(v['old_bad'] or v['new_bad']) and min(v['old_all'],v['new_all'],v['old_handoff'],v['new_handoff'])>0 and v['new_handoff']<=v['old_handoff'] and v['new_auc']>v['old_auc'] and v['earlier4']>=2
 assert bool(int(x[16]))==expected
 chosen+=expected;wall.append(int(x[17]));cpu.append(float(x[18]))
out=dict(exact_rows=36,transformed=chosen,wall_us=[min(wall),statistics.median(wall),max(wall)],
 cpu_us=[min(cpu),statistics.median(cpu),max(cpu)])
assert chosen==11
(D/'probe-report.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
