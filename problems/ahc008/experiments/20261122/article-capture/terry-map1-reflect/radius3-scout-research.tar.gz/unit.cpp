#include <bitset>
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <chrono>
#include <iostream>
#include "readiness.inc"
using namespace map1_reflect_readiness;
uint64_t draw(uint64_t& s){s^=s<<13;s^=s>>7;s^=s<<17;return s;}
int main(){
 uint64_t seed=0xfa81c229ad20e877ULL;
 int blocked=0,edges=0,unreachable=0;
 for(int k=0;k<2000;++k){
  Board w{};
  for(int p=0;p<V;++p)w[p]=draw(seed)%100<(k%10)*10;
  int p=int(draw(seed)%V);
  if(k%4==0)p=0;
  if(k%4==1)p=V-1;
  if(k%5==0)w[p]=1;
  if(k%5==1)w[p]=0;
  if(k%5==2)for(int q:nb(p))if(q>=0)w[q]=1;
  blocked+=w[p];edges+=p%30==0||p%30==29||p/30==0||p/30==29;
  BFS ref;ref.run(p,w);
  auto got=role_radius3(p,w);
  for(int q=0;q<V;++q)if(got[q]!=(ref.d[q]<=3))return 2;
  unreachable+=got.count()==1;
 }
 if(!blocked||!edges||!unreachable)return 2;
 std::cout<<"2000 exact all-cell radius3 masks, blocked="<<blocked<<" edges="<<edges<<" singleton="<<unreachable<<"\n";
}
