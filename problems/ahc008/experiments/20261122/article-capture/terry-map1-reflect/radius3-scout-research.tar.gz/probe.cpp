#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <chrono>
#include <ctime>
#include <iostream>
#include "readiness.inc"
using namespace map1_reflect_readiness;
int main(){
 for(int a=0;a<900;++a)for(int k=1;k<=5;++k){
  std::pair<int,int> old{a,k},mapped{reflect(a),k};
  if(std::pair(reflect(mapped.first),mapped.second)!=old)return 2;
  for(int d=0;d<4;++d){
   int p=nb(a)[d];
   auto j=std::find(Move,Move+4,invert(Move[d]))-Move;
   if(invert(Put[d])!=Put[j]||(p<0?-1:reflect(p))!=nb(reflect(a))[j])return 2;
  }
 }
 for(char c:std::string(".URDLurdl"))if(invert(invert(c))!=c)return 2;
 for(int k=0;k<36;++k){
  int m;if(!(std::cin>>m)||m!=(k<18?5:6))return 2;
  std::vector<int> h(m);for(int& p:h)std::cin>>p;
  auto c0=std::clock();auto start=std::chrono::steady_clock::now();
  const auto q=choose(h,start+std::chrono::milliseconds(2670));
  auto us=std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now()-start).count();
  auto cpu=double(std::clock()-c0)*1000000/CLOCKS_PER_SEC;
  const auto&a=q.old;const auto&b=q.mapped;
  std::cout<<k<<','<<m<<','<<q.sites<<','<<a.walls<<','<<b.walls<<','<<a.handoff<<','<<b.handoff<<','<<a.bad<<','<<b.bad<<','
   <<a.total<<','<<b.total<<','<<a.solo<<','<<b.solo<<','<<a.pair<<','<<b.pair<<','<<q.earlier4<<','<<q.chosen<<','<<us<<','<<cpu<<'\n';
 }
}
