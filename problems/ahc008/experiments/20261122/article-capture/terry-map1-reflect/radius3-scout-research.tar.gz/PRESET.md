# Frozen exact readiness radius 3, one engineering admission
Retain original rejected scout separately. Replace only full per-unbooked worker BFS used solely for <=3 role reach. Seed origin even if blocked; mark depth3 without expanding; Manhattan radius3 permits 25 queue entries. Do not change room flood/boundary, turns, people, constructor, ties, model or protocol. Differential checks 2000 seed-fixed complete 900-cell masks vs stock. Standalone re-run uses exact original 36x16 metrics, exact 11 choices and coordinate/command/type involution; full scout median wall <=0.18s, max <=0.30s. If fails, stop without adjusting or native. No model or scorer. Hard100s, after separate clearance:
    sha256sum -c FROZEN.sha256
    python make.py
    g++ -std=gnu++23 unit.cpp -o unit && ./unit
    g++ -std=gnu++23 probe.cpp -o probe && python probe.py
