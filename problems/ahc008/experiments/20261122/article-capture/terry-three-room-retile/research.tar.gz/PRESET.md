# Frozen three-stock-pen retiling fixture

Canonical boundary comes from three consecutive exact width-four stock
tubes with aisle columns x=0,7. Immutable top/bottom (r=0,6) braces across
x=2..5 and no other changes outside the 5×6 movable patch r=1..5,
x=1..6. Body must stay inside x=2..5 or it directly touches a permanently
open aisle. Fixed budget eight stock interior X becomes at most seven.

Enumerate each connected old-coordinate body candidate area 3..6. It has
one or two gates adjacent to body, on x=1 or 6, and guards stand on
corresponding exterior aisles. A body must have legal endpoints of both
checkerboard parities, with every chosen gate at Manhattan distance ≥2
from each compatible endpoint. Mandatory planned walls are all other
body-neighbors except immutable perimeter braces. Enumerate every triple
with mutually disjoint room footprints including gates; any conflicting
required walls/gates/body or union of more than seven walls is rejected.
No wholesale count reduction or added actor commitment: exactly 3 rooms,
at most 2 employees per room/capture and at most 6 total gate actions.

Final independent test: flood with all gates open, each individual gate
blocked, each room wholly sealed, and all nominated doors closed. In all
held states require unchanged stock boundary/aisle anchor reach relations
(as minimum: extra paths allowed); in full-open every mouth and named
body is actually accessible; finally each body must be its own exact
component, and no new phantom floor can be orphaned. Optional fillers for
phantom cells must cover their entire isolated components and fit ≤7.
Additional arbitrary walls not used in this narrow mechanism.

Record effect on all-captured floor debit (movable walls + gates + animal
bodies) separately from planned-X gain. Ceiling only for isolated static
module, not dynamic staffing/interception. No actual input/seed/tape
consulted. Do not resize patch or expand body range on failure.
