#pragma GCC optimize("O3")
#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using B=uint64_t;
constexpr int R=7,C=8,V=R*C;
constexpr B all=(B{1}<<V)-1;
constexpr B west=0x0001010101010101ULL;
constexpr B east=west<<7;
constexpr int p(int r,int c){return r*C+c;}
constexpr B bit(int a){return B{1}<<a;}
constexpr B rectangle(int r0,int r1,int c0,int c1){
 B out=0;
 for(int r=r0;r<=r1;r++)for(int c=c0;c<=c1;c++)out|=bit(p(r,c));
 return out;
}
constexpr B fixed=rectangle(0,0,2,5)|rectangle(6,6,2,5);
constexpr B patch=rectangle(1,5,1,6),core=rectangle(1,5,2,5);
constexpr B gateTiles=patch&~core;
constexpr B anchors=(west|east)|rectangle(0,0,1,1)|rectangle(0,0,6,6)|
                   rectangle(6,6,1,1)|rectangle(6,6,6,6);
constexpr B stockX=rectangle(2,2,2,5)|rectangle(4,4,2,5);
constexpr B stockG=bit(9)|bit(14)|bit(25)|bit(30)|bit(41)|bit(46);

constexpr B near(B a){return (((a&~west)>>1)|((a&~east)<<1)|(a>>8)|(a<<8))&all;}
constexpr B low(B x){return x&(-x);}
B flood(B from,B open){
 B a=from;
 for(;;){
  B n=a|(near(a)&open);
  if(n==a)return a;
  a=n;
 }
}
constexpr int pop(B a){return std::popcount(a);}
int point(B a){return std::countr_zero(a);}
constexpr B parity(){
 B out=0;
 for(int r=0;r<R;r++)for(int c=0;c<C;c++)if((r+c)%2==0)out|=bit(p(r,c));
 return out;
}
constexpr B even=parity(),odd=all^even;
struct Room {B body,gates,braces;};

bool feasible(const Room& a,const Room& b){
 return !((a.body|a.gates)&(b.body|b.gates|b.braces))&&
        !((b.body|b.gates)&a.braces)&&pop(a.braces|b.braces)<=7;
}
bool anchorReach(B oldExtra,B newExtra){
 // Don't compare a closed door with an exterior anchor; by construction
 // these sets are disjoint. Verify every stock-reachable anchor pair.
 B todo=anchors;
 B oldOpen=all&~(fixed|stockX|oldExtra);
 B newOpen=all&~newExtra;
 while(todo){
  B src=low(todo);
  B old=flood(src,oldOpen)&anchors;
  if(old&~flood(src,newOpen))return false;
  todo&=~old;
 }
 return true;
}
bool certify(const std::array<Room,3>& rooms,B& walls,int& debit){
 B allDoors=0,body=0,insideWalls=0;
 for(auto r:rooms){allDoors|=r.gates;body|=r.body;insideWalls|=r.braces;}
 if(pop(insideWalls)>7||insideWalls&(allDoors|body))return false;
 const B sealed=fixed|insideWalls|allDoors;
 for(auto r:rooms)if(flood(low(r.body),all&~sealed)!=r.body)return false;
 B exterior=flood(anchors,all&~sealed);
 B filler=all&~(exterior|body|sealed);
 if(filler&~patch||pop(insideWalls|filler)>7)return false;
 insideWalls|=filler;walls=fixed|insideWalls;
 if(!anchorReach(0,walls))return false;
 exterior=flood(anchors,all&~walls);
 if((body|allDoors)&~exterior)return false;
 // Stock has both aisles connected after any one stock mouth or one
 // stock room pair closes; test the new mouth/room locks accordingly.
 const B representativeStockGate=low(stockG);
 const B representativeStockPair=bit(9)|bit(14);
 for(B todo=allDoors;todo;todo^=low(todo))
  if(!anchorReach(representativeStockGate,walls|low(todo)))return false;
 for(auto r:rooms){
  if(!anchorReach(representativeStockPair,walls|r.gates))return false;
  if(flood(low(r.body),all&~(walls|r.gates))!=r.body)return false;
 }
 if(!anchorReach(stockG,walls|allDoors))return false;
 debit=pop(insideWalls)+pop(allDoors)+pop(body);
 return true;
}

void show(const std::array<Room,3>& r,B w){
 for(int y=0;y<R;y++){
  for(int x=0;x<C;x++){
   B q=bit(p(y,x));char c='.';
   if(w&q)c='#';
   else if((west|east)&q)c='|';
   else for(int i=0;i<3;i++){
    if(r[i].body&q)c='A'+i;
    else if(r[i].gates&q)c='a'+i;
   }
   std::cout<<c;
  }
  std::cout<<'\n';
 }
}
int main(){
 assert(pop(core)==20&&pop(stockX)==8&&pop(stockG)==6);
 assert(anchorReach(0,fixed|stockX));
 std::vector<Room> room;
 uint64_t connected=0;
 for(B body=core;body;body=(body-1)&core){
  if(pop(body)<3||pop(body)>6||flood(low(body),body)!=body)continue;
  B mouth=near(body)&gateTiles;
  if(!mouth)continue;
  ++connected;
  for(B gates=mouth;gates;gates=(gates-1)&mouth){
   if(pop(gates)>2)continue;
   B safe=body&~near(gates);
   if(!(safe&even)||!(safe&odd))continue;
   B must=near(body)&~(body|gates|fixed);
   if((must&~patch)||pop(must)>7)continue;
   room.push_back({body,gates,must});
  }
 }
 std::sort(room.begin(),room.end(),[](const Room& a,const Room& b){
  if(a.body!=b.body)return a.body<b.body;
  return a.gates<b.gates;
 });
 const int n=room.size();
 std::vector<std::vector<int>> graph(n);
 uint64_t pairs=0,raw=0,wallgood=0,certified=0;
 for(int a=0;a<n;a++)for(int b=a+1;b<n;b++)
  if(feasible(room[a],room[b])){graph[a].push_back(b);++pairs;}
 int best=1000,bestX=1000,xForBest=1000;
 B sampleWalls=0;std::array<Room,3> sample{};
 for(int a=0;a<n;a++)for(int b:graph[a]){
  auto p=std::lower_bound(graph[a].begin(),graph[a].end(),b+1);
  auto q=graph[b].begin();
  const B prior=room[a].braces|room[b].braces;
  while(p!=graph[a].end()&&q!=graph[b].end()){
   if(*p<*q){++p;continue;}
   if(*q<*p){++q;continue;}
   int c=*p;++p;++q;++raw;
   if(pop(prior|room[c].braces)>7)continue;
   ++wallgood;
   B walls=0;int debit=0;
   std::array r{room[a],room[b],room[c]};
   if(!certify(r,walls,debit))continue;
   ++certified;
   const int x=pop(walls&patch);
   bestX=std::min(bestX,x);
   if(debit<best||(debit==best&&x<xForBest)){
    best=debit;xForBest=x;sample=r;sampleWalls=walls;
   }
  }
 }
 std::cout<<"operable_connected_bodies="<<connected<<" room_gate_options="<<n
          <<" compatible_pairs="<<pairs<<" pairwise_triples="<<raw
          <<" within_union_budget="<<wallgood<<" certified="<<certified<<'\n';
 if(certified){
  std::cout<<"smallest_planned_X="<<bestX<<" best_all_caught_debit="<<best
           <<" stock_debit=26 planned_X_for_best_debit="<<xForBest<<'\n';
  show(sample,sampleWalls);
 }
}
