# Faithful h123 current-cost profile
Use fixed exact rollover workloads of the already verified h123 held100.
Select first 16 by SHA(input SHA with this project namespace) in each
of no-rollout and actual positive-rollout strata; require ≥12 available.
No score/algorithm comparison or variation presented: every profiled
run must reproduce the recorded entire stdout action SHA and official
score including the late Normal/Chase switch. Expire bounded external
tester after 5.5s even though profiling alone disables the internal
time check with an explicit fixed count. Clock-based durations are
diagnostic on this machine, not candidate-dependent official timing.
Each stage reports exclusive time with nested brackets subtracted.
I/O and uninstrumented main-time are not reported in the denominator.
