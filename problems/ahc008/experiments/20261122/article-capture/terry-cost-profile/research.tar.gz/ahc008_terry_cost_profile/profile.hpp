#pragma once
#include <array>
#include <chrono>
#include <cstdlib>
#include <fstream>

// Observer only. Time from nested instrumented activity is removed from
// its parent's bucket, so the summary is not double counted.
namespace ahc008_cost_profile {
enum Stage { Normal, BuildPlan, BuildStep, Staff, Geometry, Arts,
   Retention, ExactMass, Hunt, Idle, Chase, Shape, ActualMotion, Score, Rollouts, Count };
inline constexpr std::array<const char*,Count> names{"Normal other","Initial build planning",
   "Construction other","Aisle reassignment","Geometry memo","Articulation memo",
   "Retention MC other","Exact short mass","Hunt assignments","Idle patrol",
   "Chase routing other","Chase shape/max flow","Virtual pet motion",
   "Exact score","Rollout overhead"};
using Timer=std::chrono::steady_clock;
inline std::array<long long,Count> ns{}, calls{};
struct Scope {
 Stage stage;
 Timer::time_point start;
 Scope* outer;
 long long children=0;
 static inline Scope* active=nullptr;
 explicit Scope(Stage what):stage(what),start(Timer::now()),outer(active){active=this;}
 ~Scope(){
  const auto elapsed=std::chrono::duration_cast<std::chrono::nanoseconds>(Timer::now()-start).count();
  ns[stage]+=elapsed-children;++calls[stage];
  active=outer;if(outer)outer->children+=elapsed;
 }
};
inline void write(){
 if(const char* path=std::getenv("AHC008_COST_PROFILE")){
  std::ofstream f(path);
  for(int i=0;i<Count;++i)f<<i<<','<<names[i]<<','<<calls[i]<<','<<ns[i]<<'\n';
 }
}
}
