"""Exclusive inclusive profiles on fixed work; no tuning or policy A/B."""
import collections
import csv
import hashlib
import json
import os
from pathlib import Path
import tempfile
import sys

D=Path(__file__).resolve().parent; R=D.parent
P=R/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(P))
from benchmark_cases import run

panel=R/'ahc008_terry_passive_exact_short/held100'
tester=R/'ahc008_focus_assets/tools/target/release/tester'
observer=D/'observer'
stock=[r for r in csv.DictReader((panel/'confirm.csv').open()) if r['arm']=='terry_independent']
def pairs(r): return int(r['telemetry'].split()[10])
def digest(t): return hashlib.sha256(t).hexdigest()
assert len(stock)==100
out=[]
for subset in ('normal-no-rollout','mixed-with-rollout'):
    group=[r for r in stock if (pairs(r)==0)==(subset=='normal-no-rollout')]
    group=sorted(group,key=lambda r:digest(('profile-20261123-v1/'+r['input_sha']).encode()))[:16]
    assert len(group)>=12
    for r in group:
        raw=(panel/'in'/r['case']).read_bytes()
        assert digest(raw)==r['input_sha']
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'cost.csv'
            args=[str(tester),'env','AHC008_COST_PROFILE='+str(p),str(observer),f'--pairs={pairs(r)}']
            answer,err,rc,wall=run(args,raw,5.5)
            assert rc==0 and err.strip()==('Score = '+r['score']).encode() and digest(answer)==r['commands_sha'], (r['case'],rc,err)
            rows=[dict(stage=name,n=int(calls),ns=int(ns))for _,name,calls,ns in csv.reader(p.open())]
            assert len(rows)==15 and all(x['ns']>=0 for x in rows)
            out.append(dict(case=r['case'],subset=subset,pairs=pairs(r),input_sha=r['input_sha'],commands_sha=r['commands_sha'],official_wall=wall,rows=rows))
        print(subset,r['case'],pairs(r),flush=True,file=sys.stderr)
summary=[]
for g in ('normal-no-rollout','mixed-with-rollout'):
    us=collections.Counter();nc=collections.Counter()
    for obj in out:
        if obj['subset']!=g:continue
        for r in obj['rows']:
            us[r['stage']]+=r['ns'];nc[r['stage']]+=r['n']
    total=sum(us.values())
    summary.append(dict(group=g,count=sum(o['subset']==g for o in out),total_profiled_ns=total,
        stages=[dict(stage=k,calls=nc[k],ns=v,pct=100*v/total)for k,v in us.most_common()]))
print(json.dumps(dict(summary=summary,rows=out), indent=2))
