"""Pinned accepted h123 -> only incremental mask-to-array conversion."""
from pathlib import Path
import hashlib

d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_passive_exact_short/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
def edit(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
a='#pragma GCC optimize("O3")'
edit(a,a+'\n'+(d/'cache.hpp').read_text().replace('#pragma once\n',''))
a=' TopologyMemo topology;'
edit(a,a+'\n CrewBoardCache<V> actual_array_cache;')
edit('  exact_build::Board actual_array{};\n  for(int p=0;p<V;++p)actual_array[p]=s.walls[p];',
     '  const auto& actual_array=actual_array_cache.get(s.walls);')
(d/'solve.private.cpp').write_text(s)
