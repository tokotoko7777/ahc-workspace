#include "cache.hpp"
#include <cassert>
#include <cstdio>
#include <random>

template<std::size_t N>
void check(){
    CrewBoardCache<N> c;
    using M=std::bitset<N>;
    std::mt19937 rng(558530+N);
    auto one=[&](M s){
        auto& a=c.get(s);
        for(size_t i=0;i<N;++i)assert(a[i]==s.test(i));
    };
    M s;
    one(s);
    one(s.set());
    one(s.reset());
    for(int i=0;i<5000;++i){
        M base=s;
        if(i%11==0) {
            for(size_t j=0;j<N;++j)s[j]=rng()&1;
        }else{
            for(int j=0;j<i%7;++j)s.flip(rng()%N);
        }
        one(s);
        one(s);
        one(base);
        one(s);
    }
}
int main(){
    check<1>(); check<31>(); check<64>(); check<65>();
    check<194>(); check<900>(); check<901>();
    std::puts("140k all-cell identical board conversions, including virtual rollback");
}
