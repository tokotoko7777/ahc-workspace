# Preregistered fixed-work A/B: cached actual wall conversion only
The original loops over every cell building a 900-byte board from the
same mask on each Normal step. Keep a fully materialized byte cache,
update exactly changed bits via GNU libstdc++ public extension
_Find_first/next. Neither immutable topology nor Crew selection changes.
Same state checks across duplicate boards, additions/deletions and
dense previous-trajectory rollback. No decoding private bitset layout.
Before official execute all unit snapshots, compile single GNU C++23
without requiring extra flags. Candidate advance only if entirety of
each 300-command stream and associated official score matches, and total
wait4 solver CPU drops at least 0.75% on each independently paired
practice100 and h123 held100 fixed-work. Do not assess held on practice
failure. Compare no-rollout subset explicitly; no claim about live
clock-limited scores from these fixed-work comparisons.
