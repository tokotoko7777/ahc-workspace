#pragma once
#include <array>
#include <bitset>
#include <cstddef>

// Cache both mask and fully equivalent byte board. Reversible across
// switchbacks into and out of a Monte Carlo trajectory. _Find members
// are the GNU libstdc++ layout-independent set-bit iteration API.
template<std::size_t N>
struct CrewBoardCache {
    std::bitset<N> mask;
    std::array<unsigned char,N> board{};
    const auto& get(const std::bitset<N>& walls) {
        const auto changed = walls ^ mask;
        for (std::size_t i = changed._Find_first(); i<N; i=changed._Find_next(i)) {
            board[i] = walls[i];
        }
        mask = walls;
        return board;
    }
};
