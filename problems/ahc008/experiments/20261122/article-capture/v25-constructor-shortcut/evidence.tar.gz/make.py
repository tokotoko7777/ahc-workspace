from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);b=p.read_bytes()
assert hashlib.sha256(b).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=b.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' const vector<vector<Order>>& tasks()const{return schedule;}',''' const vector<vector<Order>>& tasks()const{return schedule;}
 const vector<int>& shortcutCursor()const{return cursor;}''')
rep(' string integratedBankPlan(){',Path(__file__).with_name('audit.inc').read_text()+' string integratedBankPlan(){')
rep('  terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});','''  const auto shortcutBefore=usedPeople;
  terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});
  shortcutRemember(shortcutBefore,usedPeople,ready);''')
rep("  cout<<g.act<<'\\n'<<flush;", "  if(g.shortcutEnabled)g.shortcutObserve();\n  cout<<g.act<<'\\n'<<flush;")
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* f=getenv("AHC008_CONSTRUCTOR_SHORTCUT")){
  ofstream out(f);out<<g.shortcutLog.str();
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
