"""Original-policy offline stdin replay; never invokes the interactive tester."""
import argparse,collections,csv,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ahc008_focus_solver/problems/ahc008'))
from benchmark import replay

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for x in ('binary','ledger','inputs','tapes'):p.add_argument(x,type=Path)
    args=p.parse_args()
    rows=[q for q in csv.DictReader(args.ledger.open()) if q['model']=='baseline']
    assert len(rows)==30
    scores=collections.Counter()
    hist=collections.Counter()
    out={}
    with tempfile.TemporaryDirectory() as tmp:
        for ref in rows:
            c=ref['case']
            source=(args.inputs/c).read_bytes()
            assert hashlib.sha256(source).hexdigest()==ref['input_sha256']
            old=(args.tapes/c).with_suffix('.actions').read_bytes()
            assert hashlib.sha256(old).hexdigest()==ref['actions_sha256']
            trace=(args.tapes/c).with_suffix('.trace').read_text().splitlines()
            stock=old.decode().splitlines()
            assert len(stock)==300
            score,*_=replay(source.decode(),trace,stock,detailed=True)
            assert score==int(ref['score'])
            audit_file=Path(tmp)/c
            lines=source.splitlines()
            n=int(lines[0]);m=int(lines[n+1]);assert m==5
            public=b'\n'.join(lines[:n+m+2])+b'\n'
            stdin=public+('\n'.join(trace[1::2])+'\n').encode()
            res=subprocess.run([str(args.binary.resolve())],input=stdin,capture_output=True,
                env=dict(os.environ,AHC008_CONSTRUCTOR_SHORTCUT=str(audit_file)),check=True)
            current=res.stdout.decode().splitlines()
            assert len(current)==300
            first=next((t for t,(a,b) in enumerate(zip(stock,current,strict=True)) if a!=b),300)
            scores['full_exact']+=first==300
            if first!=300:
                scores['differing']+=1
            counts=collections.Counter()
            episodes={}
            critical_ts=set()
            for line in audit_file.read_text().splitlines():
                t,i,frm,goal,intact,old,alt,save,suffix,longest,e,f,z=map(int,line.split())
                if t>=first:
                    counts['unverified_constructor_walk']+=1
                    continue
                counts['verified_constructor_walk']+=1
                if not intact:counts['postprocessed_override']+=1
                if not save:continue
                counts['windows']+=1;hist[save]+=1
                k=(i,goal)
                e0=episodes.setdefault(k,dict(max_save=0,start=t,end=t,moves=[],critical=False))
                e0['max_save']=max(e0['max_save'],save);e0['end']=t
                e0['moves'].append([t,frm,e,f,z,save,suffix,longest])
                if suffix==longest and suffix>=0 and save>=3:
                    e0['critical']=True;critical_ts.add(t)
            if episodes:scores['boards_with_window']+=1
            if critical_ts:scores['boards_with_critical_save_ge3']+=1
            if not counts['unverified_constructor_walk']:scores['all_observed_construction_exact']+=1
            scores.update(counts)
            out[c]=dict(first_divergence=None if first==300 else first,counts=counts,
                distinct_worker_stances=len(episodes),critical_windows=len(critical_ts),
                longest_reobserved=max((len(x['moves']) for x in episodes.values()),default=0),
                episodes={f'{i}/{g}':x for (i,g),x in episodes.items()})
    print(json.dumps(dict(cases=len(rows),totals=scores,savings_walk_histogram=hist,
       gate=scores['boards_with_critical_save_ge3']>=10,by_case=out),indent=2))
if __name__=='__main__':main()
