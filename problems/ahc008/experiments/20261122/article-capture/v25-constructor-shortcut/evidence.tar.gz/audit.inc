 bool shortcutEnabled=getenv("AHC008_CONSTRUCTOR_SHORTCUT")!=nullptr;
 ostringstream shortcutLog;
 bitset<V> shortcutActive;
 array<int,5> shortcutAim{},shortcutAct{};
 bool shortcutHas=false;
 bitset<V> shortcutStaticPrevious;
 unordered_map<int,array<short,V>> shortcutDistances;
 void shortcutRemember(const bitset<V>& before,const bitset<V>& after,const vector<int>& ready){
  if(!shortcutEnabled||humans.size()!=5||!terryBuild.inConstruction(turn))return;
  const auto& q=terryBuild.tasks();const auto& j=terryBuild.shortcutCursor();
  if(q.size()!=5||j.size()!=5)return;
  shortcutActive.reset();shortcutAim.fill(-1);shortcutAct.fill(-1);
  for(int k=0;k<int(banks.size());k++)if(ready[k])
   for(int p:banks[k].inner)shortcutActive[p]=true;
  for(int i=0;i<5;i++)if(!before[i]&&after[i]&&isupper(act[i])&&j[i]<int(q[i].size())){
   shortcutAim[i]=q[i][j[i]].from;
   shortcutAct[i]=act[i];
   shortcutHas=true;
  }
 }
 void shortcutObserve(){
  if(!shortcutHas)return;
  shortcutHas=false;
  bitset<V> existing,planned=terryBuild.braces(),otherWalls,otherMoves,guards;
  for(int p=0;p<V;p++)existing[p]=wall[p];
  for(int i=0;i<5;i++)if(act[i]!='.'){
   int p=nb[humans[i]][string_view("UDLR").find(toupper(act[i]))];
   if(p<0)continue;
   if(islower(act[i]))otherWalls[p]=true;
   else otherMoves[p]=true;
  }
  for(auto& z:banks)for(int p:{z.l,z.h,z.g,z.k})guards[p]=true;
  const auto& q=terryBuild.tasks();const auto& j=terryBuild.shortcutCursor();
  array<bitset<V>,5> soon;
  for(int i=0;i<5;i++){
   int orders=0;
   for(int k=j[i];k<int(q[i].size())&&orders<2;k++){
    bool any=false;
    for(int z:q[i][k].walls)if(!existing[z]&&!otherWalls[z])any=true;
    if(!any)continue;
    // Exclude every wall in the next two pending orders, a stricter
    // embargo than only two cells when an order has multiple walls.
    ++orders;
    for(int z:q[i][k].walls)if(!existing[z]&&!otherWalls[z])soon[i][z]=true;
   }
  }
  const auto staticBlocked=planned|existing|otherWalls;
  if(staticBlocked!=shortcutStaticPrevious){shortcutDistances.clear();shortcutStaticPrevious=staticBlocked;}
  auto distance=[&](int from,int to){
   if(from==to)return 0;
   auto at=shortcutDistances.find(from);
   if(at==shortcutDistances.end()){
    terry_build::Nav nav;nav.run(from,staticBlocked);
    at=shortcutDistances.emplace(from,nav.d).first;
   }
   return int(at->second[to]);
  };
  // Critical means largest nominal walk+build suffix (including all
  // currently pending owned work), ignoring future animal blocks.
  array<int,5> suffix{};
  int critical=-1;
  for(int i=0;i<5;i++){
   int from=humans[i],n=0;
   for(int k=j[i];k<int(q[i].size());k++){
    int jobs=0;for(int p:q[i][k].walls)jobs+=!existing[p]&&!otherWalls[p];
    if(!jobs)continue;
    int d=distance(from,q[i][k].from);
    if(d<0){n=-1;break;}
    n+=d+jobs;from=q[i][k].from;
   }
   suffix[i]=n;critical=max(critical,n);
  }
  for(int i=0;i<5;i++)if(shortcutAim[i]>=0){
   const bool intact=act[i]==shortcutAct[i];
   const int from=humans[i],goal=shortcutAim[i];
   auto active=shortcutActive;
   if(active[from])for(const auto& z:banks)
    if(find(z.inner.begin(),z.inner.end(),from)!=z.inner.end()){
     for(int p:z.inner)active[p]=false;
     break;
    }
   const auto safeBlocked=staticBlocked|active;
   terry_build::Nav back;
   back.run(goal,safeBlocked);
   const auto nominalBlocked=existing|planned|active;
   terry_build::Nav before;
   int old;
   if(nominalBlocked==safeBlocked){
    old=back.d[from];
    if(old<0&&safeBlocked[from]){
     // The forward Nav allows starting on a future wall and leaving it.
     for(int a:nb[from])if(a>=0&&back.d[a]>=0&&(old<0||1+back.d[a]<old))old=1+back.d[a];
    }
   }else{
    before.run(from,nominalBlocked);
    old=before.d[goal];
   }
   int best=1000,first=-1,second=-1,rejoin=-1;
   bitset<V> taboo=existing|otherWalls|guards|active|otherMoves;
   for(int j=0;j<5;j++)if(j!=i){taboo|=soon[j];taboo[humans[j]]=true;}
   auto see=[&](int e,int f,int z,int enter){
    // z genuinely rejoins the normal safe connected floor at least
    // one further step *before* the intended constructor stance.
    if(z<0||safeBlocked[z]||otherMoves[z]||back.d[z]<=0)return;
    int v=enter+1+back.d[z];
    if(v<best)best=v,first=e,second=f,rejoin=z;
   };
   for(int e:nb[from])if(e>=0&&planned[e]&&!taboo[e]){
    for(int z:nb[e]){
     see(e,-1,z,1);
     if(z>=0&&planned[z]&&!taboo[z])for(int t:nb[z])if(t!=e)see(e,z,t,2);
    }
   }
   const bool gain=intact&&old>best;
   shortcutLog<<turn<<' '<<i<<' '<<from<<' '<<goal<<' '<<intact<<' '<<old<<' '
     <<(gain?best:-1)<<' '<<(gain?old-best:0)<<' '<<suffix[i]<<' '<<critical<<' '
     <<first<<' '<<second<<' '<<rejoin<<'\n';
  }
 }
