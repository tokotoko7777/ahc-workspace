from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);d=p.read_bytes()
assert hashlib.sha256(d).hexdigest()=='46f210cc5dd50b8a6088724861ae5c2b044d08edb109a891ee217352730fcb84'
s=d.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' string integratedBankPlan(){',Path(__file__).with_name('audit.inc').read_text()+' string integratedBankPlan(){')
rep('  if(turn>=bankRelease){integratedMode[turn]=4;dogPhase=9;return plan();}', '''  if(turn>=bankRelease){integratedMode[turn]=4;dogPhase=9;return plan();}
  guardPatienceStart(ready,usedPeople);''')
rep('  // For remaining workers observed legal walls precede predicted jobs.','''  guardPatienceRole(usedPeople,2);
  // For remaining workers observed legal walls precede predicted jobs.''')
rep('   terryBuild.relay(turn,humans,walls,build,moveTo,usedPeople,act,133);','''   const auto auditBeforeRelay=usedPeople;
   terryBuild.relay(turn,humans,walls,build,moveTo,usedPeople,act,133);
   guardPatienceRole(usedPeople&~auditBeforeRelay,4);''')
rep('  // Untasked workers repair or fill braces after the assigned sweeps.','''  const auto auditBeforeRepair=usedPeople;
  // Untasked workers repair or fill braces after the assigned sweeps.''')
rep('  if(scheduled&&!partial){\n   // The handoff above owns service-aisle assignments.', '''  guardPatienceRole(usedPeople&~auditBeforeRepair,8);
  if(scheduled&&!partial){
   // The handoff above owns service-aisle assignments.''')
rep('   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);\n  }\n  return act;', '''   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);
  }
  if(!guardPatiencePending.empty())guardPatienceDraft=act;
  return act;''')
rep("  if(!g.advance())break;", "  if(!g.advance())break;\n  g.guardPatienceObserved();")
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* path=getenv("AHC008_GUARD_PATIENCE_AUDIT")){
  ofstream f(path);f<<g.guardPatienceLog.str();
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
