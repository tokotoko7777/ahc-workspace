import argparse,collections,csv,json
from pathlib import Path

def examine(path, ledger):
    counts=collections.defaultdict(set)
    examples=[]
    release=int(ledger['reported_release']) if ledger else 300
    fr=int(ledger['first_all_clear']) if ledger else -1
    captured={int(x.split(':')[1]) for x in ledger['captures'].split(';') if x} if ledger else None
    for line in path.read_text().splitlines():
        vals=line.split()
        t,k,a,b,initial,block,gone,reasons,same,safe,left,right=map(int,vals[:12])
        tag=(t,k)
        counts['aligned_blocked'].add(tag)
        if gone:counts['departed'].add(tag)
        if gone and reasons==32:counts['voluntary_departure'].add(tag)
        if not safe or not same:
            continue
        counts['same_animal_safe_next'].add(tag)
        if not gone:
            counts['kept_safe_next'].add(tag)
            continue
        if t+1>=release or 0<=fr<=t+1:
            counts['next_not_regular'].add(tag)
            continue
        if left and right:
            counts['departed_but_replaced'].add(tag)
            continue
        if reasons!=32:
            counts['would_displace_mandatory_or_overridden'].add(tag)
            continue
        counts['voluntary_unfilled_safe_next'].add(tag)
        ids=[i for i in range(20) if same>>i&1]
        missed=None if captured is None else [i for i in ids if i not in captured]
        if missed:
            counts['voluntary_unfilled_final_missed'].update(missed)
        examples.append(dict(t=t,tube=k,workers=[a,b],departed=gone,initial_block=block,
             next_current_workers=[left,right],next_same_pet_ids=ids,final_missed=missed,actual=vals[12]))
    return dict(count={k:len(v) for k,v in counts.items()},examples=examples)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('logs',nargs='+',type=Path)
    p.add_argument('--ledger',type=Path)
    p.add_argument('--model',default='article')
    a=p.parse_args()
    historical={} if not a.ledger else {
       row['case'].removesuffix('.txt'):row for row in csv.DictReader(a.ledger.open())
       if row['model']==a.model}
    out={l.name:examine(l,historical.get(l.stem.removesuffix('.txt'))) for l in a.logs}
    t=collections.Counter()
    for row in out.values():t.update(row['count'])
    print(json.dumps(dict(cases=len(out),totals=t,boards={k:sum(k in v['count'] for v in out.values())
        for k in t},with_historical_ledger=bool(historical),by_case=out),indent=2))
