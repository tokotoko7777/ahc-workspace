 struct GuardPatienceTrial {int k,a,b;unsigned inside;unsigned blocked;};
 bool guardPatienceEnabled=getenv("AHC008_GUARD_PATIENCE_AUDIT")!=nullptr;
 vector<GuardPatienceTrial> guardPatiencePending;
 string guardPatienceDraft;
 array<int,5> guardPatienceRoleMask{};
 ostringstream guardPatienceLog;
 void guardPatienceRole(const bitset<V>& claimed,int mask){
  if(guardPatiencePending.empty())return;
  for(int i=0;i<5;i++)if(claimed[i]&&guardPatienceRoleMask[i]==0)guardPatienceRoleMask[i]=mask;
 }
 void guardPatienceStart(const vector<int>& ready,const bitset<V>& bridgers){
  if(!guardPatienceEnabled||humans.size()!=5||turn>=299)return;
  guardPatienceRoleMask.fill(0);guardPatienceDraft.clear();
  for(int k=0;k<int(banks.size());k++)if(ready[k]&&!terryRoad.bridge[k]&&!crossing.reserves(k)){
   auto& x=banks[k];
   if(wall[x.g]||wall[x.k])continue;
   if(any_of(x.inner.begin(),x.inner.end(),[&](int q){return wall[q];}))continue;
   if(any_of(humans.begin(),humans.end(),[&](int q){return q==x.g||q==x.k||
       find(x.inner.begin(),x.inner.end(),q)!=x.inner.end();}))continue;
   unsigned blocked=0,inside=0;
   for(int j=0;j<int(pets.size());j++){
    int p=pets[j].p;
    if(md(p,x.g)<=1)blocked|=1;
    if(md(p,x.k)<=1)blocked|=2;
    if(find(x.inner.begin(),x.inner.end(),p)!=x.inner.end())inside|=1U<<j;
   }
   if(!blocked||!inside)continue;
   for(int a=0;a<5;a++)if(humans[a]==x.l)
    for(int b=0;b<5;b++)if(a!=b&&humans[b]==x.h)
     guardPatiencePending.push_back({k,a,b,inside,blocked});
  }
  guardPatienceRole(bridgers,1);
 }
 void guardPatienceObserved(){
  if(!guardPatienceEnabled||guardPatiencePending.empty())return;
  for(auto z:guardPatiencePending){
   auto& x=banks[z.k];
   const int a=z.a,b=z.b;
   const bool leftGone=humans[a]!=x.l,rightGone=humans[b]!=x.h;
   const int gone=leftGone+rightGone;
   int departReasons=0;
   for(int i:{a,b})if(i==a?leftGone:rightGone){
    int reason=guardPatienceRoleMask[i];
    if(guardPatienceDraft.empty()||act[i]!=guardPatienceDraft[i])reason=16;
    departReasons|=reason?reason:32;
   }
   unsigned nextInner=0;bool safe=!wall[x.g]&&!wall[x.k];
   for(int q:x.inner)if(wall[q])safe=false;
   for(int j=0;j<int(pets.size());j++){
    int p=pets[j].p;
    if(md(p,x.g)<=1||md(p,x.k)<=1)safe=false;
    if(p==x.inner[1]||p==x.inner[2])nextInner|=1U<<j;
   }
   const unsigned same=z.inside&nextInner;
   auto held=humans;held[a]=x.l;held[b]=x.h;
   for(int p:held)if(wall[p]||p==x.g||p==x.k||
       find(x.inner.begin(),x.inner.end(),p)!=x.inner.end())safe=false;
   // Exact post-gate same exterior check with factual next wall mask and
   // all other people left at their factual next locations.
   if(safe&&same){
    bitset<V> seen;int q[V],n=1;q[0]=held[0];seen[q[0]]=true;
    for(int i=0;i<n;i++)for(int v:nb[q[i]])
     if(v>=0&&!wall[v]&&v!=x.g&&v!=x.k&&!seen[v])seen[v]=true,q[n++]=v;
    for(int h:held)if(!seen[h])safe=false;
    for(int p:x.inner)if(seen[p])safe=false;
   }
   int nextLeft=0,nextRight=0;
   for(int h:humans){nextLeft+=h==x.l;nextRight+=h==x.h;}
   guardPatienceLog<<turn<<' '<<z.k<<' '<<a<<' '<<b<<' '<<z.inside<<' '<<z.blocked<<' '
    <<gone<<' '<<departReasons<<' '<<same<<' '<<safe<<' '<<nextLeft<<' '<<nextRight<<' '
    <<act<<'\n';
  }
  guardPatiencePending.clear();
 }
