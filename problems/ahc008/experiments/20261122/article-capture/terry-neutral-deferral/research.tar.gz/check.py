"""Public snapshot proof-support only, without judge, counterscript, solver or RNG seed."""
from pathlib import Path
import sys,json
from collections import Counter,deque
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_x_exact_replay'))
import replay as Q
sys.path.insert(0,str(Q.T))
from analyze import observed
from stochastic_lock_audit import idx

# DIR order exact official URDL is not required for equality of the
# sets: official code filters the fixed official order on both boards.
NEIGH=[tuple(Q.shift(i,c) for c in 'URDL') for i in range(900)]
def distances(w,h):
    ret=[-1]*900;ret[h]=0
    que=deque([h])
    while que:
        p=que.popleft()
        for z in NEIGH[p]:
            if z is not None and ret[z]<0 and not Q.bit(z)&w:
                ret[z]=ret[p]+1;que.append(z)
    return ret
def down(ds,p):
    return tuple(i for i,z in enumerate(NEIGH[p]) if z is not None and 0<=ds[z]<ds[p])

def dog_same(w,wo,crew,dogs):
    if not dogs:return True
    # One distance pair per distinct human endpoint, compared across all dogs.
    tables={x:(distances(w,x),distances(wo,x)) for x in set(crew)}
    for p in dogs:
        for x in crew:
            ds,do=tables[x]
            if (ds[p]>0)!=(do[p]>0):return False
            if ds[p]>0 and down(ds,p)!=down(do,p):return False
            if (ds[p]<0)!=(do[p]<0):return False
    return True

def board(rec,options):
    base=(Q.T/'tapes'/rec['case']).with_suffix('.actions')
    inp,act,tr=[p.read_bytes() for p in (Q.I/rec['case'],base,base.with_suffix('.trace'))]
    assert [Q.digest(d) for d in (inp,act,tr)]==[rec[k] for k in ('input_sha','commands_sha','trace_sha')]
    a=act.decode().splitlines();z=tr.decode().splitlines()
    assert len(a)==300 and len(z)==600 and a==z[::2]
    kinds,H,_=observed(inp,z)
    H=[(list(map(idx,p)),list(map(idx,h)),Q.mask(map(idx,w))) for p,h,w in H]
    pp,hh,ww=H[-1]
    assert bool(rec['actual_full'])==(not any(Q.state(ww,hh,pp)[1]))
    count=Counter();first=None
    for t,cmd in enumerate(a[:160]):
        p,h,w=H[t];_,nxt,wh=H[t+1]
        put,ww,crew=Q.project(w,h,cmd)
        assert (ww,crew)==(wh,nxt)
        opts=sorted({q for q in put.values() if q in options and not Q.bit(q)&w})
        if not opts:continue
        band='early_0_99' if t<100 else 'late_100_159'
        def add(k):
            count[k]+=1
            count[band+':'+k]+=1
        before=Q.state(ww,crew,p)
        for q in opts:
            add('menu')
            wo=ww^Q.bit(q); after=Q.state(wo,crew,p)
            if before[:2]!=after[:2]:
                add('reach_or_connect');continue
            region=Q.bit(q)
            for _ in range(6):region|=Q.wave(region)&(Q.ALL^wo)
            if region&Q.mask(p):
                add('some_pet_within6');continue
            comp=Q.flood(Q.bit(q),Q.ALL^wo)
            held=[(k,x) for k,x in zip(kinds,p) if comp&Q.bit(x)]
            if any(k==5 for k,x in held):
                add('affected_cat');continue
            add('cat_free_upper')
            dogs=[x for k,x in held if k==4]
            if not dog_same(ww,wo,crew,dogs):
                add('dog_choices_differ');continue
            add('certified')
            actors=[i for i,x in put.items() if x==q]
            assert actors and all(crew[i]==h[i] for i in actors)
            # Factual t+1 slack label is deliberately downstream of selection.
            available=sum(a[t+1][i]=='.' for i in actors)
            if available: add('next_factual_idle_builder')
            if first is None:
                first=dict(t=t,cell=q,actors=actors,dogs=len(dogs),
                           next_factual_idle_builder=bool(available),
                           hold_population=len(held))
    return dict(case=rec['case'],map=rec['map'],counts=dict(count),first=first)
def main():
    for p,d in Q.PINS.items():assert Q.digest(p.read_bytes())==d
    assert Q.digest((R/'ahc008_terry_x_exact_replay/replay.py').read_bytes())=='13009b7efacbf777154199d0e38659f6a14a578548fdaeb18aee1df8f4b3adc5'
    chosen=[set(map(int,m.split(','))) if m else set() for m in Q.menus()]
    rec=json.loads((Q.T/'recordings.json').read_text())
    assert len(rec)==len({x['case'] for x in rec})==100
    rows=[board(r,chosen[r['map']]) for r in rec]
    allc=Counter()
    for r in rows:allc.update(r['counts'])
    good=[r for r in rows if r['first']]
    alive=[r for r in rows if r['counts'].get('cat_free_upper',0)]
    idle=sum(r['first']['next_factual_idle_builder'] for r in good)
    phases={band:{'boards_menu':sum(bool(r['counts'].get(band+':menu')) for r in rows),
                  'boards_certified':sum(bool(r['counts'].get(band+':certified')) for r in rows),
                  'boards_with_factual_builder_idle':sum(bool(r['counts'].get(band+':next_factual_idle_builder')) for r in rows)}
            for band in ('early_0_99','late_100_159')}
    print(json.dumps(dict(n=100,phase_boards=phases,counts=dict(allc),cat_free_upper_boards=len(alive),
                          exact_boards=len(good),first_with_idle=idle,
                          support_gate=len(good)>=20 and idle>=5,rows=rows),indent=2))
if __name__=='__main__':main()
