# One-turn certified movement-neutral setup X deferral

Read-only older accepted Incoming signed held100, exact frozen prior
static optional-X menu, t<160. No simulator, judge, solver, score,
compilation, new cases or deployment. Every hashed input/opponent/action
tape must match and original wall and worker projection is checked.
Screen every actual first stock installation in the menu, row-major, and
mark first eligible per board. Requirement: replace same-action building
of just this X by wait, identical other commands/human endpoints; compare
post-human projected walls. Preserve exact per-worker reachable pet sets
and worker connectivity. Require *all* pets >6 hops from opened X in the
open graph, regardless of worker accessibility. Pets in another component
are at infinite distance; no future positions are used.

Every possible passive substep retains identical ordered legal motion
choices (at most three; no pet can approach X closely enough in this
turn). For a dog in X's open component, compare every ordered eligible
worker-ID retarget list and exact direction set of first shortest-descent
options for every possible reachable latent worker target; per-ID
positive/negative-distance masks equal give same order in the official
fixed lists. Second standard substep has the same ordered choices and
target-reset conditions compare identical worker coordinates. Outside
the X component, reach or paths cannot change. Any cat in X's open
component is conservatively rejected: with no latent-state knowledge,
a reset cat can choose target from its whole connected component, and
that ordered list necessarily includes a new cell. A cat outside that
component cannot reach X; if its stale target equals X, stock clears it
on blocked-target check and open clears it on failed reach, with no
random draw intervening. Identical ordered choice lists imply identical
RNG calls/answers and latent updates for every possible compatible
initial seed/state under the same current judge. This proof covers the
one unchanged public motion step only; it does not model adaptive role
release, future whole policy, or permanent skips.

At next turn those pets are still at least 4 steps from X. Original
builder stayed in its same adjacent stance at t. A reserved one-step
restoration can thus be legal at t+1 (other commands must not be
allowed to move into X; that requirement is separately audited below).
Label whether the factual next turn had a waiting original builder;
it's descriptive, not part of trigger, and shows no new work would
be displaced for that worker on the original tape only. No reserve
commitment or next-turn placement made. Frozen support ≥20 distinct
boards with a certificate and ≥5 of their first certificates at
factual idle slack. Count cats-only optimistic upper before dog test.
Per-phase counts and unique boards: t0–99 and t100–159.
Both thresholds are diagnostic only, not authority to adapt. No
retune. No rerun or substitutions if cap/fail.

One run after explicit CPU clearance:
```sh
timeout -k 1s 89s python3 -u ahc008_terry_neutral_deferral/check.py \
  > ahc008_terry_neutral_deferral/result.json
```
