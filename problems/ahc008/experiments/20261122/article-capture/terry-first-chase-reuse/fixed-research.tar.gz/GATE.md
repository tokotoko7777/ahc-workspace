# Exact single-action reuse in terminal paired simulation

Profiler on selected incoming showed Chase flow/shape 50.9% of profiled
positive-rollout time. Every Chase arm starts its own untouched
copy of the same live state and receives the same action at its first
turn (fixed legacy planner turn275). Cache that one action locally
and lazily, so cap0/early clock does not force extra work. Neither
active live Chase nor any later reconstructed path, pet RNG, Normal
queues, shape tie policy or stop checks are changed; saved time can
increase naturally completed pairs. Do not combine with other speedup.

Unit independent fixed work exact all sums, choices, queue and live
RNG. On current accepted distributed practice100 and independent
incoming held100 fixed recorded diagnostic caps require all full
commands/scores exact, ≥2.0% less summed solver CPU in each
positive-rollout stratum and whole panel CPU nonhigher, local max
<2.95. If first fails no independent. If both pass normal-clock
separately checking same score/full/useful any score increase
is not claimed from fixed comparability; any default deterioration
leaves accepted solver unchanged. Never input case-specific caps to
the real solver policy.
