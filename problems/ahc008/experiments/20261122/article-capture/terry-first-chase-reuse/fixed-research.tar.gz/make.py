"""Pinned selected incoming; reuse only identical first Chase proposal."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
a=s.index('Decision decide(const State& live,Normal& ordinary,int cap,Clock::time_point stop){')
b=s.index('\n}\n}',a)+2
y=s[a:b]
(d/'ref.hpp').write_text(y.replace('Decision decide(', 'Decision decide_ref(', 1))
needle=' Decision answer;'
assert y.count(needle)==1
y=y.replace(needle,needle+'\n std::optional<std::string> identicalFirstChase;')
needle='   people_step(t,chase(t,*ordinary.terrain,275));actual_motion(t,b);'
assert y.count(needle)==1
y=y.replace(needle,'''   if(turn==275){
    // Same unadvanced live snapshot, stage and fixed layout in each
    // paired Chase arm. The planner has no mutable policy state.
    if(!identicalFirstChase)identicalFirstChase=chase(live,*ordinary.terrain,275);
    people_step(t,*identicalFirstChase);
   }else{
    people_step(t,chase(t,*ordinary.terrain,275));
   }
   actual_motion(t,b);''')
(d/'solve.private.cpp').write_text(s[:a]+y+s[b:])
