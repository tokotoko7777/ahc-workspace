#define main archive_submission_main
#include "solve.private.cpp"
#undef main
#include <random>
#include <cstdio>
namespace terry_exact_root {
#include "ref.hpp"
}
int main(){
 using namespace terry_exact_root;
 std::mt19937 rng(8516701);
 for(int c=0;c<26;++c){
  const auto& g=terrain_lib::terrain(c%5);
  State s;
  if(c%5!=0)s.walls=g.plannedWalls;
  std::vector<int> floor;
  for(int x=0;x<V;++x)if(!s.walls[x])floor.push_back(x);
  std::shuffle(floor.begin(),floor.end(),rng);
  const int m=5+c%6,n=10+c%11;
  for(int k=0;k<m;++k)s.people.push_back(floor[k]);
  for(int k=0;k<n;++k)s.pets.push_back({floor[m+k],1+int(rng()%5),-1});
  Normal a(g,s),b(g,s);
  if(c%4)for(int i=0;i<m;++i){a.crew.q[i].clear();b.crew.q[i].clear();}
  auto one=decide_ref(s,a,3,Clock::time_point::max());
  auto two=decide(s,b,3,Clock::time_point::max());
  assert(one.pairs==two.pairs&&one.normal==two.normal&&one.chase_sum==two.chase_sum&&one.chose==two.chose&&a.rng.s==b.rng.s);
  for(int i=0;i<m;++i){
   auto& a0=a.crew.q[i];auto& b0=b.crew.q[i];assert(a0.size()==b0.size());
   for(size_t j=0;j<a0.size();++j)assert(a0[j].at==b0[j].at&&a0[j].mask==b0[j].mask);
  }
 }
 std::puts("26 same-work paired simulations match sums, decisions, queues and live RNG");
}
