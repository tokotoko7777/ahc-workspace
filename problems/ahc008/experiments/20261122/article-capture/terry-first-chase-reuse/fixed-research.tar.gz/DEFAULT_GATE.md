# Actual-clock admission of the exact first-Chase cache

Wait for both fixed-work panels to pass. Then repeat unchanged
selected incoming baseline versus this one memo under the original
2670 ms and no per-input pair cap. Official distributed100 and
separate unfiltered generated100 (locked seed namespace here).
Require exact official+playback+independent legality/scores on all
runs, local max tester below2.95s, score nondecrease, raw/useful
capture counts nondecrease on both. Distributed baseline full100
can never be worsened. If a normal-time stage changes behavior
through more iterations, report which and score both without
combining speed percentages. Only claim best score if practice
exceeds the previously accepted 6,152,805,559 under same 100
inputs and no other gate fails. No tuning case IDs, timing or
scoped fallback from these outcomes.
