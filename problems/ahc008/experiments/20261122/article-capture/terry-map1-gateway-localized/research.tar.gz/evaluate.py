"""Only fixed synthetic no-pet states; no judge/solver case data."""
import csv,hashlib,io,json,statistics,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
P=R/'ahc008_terry_map1_hybrid14_gateway'
board=(P/'boards.txt').read_bytes()
assert hashlib.sha256(board).hexdigest()=='49f93951cc40a568c524d363915b2d8c6ab14d98ea974948bb3ec53d0d12aa76'
def roster(label):
    out=[]
    for m in (5,6):
        for i in range(18):
            p=[];j=0
            while len(p)<m:
                v=int.from_bytes(hashlib.sha256(f'{label}:{m}:{i}:{j}'.encode()).digest()[:8],'little')
                j+=1
                if v<2**64-2**64%900 and v%900 not in p:p.append(v%900)
            out.append((m,*p))
    return out
fresh=roster('ahc008-map1-gateway-local-stance-v1')
old={h for key in ('ahc008-map1-hybrid14-gateway-dry-v1','ahc008-map1-hybrid14-dry-v1') for h in roster(key)}
assert len(set(fresh))==36 and not old&set(fresh)
data=('\n'.join(' '.join(map(str,r)) for r in fresh)+'\n').encode()
(D/'fixtures.txt').write_bytes(data)
res=subprocess.run([str(D/'dry')],input=board+data,capture_output=True,check=True,timeout=75)
(D/'dry.csv').write_bytes(res.stdout)
rows={}
for v in csv.DictReader(io.StringIO(res.stdout.decode())):
    v={k:int(x) for k,x in v.items()}
    rows.setdefault(v['case'],[]).append(v)
assert list(rows)==list(range(36)) and all(len(x)==2 for x in rows.values())
def good(a):
    return (a['assigned'] and 0<a['all']<=a['ready']<=160 and
            not (a['missing'] or a['invalid'] or a['unreachable']) and
            a['inside_built']==a['inside_exit'] and a['nominal_ready']==a['nominal_total'])
groups={}
for m in ('all',5,6):
    rs=[(a,b) for a,b in rows.values() if m=='all' or a['m']==m]
    assert all((a['arm'],b['arm'])==(0,1) and a['m']==b['m'] for a,b in rs)
    ds=[b['ready']-a['ready'] for a,b in rs if good(a) and good(b)]
    all_x=[b['all']-a['all'] for a,b in rs if good(a) and good(b)]
    groups[str(m)]=dict(baseline_pass=sum(good(a) for a,b in rs),
      candidate_pass=sum(good(b) for a,b in rs),joint=len(ds),
      delay_median=statistics.median(ds) if ds else None,delay_max=max(ds,default=None),
      all_x_median=statistics.median(all_x) if all_x else None,
      inside_built=sum(b['inside_built'] for a,b in rs),inside_exit=sum(b['inside_exit'] for a,b in rs),
      aliases=sum(b['legacy_aliases'] for a,b in rs), unowned_distribution={i:sum(b['unowned']==i for a,b in rs) for i in range(13)},
      setup_reasons={i:sum(b['setup_reason']==i for a,b in rs) for i in range(7)})
all=groups['all']
gate=all['joint']==36 and all['delay_median']<=12 and all['delay_max']<=20
o=dict(groups=groups,fixtures_sha=hashlib.sha256(data).hexdigest(),gate=gate)
(D/'result.json').write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(o))
if not gate:raise SystemExit(3)
