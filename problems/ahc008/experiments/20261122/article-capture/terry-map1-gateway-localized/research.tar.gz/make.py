from pathlib import Path
from hashlib import sha256
D=Path(__file__).resolve().parent;R=D.parent
P=R/'ahc008_terry_map1_hybrid14_gateway'
a=(P/'dry.cpp').read_bytes()
assert sha256(a).hexdigest()=='45d90eb046e9fada46f2f83df27b8b78be4fb0ddda26e17140dede0eca9ba8f2'
a=a.decode()
lo=a.index('const std::array<int,7> cap')
hi=a.index('struct Result',lo)
a=a[:lo]+(D/'splice.inc').read_text()+a[hi:]
def one(s,t):
    global a
    assert a.count(s)==1, s
    a=a.replace(s,t)
one('bool assigned=false;', 'bool assigned=false;int unowned=0,aliases=0,inside_built=0,inside_exit=0,nominal_ready=0,nominal_total=0;')
one(' Crew crew;',' Crew crew; Ownership diag;diag.interior.fill(-1);\n auto nc=catalog(l,final);\n z.nominal_total=nc.rooms.size();\n std::vector<std::pair<int,int>> awaits;')
one('else if(candidate)z.setup_reason=add_caps(crew,h,final);',
    'else if(candidate)z.setup_reason=add_caps(crew,h,final,diag);\n z.unowned=diag.missing;z.aliases=diag.aliases;')
one('   w[p]=1;','   w[p]=1;\n   if(diag.interior[p]>=0){++z.inside_built;awaits.emplace_back(i,diag.interior[p]);}')
one('  h=std::move(next);','  h=std::move(next);\n  for(auto& x:awaits)if(x.first>=0&&nc.id[h[x.first]]!=x.second){++z.inside_exit;x.first=-1;}')
one('   std::sort(counts.begin(),counts.end());\n   auto demand=h.size()==5?std::array<int,3>{1,2,2}:std::array<int,3>{2,2,2};','''   auto ranked=l.aisleCols;
   std::stable_sort(ranked.begin(),ranked.end(),[](int a,int b){return std::abs(a-15)<std::abs(b-15);});
   std::array<int,3> demand{};
   for(int i=0;i<int(h.size());i++)++demand[std::find(l.aisleCols.begin(),l.aisleCols.end(),ranked[i%3])-l.aisleCols.begin()];''')
one('   if(all&&counts==demand){z.ready=t;break;}','''   if(all&&counts==demand){
    z.ready=t;
    for(int room:nc.rooms){
     bool clear=true;for(int q:h)if(nc.id[q]==room)clear=false;
     for(int g:nc.gates[room])if(w[g])clear=false;
     z.nominal_ready+=clear;
    }
    break;
   }''')
one('unreachable,assigned,setup_reason\\n', 'unreachable,assigned,setup_reason,unowned,legacy_aliases,inside_built,inside_exit,nominal_ready,nominal_total\\n')
one("<<z.setup_reason<<'\\n';","<<z.setup_reason<<','<<z.unowned<<','<<z.aliases<<','<<z.inside_built<<','<<z.inside_exit<<','<<z.nominal_ready<<','<<z.nominal_total<<'\\n';")
(D/'dry.cpp').write_text(a)
