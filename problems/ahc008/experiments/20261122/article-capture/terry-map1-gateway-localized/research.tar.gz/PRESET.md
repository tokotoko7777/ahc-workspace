# Immutable bottom-gateway: localized new obligations only

No game cases, scoring, solver, supplied original reference or hybrid
edits. Same pinned previous bottom-gateway physical board and stock
map1 control. Same independent literal builder, no-pet physical action
validation and all-X/handoff horizon through t160 as the old gateway
schedule; validate the actual stock per-column quota rather than just
the previous sorted quota multiset. Frozen fresh SHA spawn namespace in evaluate.py;
36 common ordered distinct-cell initial formations, M5/M6 18 each,
explicit no-repeat check for prior family namespaces.

Inspect exact initialized ordinary queue roles and every wall target.
Reject any actual invalid non-X proposal. Preserve original order,
every worker's exact ordinary queue and existing duplicate aliases,
never redistribute any of those. Compute all unowned planned X,
not a hardcoded set; one exact added owner each. Reject >12.
Candidates are all adjacent final-open service-connected stance cells,
not gates or planned pivots. A named-room interior is allowed only
with a single gate and certified final-open exterior egress through
that gate; c3 for left cap c2 is this case. Any start on planned X
can escape once as the real source in each planned local BFS, but
cannot become a subsequent pivot; local insertion endpoints may
not be future walls. Actual move/put validation remains exact.

Order missing by flat coordinate. Insert one monotone chunk or two
contiguous monotone chunks on different workers, both orientations,
choosing each cap's stance by shortest-path layered DP through all
allowed ones. Compare exact final-open detour leg difference to the
unmodified original route, with original nominal other-leg workload.
Endpoint egress cost uses exact shortest distance and bottleneck
assignment to stock lane quotas; lex tie by summed projected route work,
then number and fixed lex order of chunks. No post-gate repair or
optimization. Execute original literal motions and staffing; measure
true all-X and exact stock quota. Trace counts actual interior cap
builds and builder exit before valid quota; at quota report dry nominal
rooms with unblocked gate(s) and no remaining human inside. This last
count does not mean any actual live closure or animal outcome.

Same frozen admission as prior dry phase: every case both arms fully
legal, no unresolved or unreachable original/supplemental work,
all planned X and guard quotas by t160, all builders have exited,
all nominal rooms clear at handoff. Median handoff delta ≤12, worst
≤20. Report exact per-arm coverage, failures reason (1 literal init,
2 invalid old target, 3 >12 missing, 4 no physical stance, 5 no splice
or quota match, 6 lost/duplicate new ownership), missing/alias counts,
and explicit scope limits. No retries or further searches if rejected.

After explicit approval only, cwd this directory:

    sha256sum -c FROZEN.sha256
    python3 make.py
    timeout -k 1s 23s g++ -std=gnu++23 dry.cpp -o dry
    timeout -k 1s 89s python3 -u evaluate.py
