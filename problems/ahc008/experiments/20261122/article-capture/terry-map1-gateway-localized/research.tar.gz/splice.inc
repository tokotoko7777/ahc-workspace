constexpr int MAX_MISSING=12;
struct Catalog {
 std::array<int,V> id;
 std::vector<std::vector<int>> gates;
 std::vector<int> rooms;
};
bool isgate(char c){return c=='<'||c=='>'||c=='('||c==')';}
Catalog catalog(const Layout& l,const Board& wall){
 Catalog c;c.id.fill(-1);
 Board closed=wall;
 for(int q=0;q<V;q++)if(isgate(l.ascii[q]))closed[q]=1;
 for(int q=0;q<V;q++)if(!closed[q]&&c.id[q]<0){
  BFS b;b.run(q,closed);
  int id=c.gates.size();
  c.gates.emplace_back();
  for(int j=0;j<V;j++)if(b.d[j]<INF)c.id[j]=id;
 }
 for(int q=0;q<V;q++)if(isgate(l.ascii[q])){
  const bool left=l.ascii[q]=='('||l.ascii[q]=='<';
  const int p=q+(left?1:-1);
  if(p>=0&&p<V&&c.id[p]>=0)c.gates[c.id[p]].push_back(q);
 }
 for(int i=0;i<(int)c.gates.size();i++)if(!c.gates[i].empty())c.rooms.push_back(i);
 return c;
}
struct Splice {
 int who,gap,lo,hi,extra,end;
 std::vector<int> poses;
 auto key()const{return std::tuple(who,gap,lo,hi,poses);}
};
struct Ownership { int missing=0,aliases=0; std::array<int,V> interior{}; };
int add_caps(Crew& crew,const std::vector<int>& pos,const Board& wall,Ownership& diag){
 const int m=pos.size();const auto original=crew.q;
 std::array<int,V> initial{};
 diag.interior.fill(-1);
 for(const auto& q:original)for(auto a:q)for(int d=0;d<4;d++)if(a.mask>>d&1){
  const int x=nb(a.at)[d];
  if(x<0||!wall[x])return 2; // actual invalid proposed target
  initial[x]++;
 }
 std::vector<int> need;
 for(int q=0;q<V;q++)if(wall[q]){
  if(!initial[q])need.push_back(q);else diag.aliases+=initial[q]-1;
 }
 diag.missing=need.size();const int n=need.size();
 if(n>MAX_MISSING)return 3;
 if(!n)return 0;
 auto nominal=catalog(crew.layout,wall);
 BFS service;service.run(crew.layout.aisleCols[0],wall);
 std::vector<std::vector<int>> stances(n);
 for(int k=0;k<n;k++){
  for(int p:nb(need[k]))if(p>=0&&!wall[p]&&service.d[p]<INF&&!isgate(crew.layout.ascii[p])){
   int id=nominal.id[p];
   if(id<0)continue;
   // Exterior is always permitted; interior must have a certified
   // single-mouth exit into the same exterior/service graph.
   if(!nominal.gates[id].empty()){
    if(nominal.gates[id].size()!=1)continue;
    int gate=nominal.gates[id][0];bool left=crew.layout.ascii[gate]=='(';
    int outside=gate+(left?-1:1);
    if(outside<0||outside>=V||wall[outside]||service.d[outside]>=INF||
       nominal.id[outside]<0||!nominal.gates[nominal.id[outside]].empty())continue;
   }
   stances[k].push_back(p);
  }
  if(stances[k].empty())return 4;
  std::sort(stances[k].begin(),stances[k].end());
 }
 std::vector<std::optional<BFS>> cache(V);
 auto nav=[&](int a)->BFS&{
  if(!cache[a]){cache[a].emplace();cache[a]->run(a,wall);}
  return *cache[a];
 };
 auto travel=[&](int a,int b){
  if(a<0||b<0||wall[b])return INF;
  return nav(a).d[b];
 };
 auto nearest=[&](int a,int col){
  int d=INF;
  for(int r=0;r<N;r++)d=std::min(d,travel(a,r*N+col));
  return d;
 };
 std::vector<int> base(m),tails(m);
 for(int i=0;i<m;i++){
  int p=pos[i];
  for(auto a:original[i]){base[i]+=md(p,a.at)+std::popcount(a.mask);p=a.at;}
  tails[i]=p;
 }
 // Per candidate chunk, evaluate every gap and both monotone orders.
 // Layer states are the exact adjacent stances for that wall, and
 // cost is BFS distance on immutable final-open graph plus build ticks.
 using Path=std::pair<int,std::vector<int>>;
 std::vector tbl(n,std::vector<std::vector<Splice>>(n+1));
 for(int lo=0;lo<n;lo++)for(int hi=lo+1;hi<=n;hi++)
  for(int i=0;i<m;i++)for(int gap=0;gap<=(int)original[i].size();gap++){
   int a=gap?original[i][gap-1].at:pos[i];
   int b=gap<(int)original[i].size()?original[i][gap].at:-1;
   if((gap&&wall[a])||(b>=0&&wall[b]))continue;
   int direct=b>=0?travel(a,b):0;
   if(direct>=INF)continue;
   for(int reverse=0;reverse<(hi-lo==1?1:2);reverse++){
    auto first=reverse?hi-1:lo;
    std::vector<Path> layer;
    for(int p:stances[first])if(travel(a,p)<INF)layer.emplace_back(travel(a,p)+1,std::vector<int>{p});
    for(int j=1;j<hi-lo;j++){
     std::vector<Path> next;
     for(int p:stances[first+(reverse?-j:j)]){
      Path best{INF,{}};
      for(const auto& q:layer){
       int d=travel(q.second.back(),p);
       if(d>=INF)continue;
       Path v=q;v.first+=d+1;v.second.push_back(p);
       best=std::min(best,v);
      }
      if(best.first<INF)next.push_back(best);
     }
     layer.swap(next);
    }
    for(auto& p:layer){
     int last=p.second.back(),detour=b<0?0:travel(last,b);
     if(detour>=INF)continue;
     if(reverse)std::reverse(p.second.begin(),p.second.end());
     // Route order is encoded by signed endpoint indices in Splice.
     if(reverse)p.second.insert(p.second.begin(),-1);
     tbl[lo][hi].push_back({i,gap,lo,hi,p.first+detour-direct,b<0?last:tails[i],p.second});
    }
   }
  }
 // Among candidates with same actor and post-route endpoint, exact
 // handoff costs are identical; keep a single min-extra dominating option.
 for(auto& row:tbl)for(auto& v:row){
  std::sort(v.begin(),v.end(),[](const Splice&a,const Splice&b){
   return std::tuple(a.who,a.end,a.extra,a.key())<std::tuple(b.who,b.end,b.extra,b.key());
  });
  v.erase(std::unique(v.begin(),v.end(),[](const Splice&a,const Splice&b){return a.who==b.who&&a.end==b.end;}),v.end());
 }
 auto cols=crew.layout.aisleCols;
 std::stable_sort(cols.begin(),cols.end(),[](int a,int b){return std::abs(a-15)<std::abs(b-15);});
 using Key=decltype(Splice{}.key());std::vector<Splice> best;
 std::tuple<int,int,int,std::vector<Key>> claim{INF,INF,0,{}};
 auto offer=[&](std::vector<Splice> options){
  auto arrival=base,endpoint=tails;
  for(auto& p:options){arrival[p.who]+=p.extra;endpoint[p.who]=p.end;}
  // Match exact stock lane quota with bottleneck arrival over projected
  // estimates, independent of matching tie implementation.
  std::vector<int> dp(1<<m,INF);dp[0]=0;
  for(int mask=0;mask<(1<<m)-1;mask++){
   const int i=std::popcount(unsigned(mask));
   if(dp[mask]>=INF)continue;
   for(int j=0;j<m;j++)if(!(mask>>j&1)){
    const int d=nearest(endpoint[i],cols[j%cols.size()]);
    if(d>=INF)continue;
    const int score=arrival[i]+d;
    auto &z=dp[mask|1<<j];z=std::min(z,std::max(dp[mask],score));
   }
  }
  if(dp.back()>=INF)return;
  std::vector<Key> keys;for(auto& p:options)keys.push_back(p.key());
  int sum=0;for(int x:arrival)sum+=x;
  auto key=std::tuple(dp.back(),sum,int(options.size()),keys);
  if(key<claim){claim=key;best=std::move(options);}
 };
 for(auto& a:tbl[0][n])offer({a});
 for(int cut=1;cut<n;cut++)
  for(auto& a:tbl[0][cut])for(auto& b:tbl[cut][n])if(a.who!=b.who)offer({a,b});
 if(best.empty())return 5;
 for(auto p:best){
  Queue add;
  const bool reverse=p.poses[0]<0;
  if(reverse)p.poses.erase(p.poses.begin());
  for(int j=0;j<p.hi-p.lo;j++){
   const int k=reverse?p.hi-1-j:p.lo+j;
   const int at=p.poses[k-p.lo],q=need[k],d=direction(at,q);
   assert(d<4);
   add.push_back({at,1u<<d});
   if(!nominal.gates[nominal.id[at]].empty())diag.interior[q]=nominal.id[at];
  }
  auto &s=crew.q[p.who];
  s.insert(s.begin()+p.gap,add.begin(),add.end());
 }
 std::array<int,V> after{};
 for(int i=0;i<m;i++){
  auto j=original[i].begin();
  for(auto a:crew.q[i]){
   if(j!=original[i].end()&&a.at==j->at&&a.mask==j->mask)++j;
   for(int d=0;d<4;d++)if(a.mask>>d&1)after[nb(a.at)[d]]++;
  }
  if(j!=original[i].end())return 6;
 }
 for(auto q:need)if(after[q]!=1)return 6;
 for(int q=0;q<V;q++)if(initial[q]&&after[q]!=initial[q])return 6;
 return 0;
}
