"""Time-forward policy on already-recorded snapshots, not a simulation."""
import collections as C,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent; A=P.parent/'ahc008_terry_brace_valves'
sys.path.insert(0,str(A))
from held_bound import R,I,T,sha,mask
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,wave,flood,ADJ
from timing import shift

def route(start,goal,forbid):
    if B[goal]&forbid:return None
    seen={start:None};q=C.deque([start])
    while q and goal not in seen:
        for z in ADJ[(p:=q.popleft())]:
            if z not in seen and not B[z]&forbid:seen[z]=p;q.append(z)
    if goal not in seen:return None
    out=[]
    while goal!=start:out.append(goal);goal=seen[goal]
    return out[::-1]

def geometry():
    cat=C.defaultdict(dict); body={}
    for z in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        k,i,l,r,*p=map(int,z.split());body[k,i]=mask(p)
    for line in (A/'catalog.txt').read_text().splitlines():
        z=line.split()
        if z[0]=='valve':
            k,p,s,a,i,j,*g=map(int,z[1:])
            x,y=body[k,i],body[k,j];g=mask(g)
            cat[k][p]=(s,x|y,g,((wave(x)&~x)|(wave(y)&~y))&~(g|B[p]))
    return cat

def policy(cat,history,commands):
    walls=0;deferred=set();built={};returned={};stats=C.Counter(); held=None; shadow=[]
    for t,actions in enumerate(commands):
        ps,hs,_=history[t]; pets=mask(map(idx,ps)); staff=list(map(idx,hs))
        actual={i:shift(staff[i],c) for i,c in enumerate(actions) if c.islower()}
        by_moves={i:shift(staff[i],c) for i,c in enumerate(actions) if c.isupper()}
        factual_after=[by_moves.get(i,p) for i,p in enumerate(staff)]
        wallAbort=None
        if held:
            i,p,at,anchor,start=held
            conflict=actions[i].islower() or at in actual.values()
            if conflict or t-start>=5:
                stats['abort_after' if p in built else 'abort_before']+=1
                stats['abort_stock_conflict']+=int(conflict)
                stats['snap_actor']+=int(at!=staff[i])
                if conflict:wallAbort=(i,actual.get(i),at)
                held=None
            else:staff[i]=at
        animals=pets&flood(mask(staff),ALL^walls)
        other=0
        for p in actual.values():
            if p in cat and p not in built and p not in deferred:
                s,b,g,x=cat[p]
                if animals&(b|g):
                    built[p]=t,'stock';returned[p]=t;stats['stock_commission']+=1
                else:deferred.add(p);stats['defer']+=1
            if p not in deferred:other|=B[p]
        if held is None:
            for p in sorted(deferred-set(actual.values())):
                s,b,g,x=cat[p]
                if walls&x!=x or walls&g or not animals&b:continue
                forbid=walls|other|b|g|B[p]; candidates=[]
                for i,v in enumerate(staff):
                    if actions[i]!='.' or forbid&B[v]:continue
                    rr=route(v,s,forbid)
                    if rr is not None and len(rr)<=2:candidates.append((len(rr),i,v))
                if candidates:
                    d,i,v=min(candidates);held=i,p,v,v,t
                    stats['dispatch']+=1;stats['dispatch_distance']+=d;break
        people_after=factual_after[:]
        if held:
            i,p,v,anchor,start=held;s,b,g,_=cat[p]
            anchor=factual_after[i] # reachable target projected from this tick only
            stats['stock_moves_displaced']+=actions[i].isupper()
            moves=mask(q for j,q in by_moves.items() if j!=i)
            people_after[i]=v
            ready=p in built
            if v==s and not ready:
                if B[p]&(pets|wave(pets)|mask(staff)|moves|walls|other):
                    stats['blocked_restore']+=1
                else:
                    built[p]=t,'watch';deferred.remove(p);other|=B[p]
                    stats['watch_commission']+=1
                    if v==anchor:returned[p]=t;held=None
            else:
                goal=anchor if ready else s
                rr=route(v,goal,walls|other|b|g|B[p])
                if rr is None:
                    stats['abort_after' if ready else 'abort_before']+=1;held=None
                    stats['snap_actor']+=int(v!=anchor)
                    people_after[i]=anchor
                else:
                    if rr:
                        v=rr[0];held=i,p,v,anchor,start
                        stats['recovery_moves' if ready else 'approach_moves']+=1
                    people_after[i]=v
                    if ready and v==goal:returned[p]=t;held=None
        walls|=other
        shadow.append((walls,mask(people_after),wallAbort))
    if held:stats['abort_after' if held[1] in built else 'abort_before']+=1
    assert stats['dispatch']==sum(built[p][1]=='watch' for p in returned)+stats['abort_before']+stats['abort_after']
    return built,returned,stats,walls,shadow

def main():
    options=geometry(); records=json.loads((T/'recordings.json').read_text())
    assert len(records)==100
    rows=[]; decisions={}; conflicts=[]
    for r in records:
        nm=r['case'];k=r['map']; cat=options[k]
        if not cat:
            rows.append(dict(case=nm,map=k,safe=0,saved=0,false=0,stats={}));continue
        case=I/'in'/nm; a=(T/'tapes'/nm).with_suffix('.actions');b=a.with_suffix('.trace')
        assert [sha(p) for p in (case,a,b)]==[r[d] for d in ('input_sha','commands_sha','trace_sha')]
        trace=b.read_text().splitlines();commands=a.read_text().splitlines()
        assert commands==trace[::2] and len(commands)==300
        _,hist,_=observed(case.read_bytes(),trace)
        built,returned,stats,phys,shadow=policy(cat,hist,commands);decisions[nm]=built,returned
        captured=set()
        for t,(phys_t,workers,abort) in enumerate(shadow):
            pets,hs,wa=hist[t+1]
            positions=list(map(idx,pets))
            stock=flood(mask(map(idx,hs)),ALL^mask(map(idx,wa)))
            first=[i for i,p in enumerate(positions) if i not in captured and not stock&B[p]]
            captured.update(first)
            if not first:continue
            hx=flood(workers,ALL^phys_t)
            leaks=[i for i in first if hx&B[positions[i]]]
            if leaks or abort:conflicts.append(dict(case=nm,map=k,turn=t,first=first,leaks=leaks,stock_wall_priority_abort=abort))
        ps,hs,w=hist[-1];final=mask(map(idx,w))
        assert all(final&B[p] for p in cat) and r['actual_full']
        assert final&~mask(cat)==phys&~mask(cat)
        safe=(final&mask(cat))&~wave(flood(mask(map(idx,ps)),ALL^final))
        left=safe&~mask(built)
        assert not flood(mask(map(idx,hs)),ALL^(final^left))&mask(map(idx,ps))
        rows.append(dict(case=nm,map=k,safe=safe.bit_count(),saved=left.bit_count(),
                         false=(safe&mask(built)).bit_count(),stats=dict(stats)))
    reference=json.loads((A/'timing_report.json').read_text())['events']
    safe_reference={z['case']:z['safe_and_stock_unused'] for z in json.loads((A/'held_report.json').read_text())['rows']}
    assert all(row['safe']==safe_reference[row['case']] for row in rows)
    assert len(reference)==666 and len(rows)==100
    counts=C.defaultdict(C.Counter); diagnoses=[]
    bands=C.defaultdict(C.Counter)
    for x in reference:
        nm=x['case'];p=x['valve'];k=x['map'];t=x['close']
        built,ret=decisions[nm]; mark=built.get(p)
        ready=bool(mark and mark[0]<t); strict=ready and ret.get(p,300)<t
        for z in (k,'all'):
            counts[z].update(required=1,optimistic=ready,protected=strict)
            if ready:counts[z][mark[1]]+=1
        band='0..159' if t<160 else '160..299'
        bands[band].update(total=1,optimistic=ready,protected=strict)
        diagnoses.append(dict(case=nm,map=k,valve=p,close=t,built=mark,returned=ret.get(p),ready=ready,protected=strict))
    stat=C.Counter()
    for x in rows:stat.update(x['stats'])
    save=sum(x['saved'] for x in rows)/100
    due={str(k):dict(v) for k,v in counts.items()}
    gate=save>=6 and 4*due['all']['optimistic']>=3*due['all']['required'] and all(
        10*due[str(k)]['optimistic']>=7*due[str(k)]['required'] for k in (2,3))
    earlier=json.loads((R/'ahc008_terry_valve_commission/report.json').read_text())
    oldBands=C.defaultdict(C.Counter)
    for q in earlier['first_required']:
        oldBands['0..159' if q['close']<160 else '160..299'].update(total=1,optimistic=q['ready'],protected=q['protected'])
    print(json.dumps(dict(n=len(rows),readiness=due,time_bands=dict(bands),
                          previous_readiness=earlier['readiness'],previous_time_bands=dict(oldBands),
                          stats=dict(stat),safe_unused_original=sum(x['safe'] for x in rows)/100,
                          old_capture_heads_reconnected=sum(len(q['leaks']) for q in conflicts),
                          reservations_interrupted_at_old_capture_turn=sum(bool(q['stock_wall_priority_abort']) for q in conflicts),
                          old_capture_conflicts=conflicts,
                          saved_safe_unused_per_board=save,false_commission_unused_per_board=sum(x['false'] for x in rows)/100,
                          gate=gate,rows=rows,first_required=diagnoses),indent=2))
if __name__=='__main__':main()
