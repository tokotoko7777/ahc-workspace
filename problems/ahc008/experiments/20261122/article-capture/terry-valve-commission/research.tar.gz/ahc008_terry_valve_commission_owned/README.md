# Five-action ownership of a reserved valve worker: rejected shadow

Run `python ahc008_terry_valve_commission_owned/audit.py > ahc008_terry_valve_commission_owned/report.json`.
See the [fixed predeclaration](PRESET.md). No game/solver/tester executed.
Same causal opening conditions, menu, role capacity and deadline; changed
only whether the assigned worker can temporarily override factual walks and
how they return to the original pose after those displaced walks. Other
actors and all stock walls are preserved, using optimistic pose resets on
failed re-entry. Pet trajectories are factual, not simulated in the
perturbed geometry.

| Metric | Previous strict idle priority | Reservation owns walks |
| --- | ---: | ---: |
| Optimistically ready before stock first isolation | 276/666 | 326/666 |
| Physically returned by the original closure | 199/666 | 242/666 |
| Map 2 optimistic / protected | 118/309 / 90/309 | 140/309 / 103/309 |
| Map 3 optimistic / protected | 158/357 / 109/357 | 186/357 / 139/357 |
| Before turn 160 optimistic / protected | 206/515 / 148/515 | 242/515 / 182/515 |
| Turns 160–299 optimistic / protected | 70/151 / 51/151 | 84/151 / 60/151 |
| Mean safely unused valve cells left open | 7.64 | 6.73 |
| Mean lost safe-unused cells from commissions | 3.24 | 4.15 |

For the ownership arm: 686 factual walks overridden, 304 optimistic snaps,
142 reservations interrupted to protect a stock capture-turn wall assignment,
and 414 stock-first-captured heads reachable in the actual-position shadow
at those original split times (head IDs saved per case/turn in JSON).
The wall orders themselves are never canceled. A pet reachable in this
perturbed snapshot is not a prediction of failure under new live motion.

Readiness misses all thresholds; area-only threshold passes. No reason to
escalate to a live test or alter the fixed geometry/windows.
