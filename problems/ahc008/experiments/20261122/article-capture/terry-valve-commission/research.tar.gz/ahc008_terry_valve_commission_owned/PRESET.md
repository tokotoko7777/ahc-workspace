# Reservation-owned moves ablation
Same frozen held100 tapes, brace-valve menu, original commission condition,
watch trigger, order, dispatch ≤2, five-action episode, and one-job cap as
the previous shadow. A held actor may now replace any factual uppercase
move or idle; all lowercase orders and all other workers are preserved.
If the held pose conflicts with a factual wall or that actor owes a wall,
terminate the episode and use the factual pose (optimistic resync as before).
Before each recovery action, aim at the original pose after the *current*
stock command (known at this tick), not a future pose. Report changed walks,
recovery, aborts, and old capture IDs that reconnect in the shadow. Forked
animal paths are not modeled. First-close labels joined after decisions.
Same required ≥75% pooled and ≥70% in each map; ≥6 safe-unused floor
potential retained across 100. Report t<160 and later readiness descriptively
without using those labels to influence actions or gate. No live solver,
score or retuning.
