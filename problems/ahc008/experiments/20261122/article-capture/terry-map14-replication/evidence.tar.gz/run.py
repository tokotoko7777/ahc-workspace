"""Invoke the unchanged, audited pair runner with the locked manifest."""
import csv
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
REUSE=HERE.parent/'ahc008_terry_top2_oracle'
sys.path.insert(0,str(REUSE))
import bench
NS='ahc008/20261123/terry-map14-replication-v1'
NO_HELD='not-part-of-this-benchmark'
LOCK='392423fb0e8896fd7aef05ed640d8e098ed3de306fab70186a42839c2f2995a6'

def summarize(output):
    rows=list(csv.DictReader(output.open()))
    assert len(rows)==200
    cases={}
    for r in rows:
        assert r['actual_map']==('1' if r['arm']=='stock' else '4')
        assert r['arm'] not in cases.setdefault(r['case'],{})
        cases[r['case']][r['arm']]=r
    sums={}
    for arm in ('stock','runner_up'):
        a=[x[arm] for x in cases.values()]
        sums[arm]={k:sum(int(x[k]) for x in a) for k in ('score','full','useful300','final_residual','completed_pairs')}
        mx=max(float(x['wall'])for x in a)
        sums[arm].update(wall_max=mx,local_reserve_from_3s=3.-mx)
    a,b=sums.values()
    w=sum(int(r['runner_up']['score'])>int(r['stock']['score'])for r in cases.values())
    ties=sum(r['runner_up']['score']==r['stock']['score'] for r in cases.values())
    gate=(100*b['score']>=101*a['score'] and w>=65 and b['full']>=a['full']
          and b['useful300']>=a['useful300'] and max(a['wall_max'],b['wall_max'])<3.)
    print(json.dumps(dict(scoped_replication=sums,score_pct=100*(b['score']-a['score'])/a['score'],
                          case_wins=w,ties=ties,losses=len(cases)-w-ties,replication_gate=gate),indent=2))

def main():
    if sys.argv[1:]==['--help']:
        raise SystemExit('usage: run.py HARNESS TESTER SOLVER OUTPUT')
    assert len(sys.argv)==5, 'usage: run.py HARNESS TESTER SOLVER OUTPUT'
    _,harness,tester,solver,output=sys.argv
    locked=HERE/'manifest.json'
    assert bench.sha(locked)==LOCK
    m=json.loads(locked.read_text())
    assert m['namespace']==NS and m['criterion']==[1,4] and len(m['cases'])==100
    selected=HERE/'selected'
    assert json.loads((selected/'manifest.json').read_text())==dict(
        m,dev_namespace=NS,held_namespace=NO_HELD,seedlist_sha256=m['source_seeds_sha256'])
    bench.DEV=NS
    bench.HELD=NO_HELD
    sys.argv=[sys.argv[0],harness,tester,solver,str(selected),output]
    bench.main()
    summarize(Path(output))

if __name__=='__main__':
    main()
