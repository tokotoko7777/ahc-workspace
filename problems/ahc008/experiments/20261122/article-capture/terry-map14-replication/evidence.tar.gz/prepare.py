"""Generate only the fixed uniform source stream; select by public prelude."""
import argparse
import collections
import json
import shutil
import subprocess
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'ahc008_terry_top2_oracle'))
from prepare import seed, rank, load_weights, sha, FROZEN_BINARY
NS='ahc008/20261123/terry-map14-replication-v1'
LIMIT=4096
N=100
PAIR=(1,4)
NO_HELD='not-part-of-this-benchmark'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('generator',type=Path)
    a=p.parse_args()
    gen=a.generator.resolve()
    stream=HERE/'stream'
    stream.mkdir(exist_ok=True)
    s=[seed(NS,i) for i in range(LIMIT)]
    assert len(set(s))==LIMIT
    public=HERE/'seeds.txt'
    desired=''.join(f'{v}\n' for v in s)
    if public.exists(): assert public.read_text()==desired
    else: public.write_text(desired)
    subprocess.run([str(gen),str(public.resolve())],cwd=stream,check=True)
    weights = load_weights()
    src = sorted((stream/'in').glob('*.txt'))
    assert [p.name for p in src]==[f'{i:04}.txt' for i in range(LIMIT)]
    first=[]; hist=collections.Counter()
    for i,path in enumerate(src):
        m,sp,p,q=rank(weights,path)
        hist[p,q]+=1
        if (p,q)==PAIR and len(first)<N:
            first.append(dict(case=f'{len(first):04}.txt',source_index=i,source=path.name,
                              sha256=sha(path),humans=m,species=sp,stock_top=p,diagnostic_runner_up=q))
    assert len(first)==N,(len(first),hist[PAIR])
    assert len(set(r['sha256'] for r in first))==N
    selected=HERE/'selected'
    (selected/'in').mkdir(parents=True,exist_ok=True)
    for row in first:
        shutil.copyfile(stream/'in'/row['source'],selected/'in'/row['case'])
    manifest=dict(namespace=NS,sample_limit=LIMIT,eligible_count=hist[PAIR],criterion=list(PAIR),cases=first,
                  source_seeds_sha256=sha(public),official_generator_sha256=sha(gen),faithful_solver_sha256=FROZEN_BINARY)
    text=json.dumps(manifest,indent=2)+'\n'
    f=HERE/'manifest.json'
    if f.exists(): assert f.read_text()==text
    else: f.write_text(text)
    # Compatibility envelope uses the exact unchanged universal pair runner.
    shutil.copyfile(public,selected/'seeds.txt')
    compatible=dict(manifest,dev_namespace=NS,held_namespace=NO_HELD,seedlist_sha256=sha(public))
    (selected/'manifest.json').write_text(json.dumps(compatible,indent=2)+'\n')
    print(f'locked first {N} of {hist[PAIR]} eligible (last index {first[-1]["source_index"]}) in {LIMIT} uniform inputs')
    print('manifest',sha(f),'seed list',sha(public))

if __name__=='__main__': main()
