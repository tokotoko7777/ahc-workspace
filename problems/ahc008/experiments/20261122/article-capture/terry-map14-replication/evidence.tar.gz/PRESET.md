# Scoped map1→4 replication, preregistered
The broader top-two hindsight oracle gained 2.01065% and failed its 2.5%
gate. Do not fit a general predictor, relax this gate, reuse outcomes for
this test, or open the prior general held namespace. The earlier subgroup
of 11/11 favorable cases only proposes one independent replication.

Both arms use frozen fast faithful d14f6471, default clock, stock automatic
vs `--map=4`. Fixed eligible condition from the exact count-based NN only:
stock first map is 1 and exact second is 4 (lower ID on a tie). No score gap,
species threshold, crew split, input-position feature, solver outcome, or
other subgroup is used to admit cases. Generate uniform official inputs in
order from indices i=0…4095, the first eight SHA256 bytes as a little-endian
integer from UTF-8 `ahc008/20261123/terry-map14-replication-v1/{i}`.
Select the first 100 qualifying inputs, fix hashes before scoring, and
stop rather than widen the stream if fewer qualify. Only these 100 receive
scores. This is a conditional population, not an unbiased overall score.

Declare promising only if the forced map's paired total is at least 1%
above stock, at least 65 strictly winning cases out of 100, no lower total
of raw full or useful full (>=300 per-human reachable average), all official
legality and independent replays succeed, and both local max tester times
are strictly below 3.0 seconds. Report reserve 3.0 minus each local
maximum, not an AtCoder timing guarantee. Score ties are not wins.
Default wall-clock rollouts may vary. Lock the rule without changes,
including the same exact eligibility, before any new independent uniform
100 comparison, required before considering any actual production rule.
No historical contest rank or 6.263B target implication.
