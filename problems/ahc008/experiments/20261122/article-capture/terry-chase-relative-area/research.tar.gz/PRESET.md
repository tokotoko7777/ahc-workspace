# Detached relative-area Chase recut, one candidate per state

No compile or run before separate clearance. Freeze and use all 375
t275–299 actual Chase observations, 15 boards from signed inherited
incoming held100, in exactly the previous tree-protect order. Verify
all input/action/trace hashes, original tape alignment and current
accepted signed mode/map telemetry. Use the same tree-protect stock
Chase shape implementation and libraries, not a new model or tester.
No data-dependent strata or expanded geometry. External run cap 120s;
timeout or an assertion is incomplete, not a negative efficacy claim.

Eligibility: humans initially in one physical connected component and
the stock hypothetical shape keeps all together. Stock has a nonempty
newly isolated pet-ID set compared with today's state. Every stock wall
physically placeable right now, and distinct real crew can reach all its
adjacent exterior stances, using paths that avoid the complete eventual
wall mask. Bottleneck ETA plus build turn fits 300-turn season. This
excludes the split treatment from tree-protect. Crew per-person map area
is the same as their common reached area in all qualifying states.

One deterministic recut on the current crew component only. Retain
canonical U,R,D,L BFS predecessor paths from person0 to every human.
A vertex is a potential wall only if legally placeable now, not in that
connector, and at least one crew member can reach a physically open
adjacent stance by remaining time minus one on current terrain. This
last condition is necessary only; exact staffing/egress is done later.

Split each cell into In and Out, add In→Out (1 for eligible gate else
INF), Out→In INF and each neighbors' Out→In INF. Connect SRC→Out
(901 per cell, or INF on protected connector; constant for any finite
cut), hard-source Out for all currently reachable pets not in the stock
newly isolated set, and hard-sink In for the stock-newly-isolated IDs.
Already isolated cells/IDs do not enter the graph. The finite cut proxy
is 901 times lost Out tiles plus gate count, hence gate ties never
overrule 1 tile. Maximum finite capacity <= 901*900+900 < 1e8; use
int64 capacities, stop at 1e8 and reject such cuts as infeasible. For
finite values flow terminated unrestricted and canonical source residual
reach decides the unique deterministic wall mask. Source-island labels
do not prove those tiles truly connect to humans.

Post-check actual flood topology on both masks: full same isolate-ID set,
connected humans and protected connector in their actual component,
strictly larger common reached floor (hence strictly fewer currently
reachable tiles lost to them), strictly smaller actual union of components
containing the newly isolated pets, and no bigger union of those
components plus new wall footprint. Don't count empty islands or labeled
floors merely assigned source-side. Candidate every wall legal now and
complete distinct staffing via exact bottleneck DP on fully built
terrain, no worse ETA than stock or remaining deadline. Neither arm gets
credit for simulated future animal movement.

Freeze support: >=5 distinct (board, stock walls, recut walls, newly
isolated IDs), >=3 boards, >=50 actual mean crew floor tiles reclaimed
(sum best qualifying gain per board). Record terminal exclusions, exact
denominators, stock/candidate isolate and animal component areas, deployed
wall tiles and the two exact ETAs. If fail, no retuning or widening.
None of these hypothetical plans are issued, scored, or claimed
optimal for physical reachable area or realizable capture.
