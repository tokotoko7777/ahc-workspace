#pragma GCC optimize("O3")
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main old_equal_flow_unused_main
#include "../ahc008_terry_chase_cut_ties/kernel.cpp"
#undef main
#pragma GCC diagnostic pop

using Cells=std::vector<int>;
namespace maps=terry_exact_maps;
constexpr int Scale=901;
constexpr int64_t Hard=100000000;
static_assert(int64_t(Scale)*p::size+p::size<Hard);
static_assert(int64_t(p::size)*3*Hard<INT64_MAX);

Board crew_tree(const Board& wall,const Cells& people) {
    std::array<int,p::size> pred,queue;
    pred.fill(-1); const int root=people.front();
    pred[root]=root; queue[0]=root;
    for(int i=0,n=1;i<n;++i)
        for(int z:p::neighbors(queue[i]))
            if(z>=0&&!wall[z]&&pred[z]<0){pred[z]=queue[i];queue[n++]=z;}
    Board tree;
    for(int h:people){
        if(pred[h]<0)return {};
        for(int z=h;!tree[z];z=pred[z]) tree.set(z);
    }
    return tree;
}
Board block_now(const Board& w,const Cells& h,const Cells& pets){
    Board b=w;
    for(int v:h)b.set(v);
    for(int v:pets){
        b.set(v);
        for(int z:p::neighbors(v)) if(z>=0)b.set(z);
    }
    return b;
}
unsigned ids_outside(const Board& reachable,const Cells& pets){
    assert(pets.size()<=30);
    unsigned m=0;
    for(int j=0;j<int(pets.size());++j) if(!reachable[pets[j]])m|=1u<<j;
    return m;
}
Board animal_union(const Board& wall,const Cells& pets,unsigned keep){
    Board result;
    for(int j=0;j<int(pets.size());++j)if((keep>>j&1)&&!result[pets[j]])
        result|=get_component(wall,pets[j]);
    return result;
}
Board build_mask(const Cells& a) {
    Board b;for(int v:a)b.set(v);
    return b;
}
Board eligible(const Board& w,const Board& common,const Board& blocked,
               const Board& tree,const Cells& people,int rem){
    Board stance,gate;
    for(int h:people){
        auto d=p::distances(w,h);
        for(int z=0;z<p::size;++z)if(d[z]>=0&&d[z]<rem)stance.set(z);
    }
    for(int v=0;v<p::size;++v)if(common[v]&&!blocked[v]&&!tree[v])
        for(int u:p::neighbors(v))if(u>=0&&stance[u]){gate.set(v);break;}
    return gate;
}
std::optional<Cells> propose(const Board& common,const Board& tree,const Board& can_gate,
                             const Cells& pets,unsigned old_isolated,unsigned newly){
    const int src=2*p::size,snk=src+1;
    MaxFlow<int64_t> net(snk+1);
    for(int v=0;v<p::size;++v)if(common[v]){
        net.add_edge(2*v,2*v+1,can_gate[v]?1:Hard);
        net.add_edge(2*v+1,2*v,Hard);
        net.add_edge(src,2*v+1,tree[v]?Hard:Scale);
        for(int u:p::neighbors(v))if(u>=0&&common[u])net.add_edge(2*v+1,2*u,Hard);
    }
    for(int j=0;j<int(pets.size());++j)if(!(old_isolated>>j&1)){
        const int v=pets[j];assert(common[v]);
        if(newly>>j&1)net.add_edge(2*v,snk,Hard);
        else net.add_edge(src,2*v+1,Hard);
    }
    if(net.flow(src,snk,Hard)>=Hard)return std::nullopt;
    auto side=net.min_cut(src); assert(!side[snk]);
    Cells fences;
    for(int v=0;v<p::size;++v)if(common[v]){
        assert(!side[2*v+1]||side[2*v]);
        if(side[2*v]&&!side[2*v+1]){
            assert(can_gate[v]);
            fences.push_back(v);
        }
    }
    return fences;
}
int main() {
    int board,turn,map;
    while(std::cin>>board>>turn>>map){
        const auto people=read_vec(),pets=read_vec(),closed=read_vec();
        const int rem=300-turn;
        assert(1<=rem&&rem<=25&&!people.empty());
        const Board w=build_mask(closed);
        const auto end=[&](std::string_view label){std::cout<<board<<' '<<turn<<' '<<label<<'\n';};
        if(std::any_of(people.begin(),people.end(),[&](int h){return w[h];})||
           std::any_of(pets.begin(),pets.end(),[&](int x){return w[x];}))return 3;
        Board tree=crew_tree(w,people);
        if(tree.none()){end("already_split");continue;}
        const Board common=get_component(w,people.front());
        const auto targets=p::majorityPets(w,people,pets);
        if(targets.empty()){end("no_target");continue;}
        const auto stock=p::shape<MaxFlow<int>>(w,maps::terrain(map).aisleCells,people,targets,turn);
        if(stock.walls.empty()){end("empty_stock");continue;}
        const Board blocked=block_now(w,people,pets),sw=build_mask(stock.walls);
        const Board a=w|sw;
        if(std::any_of(people.begin(),people.end(),[&](int h){return a[h];})){
            end("stock_drops_worker_tile");continue;
        }
        const Board areach=get_component(a,people.front());
        if(std::any_of(people.begin(),people.end(),[&](int h){return !areach[h];})){
            end("stock_split");continue;
        }
        const unsigned old_isolated=ids_outside(common,pets),sids=ids_outside(areach,pets);
        const unsigned newly=sids&~old_isolated;
        if(!newly){end("stock_no_new");continue;}
        if((sw&blocked).any()){end("stock_illegal_now");continue;}
        const int d0=eta(a,people,stock.walls);
        if(d0>=rem){end("stock_staff_or_eta");continue;}
        const auto alt=propose(common,tree,eligible(w,common,blocked,tree,people,rem),
                               pets,old_isolated,newly);
        if(!alt){end("infinite_recut");continue;}
        if(alt->empty()){end("empty_recut");continue;}
        if(*alt==stock.walls){end("same_walls");continue;}
        const Board bw=build_mask(*alt), b=w|bw,reached=get_component(b,people.front());
        if((bw&(blocked|tree|~common)).any()||(tree&~reached).any()||
           std::any_of(people.begin(),people.end(),[&](int h){return !reached[h];})){
            end("recut_illegal_or_split");continue;
        }
        if(ids_outside(reached,pets)!=sids){end("recut_wrong_ids");continue;}
        if(reached.count()<=areach.count()){end("recut_no_actual_crew_gain");continue;}
        const Board sa=animal_union(a,pets,newly),sb=animal_union(b,pets,newly);
        if(sb.count()>=sa.count()||(sb|bw).count()>(sa|sw).count()){
            end("recut_no_actual_animal_shrink");continue;
        }
        const int d1=eta(b,people,*alt);
        if(d1>=rem||d1>d0){end("recut_staff_or_eta");continue;}
        std::cout<<board<<' '<<turn<<" witness "<<reached.count()-areach.count()
            <<' '<<sa.count()<<' '<<sb.count()<<' '<<d0<<' '<<d1<<' '<<newly
            <<' '<<stock.walls.size();
        for(int z:stock.walls)std::cout<<' '<<z;
        std::cout<<' '<<alt->size();
        for(int z:*alt)std::cout<<' '<<z;
        std::cout<<'\n';
    }
}
