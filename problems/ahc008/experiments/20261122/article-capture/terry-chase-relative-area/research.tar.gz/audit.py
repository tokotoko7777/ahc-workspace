"""Purely factual accepted incoming-stock Chase snapshot screen."""
import collections,csv,hashlib,json,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
P=R/'ahc008_terry_hunt_wall_audit';I=R/'ahc008_terry_incoming_shadow/held100'
sys.path.insert(0,str(P))
from analyze import sha,idx,observed
def main():
    files=P/'recordings.json'
    assert sha(files)=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
    book=I/'confirm.csv'
    assert sha(book)=='9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2'
    r=[x for x in csv.DictReader(book.open())if x['arm']=='terry_independent']
    tel={x['case']:list(map(int,x['telemetry'].split()))for x in r}
    records=json.loads(files.read_text())
    assert len(records)==len(tel)==100
    seq=[];checks=[];boards=[]
    for record in records:
        name=record['case']; action=P/'tapes'/Path(name).with_suffix('.actions')
        trace=action.with_suffix('.trace');case=I/'in'/name
        assert [sha(x)for x in (case,action,trace)]==[record[k]for k in ('input_sha','commands_sha','trace_sha')]
        t=tel[name]
        assert t[0]==record['map'] and t[10]==record['pairs'] and t[-1]==record['score']
        if not t[13]:continue
        boards.append(name)
        lines=trace.read_text().splitlines()
        assert lines[::2]==action.read_text().splitlines()
        _,hist,_=observed(case.read_bytes(),lines)
        def vec(points):
            q=list(map(idx,points));return str(len(q))+' '+' '.join(map(str,q))
        for turn in range(275,300):
            p,h,w=hist[turn]
            seq.append(f'{int(Path(name).stem)} {turn} {t[0]} {vec(h)} {vec(p)} {vec(sorted(w))}')
            checks.append((int(Path(name).stem),turn))
    prior_path=R/'ahc008_terry_chase_tree_protect/report.json'
    assert hashlib.sha256(prior_path.read_bytes()).hexdigest()=='4b742661e6862e31acf768fe440d50bc51955418a79564e126490598bbea9c95'
    prior=json.loads(prior_path.read_text())
    assert [(x['board'],x['turn']) for x in prior['rows']]==checks
    payload='\n'.join(seq)+'\n'
    kernel=Path(sys.argv[1]).resolve()
    o=subprocess.run([str(kernel)],input=payload,capture_output=True,check=True,text=True,timeout=115)
    rows=[];c=collections.Counter();keys=set();best={}
    for row in o.stdout.splitlines():
        b,t,why,*v=row.split();b,t=int(b),int(t)
        c[why]+=1
        info=dict(board=b,turn=t,reason=why)
        if why=='witness':
            gain,stock_area,recut_area,d0,d1,ids,k,*walls=map(int,v)
            a=walls[:k];l,*z=walls[k:]
            assert len(z)==l and a!=z and 0<=d1<=d0<=299-t and gain>0 and ids
            keys.add((b,tuple(a),tuple(z),ids))
            assert 0<recut_area<stock_area
            best[b]=max(best.get(b,0),gain)
            info.update(gain=gain,stock=a,alt=z,stock_area=stock_area,alt_area=recut_area,stock_eta=d0,alt_eta=d1,isolates=ids)
        else:assert not v
        rows.append(info)
    assert len(boards)==15 and len(seq)==375
    assert [(r['board'],r['turn'])for r in rows]==checks
    result=dict(snapshot_sha=hashlib.sha256(payload.encode()).hexdigest(),tape_denominator=100,chase_boards=len(boards),chase_cases=boards,
                snapshots=len(rows),counts=dict(c),unique_witnesses=len(keys),witness_boards=len(best),
                exact_gain=str(sum(best.values())),gate=len(keys)>=5 and len(best)>=3 and sum(best.values())>=50,rows=rows)
    (D/'report.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))
if __name__=='__main__':main()
