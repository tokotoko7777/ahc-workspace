#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=ahc008_terry_chase_relative_area
sha256sum -c "$D/FROZEN.sha256"
case "${1:-}" in
 compile) test ! -e "$D/kernel"; g++ -std=c++23 -O3 "$D/kernel.cpp" -o "$D/kernel" ;;
 run) test ! -e "$D/report.json" && test ! -e "$D/run.log"; timeout 120 python3 "$D/audit.py" "$D/kernel" | tee "$D/run.log" ;;
 *) exit 2 ;;
esac
