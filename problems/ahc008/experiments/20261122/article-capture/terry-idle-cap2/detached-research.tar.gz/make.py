from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
a='inline void idle_phase(const State& s,const std::vector<int>& columns,std::vector<char>& action){'
put(a,'''inline int cap2_turn=-1;
inline std::vector<std::string> cap2_rows;
'''+a)
put(' std::vector<int> to(m,-1);',' std::vector<int> to(m,-1), oldTarget(m,-1);')
a='  for(Link l:pairs)if(flow.get_edge(l.e).flow)to[l.i]=s.pets[l.j].pos/30;'
put(a,'''  for(Link l:pairs)if(flow.get_edge(l.e).flow){
   to[l.i]=s.pets[l.j].pos/30;oldTarget[l.i]=l.j;
  }''')
a=' for(int i=0;i<m;++i)if(!action[i]){\n  const int p=s.people[i],r=p/30;'
put(a,''' if(cap2_turn>=0){
  unsigned spare=0;
  for(int i=0;i<m;++i)if(!action[i])spare|=1u<<i;
  cap2_rows.push_back("S "+std::to_string(cap2_turn)+" "+std::to_string(spare));
  std::vector<int> count(n);
  int volume=0,overflow=0;
  for(int j:oldTarget)if(j>=0){++volume;overflow+=++count[j]>2;}
  std::vector<int> aisleIndex(m,-1);
  for(int i=0;i<m;++i)if(spare>>i&1u){
   auto it=std::find(columns.begin(),columns.end(),s.people[i]%30);
   if(it!=columns.end())aisleIndex[i]=int(it-columns.begin());
  }
  bool uncovered=false;
  if(overflow)for(int i=0;i<m;++i)if(aisleIndex[i]>=0)
    for(int j=0;j<n;++j)if(!count[j]&&dist[i][s.pets[j].pos]<=30)uncovered=true;
  if(uncovered){
   cap2_rows.push_back("T "+std::to_string(cap2_turn));
   const int base=m+n,src=base+n*int(columns.size()),snk=src+1;
   terry_exact_ties::MinCostFlow<int,long long> flow(snk+1);
   struct Choice{int i,j,e;};std::vector<Choice> arcs;
   for(int i=0;i<m;++i)if(aisleIndex[i]>=0){
    flow.add_edge(src,i,1,0);
    for(int j=0;j<n;++j)if(int dd=dist[i][s.pets[j].pos];dd<=30)
     arcs.push_back({i,j,flow.add_edge(i,base+aisleIndex[i]*n+j,1,dd)});
   }
   for(int a=0;a<(int)columns.size();++a)for(int j=0;j<n;++j)
     flow.add_edge(base+a*n+j,m+j,1,0);
   for(int j=0;j<n;++j){
    flow.add_edge(m+j,snk,2,0);
    flow.add_edge(m+j,snk,m,30*m+1);
   }
   auto result=flow.flow(src,snk,volume);assert(result.first==volume);
   std::vector<int> chosen(m,-1),after(n);
   int newOverflow=0;
   for(auto a:arcs)if(flow.get_edge(a.e).flow){chosen[a.i]=a.j;newOverflow+=++after[a.j]>2;}
   std::vector<std::pair<int,int>> added;
   for(int i=0;i<m;++i)if(chosen[i]>=0&&!count[chosen[i]])added.push_back({i,chosen[i]});
   if(newOverflow<overflow&&!added.empty()){
    auto alternate=action;
    for(int i=0;i<m;++i)if(!alternate[i]){
     const int p=s.people[i],r=p/30;
     const int t=chosen[i]>=0?s.pets[chosen[i]].pos/30:(r>=16?15:r<=13?14:r);
     if(r==t)continue;
     const int k=t<r?0:2,u=nb[p][k];
     if(u>=0&&!w[u])alternate[i]=k==0?'U':'D';
    }
    std::string z="A "+std::to_string(cap2_turn)+" "+sanitize(s,alternate);
    for(auto [i,j]:added)z+=" "+std::to_string(i)+" "+std::to_string(j);
    cap2_rows.push_back(std::move(z));
   }
  }
 }
'''+a)
a='    hunt::emit(s.people,jobs,legal,booked);'
put(a,a+'''
    if(cap2_turn>=0){
     std::vector<bool> used(rooms.size());
     for(auto j:jobs)used[j.room]=true;
     for(int k=0;k<int(rooms.size());++k){
      const auto& r=rooms[k];
      if(used[k]||!r.area||(r.left<0&&r.right<0))continue;
      if(std::none_of(ps.begin(),ps.end(),[&](int p){return geometry.ids[p]==k;}))continue;
      std::string z="R "+std::to_string(cap2_turn)+" "+std::to_string(r.left)+" "+std::to_string(r.right);
      for(int p=0;p<V;++p)if(geometry.ids[p]==k&&p!=r.left&&p!=r.right)z+=" "+std::to_string(p);
      cap2_rows.push_back(std::move(z));
     }
    }
''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn<275&&std::getenv("AHC008_IDLE_CAP2_LOG"))cap2_turn=turn;
'''+a+'''
  cap2_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* p=std::getenv("AHC008_IDLE_CAP2_LOG")){
   std::ofstream f(p);
   for(const auto& row:cap2_rows)f<<row<<'\\n';
 }
'''+a)
(d/'observer.private.cpp').write_text(s)
