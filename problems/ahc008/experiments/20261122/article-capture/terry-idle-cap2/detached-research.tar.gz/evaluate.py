import collections,itertools,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import case_history,command_effect,step,snapshot,mask,cells,B,ALL,flood
def close(w,p,h,cmd,gates,body,spare,oldid,reach):
    roles=[[(i,d) for i in cells(spare) if h[i]==step(q,'L' if d=='r' else 'R')]for q,d in gates]
    for assign in itertools.product(*roles):
        who={i for i,_ in assign}
        if len(who)!=len(assign):continue
        test=list(cmd)
        for i,d in assign:
            assert test[i]=='.';test[i]=d
        alt=command_effect(h,w,p,test)
        if not alt:continue
        nw,nh=alt
        if nw&body or flood(B[next(cells(body))],ALL^nw)!=body:continue
        ids,new,_=snapshot(nw,nh,p)
        if oldid&~ids or any(reach[i]==reach[j] and new[i]!=new[j] for i in range(len(nh)) for j in range(i)):continue
        yield who,ids
def audit(rec,stats):
    _,hist,cmds=case_history(rec)
    masks={};rooms=collections.defaultdict(list);alt={}
    for line in (D/'logs'/rec['case']).with_suffix('.jobs').read_text().splitlines():
        k,t,*r=line.split();t=int(t)
        assert 0<=t<275
        if k=='S':masks[t]=int(r[0])
        elif k=='A':
            v=list(map(int,r[1:]));assert not len(v)%2
            alt[t]=(r[0],list(zip(v[::2],v[1::2])))
        elif k=='R':
            l,r,*p=map(int,r)
            if p:rooms[t].append((l,r,mask(p)))
        else:
            assert k=='T';stats['overcover_with_reachable_uncovered']+=1
    changes=[];witnesses=set();stats['optimization_proposals']+=len(alt)
    for t,(c,added) in sorted(alt.items()):
        if t+1>=275 or c==cmds[t]:continue
        assert all(x==y or masks[t]>>i&1 for i,(x,y) in enumerate(zip(c,cmds[t])))
        stats['raw_sanitized_changes']+=1
        p,h,w=hist[t]
        f,factual,cur=hist[t+1]
        trial=command_effect(h,w,p,c)
        assert trial and trial[0]==cur
        if snapshot(cur,factual,p)[0]&~snapshot(cur,trial[1],p)[0]:
            stats['prep_isolate_loss']+=1;continue
        changes.append(t)
        added=[(a,i)for a,i in added if c[a]!=cmds[t][a] and c[a] in 'UD']
        if not added:continue
        cmd=cmds[t+1]
        spare=masks.get(t+1,0)&sum(1<<i for i,u in enumerate(cmd)if u=='.')
        if any(x!=y and not (spare>>i&1)for i,(x,y)in enumerate(zip(factual,trial[1]))):
            stats['protected_next_conflict']+=1;continue
        stock=command_effect(factual,cur,f,cmd);assert stock
        ids,reach,_=snapshot(stock[0],stock[1],f)
        same=command_effect(trial[1],cur,f,cmd)
        if not same or same[0]!=stock[0] or ids&~snapshot(same[0],same[1],f)[0]:
            stats['prep_next_conflict']+=1;continue
        for l,r,body in rooms[t+1]:
            hits=[(a,i)for a,i in added if body&B[f[i]] and not ids&B[i]]
            if not hits:continue
            gates=[(j,d)for j,d in [(l,'r'),(r,'l')]if j>=0]
            old=list(close(cur,f,factual,cmd,gates,body,spare,ids,reach))
            new=list(close(cur,f,trial[1],cmd,gates,body,spare,ids,reach))
            if any(not any(v&B[i] for _,v in old) and any(a in g and v&B[i] for g,v in new)for a,i in hits):
                witnesses.add((t+1,l,r,tuple(cells(body))))
    return dict(changes=changes,witnesses=sorted(witnesses))
recs=json.loads((R/'ahc008_terry_hunt_wall_audit/recordings.json').read_text());assert len(recs)==100
stats=collections.Counter();data={}
for z in recs:
    r=audit(z,stats)
    if r['changes'] or r['witnesses']:data[z['case']]=r
summary=dict(changes=sum(len(r['changes']) for r in data.values()),
    change_boards=sum(bool(r['changes']) for r in data.values()),
    witnesses=sum(len(r['witnesses']) for r in data.values()),
    witness_boards=sum(bool(r['witnesses']) for r in data.values()),stats=dict(stats))
summary['pass']=summary['changes']>=20 and summary['change_boards']>=10 and summary['witnesses']>=5 and summary['witness_boards']>=3
(D/'report.json').write_text(json.dumps(dict(summary=summary,boards=data),indent=2)+'\n')
print(json.dumps(summary))
