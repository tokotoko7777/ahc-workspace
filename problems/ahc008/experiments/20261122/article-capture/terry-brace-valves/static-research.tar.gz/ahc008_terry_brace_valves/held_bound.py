"""Static/factual criteria and exact fictional final-state floor bound."""
import collections,hashlib,json,sys
from pathlib import Path

D=Path(__file__).resolve().parent
R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008/experiments/20261122'
I=R/'ahc008_terry_incoming_shadow/held100'
T=R/'ahc008_terry_hunt_wall_audit'
sys.path.insert(0,str(H))
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,wave,flood

def mask(i):return sum({B[p] for p in i})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def human_floor(w,h):
    data=[]
    for p in h:
        reach=next((x for x in data if x&B[p]),None)
        data.append(reach if reach is not None else flood(B[p],ALL^w))
    return sum(x.bit_count() for x in data)/len(h)

def main():
    vals=collections.defaultdict(list)
    for line in (D/'catalog.txt').read_text().splitlines():
        z=line.split()
        if z[0]=='valve':
            k,p,s,a,i,j,g0,g1,h0,h1=map(int,z[1:])
            vals[k].append((p,(i,j),set((g0,g1,h0,h1))))
    rooms={}
    for z in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        k,i,l,r,*p=map(int,z.split());rooms[k,i]=mask(p)
    records=json.loads((T/'recordings.json').read_text())
    assert len(records)==100 and len({x['case'] for x in records})==100
    out=[]
    for rec in records:
        nm=rec['case']; case=I/'in'/nm
        a=(T/'tapes'/nm).with_suffix('.actions')
        t=a.with_suffix('.trace')
        assert (sha(case),sha(a),sha(t))==(rec['input_sha'],rec['commands_sha'],rec['trace_sha'])
        option=vals[rec['map']]
        vals_mask=mask(p for p,_,_ in option)
        a_cmds=a.read_text().splitlines()
        trace=t.read_text().splitlines()
        assert len(a_cmds)==300 and a_cmds==trace[::2]
        _,hist,_=observed(case.read_bytes(),trace)
        assert len(hist)==301
        # Factual attached stock room events only: test whole physical
        # body after a real wall placement and first actual disconnection.
        body_ids={rooms[rec['map'],i]:i for _,ij,_ in option for i in ij}
        events=set()
        old_wall=0;old_reached=0
        for step,(animals,staff,walls) in enumerate(hist):
            w=mask(map(idx,walls))
            if not body_ids or w==old_wall and step:
                continue
            rs=flood(mask(map(idx,staff)),ALL^w)
            for p in map(idx,animals):
                if not rs&B[p] and old_reached&B[p]:
                    rm=flood(B[p],ALL^w)
                    if rm in body_ids:events.add(body_ids[rm])
            old_wall=w;old_reached=rs
        unused={p for p,(i,j),_ in option if i not in events and j not in events}
        pets,people,walls=hist[-1]
        pp,h=[list(map(idx,x)) for x in (pets,people)]
        w=mask(map(idx,walls))
        # Exact maximum for the fixed valid final graph: no selected opened
        # valve touching an original pet component can contribute to safe
        # human reach. Open every installed candidate not touching pet
        # floor; none can ever link into a pet component, whatever groups
        # merge through the simultaneous openings.
        pOnly=flood(mask(pp),ALL^w)
        before=flood(mask(h),ALL^w)
        assert bool(not pOnly&before)==bool(rec['actual_full'])
        safe=(w&vals_mask)&~wave(pOnly) if rec['actual_full'] else 0
        now=w^safe
        if rec['actual_full']:
            assert not (flood(mask(h),ALL^now)&flood(mask(pp),ALL^now))
        retained=human_floor(now,h)-human_floor(w,h)
        preserve_stock=safe&mask(unused)
        stock_floor=human_floor(w^preserve_stock,h)-human_floor(w,h)
        out.append(dict(case=nm,map=rec['map'],full=bool(rec['actual_full']),
            candidates=len(option),unused_stock=len(unused),stock_used=len(option)-len(unused),
            installed=(w&vals_mask).bit_count(),safe=safe.bit_count(),retained=retained,
            safe_and_stock_unused=preserve_stock.bit_count(),retained_and_stock_unused=stock_floor))
    agg={p:sum(x[p] for x in out)/len(out)
         for p in ('candidates','unused_stock','installed','safe','retained','retained_and_stock_unused')}
    print(json.dumps(dict(n=len(out),maps=dict(collections.Counter(x['map'] for x in out)),
       means=agg,candidate_count_gate=agg['candidates']>=10,final_slack_gate=agg['retained']>=6,rows=out),indent=2))
if __name__=='__main__':main()
