#pragma once
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <array>
#include <optional>
#include <vector>

namespace terry_valves {
using namespace terry_exact_maps;
struct Tube {
 int id=-1,row=-1,lo=-1,hi=-1;
 std::array<int,2> gate{-1,-1},guard{-1,-1};
 Board body;
};
struct Valve {
 int cell=-1,stance=-1,aisle=-1;
 std::array<int,2> tube{}; // indices into Layout::tubes
};
struct Layout {
 Terrain original, initial;
 std::vector<Tube> tubes;
 std::vector<Valve> valves;
 Board omissions;
};
inline Board component(const Components& c,int p){
 Board r;
 if(c.labels[p]<0)return r;
 for(int q=0;q<V;q++)if(c.labels[q]==c.labels[p])r.set(q);
 return r;
}
inline Layout generate(int map){
 assert(2<=map&&map<=4);
 Layout a;
 a.original=terrain(map);a.initial=a.original;
 const auto& t=a.original;
 auto conf=classify(t,t.plannedWalls,{}, {cell(0,t.aisleColumns.front())});
 auto shut=labels(t.plannedWalls|t.doorCells);
 // Deterministic catalogue: original straight horizontal two-mouth bodies
 // of width >=3 and both old guards actually stand in their named aisles.
 for(int id=0;id<conf.count();id++){
  const auto& old=conf.rooms[id];
  if(old.left<0||old.right<0||old.left/W!=old.right/W)continue;
  int r=old.left/W,l=old.left%W+1,h=old.right%W-1;
  if(h-l+1<3||l<2||h+2>=W)continue;
  Tube tube{id,r,l,h,{old.left,old.right},{old.left-1,old.right+1},{}};
  if(!t.aisle(tube.guard[0])||!t.aisle(tube.guard[1]))continue;
  for(int c=l;c<=h;c++)tube.body.set(cell(r,c));
  if(component(shut,cell(r,l))!=tube.body ||
     old.size!=int(tube.body.count())+2)continue;
  a.tubes.push_back(tube);
 }
 // Freeze pairing before replay: group by bank range, visit upper rows
 // first, and greedily pair with the next exact room two rows lower.
 std::sort(a.tubes.begin(),a.tubes.end(),[](const Tube& x,const Tube& y){
  if(x.lo!=y.lo)return x.lo<y.lo;
  if(x.hi!=y.hi)return x.hi<y.hi;
  return x.row<y.row;
 });
 std::vector<bool> assigned(a.tubes.size());
 for(int x=0;x<int(a.tubes.size());x++){
  if(assigned[x])continue;
  const auto& u=a.tubes[x];
  for(int y=x+1;y<int(a.tubes.size());y++){
   if(assigned[y])continue;
   const auto& v=a.tubes[y];
   if(v.lo!=u.lo||v.hi!=u.hi||v.row!=u.row+2)continue;
   const int s=u.row+1,c=u.lo;
   int p=cell(s,c),staff=cell(s,c-1),road=cell(s,c-2);
   if(!t.planned(p)||t.planned(staff)||t.doorCells[staff]||
      !t.aisle(road)||t.planned(road)||!t.planned(cell(s,c+1)))continue;
   if(shut.labels[staff]<0||shut.labels[staff]!=shut.labels[road])continue;
   a.valves.push_back({p,staff,road,{x,y}});
   assigned[x]=assigned[y]=true;
   a.omissions.set(p);
   break;
  }
 }
 a.initial.plannedWalls&=~a.omissions;
 for(int p=0;p<V;p++)if(a.omissions[p])a.initial.cells[p]=Marker::Open;
 return a;
}
}
