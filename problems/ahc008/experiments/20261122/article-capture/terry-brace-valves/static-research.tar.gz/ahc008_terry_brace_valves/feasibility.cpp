#pragma GCC optimize("O3")
#include "valves.hpp"
#include <cassert>
#include <iostream>
using namespace terry_valves;
Board byId(const Rooms& r,int id,const Board& noDoors){
 Board b;for(int p=0;p<V;p++)if(r.ids[p]==id&&!noDoors[p])b.set(p);
 return b;
}
void audit(int m){
 const auto a=generate(m);
 const auto& t=a.original;
 const Board virtualWalls=t.plannedWalls|t.doorCells;
 const Board setup=a.initial.plannedWalls;
 const Board virtualOmitted=setup|t.doorCells;
 const auto original=labels(virtualWalls), modified=labels(virtualOmitted);
 auto fixed=classify(t,t.plannedWalls,{}, {cell(0,t.aisleColumns.front())});
 auto weak=classify(a.initial,setup,{}, {cell(0,t.aisleColumns.front())});
 Board affected;
 std::vector<int> affectedID;
 for(const auto& v:a.valves){
  assert(t.planned(v.cell)&&!setup[v.cell]&&!t.doorCells[v.cell]);
  assert(!virtualOmitted[v.stance]&&t.aisle(v.aisle));
  assert(modified.labels[v.stance]==modified.labels[v.aisle]);
  int degree=0,left=0,body=0;
  for(int p:adjacent(v.cell))if(p>=0&&!virtualOmitted[p]){
   ++degree;
   left+=p==v.stance;
   body+=a.tubes[v.tube[0]].body[p]||a.tubes[v.tube[1]].body[p];
  }
  assert(degree==3&&left==1&&body==2);
  auto after=labels(virtualOmitted|Board{}.set(v.cell));
  for(int j:v.tube){
   auto& tube=a.tubes[j];
   assert((affected&tube.body).none());
   affected|=tube.body;affectedID.push_back(tube.id);
   for(int p=0;p<V;p++)if(tube.body[p]){
    assert(weak.ids[p]<0); // no phantom room after all valve omissions
    assert(modified.labels[p]==modified.labels[v.aisle]);
    assert(component(after,p)==tube.body);
   }
   // Both original entrances remain physical, before/after this local
   // restoration; any one gate by itself is not enough for a physical seal.
   for(int g:tube.gate){
    Board afterOne=setup;afterOne.set(v.cell);afterOne.set(g);
    auto phys=labels(afterOne);
    assert(phys.labels[tube.guard[0]]>=0&&phys.labels[tube.guard[1]]>=0);
    assert(phys.labels[tube.guard[0]]==phys.labels[tube.guard[1]]);
   }
  }
  assert(after.labels[v.stance]==after.labels[v.aisle]);
 }
 assert(a.valves.size()==a.omissions.count());
 assert(affectedID.size()==2*a.valves.size());
 int noChange=0;
 for(int id=0;id<fixed.count();id++){
  if(std::find(affectedID.begin(),affectedID.end(),id)!=affectedID.end())continue;
  Board b=byId(fixed,id,t.doorCells);
  if(b.none())continue;
  int p=0;while(!b[p])++p;
  assert(component(original,p)==component(modified,p));
  int wid=weak.ids[p];
  assert(wid>=0&&wid<weak.count()&&byId(weak,wid,t.doorCells)==b);
  auto u=fixed.rooms[id],v=weak.rooms[wid];
  assert(u.left==v.left&&u.right==v.right&&u.size==v.size);
  ++noChange;
 }
 // Verify stock routes under any original single closure survive opening
 // these X. Private dynamic state can differ, but physical graph is a
 // supergraph and each explicitly staffed valve approaches from exterior.
 std::vector<int> aisles;
 for(int p=0;p<V;p++)if(t.aisle(p))aisles.push_back(p);
 for(int g=0;g<V;g++)if(t.doorCells[g]){
  auto law=labels(t.plannedWalls|Board{}.set(g)), test=labels(setup|Board{}.set(g));
  for(int i:aisles)for(int j:aisles)
   if(law.labels[i]==law.labels[j])assert(test.labels[i]==test.labels[j]);
  for(const auto& v:a.valves)assert(test.labels[v.stance]==test.labels[v.aisle]);
 }
 auto fullyRestored=setup|a.omissions;
 assert(fullyRestored==t.plannedWalls);
 std::cout<<"map "<<m<<": candidate valves "<<a.valves.size()<<", untouched rooms "<<noChange
          <<", two-mouth eligible original bodies "<<a.tubes.size()<<'\n';
 for(const auto& v:a.valves){
  const auto& x=a.tubes[v.tube[0]];const auto& y=a.tubes[v.tube[1]];
  std::cout<<"valve "<<m<<' '<<v.cell<<' '<<v.stance<<' '<<v.aisle<<' '
           <<x.id<<' '<<y.id<<' '<<x.gate[0]<<' '<<x.gate[1]<<' '<<y.gate[0]<<' '<<y.gate[1]<<'\n';
 }
}
int main(){for(int m:{2,3,4})audit(m);}
