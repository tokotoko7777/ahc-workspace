"""Check planned valve restoration windows on already verified observations."""
from collections import Counter,defaultdict
from itertools import chain
from pathlib import Path
import json
from held_bound import D,R,T,I,H,sha,mask
from guarded_entry_trace import observed, STEPS
from stochastic_lock_audit import ALL,B,idx,wave,flood,ADJ

def shift(p,c):
    dr,dc=STEPS[c.upper()]
    return p+dr*30+dc

def hops(p):
    return (p,*ADJ[p])

def board_timing(option,body_masks,kinds,hist,commands,trace):
    walls=[mask(map(idx,x[2])) for x in hist]
    people=[list(map(idx,x[1])) for x in hist]
    pets=[list(map(idx,x[0])) for x in hist]
    hreach=[flood(mask(h),ALL^w) for h,w in zip(people,walls)]
    old_wall_at={}
    actual_block=[]
    pet_walk=[]
    for t,c in enumerate(commands):
        build={}
        for i,x in enumerate(c):
            if x.islower():
                q=shift(people[t][i],x)
                build[i]=q;old_wall_at[q]=t
        actual_block.append(build)
        p=set(pets[t])
        for at,cmd in zip(pets[t],trace[2*t+1].split()):
            for a in cmd:
                if a!='.':
                    at=shift(at,a)
                    p.add(at)
        pet_walk.append(mask(p))

    attached={body_masks[r]:q for q,(_,rs) in option.items() for r in rs}
    first={}
    for t in range(300):
        if walls[t]==walls[t+1]:continue
        for p in pets[t+1]:
            if hreach[t]&B[p] and not hreach[t+1]&B[p]:
                body=flood(B[p],ALL^walls[t+1])
                q=attached.get(body)
                if q is not None:
                    first.setdefault(q,t)

    def fit(q,e,strict):
        valve=B[q]
        stance,_=option[q]
        start=max(0,e-8)
        n=len(people[0])
        chosen=None
        # Guard paths are unmodeled until the start of this factual window.
        for who in range(n):
            states={(people[start][who],False):(0,-1,())}
            for t in range(start,e):
                pos=people[t]; nxt=people[t+1]; out=commands[t]
                blocked=actual_block[t]
                other_wall=mask(z for j,z in blocked.items() if j!=who and z!=q)
                own_stock=blocked.get(who)==q
                own_essential=who in blocked and not own_stock
                other_end=mask(z for j,z in enumerate(nxt) if j!=who)
                other_start=mask(z for j,z in enumerate(pos) if j!=who)
                open_post=ALL^(walls[t+1]&~valve)
                endangered=mask(z for z in pets[t+1] if not hreach[t+1]&B[z])
                avoid=[]
                for restored in (False,True):
                    allowed=open_post&~valve if restored else open_post
                    old_lost=flood(endangered,allowed) if endangered else 0
                    if old_lost&other_end:
                        avoid.append(ALL)
                    else:
                        avoid.append(old_lost)
                born=not ((mask(pets[t])|wave(mask(pets[t]))|other_start|other_end)&valve)
                new={}
                for (start_at,was), (cost,when,path) in states.items():
                    sta=B[start_at]
                    open_pre=ALL^(walls[t]&~valve)
                    if sta&other_wall or not sta&open_pre or was and sta&valve:continue
                    if was and valve&(pet_walk[t]|other_start|other_end):continue
                    original=pos[who]; end0=nxt[who]
                    if own_essential and start_at!=original:continue
                    if strict and out[who].isupper() and start_at!=original:continue
                    mimic=own_essential
                    regular=[start_at] if mimic else ([end0] if strict and out[who].isupper() else hops(start_at))
                    opts=[(z,was,False) for z in regular]
                    if not was and not mimic and start_at==stance and born and not valve&pet_walk[t]:
                        if not (strict and out[who].isupper()):
                            opts.append((start_at,True,True))
                    for at,after,put in opts:
                        tile=B[at]
                        if avoid[after]&tile or not open_post&tile or after and tile&valve:
                            continue
                        if put:
                            deviation=int(not own_stock)
                            ww=t
                        else:
                            deviation=int(own_stock or (not mimic and not (start_at==original and at==end0)))
                            ww=when
                        candidate=(cost+deviation,ww,path+((t,start_at,at,put),))
                        key=(at,after)
                        if key not in new or candidate<new[key]:new[key]=candidate
                states=new
                if not states:break
            key=(people[e][who],True)
            if key in states:
                a=(states[key],who)
                if chosen is None or a<chosen:chosen=a
        if chosen is None:return None
        (cost,when,path),who=chosen
        return dict(worker=who,changed=cost,build=when,path=path)

    ans=[]
    for q,e in sorted(first.items()):
        assert walls[e+1]&B[q] and q in old_wall_at
        a=fit(q,e,False)
        b=fit(q,e,True)
        assert a is not None or b is None
        ans.append(dict(valve=q,close=e,stock_build=old_wall_at[q],witness=a,strict=b))
    return ans

def main():
    cat=defaultdict(dict); body=defaultdict(dict)
    for x in (D/'catalog.txt').read_text().splitlines():
        z=x.split()
        if z[0]=='valve':
            k,p,s,a,i,j,*_=map(int,z[1:])
            cat[k][p]=(s,(i,j))
    for z in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        k,i,l,r,*p=map(int,z.split())
        body[k][i]=mask(p)
    records=json.loads((T/'recordings.json').read_text())
    assert len(records)==100
    events=[]; caseCount=Counter(r['map'] for r in records)
    for r in records:
        k=r['map']; nm=r['case']
        if not cat[k]:continue
        case=I/'in'/nm
        a=(T/'tapes'/nm).with_suffix('.actions');t=a.with_suffix('.trace')
        assert [sha(x) for x in (case,a,t)]==[r[x] for x in ('input_sha','commands_sha','trace_sha')]
        trace=t.read_text().splitlines();commands=a.read_text().splitlines()
        assert commands==trace[::2] and len(commands)==300
        kinds,h,_=observed(case.read_bytes(),trace)
        events.extend(dict(case=nm,map=k,**x) for x in board_timing(cat[k],body[k],kinds,h,commands,trace))
    def summary(q):
        N=len(q)
        prob=lambda k:sum(x[k] is not None for x in q)
        return dict(total=N,compatible=prob('witness'),strict=prob('strict'),
                    original_placement_in_window=sum(max(0,x['close']-8)<=x['stock_build']<x['close'] for x in q),
                    original_placement_at_close=sum(x['stock_build']==x['close'] for x in q),
                    median_changed_commands=sorted(x['witness']['changed'] for x in q if x['witness'])[(prob('witness')-1)//2] if prob('witness') else None)
    agg=summary(events)
    maps={m:summary([x for x in events if x['map']==m]) for m in (2,3)}
    assert all(a['total']>0 for a in maps.values())
    gate=4*agg['compatible']>=3*agg['total'] and all(10*a['compatible']>=7*a['total'] for a in maps.values())
    print(json.dumps(dict(caseCounts=dict(caseCount),all=agg,by_map=maps,gate=gate,events=events),indent=2))
if __name__=='__main__':main()
