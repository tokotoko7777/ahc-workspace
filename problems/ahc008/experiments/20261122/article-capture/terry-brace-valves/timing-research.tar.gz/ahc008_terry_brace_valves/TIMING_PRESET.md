# Valve timing compatibility, factual protected replay

No wall or movement in any official run is changed. Population is the same
incoming held100 archive and the previously frozen valve catalog. Include once,
for each valve, its first stock action isolating at least one previously
human-accessible pet into the exact physical original body of either attached
room. Include all these fixtures, including failures; the only look-back is
the eight actions strictly before that close (truncate at turn zero). Output
for maps 2 and 3 as well as pooled. The predeclared test is ≥75% pooled and
≥70% on each eligible map, with no variant-specific filtering or window tuning.

For each candidate actor, reachability DP starts at its exact observed pose.
Other actors retain all commands, positions and wall placements. This actor
keeps all non-valve lowercase wall orders from their actual stances, but can
use walks/waits speculatively instead of their factual walks/waits. The strict
sub-output additionally fixes actual non-idle walks and only reuses idle
actions (plus the original placement of that valve, if in the window). Every
other existing wall remains; the original installation of this valve is
substituted, not double-counted. In this fixed tape sandbox the tracked worker
must stand at the nominated stance, legally build, and return to the factual
next-close pose by the stock close action; any worker qualifies. Check actual
all-pet adjacency, occupants, movement destinations, actor starting position
against other's wall placement, and observed after-action pet microsteps if
ahead of the original valve installation. While the valve is unbuilt, require
all factual already-isolated pet IDs to stay disconnected from every worker,
including the tracked actor. All moves are adjacent and use the step's
actual non-valve walls. Report changed actor commands (not distinguishable
from invisibly paid waits). Report original valve stock placement timing and
whether a witness is strict or speculative; no cherry-picking events.

Passing is necessary evidence for scheduling, not causal attribution or
adoption evidence. Before the eight-turn window there is no replay assurance
that pets would follow the same positions without the wall. Even fitting the
fixed window does not place a worker on a useful path under a live trigger.
