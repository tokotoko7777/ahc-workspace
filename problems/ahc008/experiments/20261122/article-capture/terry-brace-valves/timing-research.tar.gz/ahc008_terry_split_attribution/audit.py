"""Independent factual terminal worker-split attribution and small exact alternatives."""
import collections,csv,itertools,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent; par=R/'ahc008_terry_hunt_wall_audit'
sys.path.insert(0,str(par))
from analyze import terrain, snapshot, sha, mask, cells, idx, observed, B, ALL, flood
I=R/'ahc008_terry_incoming_shadow/held100'
DIRECTIONS={'U':-30,'R':1,'D':30,'L':-1}
def step(p,c):
    q=p+DIRECTIONS[c.upper()]
    return q if 0<=q<900 and abs(q//30-p//30)+abs(q%30-p%30)==1 else None
def canmove(p):
    return [q for c in DIRECTIONS if (q:=step(p,c)) is not None]
def group_info(w,h,p):
    ids,a,_=snapshot(w,h,p)
    groups={}
    for i,v in enumerate(a): groups.setdefault(v,[]).append(i)
    return [dict(workers=x, pets=[i for i,z in enumerate(p) if v&B[z]],area=v.bit_count())for v,x in groups.items()]
def info(w,h,p):
    ids,areas,_=snapshot(w,h,p)
    return dict(isolated=list(cells(ids)),floor_numerator=sum(v.bit_count()for v in areas),
                humans=len(h),components=group_info(w,h,p))
def apart(w,h,p):
    iso,parts,_=snapshot(w,h,p)
    return {(i,j)for i in range(len(h))for j in range(i+1,len(h)) if parts[i]!=parts[j]}

def command_effect(h,w,p,cmd):
    blocked=set(h)|set(p)
    for z in p:blocked.update(canmove(z))
    move=[]; build=[]
    for i,c in enumerate(cmd):
        if c=='.':move.append(h[i]);continue
        there=step(h[i],c)
        if there is None or w&B[there]:return None
        if c.islower():
            if there in blocked:return None
            move.append(h[i]);build.append(there)
        else:move.append(there)
    if set(move)&set(build):return None
    return (w|mask(build),move)

def candidates(t,h,w,p,cmd,hnew,wnew,factual,preboard):
    ids,areas,_=snapshot(wnew,hnew,p); results=collections.defaultdict(list)
    split=apart(wnew,hnew,p)-apart(w,h,p)
    groups=group_info(wnew,hnew,p); big=max(groups,key=lambda s:(len(s['workers']),s['area'],-s['workers'][0]))
    minority=set(range(len(h)))-set(big['workers'])
    def inspect(k,c,who,alternatives,previous=None):
        if alternatives is None:return
        aw,ah=alternatives
        ai,ar,_=snapshot(aw,ah,p)
        sep=apart(aw,ah,p)
        delta=sum(s.bit_count()for s in ar)-factual['floor_numerator']
        if ai==ids and not sep-split-apart(w,h,p) and delta>0:
            results[k].append(dict(workers=who,act=''.join(c),previous=previous,
                                   same_ids=True,area_gain=delta/len(h),post=info(aw,ah,p),
                                   prevented_pairs=[list(z)for z in sorted(split-sep)]))
    moves=[i for i,c in enumerate(cmd) if c.isupper()]
    for n in range(1,len(moves)+1):
        for actors in itertools.combinations(moves,n):
            c=list(cmd)
            for i in actors:c[i]='.'
            inspect('stay',c,actors,command_effect(h,w,p,c))
    for i,g in enumerate(cmd):
        if g.islower():
            c=list(cmd);c[i]='.'
            inspect('delay_one_wall',c,[i],command_effect(h,w,p,c))
    # Enumerate all changed current moves of minority workers only.
    # Keep their builds, and every other recorded actor command.
    actors=[i for i in sorted(minority) if not cmd[i].islower()]
    choices=[(cmd[i],)+tuple(c for c in '.URDL' if c!=cmd[i])for i in actors]
    for new in itertools.product(*choices):
        ix=[i for i,g in zip(actors,new)if g!=cmd[i]]
        if not ix:continue
        c=list(cmd)
        for i,g in zip(actors,new):c[i]=g
        inspect('current_reposition',c,ix,command_effect(h,w,p,c))
    if preboard:
        hp,wp,pp,prev=preboard
        # One prior minority worker can change a wait to one cardinal move.
        # Current non-target actions, prior non-target actions and all builds
        # remain exactly stock. Current target move may change, never its build.
        for i in sorted(minority):
            if prev[i]!='.' or cmd[i].islower():continue
            for m in DIRECTIONS:
                c0=list(prev);c0[i]=m
                alt=command_effect(hp,wp,pp,c0)
                if alt is None or alt[0]!=w:continue
                aw,ah=alt
                # Require no already-isolated animal ID change at the prior
                # post-human factual snapshot either.
                if snapshot(w,ah,pp)[0]!=snapshot(w,h,pp)[0]:continue
                altp,hp2,_=snapshot(w,ah,p)
                if altp!=snapshot(w,h,p)[0]:continue
                for m2 in '.URDL':
                    c=list(cmd);c[i]=m2
                    inspect('prior_dot_then_reposition',c,[i],command_effect(ah,aw,p,c),''.join(c0))
    return results

def exact_lead(t,hist,cmds,new_pairs):
    # Reposition only workers split from the deterministic majority. Keep
    # all physical stock wall placements in this step and every approach
    # step, and keep all other workers' moves. Examine minimal Chase lookback.
    p,h,before=hist[t]; _,end,after=hist[t+1]
    groups=group_info(after,end,p)
    big=max(groups,key=lambda z:(len(z['workers']),z['area'],-z['workers'][0]))
    keep=set(big['workers'])
    varied=sorted(set(range(len(h)))-keep)
    assert 0<len(varied)<=len(h)//2
    destinations=next(v for i,v in enumerate(snapshot(after,end,p)[1])if i in keep)
    floor0=sum(x.bit_count()for x in snapshot(after,end,p)[1])
    base_ids=snapshot(after,end,p)[0]
    result=[]
    for lead in range(0,t-275+1):
        paths=[]
        for a in varied:
            states={hist[t-lead][1][a]: []}
            for j in range(t-lead,t+1):
                pp,people,w=hist[j];_,next_people,new_w=hist[j+1]
                installed=new_w&~w
                original=cmds[j][a]
                allowed=[]
                for pos,path in states.items():
                    # A wall cannot be placed on any current worker even if
                    # that worker would walk away during the same action.
                    if installed&B[pos]:continue
                    if original.islower():
                        target=step(people[a],original)
                        ch=next((c.lower()for c in DIRECTIONS if step(pos,c)==target),None)
                        if ch is not None:allowed.append((pos,path+[(j,ch,pos)]))
                    else:
                        for c in '.URDL':
                            q=pos if c=='.' else step(pos,c)
                            if q is not None and not new_w&B[q]:
                                allowed.append((q,path+[(j,c,q)]))
                states=dict(allowed)
            paths.append([(pos,path)for pos,path in states.items()if destinations&B[pos]])
        if not all(paths):continue
        for combos in itertools.product(*paths):
            prior_position=list(hist[t-lead][1])
            ok=True; actions=[]
            for j in range(t-lead,t+1):
                pp,people,w=hist[j];p1,stock_h,new_w=hist[j+1]
                c=list(cmds[j])
                for a,(_,path) in zip(varied,combos):c[a]=path[j-(t-lead)][1]
                alt=command_effect(prior_position,w,pp,c)
                if alt is None:ok=False;break
                aw,ah=alt
                if aw!=new_w or snapshot(aw,ah,pp)[0]!=snapshot(new_w,stock_h,pp)[0]:
                    ok=False;break
                if j<t and snapshot(aw,ah,p1)[0]!=snapshot(new_w,stock_h,p1)[0]:
                    ok=False;break
                prior_position=ah
                actions.append(dict(turn=j,old=cmds[j],new=''.join(c)))
            if not ok:continue
            ids,areas,_=snapshot(after,prior_position,p)
            gain=sum(x.bit_count()for x in areas)-floor0
            assert ids==base_ids
            if gain<=0 or apart(after,prior_position,p)&new_pairs:continue
            result.append(dict(lead=lead,workers=varied,actions=actions,area_gain=gain/len(h),
                                 endpoint=info(after,prior_position,p)))
        if result:return result
    return result

def omission_trades(p,h,w,cmd):
    placed=[i for i,v in enumerate(cmd) if v.islower()]
    out=[]
    for k in range(1,len(placed)+1):
        for subset in itertools.combinations(placed,k):
            c=list(cmd)
            for i in subset:c[i]='.'
            alt=command_effect(h,w,p,c)
            assert alt is not None
            nw,nh=alt
            out.append(dict(omitted_workers=subset,command=''.join(c),post=info(nw,nh,p)))
    return out

def run_board(rec,meta,ts):
    name=rec['case']; inp=I/'in'/name
    a=par/'tapes'/Path(name).with_suffix('.actions'); trace=a.with_suffix('.trace')
    assert sha(inp)==rec['input_sha'] and sha(a)==rec['commands_sha'] and sha(trace)==rec['trace_sha']
    cmds=a.read_text().splitlines();txt=trace.read_text().splitlines()
    assert cmds==txt[::2] and len(cmds)==300
    _,hist,_=observed(inp.read_bytes(),txt)
    hist=[([idx(v)for v in p],[idx(v)for v in h],mask(map(idx,w)))for p,h,w in hist]
    p,h,w=hist[-1]
    final=info(w,h,p)
    if len(final['components'])<=1:return None
    ans=dict(case=name,chase=bool(meta[13]),actual_full=bool(rec['actual_full']),final=final,events=[])
    plan,gate=ts[rec['map']]
    for t,cmd in enumerate(cmds):
        p,h,w=hist[t];pnext,hn,wn=hist[t+1]
        ap=apart(wn,hn,p)-apart(w,h,p)
        if not ap:continue
        assert command_effect(h,w,p,cmd)==(wn,hn)
        built=wn&~w
        factual=info(wn,hn,p)
        pre=info(w,h,p)
        event=dict(turn=t,phase='chase' if meta[13] and t>=275 else 'normal',command=cmd,
                   split_pairs=[list(z)for z in sorted(ap)],built=list(cells(built)),
                   planned_X=list(cells(built&plan)),named_gates=list(cells(built&gate)),pre=pre,
                   immediately_post_human=factual,after_pet=info(wn,hn,pnext))
        if t:
            pp,hp,wp=hist[t-1]; prev=(hp,wp,pp,cmds[t-1])
        else:prev=None
        event['options']=candidates(t,h,w,p,cmd,hn,wn,factual,prev)
        event['omission_trades']=omission_trades(p,h,w,cmd)
        event['unchanged_physical_walls_chase_lead']=exact_lead(t,hist,cmds,ap) if meta[13] and t>=275 else []
        ans['events'].append(event)
    # Record every membership change once the first worker split exists,
    # so the post-cut group changes are visible independently of floor loss.
    first=ans['events'][0]['turn']+1
    memberships=[]; old=None
    for t in range(first,301):
        p,h,w=hist[t]; z=group_info(w,h,p)
        k=[(v['workers'],v['pets'])for v in z]
        if k!=old:memberships.append(dict(state=t,components=z));old=k
    ans['membership_changes']=memberships
    return ans

def main():
    r=json.loads((par/'recordings.json').read_text())
    source=I/'confirm.csv'
    assert sha(source)=='9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2'
    tel={x['case']:list(map(int,x['telemetry'].split()))for x in csv.DictReader(source.open()) if x['arm']=='terry_independent'}
    assert len(r)==len(tel)==100
    ts=terrain()
    results=[s for x in r if (s:=run_board(x,tel[x['case']],ts)) is not None]
    report=dict(total=100,split_cases=len(results),splits=results)
    (D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    for b in results:
        print(b['case'],'full',b['actual_full'],'terminal',b['final'])
        for e in b['events']:
            print('  ',e['turn'],e['phase'],e['command'],e['built'],'X',e['planned_X'],'gates',e['named_gates'])
            print('   ',e['pre'],e['immediately_post_human'])
            for k,opt in e['options'].items():print('   ',k,len(opt),max(x['area_gain']for x in opt),opt[0]['act'])
if __name__=='__main__':main()
