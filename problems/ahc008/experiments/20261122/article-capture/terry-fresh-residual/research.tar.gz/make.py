from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_first_chase_reuse/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='8f50dda74f578fc8ddbf8176d15172a80df96d23d82c57db8ae51aedce4294b7'
a=' const auto stop=started+std::chrono::milliseconds(limit_ms);'
assert s.count(a)==1
s=s.replace(a,''' const char* residual=std::getenv("AHC008_RESIDUAL_LOG");
 if(residual&&cap>100)return 2;
 std::ofstream diag;
 if(residual)diag.open(residual);
 const auto stop=residual?Clock::time_point::max():started+std::chrono::milliseconds(limit_ms);''')
a='  people_step(s,command);'
assert s.count(a)==1
s=s.replace(a,'''  if(residual&&turn>=275){
   using NN=terry_exact_ties::MinCostFlow<int,int>;
   terry_partition::ChaseReport detail;
   const auto ch=terry_partition::executeChase<MaxFlow<int>,NN>(s.walls,cfg.aisleCells,s.people,pet_cells(s),turn,can_place(s),&detail);
   const auto exact=sanitize(s,std::vector<char>(ch.begin(),ch.end()));
   if(d.chose&&exact!=command)return 3;
   auto g=terrain_lib::classify(cfg,s.walls,s.walls,s.people);
   diag<<'T'<<' '<<turn<<' '<<d.chose<<' '<<exact<<' '<<detail.cut.targetCount<<' '<<detail.oldScore<<' '<<detail.newScore<<' '<<detail.cut.walls.size();
   for(int x:detail.cut.walls)diag<<' '<<x;
   for(int i=0;i<m;++i)diag<<' '<<(i<(int)detail.matching.size()?detail.matching[i]:-1);
   diag<<'\\n';
   for(int k=0;k<g.count();++k){
    auto r=g.rooms[k];if(r.left<0&&r.right<0)continue;
    diag<<'R'<<' '<<turn<<' '<<r.left<<' '<<r.right;
    for(int p=0;p<V;++p)if(g.ids[p]==k&&p!=r.left&&p!=r.right)diag<<' '<<p;
    diag<<'\\n';
   }
  }
'''+a)
(d/'observer.private.cpp').write_text(s)
