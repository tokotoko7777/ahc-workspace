from collections import Counter,deque
import hashlib,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122'),str(R/'ahc008_terry_split_attribution')]
from audit import step,command_effect,snapshot,idx,observed,mask,B,ALL,flood,cells
I=R/'ahc008_terry_first_chase_reuse/default-fresh100/in'
NB=[[q for c in 'URDL' if (q:=step(p,c)) is not None] for p in range(900)]
def bfs(w,p):
    d={p:0};q=deque([p])
    while q:
        a=q.popleft()
        for b in NB[a]:
            if b not in d and not w&B[b]:
                d[b]=d[a]+1;q.append(b)
    return d
def eta(roles):
    # Match each wall to one distinct person in legal adjacent open stance.
    pairs=sorted(roles,key=len)
    def go(k,u):
        if k==len(pairs):return 0
        ans=900
        for a,d in pairs[k]:
            if not u&B[a]:ans=min(ans,max(d,go(k+1,u|B[a])))
        return ans
    return None if (v:=go(0,0))==900 else v
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def one(rec):
    name=rec['case']; ip=I/name; ap=(D/'tapes'/name).with_suffix('.actions'); tp=ap.with_suffix('.trace')
    assert [digest(p) for p in [ip,ap,tp]]==[rec[s] for s in ('input_sha','commands_sha','trace_sha')]
    trace=tp.read_text().splitlines(); kinds,raw,_=observed(ip.read_bytes(),trace)
    hist=[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w)))for p,h,w in raw]
    cmd=ap.read_text().splitlines(); assert cmd==trace[::2]
    p,h,w=hist[300]; ended=snapshot(w,h,p)[0]
    residual=[i for i in range(len(kinds))if not ended&B[i]]
    assert residual
    data={i:[]for i in residual}; turns={}
    for line in ap.with_suffix('.diag').read_text().splitlines():
        tag,t,*row=line.split();t=int(t)
        if tag=='T':
            mode,alt,targets,old,new,n,*vals=row
            n=int(n);v=list(map(int,vals)); turns[t]=[int(mode),alt,int(targets),int(old),int(new),v[:n],v[n:],[]]
        else:
            assert tag=='R';l,r,*body=map(int,row)
            if body:turns[t][-1].append(([g for g in (l,r) if g>=0],[(l,'L'),(r,'R')],mask(body)))
    assert sorted(turns)==list(range(275,300))
    for t,(mode,alt,targets,old,new,cut,match,rooms) in turns.items():
        p,h,w=hist[t]
        assert len(match)==len(h)
        blocked={g:[i for i,z in enumerate(p)if z==g or g in NB[z]] for g in range(900)}
        dist=[bfs(w,z) for z in h]
        post=command_effect(h,w,p,cmd[t]);assert post==(hist[t+1][2],hist[t+1][1])
        postids=snapshot(post[0],post[1],p)[0]
        gateinfo={}
        for gates,roles,body in rooms:
            for g in gates:gateinfo[g]=[a.get(g)for a in dist]
        for i in residual:
            pa=bfs(w,p[i]); near=sorted((pa[g],g) for g in gateinfo if g in pa)
            local=[]
            for gates,roles,body in rooms:
                if not body&B[p[i]]:continue
                placed=w|mask(gates); overlaps=(mask(gates)|body)&mask(h)
                exact=not (mask(gates)&w or overlaps or body&placed) and flood(B[p[i]],ALL^placed)==body
                stances=[step(g,d)for g,d in roles if g>=0]
                te=eta([[(j,d[s])for j,d in enumerate(dist) if s in d]for s in stances])
                bv={g:blocked[g]for g in gates if blocked[g]}
                local.append(dict(gates=gates,exact=exact,compatible_stance_minimax=te,blocked=bv,
                    staffed_safe=bool(exact and te==0 and not bv)))
            cut_mask=mask(cut); hypothetical=None
            if cut and not cut_mask&(mask(h)|mask(p)):
                hypothetical=bool(snapshot(w|cut_mask,h,p)[0]&B[i])
            cut_eta=eta([[(j,min(d[q]for q in NB[g]if q in d))for j,d in enumerate(dist)if any(q in d for q in NB[g])]for g in cut]) if cut and len(cut)<=len(h) else None
            data[i].append(dict(turn=t,where=p[i],mode='Chase'if mode else'Normal',stock=cmd[t],chase_shadow=alt,
                exact_actual_isolated=bool(postids&B[i]),closest_reachable_named_gate=near[0]if near else None,
                named=local,current_cut=cut,chase_matching=match,cut_captures=hypothetical,cut_stance_minimax=cut_eta,
                cut_blockers={g:blocked[g]for g in cut if blocked[g]},chase_targets=targets,chase_hypothetical_score=[old,new]))
    rows={}
    for i,v in data.items():
        summary=Counter()
        for a in v:
            summary['in_exact_named_body']+=any(x['exact'] for x in a['named'])
            summary['staffed_safe']+=any(x['staffed_safe'] for x in a['named'])
            summary['blocked_named']+=any(x['exact'] and x['blocked'] for x in a['named'])
            summary['reachable_named']+=any(x['exact'] and x['compatible_stance_minimax'] is not None and x['compatible_stance_minimax']<=299-a['turn']for x in a['named'])
            summary['chase_cut_contains_capture']+=bool(a['cut_captures'])
            summary['chase_cut_usable_now']+=bool(a['cut_captures'] and a['cut_stance_minimax']==0 and not a['cut_blockers'])
            summary['chase_cut_blocked']+=bool(a['cut_captures'] and a['cut_blockers'])
        rows[i]=dict(species=kinds[i],min_gate_distance=min((a['closest_reachable_named_gate'][0]for a in v if a['closest_reachable_named_gate']),default=None),summary=dict(summary),turns=v)
    return dict(pairs=rec['pairs'],score=rec['score'],rows=rows)
out={r['case']:one(r)for r in json.loads((D/'recordings.json').read_text())}
assert sum(len(x['rows'])for x in out.values())==4
(D/'report.json').write_text(json.dumps(out,indent=2)+'\n')
for name,rec in out.items():
    for i,r in rec['rows'].items():print(name,i,r['species'],r['min_gate_distance'],r['summary'])
