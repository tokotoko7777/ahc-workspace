"""Factual same-turn small original-room opportunities; no policy/tester."""
import collections,csv,hashlib,itertools,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,cells,flat,flood,near,observed,replay,wave
catalog=collections.defaultdict(list)
for a in (D/'catalog.tsv').read_text().splitlines():
    m,k,left,right,*ps=map(int,a.split())
    if 1<=len(ps)<=4:
        mouths=[(g,c) for g,c in [(left,'r'),(right,'l')] if g>=0]
        cat=(k,bitmask(ps),mouths)
        catalog[m].append(cat)
def audit(row):
    f=row['case'];mid=int(row['telemetry'].split()[0])
    raw=(R/'ahc008_focus_assets/tools/in'/f).read_bytes()
    hp=R/'ahc008_terry_scaffold_audit/tapes'/f
    a=hp.with_suffix('.actions').read_bytes()
    tr=hp.with_suffix('.trace').read_text().splitlines();acts=a.decode().splitlines()
    assert hashlib.sha256(raw).hexdigest()==row['input_sha']
    assert hashlib.sha256(a).hexdigest()==row['commands_sha']
    assert replay(raw.decode(),tr,acts,detailed=True)[0]==int(row['score'])
    _,hist,_=observed(raw,tr)
    state=[(list(map(flat,p)),list(map(flat,h)),bitmask(map(flat,w))) for p,h,w in hist]
    # Credit only once per distinct actual terminal compartment. Record all
    # occupants' first actual capture and size, and require they all occurred
    # in that same original separation event.
    caught={i:(t,s) for t,i,k,s in (map(int,e.split(':')) for e in row['captures'].split(';') if e)}
    lp,lh,lw=state[-1]; lhum=flood(bitmask(lh),ALL^lw);later={}
    for pos in lp:
        if B[pos]&lhum:continue
        comp=flood(B[pos],ALL^lw)
        ids=frozenset(i for i,q in enumerate(lp) if B[q]&comp)
        groups={caught.get(i) for i in ids}
        if None in groups or len(groups)!=1:continue
        tm,sz=next(iter(groups))
        assert sz>=comp.bit_count(),(f,sz,comp.bit_count())
        cp,_,cw=state[tm]
        at_catch=flood(B[cp[min(ids)]],ALL^cw)
        roster=frozenset(i for i,p in enumerate(cp) if B[p]&at_catch)
        if roster!=ids:continue
        if comp.bit_count()>=2:later[ids]=(tm,comp.bit_count())
    chase=int(row['telemetry'].split()[13])
    stat=collections.Counter();best={};witness=[]
    for t in range(275 if chase else 300):
        p,h,w=state[t];_,ah,aw=state[t+1]
        animal=bitmask(p);pre_h=bitmask(h)
        old=flood(pre_h,ALL^w)
        inc_h=flood(bitmask(ah),ALL^aw)
        old_ids={i for i,x in enumerate(p) if B[x]&old and not B[x]&inc_h}
        stock=acts[t]
        banned=w|pre_h|animal|wave(animal)
        blocked_now=aw^w
        for rid,body,doors in catalog[mid]:
            if not (body&animal&old) or body&(w|pre_h):continue
            gate=bitmask(g for g,c in doors)
            if gate&banned:continue
            # Independent exact certification prior to other orders: every
            # physical path leaving this room must cross these specific gates.
            if flood(body&-body,ALL^w^gate)!=body:continue
            pending=[(g,c) for g,c in doors if not B[g]&blocked_now]
            if not pending:continue
            groups=[]
            new_ids={i for i,x in enumerate(p) if B[x]&body and B[x]&old}
            for ids,(event,size) in later.items():
                if ids<=new_ids and event>t+1 and size>body.bit_count():
                    groups.append((ids,size-body.bit_count(),event))
            if not groups:continue
            stat['earlier_occupied_small_pre_staffing']+=1
            options=[[i for i,x in enumerate(h) if near(x,c.upper())==g and not stock[i].islower()] for g,c in pending]
            if any(not x for x in options):continue
            stat['aligned_any_options']+=1
            for actor in itertools.product(*options):
                if len(set(actor))!=len(actor):continue
                final_h=ah.copy();cmd=list(stock)
                for i,(g,c) in zip(actor,pending,strict=True):final_h[i]=h[i];cmd[i]=c
                if bitmask(final_h)&(aw|gate):continue
                new_h=flood(bitmask(final_h),ALL^(aw|gate))
                if any(B[p[i]]&new_h for i in old_ids):continue
                if new_h&body or any(B[p[i]]&new_h for i in new_ids):continue
                if not new_h&old:continue
                # Ensure stock building has not made floor smaller inside
                # this new room (check exact current reached component).
                if flood(body&-body,ALL^(aw|gate))!=body:continue
                label='dots' if all(stock[i]=='.' for i in actor) else 'redirect_movement'
                stat[label+'_assignment_count']+=1
                for ids,gain,event in groups:
                    key=(label,ids)
                    if gain>best.get(key,0):best[key]=gain
                    witness.append(dict(t=t,rid=rid,small=body.bit_count(),gain=gain,ids=sorted(ids),later=event,
                                        type=label,stock=stock,alternate=''.join(cmd)))
    dots={i:g for (k,i),g in best.items() if k=='dots'}
    redirect={i:g for (k,i),g in best.items() if k=='redirect_movement'}
    stat['dots_saved_floor']=sum(dots.values())
    stat['movement_saved_floor']=sum(redirect.values())
    stat['union_saved_floor']=sum(max(dots.get(i,0),redirect.get(i,0)) for i in dots.keys()|redirect.keys())
    return dict(case=f,map=mid,stats=stat,witnesses=witness)
def main():
    out=[];total=collections.Counter()
    for row in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open()):
        if row['arm']!='terry_independent':continue
        r=audit(row);total.update(r['stats']);out.append(r)
    assert len(out)==100
    print(json.dumps(dict(boards=len(out),total=total,boards_positive=collections.Counter(
      k for r in out for k,v in r['stats'].items() if v),cases=out),indent=2))
if __name__=='__main__':main()
