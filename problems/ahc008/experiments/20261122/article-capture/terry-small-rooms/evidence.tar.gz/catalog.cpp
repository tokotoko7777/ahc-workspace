#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <iostream>
using namespace terry_exact_maps;
int main(){
 for(int m=0;m<5;++m){
  const auto& t=terrain(m);
  auto p=classify(t,t.plannedWalls,{}, {t.aisleColumns[0]});
  for(int r=0;r<p.count();++r){
   auto q=p.rooms[r];
   if(q.left<0&&q.right<0)continue;
   std::cout<<m<<' '<<r<<' '<<q.left<<' '<<q.right;
   for(int x=0;x<V;++x)if(p.ids[x]==r&&!t.doorCells[x])std::cout<<' '<<x;
   std::cout<<'\n';
  }
 }
}
