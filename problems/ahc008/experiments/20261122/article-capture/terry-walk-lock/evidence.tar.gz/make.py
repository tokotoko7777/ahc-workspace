import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_motion_cache/submission.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='d14f6471e5f64bf4a936f8cf27a0f585136a53e13f3e4a27af9fa21f6427b49c'
def put(token,f):
 global s
 assert s.count(token)==1,token
 s=s.replace(token,f(token))
put('namespace terry_exact_root {',lambda x:x+'''
  inline int walk_lock_audit_turn=-1;
  inline std::vector<std::string> walk_lock_audit_rows;
''') if s.count('namespace terry_exact_root {')==1 else None
# The standalone reopens its namespace. The first occurrence is global to both.
if 'inline int walk_lock_audit_turn' not in s:
 s=s.replace('namespace terry_exact_root {','''namespace terry_exact_root {
  inline int walk_lock_audit_turn=-1;
  inline std::vector<std::string> walk_lock_audit_rows;
''',1)
put('  auto stage=crew.act_literal(actual_array,s.people,ps);',lambda x:x+'''
  if(walk_lock_audit_turn>=0){
   std::string line=std::to_string(walk_lock_audit_turn)+" ";
   std::string roles;
   for(int i=0;i<int(s.people.size());++i){
    const char a=stage.action[i];
    roles += move_dir(a)>=0&&!crew.q[i].empty()?a:'.';
   }
   line+=roles;
   for(int i=0;i<int(s.people.size());++i)
    for(const auto& job:crew.q[i])
     if(job.mask)line+=" "+std::to_string(i)+":"+std::to_string(job.at);
   walk_lock_audit_rows.push_back(std::move(line));
  }
''')
put('  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);',lambda x:'''
  if(m>=7&&turn<=133&&std::getenv("AHC008_TERRY_WALK_LOCK_AUDIT"))
      walk_lock_audit_turn=turn;
'''+x+'''
  walk_lock_audit_turn=-1;
''')
put(' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){',lambda x:'''
 if(const char* path=std::getenv("AHC008_TERRY_WALK_LOCK_AUDIT")){
  std::ofstream f(path);
  for(const auto& line:walk_lock_audit_rows)f<<line<<'\\n';
 }
'''+x)
(d/'audit.private.cpp').write_text(s)
