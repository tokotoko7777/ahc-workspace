"""Offline factual constructor walks only, exact pinned faithful tapes."""
import collections,csv,hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,flat,flood,near,observed,replay,wave
catalog=collections.defaultdict(dict)
for row in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
    m,room,left,right,*ps=map(int,row.split())
    if (left>=0)!=(right>=0) and 1<=len(ps)<=4:
        g=left if left>=0 else right
        catalog[m][g]=(room,bitmask(ps),'r' if left>=0 else 'l')
def case(q):
    f=q['case'];mid=int(q['telemetry'].split()[0])
    raw=(R/'ahc008_focus_assets/tools/in'/f).read_bytes()
    tp=R/'ahc008_terry_scaffold_audit/tapes'/f
    action=tp.with_suffix('.actions').read_bytes()
    tr=tp.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==q['input_sha']
    assert hashlib.sha256(action).hexdigest()==q['commands_sha']
    stock=action.decode().splitlines()
    assert replay(raw.decode(),tr,stock,detailed=True)[0]==int(q['score'])
    inp=raw.decode().splitlines()
    n=int(inp[0]);m=int(inp[n+1]);assert m>=7
    with tempfile.TemporaryDirectory() as d:
        lg=Path(d)/'out'
        z=subprocess.run([str(D/'audit'),'--pairs=0'],input='\n'.join(inp[:n+2+m]+tr[1::2])+'\n',
            text=True,capture_output=True,check=True,env=dict(os.environ,AHC008_TERRY_WALK_LOCK_AUDIT=str(lg)))
        assert z.stdout.splitlines()[:134]==stock[:134]
        trace=lg.read_text().splitlines();assert len(trace)==134
    kinds,hist,_=observed(raw,tr)
    caught={i:(t,s) for t,i,k,s in (map(int,e.split(':')) for e in q['captures'].split(';') if e)}
    out=[];stats=collections.Counter(); credit=set()
    for line in trace:
        ts,tag,*pending=line.split();t=int(ts)
        assert len(tag)==m
        todo=[tuple(map(int,x.split(':'))) for x in pending]
        p,h,w=hist[t];_,sh,sw=hist[t+1]
        p=list(map(flat,p));h=list(map(flat,h));sh=list(map(flat,sh))
        old=bitmask(map(flat,w));stockwall=bitmask(map(flat,sw))
        pts=bitmask(p);ban=old|stockwall|bitmask(h)|pts|wave(pts)
        root=flood(bitmask(h),ALL^old)
        baseline=flood(bitmask(sh),ALL^stockwall)
        for i,a in enumerate(tag):
            if a=='.':continue
            if stock[t][i]!=a:continue # actual sanitized submission must be this walk
            stats['actual_ctor_walks']+=1
            for direction in 'LR':
                g=near(h[i],direction)
                if g is None or g not in catalog[mid]:continue
                rid,body,closing=catalog[mid][g]
                if closing!=direction.lower():continue
                stats['matching_ctor_stance']+=1
                if not (root&body&pts) or (body&bitmask(h)) or (B[g]&ban):continue
                if flood(body&-body,ALL^(old|B[g]))!=body:continue
                stats['legal_ready_occupied']+=1
                projected=sh.copy();projected[i]=h[i]
                neww=stockwall|B[g]
                if neww&bitmask(projected):continue
                free=ALL^neww
                environs=flood(bitmask(projected),free)
                if environs&body or flood(body&-body,free)!=body:continue
                if (root&pts&~baseline)&environs:continue
                subjects=[j for j,v in enumerate(p) if B[v]&body and B[v]&baseline]
                if not subjects:continue
                stats['exact_cases_before_crew_safety']+=1
                if any(((B[b]&neww or not (flood(B[projected[j]],free)&B[b]))) for j,b in todo):
                    stats['pending_stance_rejects']+=1;continue
                stats['closures_no_pending_path_loss']+=1
                stats['heads_in_candidate_locks']+=len(subjects)
                credit.update(subjects)
                out.append(dict(t=t,actor=i,stock=a,lock=closing,gate=g,room=rid,body=body.bit_count(),
                    ids=subjects,kind=[kinds[j] for j in subjects],later={j:caught.get(j) for j in subjects}))
    stats['unique_new_pet_ids']=len(credit)
    stats['unique_misses']=len(credit-set(caught))
    return dict(case=f,map=mid,stats=stats,witness=out)
def main():
    out=[];total=collections.Counter()
    for q in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open()):
        if q['arm']!='terry_independent' or int(q['humans'])<7:continue
        r=case(q);out.append(r);total.update(r['stats'])
    print(json.dumps(dict(cases=len(out),total=total,board_counts=collections.Counter(
        k for z in out for k,v in z['stats'].items() if v),details=out),indent=2))
if __name__=='__main__':main()
