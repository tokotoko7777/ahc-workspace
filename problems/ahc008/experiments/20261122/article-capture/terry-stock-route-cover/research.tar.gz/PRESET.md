# Stock dry construction: route/stance insertion vs literal

Unchanged exact stock maps 1 and 2. Existing exact build standalone
literal Crew.init and act_literal, with accepted move-first sanitization.
Both arms have the exact same target X, loading and guard quota. Candidate
uses the same exact handoff matcher at the computed route endpoints; the
literal control retains normal concurrent construction/relay. No hybrid
layout, capture, supplied original, game cases, score or official tester.

For each map and M=5,6 use exactly 12 synthetic deterministic no-pet
formations. Order maps1/2, M5/6, 12 draws, distinct initial cells within a
board selected by SplitMix64 stream/Fisher–Yates prefix in dry.cpp. Both
arms start from the same actual unbuilt cells. Candidate first evacuates
any future-X or orphan starts along shortest paths on the actual empty
board to the final service component. Count placement-free movement,
waits, and elapsed alongside all other actions. Require all actual
configured aisles in that component and every X has a valid adjacency.
No planned X is a later stance or a planned construction transit cell.

One architecture: next unowned wall by least number of final-service
stances then cell; evaluate all valid stance/worker/insertion gaps with
global (max, sum) estimated route durations including nearest-aisle
distance, exact final-service BFS leg lengths and one tick per wall.
Tie by largest adjacent still-unowned packet, then stance, worker, gap.
Packet owns all still-unowned adjacent walls. No reassignment. After
routes are fixed, actual exact empty-queue stock bottleneck match from
each route's terminal node determines the endpoint lane quotas. Execute
concurrently; each worker who completes their packet route starts toward
the matched lane, even while others still build; exact final-safe paths.
Actual handoff is first state with exact physical all-X and full stock
lane quota. Report actual all-X and handoff turns separately. Default stock
route/queues are unchanged; sanitizer-suppressed proposals counted.

Earlier final-open control is not comparable unmodified: specific
changed mixed-short map2, four-lane mirror orders and M8–10. This is two
arms on unchanged stock layouts; no claim against that mixed variant.

Horizon 360 turns per dry arm. Require 48/48 both exact legal all-X and
full quota, total actual handoff candidate <=90% stock, and maximum
candidate minus baseline <=5 turns. Report per-case true move/build/idle
and evacuation, separate map-shared final BFS and per-case setup CPU
microseconds. No implied pet/routing resilience or live score. No
outcome-driven tweaks, second screen, or resource-limit changes.

Run once after explicit clearance, working from this directory:

    sha256sum -c FROZEN.sha256
    timeout -k 1s 20s g++ -std=gnu++23 dry.cpp -o dry
    timeout -k 1s 45s ./dry > dry.csv 2> timing.log
