#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <ctime>
#include <iostream>
#include <numeric>
using namespace std; namespace E=exact_build; namespace T=terry_exact_maps;
using E::INF; using E::V; using E::Board; using E::BFS; using E::nb;
int micros(clock_t start){return int(1000000LL*(clock()-start)/CLOCKS_PER_SEC);}
constexpr int H=360;
constexpr uint64_t seed=0x70953d01e627fa8bULL;
uint64_t draw(uint64_t &s){uint64_t a=(s+=0x9e3779b97f4a7c15ULL);a=(a^(a>>30))*0xbf58476d1ce4e5b9ULL;a=(a^(a>>27))*0x94d049bb133111ebULL;return a^(a>>31);}
struct Packet{int at;vector<int> walls;};
struct Result{int all=-1,ready=-1,evac=0,setup=0,walk=0,build=0,idle=0,suppressed=0,error=0;};
struct Cover{
 E::Layout l; Board wall{},invalid{};
 vector<int> cells;
 vector<vector<int>> choices=vector<vector<int>>(V);
 vector<BFS> path=vector<BFS>(V);
 vector<int> lane=vector<int>(V,INF);
 bool pass=true;
 explicit Cover(const T::Terrain& t){
  for(int p=0;p<V;p++){wall[p]=t.plannedWalls[p];l.ascii[p]=char(t.cells[p]);}
  l.aisleRows=t.aisleRows;l.aisleCols=t.aisleColumns;
  BFS b;b.run(l.aisleCols.at(0),wall);
  for(int p=0;p<V;p++)invalid[p]=wall[p]||b.d[p]>=INF;
  for(int c:l.aisleCols)for(int r=0;r<30;r++)if(invalid[30*r+c])pass=false;
  for(int p=0;p<V;p++)if(!invalid[p]){
   path[p].run(p,invalid);
   for(int c:l.aisleCols)for(int r=0;r<30;r++)lane[p]=min(lane[p],path[p].d[30*r+c]);
  }
  for(int q=0;q<V;q++)if(wall[q]){
   cells.push_back(q);
   for(int p:nb(q))if(p>=0&&!invalid[p])choices[q].push_back(p);
   sort(choices[q].begin(),choices[q].end());
   if(choices[q].empty())pass=false;
  }
  sort(cells.begin(),cells.end(),[&](int a,int b){return make_tuple(choices[a].size(),a)<make_tuple(choices[b].size(),b);});
 }
 bool ready(const vector<int>& h)const{
  auto c=l.aisleCols;
  stable_sort(c.begin(),c.end(),[](int a,int b){return abs(a-15)<abs(b-15);});
  vector<int> cnt(30),demand(30);
  for(int i=0;i<(int)h.size();i++)++demand[c[i%c.size()]];
  for(int p:h)++cnt[p%30];
  return cnt==demand;
 }
 vector<vector<Packet>> route(const vector<int>& h) const {
  Board todo=wall;
  int m=h.size(); vector<vector<Packet>> r(m); vector<int> length(m);
  for(int p:cells)if(todo[p]){
   auto best=make_tuple(INF,INF,0,INF,INF,INF);
   Packet saved{};int who=-1,at=-1,elapsed=0;
   for(int s:choices[p]){
    Packet packet{s,{}};
    for(int a:nb(s))if(a>=0&&todo[a])packet.walls.push_back(a);
    sort(packet.walls.begin(),packet.walls.end());
    for(int i=0;i<m;i++)for(int g=0;g<=(int)r[i].size();g++){
     const auto& v=r[i]; const int k=v.size();
     int a=g?v[g-1].at:h[i], b=g<k?v[g].at:-1;
     int new_length=length[i]+path[a].d[s]+int(packet.walls.size());
     if(b>=0)new_length+=path[s].d[b]-path[a].d[b];
     int mx=0,total=0;
     for(int j=0;j<m;j++){
      int terminal=(j==i&&g==k)?s:(r[j].empty()?h[j]:r[j].back().at);
      int z=(j==i?new_length:length[j])+lane[terminal];
      mx=max(mx,z);total+=z;
     }
     auto key=make_tuple(mx,total,-int(packet.walls.size()),s,i,g);
     if(key<best){best=key;saved=packet;who=i;at=g;elapsed=new_length;}
    }
   }
   assert(who>=0);
   for(int q:saved.walls){assert(todo[q]);todo[q]=false;}
   r[who].insert(r[who].begin()+at,saved);length[who]=elapsed;
  }
  for(int q=0;q<V;q++)assert(!todo[q]);
  return r;
 }
};
void tally(Result& r,const vector<int>& h,const vector<int>& next,int built){
 for(int i=0;i<(int)h.size();i++)if(h[i]==next[i])++r.idle;else ++r.walk;
 r.idle-=built;r.build+=built;
}
Result literal(const Cover& c,vector<int> h){
 Result r; const auto begin=clock(); E::Crew crew;
 bool ok=crew.init(c.l,h);
 r.setup=micros(begin);
 if(!ok){r.error=1;return r;}
 Board w{};
 for(int t=0;t<=H;t++){
  if(w==c.wall){if(r.all<0)r.all=t;if(c.ready(h)){r.ready=t;return r;}}
  if(t==H)break;
  auto cmd=crew.act_literal(w,h,{}).action;
  auto nxt=h;Board occupied{};
  for(int p:h)occupied[p]=true;
  for(int i=0;i<(int)h.size();i++){
   int d=std::find(std::begin(E::Move),std::end(E::Move),cmd[i])-std::begin(E::Move);
   if(d>=4)continue;
   int p=nb(h[i])[d];if(p<0||w[p]){++r.suppressed;continue;}
   nxt[i]=p;occupied[p]=true;
  }
  int built=0;
  for(int i=0;i<(int)h.size();i++){
   int d=std::find(std::begin(E::Put),std::end(E::Put),cmd[i])-std::begin(E::Put);
   if(d>=4)continue;
   int p=nb(h[i])[d];
   if(p<0||w[p]||occupied[p]){++r.suppressed;continue;}
   if(!c.wall[p]){r.error=2;return r;}
   w[p]=true;occupied[p]=true;++built;
  }
  for(int p:nxt)assert(!w[p]);
  tally(r,h,nxt,built);h.swap(nxt);
 }
 r.error=3;return r;
}
Result candidate(const Cover& c,vector<int> h){
 Result r;if(!c.pass){r.error=4;return r;}int m=h.size();
 vector<int> go=h;
 for(int i=0;i<m;i++)if(c.invalid[h[i]]){
  BFS b;b.run(h[i],{});pair<int,int> best{INF,V};
  for(int q=0;q<V;q++)if(!c.invalid[q])best=min(best,pair{b.d[q],q});
  assert(best.first<INF);go[i]=best.second;
 }
 while(go!=h){
  auto nxt=h;
  for(int i=0;i<m;i++)if(h[i]!=go[i]){
   BFS b;b.run(h[i],{});nxt[i]=b.first[go[i]];
   assert(nxt[i]>=0&&E::md(h[i],nxt[i])==1);
  }
  tally(r,h,nxt,0);h.swap(nxt);++r.evac;
 }
 const auto begin=clock();
 auto routes=c.route(h);
 auto ends=h;
 for(int i=0;i<m;i++)if(!routes[i].empty())ends[i]=routes[i].back().at;
 auto quota=E::match(c.l,c.wall,ends,vector<E::Queue>(m));
 r.setup=micros(begin);
 if(quota.eta>=INF){r.error=5;return r;}
 vector<int> goal(m),j(m),k(m);
 for(int i=0;i<m;i++){
  int col=quota.cols[i];pair<int,int> best{INF,V};
  for(int row=0;row<30;row++)best=min(best,pair{c.path[ends[i]].d[30*row+col],30*row+col});
  assert(best.first<INF);goal[i]=best.second;
 }
 Board w{};
 for(int t=r.evac;t<=H;t++){
  if(w==c.wall){if(r.all<0)r.all=t;if(c.ready(h)){r.ready=t;return r;}}
  if(t==H)break;
  auto nxt=h;vector<int> puts;
  for(int i=0;i<m;i++){
   bool done=j[i]==int(routes[i].size());
   int at=done?goal[i]:routes[i][j[i]].at;
   if(h[i]!=at){
    nxt[i]=c.path[h[i]].first[at];
    assert(nxt[i]>=0&&!c.invalid[nxt[i]]&&E::md(h[i],nxt[i])==1);
   }else if(!done){
    auto &pack=routes[i][j[i]];
    int q=pack.walls[k[i]++];assert(!w[q]&&c.wall[q]&&E::md(h[i],q)==1);
    puts.push_back(q);
    if(k[i]==int(pack.walls.size())){k[i]=0;++j[i];}
   }
  }
  for(int q:puts){
   assert(!w[q]&&find(h.begin(),h.end(),q)==h.end()&&find(nxt.begin(),nxt.end(),q)==nxt.end());
   w[q]=true;
  }
  tally(r,h,nxt,puts.size());h.swap(nxt);
 }
 r.error=6;return r;
}
int main(){
 int sum0=0,sum1=0,worst=-INF,n=0;bool ok=true;
 cout<<"map,m,draw,starts,baseline_all,candidate_all,baseline_ready,candidate_ready,evac,baseline_setup_us,candidate_setup_us,baseline_walk,candidate_walk,baseline_build,candidate_build,baseline_idle,candidate_idle,baseline_suppressed,baseline_error,candidate_error\n";
 uint64_t state=seed;
 for(int map:{1,2}){
  auto time=clock();Cover c(T::terrain(map));
  cerr<<"MAP_SETUP_US "<<map<<" "<<micros(time)<<'\n';
  for(int m:{5,6})for(int it=0;it<12;it++){
   vector<int> pool(V);iota(pool.begin(),pool.end(),0);
   for(int i=0;i<m;i++)swap(pool[i],pool[i+draw(state)%(V-i)]);
   vector<int> h(pool.begin(),pool.begin()+m);
   auto a=literal(c,h),b=candidate(c,h);++n;
   cout<<map<<','<<m<<','<<it<<',';
   for(int i=0;i<m;i++){if(i)cout<<':';cout<<h[i];}
   cout<<','<<a.all<<','<<b.all<<','<<a.ready<<','<<b.ready<<','<<b.evac<<','<<a.setup<<','<<b.setup
       <<','<<a.walk<<','<<b.walk<<','<<a.build<<','<<b.build<<','<<a.idle<<','<<b.idle<<','
       <<a.suppressed<<','<<a.error<<','<<b.error<<'\n';
   bool works=a.ready>=0&&b.ready>=0&&!a.error&&!b.error&&
              a.build==int(c.cells.size())&&b.build==int(c.cells.size());
   ok&=works;
   if(works){sum0+=a.ready;sum1+=b.ready;worst=max(worst,b.ready-a.ready);}
  }
 }
 bool gate=ok&&n==48&&10*sum1<=9*sum0&&worst<=5;
 cout<<"GATE "<<gate<<" complete "<<ok<<" n "<<n<<" base_sum "<<sum0<<" candidate_sum "<<sum1<<" max_regression "<<worst<<'\n';
 return gate?0:3;
}
