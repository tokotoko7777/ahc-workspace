"""Exact topology reuse in the faithful TERRY-method normal controller."""
from pathlib import Path
import hashlib,sys
f,p=map(Path,sys.argv[1:])
raw=f.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d14f6471e5f64bf4a936f8cf27a0f585136a53e13f3e4a27af9fa21f6427b49c'
s=raw.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
rep('inline Rooms classify(const Terrain& t,const Board& actual,const Board& pending,\n                      const std::vector<int>& humans){\n Rooms out;\n const auto act=labels(actual);\n const int major=out.majority=majority_group(act,humans);',
    'inline Rooms classify_from(const Terrain& t,const Board& actual,const Board& pending,\n                      const Components& act,int major){\n Rooms out;\n out.majority=major;')
rep(' return out;\n}\n}\n\n#include <algorithm>\n#include <array>\n#include <bit>\n#include <cstdlib>\n#include <deque>',
    ' return out;\n}\ninline Rooms classify(const Terrain& t,const Board& actual,const Board& pending,const std::vector<int>& humans){\n auto act=labels(actual);\n return classify_from(t,actual,pending,act,majority_group(act,humans));\n}\n}\n\n#include <algorithm>\n#include <array>\n#include <bit>\n#include <cstdlib>\n#include <deque>')
rep('struct NormalCount{','''// A Normal instance uses a single immutable semantic terrain.
struct TopologyMemo {
 bool actual_valid=false, rooms_valid=false, arts_valid=false;
 Mask actual_walls, projected_walls, articulation_walls, articulation;
 terrain_lib::Components actual_labels;
 terrain_lib::Rooms rooms;
 int room_majority=-1;
 const terrain_lib::Rooms& get(const terrain_lib::Terrain& t,const Mask& actual,
      const Mask& projected,const std::vector<int>& people){
  if(!actual_valid||actual_walls!=actual){
   actual_walls=actual;
   actual_labels=terrain_lib::labels(actual);
   rooms_valid=false;actual_valid=true;
  }
  const int major=terrain_lib::majority_group(actual_labels,people);
  if(!rooms_valid||projected_walls!=projected||room_majority!=major){
   rooms=terrain_lib::classify_from(t,actual,projected,actual_labels,major);
   projected_walls=projected;room_majority=major;rooms_valid=true;
  }
  return rooms;
 }
 const Mask& arts(const terrain_lib::Terrain& t,const Mask& projected){
  if(!arts_valid||articulation_walls!=projected){
   articulation=door_articulation(t,projected);
   articulation_walls=projected;arts_valid=true;
  }
  return articulation;
 }
};
struct NormalCount{''')
rep(' exact_build::Crew crew;\n Pcg rng;', ' exact_build::Crew crew;\n Pcg rng;\n TopologyMemo topology;')
rep('auto geometry=terrain_lib::classify(*terrain,s.walls,builds,s.people);','const auto& geometry=topology.get(*terrain,s.walls,builds,s.people);')
rep('bits_to_array(door_articulation(*terrain,builds))','bits_to_array(topology.arts(*terrain,builds))')
p.write_text(s)
