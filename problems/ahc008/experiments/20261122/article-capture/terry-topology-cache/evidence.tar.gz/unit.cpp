#define main integrated_main
#include "submission.private.cpp"
#undef main
#include <iostream>
using namespace terry_exact_root;
bool same(const terrain_lib::Rooms& a,const terrain_lib::Rooms& b){
 if(a.ids!=b.ids||a.majority!=b.majority||a.participates!=b.participates
    ||a.projected!=b.projected||a.excludedSentinel!=b.excludedSentinel
    ||a.rooms.size()!=b.rooms.size())return false;
 for(int i=0;i<int(a.rooms.size());++i){
  auto q=a.rooms[i],w=b.rooms[i];
  if(std::tie(q.size,q.left,q.right)!=std::tie(w.size,w.left,w.right))return false;
 }
 return true;
}
int main(){
 std::mt19937_64 r(20261123);
 for(int id=0;id<5;++id){
  const auto& layout=terrain_lib::terrain(id);
  TopologyMemo memo;
  Mask actual,proposed;
  for(int k=0;k<300;++k){
   if(k%11==0){
    actual=layout.plannedWalls;
    for(int x=0;x<30;++x)actual[30*x+11]=true;
    for(int j=0;j<16;++j)actual.flip(r()%900);
    proposed=actual;
   }
   if(k%3==0)proposed[r()%900]=true;
   std::vector<int> crew;
   for(int i=0;i<7;++i){
    int p;
    do{p=r()%900;}while(actual[p]||(k%4==1&&p%30>10)||(k%4==2&&p%30<12));
    crew.push_back(p);
   }
   assert(same(terrain_lib::classify(layout,actual,proposed,crew),memo.get(layout,actual,proposed,crew)));
   assert(door_articulation(layout,proposed)==memo.arts(layout,proposed));
  }
 }
 std::cout<<"1500 exact cached room/door snapshots incl majority changes\n";
}
