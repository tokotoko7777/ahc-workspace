from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int preempt_turn=-1;\ninline std::vector<std::string> preempt_rows;\n'+s[i:]
a='    hunt::emit(s.people,jobs,legal,booked);'
put(a,a+'''
    if(preempt_turn>=0){
     auto open=actual&~builds&~moves;
     unsigned walking=0;
     std::vector<bool> served(rooms.size());
     for(auto j:jobs){
      served[j.room]=true;
      int eta=(j.left>=0&&!open[j.left])||(j.right>=0&&!open[j.right]);
      if(j.left>=0)eta=std::max(eta,std::abs(s.people[j.a]/30-j.left/30));
      if(j.right>=0)eta=std::max(eta,std::abs(s.people[j.b]/30-j.right/30));
      unsigned w=0;
      if(eta>0){
       if(j.left>=0&&booked[j.a]&&move_dir(*booked[j.a])>=0)w|=1u<<j.a;
       if(j.right>=0&&booked[j.b]&&move_dir(*booked[j.b])>=0)w|=1u<<j.b;
      }
      if(!w)continue;
      walking|=w;
      preempt_rows.push_back("J "+std::to_string(preempt_turn)+" "+std::to_string(eta)+" "+
        std::to_string(j.left)+" "+std::to_string(j.right)+" "+std::to_string(w));
     }
     if(walking)for(int k=0;k<(int)rooms.size();++k){
      const auto& r=rooms[k];
      if(served[k] || r.area<=0 || (r.left<0&&r.right<0))continue;
      std::string row="R "+std::to_string(preempt_turn)+" "+std::to_string(r.left)+" "+std::to_string(r.right);
      for(int p=0;p<V;++p)if(geometry.ids[p]==k&&p!=r.left&&p!=r.right)row+=" "+std::to_string(p);
      preempt_rows.push_back(std::move(row));
     }
    }
''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn>=100&&turn<225&&std::getenv("AHC008_PREEMPT_LOG"))preempt_turn=turn;
'''+a+'''
  preempt_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* p=std::getenv("AHC008_PREEMPT_LOG")){
   std::ofstream f(p);
   for(const auto& row:preempt_rows)f<<row<<'\\n';
 }
'''+a)
(d/'observer.private.cpp').write_text(s)
