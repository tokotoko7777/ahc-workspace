import collections,hashlib,itertools,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import case_history,command_effect,step,snapshot,B,ALL,mask,cells,flood,wave
P=R/'ahc008_terry_hunt_wall_audit'

def audit(rec,pin,stats):
    kinds,hist,cmds=case_history(rec)
    file=(D/'logs'/rec['case']).with_suffix('.jobs')
    assert hashlib.sha256(file.read_bytes()).hexdigest()==pin[rec['case']]
    jobs=collections.defaultdict(list); rooms=collections.defaultdict(list)
    for line in file.read_text().splitlines():
        tag,t,*row=line.split();t=int(t);r=list(map(int,row));assert 100<=t<225
        if tag=='J':
            eta,l,r,actors=r
            assert eta>0 and actors
            jobs[t].append((eta,l,r,actors))
        else:
            assert tag=='R'
            l,r,*body=r
            if len(body) in (3,4):rooms[t].append((l,r,mask(body)))
    wins=[]
    for t in range(100,225):
        stats['examined']+=1
        if not jobs[t]:continue
        stats['with_deferred_walkers']+=1
        p,h,w=hist[t];cmd=cmds[t]
        sw,sh=command_effect(h,w,p,cmd)
        assert (sw,sh)==(hist[t+1][2],hist[t+1][1])
        ids,reach,_=snapshot(sw,sh,p)
        usable={i for _,_,_,actors in jobs[t] for i in cells(actors) if cmd[i] in 'UD'}
        best=None
        for l,r,body in rooms[t]:
            gg=[(g,d)for g,d in [(l,'r'),(r,'l')] if g>=0]
            gate=mask(g for g,_ in gg)
            if (sw&body) or sw&gate or wave(body)&~(body|sw)!=gate:continue
            if not any(body&B[q] and not ids&B[i] for i,q in enumerate(p)):continue
            roles=[[(i,d)for i in sorted(usable) if h[i]==step(g,'L'if d=='r'else'R')]for g,d in gg]
            if not all(roles):continue
            stats['staffed_body_rows']+=1
            for rset in itertools.product(*roles):
                who={i for i,_ in rset}
                if len(who)!=len(rset):continue
                alt=list(cmd)
                for i,d in rset:
                    assert alt[i] in 'UD'
                    alt[i]=d
                rv=command_effect(h,w,p,alt)
                if not rv:
                    stats['physical_illegal']+=1;continue
                v,vh=rv
                assert v==sw|gate
                if any(body&B[q] for q in vh) or flood(B[next(cells(body))],ALL^v)!=body:continue
                ni,nreach,_=snapshot(v,vh,p)
                if ids&~ni:stats['lost_ids']+=1;continue
                if any(reach[i]==reach[j] and nreach[i]!=nreach[j] for i in range(len(h))for j in range(i)):
                    stats['worker_split']+=1;continue
                exact=(ni&~ids)&mask(i for i,x in enumerate(p)if body&B[x])
                if not exact:continue
                impacted=[(eta,jl,jr,roles)for eta,jl,jr,roles in jobs[t] if roles&mask(who)]
                rank=(exact.bit_count(),-body.bit_count(),-len(impacted),-len(who),-l,-r,tuple(-i for i in sorted(who)))
                if best is None or rank>best[0]:
                    best=(rank,dict(turn=t,body=list(cells(body)),gates=[g for g,_ in gg],pet_ids=list(cells(exact)),
                            original=cmd,alternative=''.join(alt),preempted=sorted(who),impacted=impacted,
                            cost=body.bit_count()+len(gg)))
        if best:wins.append(best[1])
    if not wins:return wins
    missing={i for q in wins for i in q['pet_ids']}
    first={}
    for t in range(min(q['turn'] for q in wins),300):
        p,h,w=hist[t];_,after,wa=hist[t+1]
        iso=snapshot(wa,after,p)[0]
        for i in sorted(missing.intersection(cells(iso))):
            body=flood(B[p[i]],ALL^wa); gates=wave(body)&(wa&~w)
            first[i]=dict(turn=t,body=body.bit_count(),touching_new_walls=gates.bit_count(),
                cost=body.bit_count()+gates.bit_count())
            missing.remove(i)
        if not missing:break
    for q in wins:
        q['later_stock']={i:first.get(i) for i in q['pet_ids']}
        q['displaced_jobs_really_emitted']=[]
        for eta,l,r,_ in q['impacted']:
            g=mask(g for g in (l,r)if g>=0)
            t=q['turn']
            for u in range(t+1,min(299,t+eta)+1):
                if g&hist[u+1][2]==g and g&hist[u][2]!=g:
                    q['displaced_jobs_really_emitted'].append([l,r,u]);break
    return wins

def main():
    recfile=P/'recordings.json'
    assert hashlib.sha256(recfile.read_bytes()).hexdigest()=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
    rows=json.loads(recfile.read_text()); pin=dict(l.split()for l in (D/'materialize.log').read_text().splitlines())
    assert len(rows)==len(pin)==100
    stats=collections.Counter();by={}
    for r in rows:
        w=audit(r,pin,stats)
        if w:by[r['case']]=w
    independent=[]; benefit=set()
    for c,rs in by.items():
        unique=set()
        for e in rs:
            key=(tuple(e['gates']),tuple(e['body']),tuple(e['pet_ids']))
            if key in unique:continue
            unique.add(key);independent.append(e)
            for i,z in e['later_stock'].items():
                if z is None or z['cost']>e['cost']:benefit.add((c,i))
    summary=dict(events=len(independent),boards=len(by),material_distinct_heads=len(benefit),
        witnessed_turns=sum(len(a)for a in by.values()),
        two_actor=sum(len(x['preempted'])>1 for x in independent),
        multiprotected_jobs=sum(len(x['impacted'])>1 for x in independent),
        actual_followup_deferred_closure=sum(bool(x['displaced_jobs_really_emitted'])for x in independent),
        stats=dict(stats))
    summary['gate']=len(independent)>=20 and len(by)>=12 and len(benefit)>=5
    (D/'report.json').write_text(json.dumps(dict(summary=summary,boards=by),indent=2)+'\n')
    print(json.dumps(summary))
if __name__=='__main__':main()
