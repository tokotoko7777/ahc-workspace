"""Exact detached prior-wait inward shortening; no solver/tester call."""
import collections,itertools,json,re,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
P=R/'ahc008_terry_hunt_wall_audit';I=R/'ahc008_terry_incoming_shadow/held100'
sys.path.insert(0,str(R/'ahc008_terry_split_attribution'))
from audit import command_effect, step, terrain, snapshot, sha, mask, cells, idx, observed, B, ALL, flood, DIRECTIONS
from stochastic_lock_audit import wave
# Avoid ambiguity with the file of this same name loaded as __main__.
def two_mouths():
    text=(R/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
    records=[]
    for i,g in enumerate(re.split(r'// map \d\s*\n',text)[:-1]):
        values=[[int(z[:-1],16) for z in r.split(',')]for r in
                re.findall(r'\{((?:0x[0-9a-f]+u,){4}0x[0-9a-f]+u)\}',g)]
        out={}
        for r in range(30):
            z=0 if r==0 else 1 if r%2==0 else 3 if r%4==3 else 4 if i==4 and r%8==5 else 2
            w,a,b,c,d=values[z]
            for ch,m in [('R',c),('L',d)]:
                for p in cells(m):out[r*30+p]=ch
        records.append(out)
    assert list(map(len,records))==[14,28,90,120,42]
    return records

def support(w,p,speed):
    possible=B[p]
    for _ in range(speed):
        moved=wave(possible)&~w
        # No neighbor on a location is a legal stasis. Iterate only the
        # current sparse support locations, not all candidate endpoint paths.
        holds=sum(B[z] for z in cells(possible)if not wave(B[z])&~w)
        possible=moved|holds
    return possible

def at(h,w,p):return snapshot(w,h,p)[0]
def exact_floor(xs):return sum(x.bit_count()for x in xs)

def board(rec,geom):
    name=rec['case']; f=I/'in'/name
    a=P/'tapes'/Path(name).with_suffix('.actions'); trace=a.with_suffix('.trace')
    assert sha(f)==rec['input_sha'] and sha(a)==rec['commands_sha'] and sha(trace)==rec['trace_sha']
    cmds=a.read_text().splitlines(); lines=trace.read_text().splitlines()
    assert len(cmds)==300 and cmds==lines[::2]
    kinds,history,_=observed(f.read_bytes(),lines)
    hist=[([idx(p)for p in ps],[idx(h)for h in hs],mask(map(idx,w)))for ps,hs,w in history]
    doors=geom[rec['map']]; counts=collections.Counter(); tab=[]
    total=bound=Fraction()
    for t in range(1,275):
        p,h,w=hist[t]; pnext,h1,w1=hist[t+1]
        added=w1&~w
        if added.bit_count()<2:continue
        actual=[]
        for a,x in enumerate(cmds[t]):
            if x not in 'lr':continue
            g=step(h[a],x); inner=step(g,x)
            if g in doors and x.upper()==doors[g] and inner is not None:
                actual.append((a,x,g,inner))
        if len(actual)<2:continue
        old_ids,reach0,_=snapshot(w,h,p)
        captured,reach1,_=snapshot(w1,h1,p)
        todo=captured&~old_ids
        if not todo:continue
        prep_p,prep_h,prep_w=hist[t-1]; pre_actual=at(h,w,prep_p)
        while todo:
            i=next(cells(todo)); room=flood(B[p[i]],ALL^w1)
            roster=tuple(j for j,z in enumerate(p)if B[z]&room)
            todo&=~sum(1<<j for j in roster)
            boundary=wave(room)&added
            choices=[(a,x,g,inside)for a,x,g,inside in actual if B[g]&boundary and B[inside]&room and not B[h[a]]&room]
            if len(choices)!=2 or mask(g for _,_,g,_ in choices)!=boundary:continue
            if {e[1]for e in choices}!={'r','l'}:continue
            counts['two_mouth_rooms']+=1
            ready=[o for o in choices if cmds[t-1][o[0]]=='.' and prep_h[o[0]]==h[o[0]]]
            counts['eligible_prior_wait_gates']+=len(ready)
            if not ready:continue
            counts['rooms_with_wait']+=1
            accepted=[]; greatest=greatest_bound=Fraction()
            pockets=None
            for k in range(1,len(ready)+1):
                for option in itertools.combinations(ready,k):
                    prev=list(cmds[t-1]); current=list(cmds[t])
                    for a,x,g,inside in option:prev[a]=x.upper()
                    first=command_effect(prep_h,prep_w,prep_p,prev)
                    if not first or first[0]!=w:continue
                    pre_w,pre_h=first
                    if (at(pre_h,pre_w,prep_p)!=pre_actual or at(pre_h,pre_w,p)!=old_ids):continue
                    closure=command_effect(pre_h,pre_w,p,current)
                    if not closure:continue
                    alt_w,alt_h=closure
                    removed=mask(g for _,_,g,_ in option)
                    sunk=mask(inner for _,_,_,inner in option)
                    if removed.bit_count()!=k or sunk.bit_count()!=k or alt_w!=((w1^removed)|sunk):continue
                    alt_id,alt_r,_=snapshot(alt_w,alt_h,p)
                    if alt_id!=captured or any(u&~v for u,v in zip(reach1,alt_r)):continue
                    expected=room&~sunk
                    if not expected or expected!=flood(expected&-expected,ALL^alt_w):continue
                    if tuple(j for j,z in enumerate(p)if B[z]&expected)!=roster or mask(alt_h)&expected:continue
                    gain=Fraction(exact_floor(alt_r)-exact_floor(reach1),len(h))
                    if gain<=0:continue
                    if pockets is None:
                        blocked_stock=added|wave(added)
                        pockets={j:support(w,z,kinds[j])&~blocked_stock
                                 for j,z in enumerate(prep_p)if kinds[j] in (1,2,3)}
                    banned=sunk|wave(sunk)
                    passive=all(not s&banned for s in pockets.values()) and all(not (pockets[j]&room&~expected)for j in roster if j in pockets)
                    all_passive=passive and len(pockets)==len(p)
                    greatest=max(greatest,gain)
                    if passive:greatest_bound=max(greatest_bound,gain)
                    accepted.append(dict(actors=[q[0]for q in option],old=list(cells(removed)),new=list(cells(sunk)),
                       prev=''.join(prev),now=''.join(current),gain=str(gain),passive_support=passive,board_all_passive=all_passive,
                       captured_passive=[j for j in roster if j in pockets]))
            if accepted:
                counts['rooms_with_gain']+=1
                counts['gain_options']+=len(accepted)
                counts['passive_options']+=sum(x['passive_support'] for x in accepted)
                counts['all_passive_options']+=sum(x['board_all_passive'] for x in accepted)
                counts['room_with_passive_bound']+=bool(greatest_bound)
                counts['room_with_passive_capture_bound']+=any(x['passive_support'] and x['captured_passive'] for x in accepted)
                total+=greatest;bound+=greatest_bound
                tab.append(dict(turn=t,room_size=room.bit_count(),roster=roster,options=accepted))
    return dict(case=name,counts=dict(counts),noncausal_gain=str(total),passive_support_gain=str(bound),witness=tab)

def main():
    rec=json.loads((P/'recordings.json').read_text());assert len(rec)==100
    geom=two_mouths()
    rows=[board(r,geom) for r in rec]
    counts=collections.Counter()
    for row in rows:counts.update(row['counts'])
    total=sum(Fraction(q['noncausal_gain'])for q in rows)
    bound=sum(Fraction(q['passive_support_gain'])for q in rows)
    boards=sum(Fraction(q['noncausal_gain'])>0 for q in rows)
    report=dict(cases=100,counts=dict(counts),gain_exact=str(total),positive_boards=boards,
                passive_support_gain_exact=str(bound),passive_support_boards=sum(Fraction(q['passive_support_gain'])>0 for q in rows),
                gate=total>=150 and boards>=20,rows=rows)
    (D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k!='rows'},indent=2))
if __name__=='__main__':main()
