# Shift a genuine ordinary two-mouth capture inward using literal prior wait
Factual held100 accepted incoming tapes, no solver, tester, new cases,
later chase uses or comparison to official practice. Only t=1..274
ordinary stock captures with exactly two simultaneously installed nominal
two-mouth markers on the true new pet room boundary, eligible from their
real outside stances, both new cuts actual physical walls. Inspect one-
or two-gate inward changes if every changed builder submitted '.' at t−1.
This is literal observed wait, not a claim of unbooked internal intent.

Replace each participating t−1 wait by one adjacent move from the old
exterior stance into its old mouth. At t build one tile farther inward,
same direction/actor. All other submitted actions, walls and times stay;
no extra delay, no alternate pet trajectories substituted. Both action
batches must be physically executable. Test exact global isolated pet-ID
set after preceding human actions and after current human actions; also
check the intervening factual pre-action isolate IDs. At closure every
worker's new reachable set contains its stock set. New occupied room is
exactly the old physical room minus the added wall cells, same stock pet
roster and no worker in it. All current animals and pre/post workers'
positions respected for legality. Deduplicate by stock occupied component
and take best qualifying area gain for it, arithmetic sum across episodes;
this alone does not certify they can all coexist as one changed policy.
Advance only if >=150 exact summed mean-per-human area tiles and >=20
positive boards. Stop without widening or live work if below either.

Separately certify a conservative passive movement-support diagnostic:
after t−1 walls, propagate each cow/pig/rabbit from its recorded position
to all possible full-turn endpoint positions (degree-zero stays). Restrict
to endpoints individually compatible with *all* stock t wall commands,
then disallow any endpoint where the changed t walls are not individually
legal; for originally captured passive IDs require stock-room occupancy
implies occupancy of shifted room. Thus no passive draw can invalidate
the shift conditional on original gates buildable and respective passive
IDs actually in the stock room. Does not model directed dog/cat
trajectories or simultaneous non-modal stock behavior. Quantify
all-passive boards separately; failure of the bound is not evidence
that actual movements fail. No tuning from this diagnostic.
