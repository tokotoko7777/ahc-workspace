"""Purely causal prep selection, followed separately by factual labels; no solver."""
import collections,json,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
P=R/'ahc008_terry_hunt_wall_audit'
I=R/'ahc008_terry_incoming_shadow/held100'
sys.path.insert(0,str(R/'ahc008_terry_split_attribution'))
from audit import command_effect, step, snapshot, sha, mask, cells, idx, observed, B, ALL, flood
from stochastic_lock_audit import wave

def case_history(rec):
    fn=rec['case'];f=I/'in'/fn
    a=P/'tapes'/Path(fn).with_suffix('.actions'); tr=a.with_suffix('.trace')
    assert [sha(x)for x in (f,a,tr)]==[rec[k]for k in ('input_sha','commands_sha','trace_sha')]
    trace=tr.read_text().splitlines()
    actions=a.read_text().splitlines()
    assert actions==trace[::2] and len(actions)==300
    kinds,hist,_=observed(f.read_bytes(),trace)
    return kinds,[([idx(x)for x in p],[idx(x)for x in h],mask(map(idx,w)))for p,h,w in hist],actions

def jobs_by_turn(p,m):
    out=collections.defaultdict(list)
    last=-1
    for line in p.read_text().splitlines():
        t,eta,g0,g1,a0,a1,*room=map(int,line.split())
        assert last<=t<274
        assert 0<=a0<m and 0<=a1<m
        assert all(0<=q<900 for q in room)
        out[t].append((eta,g0,g1,a0,a1,tuple(room)))
        last=t
    return out

def support(start,w,kind):
    s=B[start]
    if kind>=4:
        one=wave(s)&~w
        return s|one|(wave(one)&~w)
    assert 1<=kind<=3
    for _ in range(kind):
        holds=sum(B[p]for p in cells(s)if not wave(B[p])&~w)
        s=(wave(s)&~w)|holds
    return s

def views(w,h):
    known=[]
    for x in h:
        if w&B[x]:return []
        known.append(next((v for v in known if v&B[x]),0)or flood(B[x],ALL^w))
    return known

def contains(old,new):
    return len(old)==len(new) and all(not x&~y for x,y in zip(old,new))
def body(w,seed):
    if w&B[seed]:return 0
    return flood(B[seed],ALL^w)
def isolate(w,h,p):
    return snapshot(w,h,p)[0]
def floor(v,m):
    return Fraction(sum(x.bit_count()for x in v),m)

def pick(turn,kinds,current,cmd,jobs,stats):
    """This function intentionally cannot access any future state or mode."""
    pets,people,oldwall=current
    actual=command_effect(people,oldwall,pets,cmd)
    assert actual
    wall,hum=actual
    hs=mask(hum)
    op=ALL^wall
    old_inc=mask(pets)
    support_cache=None
    for eta,l,r,i,j,_room in jobs:
        if eta!=1 or min(l,r)<0 or i==j:continue
        stats['eta1_two_mouth_jobs']+=1
        if r<l or r//30!=l//30:continue
        sides=((i,l,'R'),(j,r,'L'))
        st=[step(g,{'R':'L','L':'R'}[d])for a,g,d in sides]
        into=[step(g,d)for a,g,d in sides]
        if None in st or None in into:continue
        if len({l,r,*into})<3:continue
        if any(wall&B[q]for q in {l,r,*into}) or hs&mask((l,r)):continue
        outs=mask((l,r))
        old_after=wall|outs
        P0=body(old_after,into[0])
        if not P0 or not P0&B[into[1]] or P0&hs or not old_inc&P0:continue
        if not (wave(P0)&outs)==outs:continue
        # Omit no stock current walls and do not accept a physically one-mouth
        # component even if an internal room happened to have two labels.
        if any(body(wall|B[gate],into[0])==P0 for gate in (l,r)):continue
        old_floor=views(old_after,hum)
        for k,(actor,gate,d) in enumerate(sides):
            other,ogate,od=sides[1-k]
            if cmd[actor]!='.' or people[actor]!=st[k]:continue
            if not cmd[other].isupper() or hum[other]!=st[1-k]:continue
            stats['same_role_prep_shapes']+=1
            inward=into[k]
            if inward==ogate or not P0&B[inward] or hs&B[inward]:continue
            prev=list(cmd);prev[actor]=d
            prep=command_effect(people,oldwall,pets,prev)
            if not prep or prep[0]!=wall or prep[1][actor]!=gate:continue
            if not contains(views(wall,hum),views(wall,prep[1])):continue
            if isolate(wall,hum,pets)!=isolate(wall,prep[1],pets):continue
            new_after=wall|mask((inward,ogate))
            target=P0&~B[inward]
            if not target or body(new_after,next(cells(target)))!=target:continue
            if not contains(old_floor,views(new_after,prep[1])):continue
            stats['exact_smaller_shapes']+=1
            new_danger=(B[inward]|wave(B[inward]))&~(B[gate]|wave(B[gate]))
            if support_cache is None:
                support_cache=0
                for p,kind in zip(pets,kinds,strict=True):support_cache|=support(p,wall,kind)
            if new_danger&support_cache:
                stats['current_support_veto']+=1
                continue
            return dict(turn=turn,k=k,actor=actor,other=other,gate=gate,other_gate=ogate,
                        inside=inward,d=d,other_d=od,body=P0,prep=prep,expected=target,
                        issued=''.join(prev))

def label(q,kinds,nextstate,stock_post,cmd,stats):
    """Labels use future observations only after the option has been frozen."""
    p,h,w=nextstate
    _,sh,sw=stock_post
    actor=q['actor']; a=q['other']
    wall,ph=q['prep']
    assert wall==w and all(x==y for i,(x,y)in enumerate(zip(h,ph,strict=True))if i!=actor)
    expected=(cmd[actor]==q['d'].lower() and cmd[a]==q['other_d'].lower()
              and step(h[actor],cmd[actor])==q['gate']
              and step(h[a],cmd[a])==q['other_gate'])
    opened=ALL^sw
    stock_ids,sreach,_=snapshot(sw,sh,p)
    prior_ids=isolate(w,h,p)
    stock_room=body(sw,q['inside'])
    caught_in_room=(stock_ids&~prior_ids)&sum(1<<i for i,x in enumerate(p)if stock_room&B[x])
    label_matched=expected and bool(caught_in_room)
    q['next_roles_match']=expected
    q['stock_new_room_ids']=list(cells(caught_in_room))
    status='not_same_role_close'
    verified=False
    actual_unsafe_lost=0
    if label_matched:
        stats['matched_closures']+=1
        alt=command_effect(ph,w,p,cmd)
        if alt:
            aw,ah=alt
            target=stock_room&~B[q['inside']]
            aid,ar,_=snapshot(aw,ah,p)
            actual_unsafe_lost=stock_ids&~aid
            if (aw==((sw^B[q['gate']])|B[q['inside']])
                and stock_room==q['body'] and target==q['expected'] and target
                and body(aw,next(cells(target)))==target
                and aid==stock_ids and contains(sreach,ar)):
                verified=True
                stats['verified']+=1
                q['gain']=str(floor(ar,len(ah))-floor(sreach,len(ah)))
                status='verified'
            else:status='matched_not_exact'
        else:status='matched_illegal'
    elif expected:status='same_roles_but_no_caught_id'
    if not verified:
        back=list(cmd)
        back[actor]={'R':'L','L':'R'}[q['d']]
        restored=command_effect(ph,w,p,back)
        q['cancel_return_legal']=restored is not None
        q['cancel_displaces_stock_nonwait']=cmd[actor]!='.'
        stats['cancel_return_legal' if restored else 'cancel_return_blocked']+=1
        stats['cancel_return_displaces_nonwait']+=cmd[actor]!='.'
        if restored:
            aw,ah=restored
            broken=stock_ids&~isolate(aw,ah,p)
            q['cancel_lost_ids']=list(cells(broken))
            if label_matched:actual_unsafe_lost|=broken
        elif label_matched:
            # Cannot issue either the tested build or a legal restoration
            # while preserving all other submitted actions.
            actual_unsafe_lost|=caught_in_room
    stats['matched_lost_old_ids']+=actual_unsafe_lost.bit_count() if label_matched else 0
    q['matched_lost_old_ids']=list(cells(actual_unsafe_lost)) if label_matched else []
    q['status']=status

def main():
    recordings=json.loads((P/'recordings.json').read_text())
    assert len(recordings)==100
    location=Path(sys.argv[1])if len(sys.argv)>1 else D/'logs'
    hashes=dict(line.split() for line in (D/'materialize.log').read_text().splitlines())
    assert len(hashes)==100
    results=[];c=collections.Counter()
    print('no live alternatives: selecting entirely before next-state labels',flush=True)
    for rec in recordings:
        fn=rec['case']
        kinds,hist,cmd=case_history(rec)
        log=location/Path(fn).with_suffix('.jobs')
        assert sha(log)==hashes[fn]
        jobs=jobs_by_turn(log,len(hist[0][1]))
        stats=collections.Counter();opt=[]
        for t,order in jobs.items():
            chosen=pick(t,kinds,hist[t],cmd[t],order,stats)
            if chosen is None:continue
            stats['selected']+=1
            label(chosen,kinds,hist[t+1],hist[t+2],cmd[t+1],stats)
            for k in ('prep','body','expected'):del chosen[k]
            opt.append(chosen)
        c.update(stats)
        results.append(dict(case=fn,stats=dict(stats),options=opt))
    vb=sum(r['stats'].get('verified',0)>0 for r in results)
    gain=sum(Fraction(x['gain'])for r in results for x in r['options']if 'gain' in x)
    q=dict(boards=len(results),stats=dict(c),verified_boards=vb,hindsight_floor_sum=str(gain),
           gate=c['verified']>=20 and vb>=10 and 2*c['verified']>=c['selected'] and c['matched_lost_old_ids']==0,
           rows=results)
    (D/'causal-report.json').write_text(json.dumps(q,indent=2)+'\n')
    print(json.dumps({k:v for k,v in q.items()if k!='rows'},indent=2))
if __name__=='__main__':main()
