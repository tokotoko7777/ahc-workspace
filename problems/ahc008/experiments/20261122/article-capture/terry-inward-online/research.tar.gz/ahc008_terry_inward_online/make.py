"""Expose selected causal h=1 two-mouth stock jobs; never modify actions."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def put(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int inward_log_turn=-1;\ninline std::vector<std::string> inward_choice_rows;\n'+s[i:]
a='    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));'
put(a,a+'''
    if(inward_log_turn>=0)for(const auto& j:jobs){
     if(j.left<0||j.right<0)continue;
     const auto open=(actual&~builds&~moves);
     const int eta=std::max({int(!open[j.left]||!open[j.right]),
       std::abs(s.people[j.a]/30-j.left/30),std::abs(s.people[j.b]/30-j.right/30)});
     if(eta!=1)continue;
     std::string row=std::to_string(inward_log_turn)+" "+std::to_string(eta)+" "+
       std::to_string(j.left)+" "+std::to_string(j.right)+" "+
       std::to_string(j.a)+" "+std::to_string(j.b);
     for(int p=0;p<V;++p)if(geometry.ids[p]==j.room)row+=" "+std::to_string(p);
     inward_choice_rows.push_back(std::move(row));
    }
''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn<274&&std::getenv("AHC008_INWARD_LOG"))inward_log_turn=turn;
'''+a+'''
  inward_log_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* p=std::getenv("AHC008_INWARD_LOG")){
   std::ofstream f(p);
   for(const auto& row:inward_choice_rows)f<<row<<'\\n';
 }
'''+a)
(d/'observer.private.cpp').write_text(s)
