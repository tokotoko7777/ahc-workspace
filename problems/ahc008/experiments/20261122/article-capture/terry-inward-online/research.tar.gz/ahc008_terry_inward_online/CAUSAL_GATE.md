# Causal inward-prep selector, detached outcome labels
Input: exactly the 100 accepted incoming held tapes, digest-verified replayed
stock t0..274 jobs; no future state available to pick. At t<274 use only
current positions/types/board, known proposed stock commands and ordered
stock chosen jobs. First ETA1 two-mouth job with one scout on exterior
stance who submitted '.', other guard actually moving onto the opposite
stance, both mouths and inward cells open after preserved stock t action.
Choose the first feasible left-side candidate before its right side;
all other commands/walls unchanged. Verify physical original compartment
with at least one current pet, hypothetical inward floor as original
minus the new wall, no human in the old room, exact current prep ID
preservation and per-person reached-set superset in prep and projected
inward closure. No any-pet endpoint support in inward-only gate hazard
(passive exact layer, directed 0/1/2 geometric), independent of the next
observed animal endpoint. Select at most one prep per board-turn.

Only after freeze, label factual same t+1 actor/door closure with an
actually newly isolated ID in the intended room. Compare exact action
batches: at t only scout wait changes; at t+1 same build char from
the inward stance, every other live command untouched. Strict label
requires all isolated IDs and floor supersets preserved and exact known
room footprint. On cancel, trying to restore the oldest scout pose
consumes its next action (track legal/blocked return, lost IDs, overriding
non-wait). Any loss from a matched closure in the tested action or safe
cancel envelope is a veto. None of these labels makes a causal animal
trajectory prediction. Multiple preparations along one fixed tape
are independent, not an executed consecutive policy.

Advance only with 20 verified closures, 10 distinct boards, at least
half the preparations verifying, zero lost immediate stock IDs in
matched closures. Otherwise stop without widening or rerunning.
No production action, keeper, branch retention or solver changes.
