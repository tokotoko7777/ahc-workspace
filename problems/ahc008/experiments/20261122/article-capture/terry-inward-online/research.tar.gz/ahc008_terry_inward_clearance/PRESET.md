# Strict t−1 no-new-hazard envelope, prior-wait witnesses only
Use the exact original frozen incoming held100 tapes and fixed prior-wait
options only; do not search new states or gate shifts. Compute physically
possible endpoints at observed t from each actual earlier animal start,
using the unchanged post-t−1 people walls. For passive cows, pigs and
rabbits use exact layer support (1,2,3; an isolated point stays).
For dog/cat conservatively union all positions at 0,1,2 individual
cardinal substeps, independent of targets, pets/people, and command
trajectory. A changed stance does not change any t−1 physical wall.
No source/solver/tester work.

Newly forbidden cells = closed cardinal neighborhoods of inward wall
targets minus closed cardinal neighborhoods of replaced outward wall
targets. Do not subtract unshifted stock mouths or unrelated walls:
this is the harder replaced-set comparison. A candidate must have no
animal support in the difference, while every previously verified
submitted action and worker/room/floor guarantee remains as recorded.
Do not use the actual t endpoints for support admission. A pass only
covers new wall legality conditional on the ordinary gates being
legal; it does not ensure the same stochastic trajectories or even
that an online observer would find the same opportunities. Original
earlier outcome and all previously verified factual constraints stay.

Count distinct room events and boards; sum max per-room positive area
among these already certified alternatives. Advance only at >=20
certified room opportunities on >=10 boards; that authorizes an online
causal observer design, not a real candidate. Fail without widening.
