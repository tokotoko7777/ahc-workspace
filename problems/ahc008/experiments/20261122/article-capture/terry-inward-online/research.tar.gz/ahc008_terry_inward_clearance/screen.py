"""No solver or tester: hazard enclosure from the prior-wait audit options."""
import collections,json,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
I=R/'ahc008_terry_incoming_shadow/held100'
P=R/'ahc008_terry_hunt_wall_audit'
A=R/'ahc008_terry_inward_prior_slack'
sys.path.insert(0,str(P))
from analyze import sha,mask,cells,idx,observed,B
from stochastic_lock_audit import wave
LOCK='a078ee8c6b31ad31334838314c51320e54c38dd63539e85c0339f6688f0b0d45'

def endpoint(start,w,kind):
    s=B[start]
    if kind>=4:
        first=wave(s)&~w
        return s|first|(wave(first)&~w)
    for k in range(kind):
        idle=sum(B[p]for p in cells(s)if not wave(B[p])&~w)
        s=(wave(s)&~w)|idle
    return s

def main():
    q=A/'report.json'
    assert sha(q)==LOCK
    old=json.loads(q.read_text())
    rec={r['case']:r for r in json.loads((P/'recordings.json').read_text())}
    assert len(old['rows'])==len(rec)==100
    totals=collections.Counter(); by_species=collections.Counter()
    reasons=collections.Counter(); rows=[]
    summed=Fraction(); viable=0; total_rooms=0
    for b in old['rows']:
        name=b['case'];r=rec[name];f=I/'in'/name
        a=P/'tapes'/Path(name).with_suffix('.actions'); tape=a.with_suffix('.trace')
        assert sha(f)==r['input_sha'] and sha(a)==r['commands_sha'] and sha(tape)==r['trace_sha']
        ts=tape.read_text().splitlines()
        assert a.read_text().splitlines()==ts[::2]
        kinds,hist,_=observed(f.read_bytes(),ts)
        seen={}
        out=[]
        total=Fraction()
        for room in b['witness']:
            t=room['turn']; assert 1<=t<275
            pp,_,_=hist[t-1];_,_,walls=hist[t]
            if t not in seen:
                w=mask(map(idx,walls))
                seen[t]=[endpoint(idx(p),w,k) for p,k in zip(pp,kinds,strict=True)]
            best=Fraction()
            for alt in room['options']:
                a0=mask(alt['old']);b0=mask(alt['new'])
                diff=(b0|wave(b0))&~(a0|wave(a0))
                assert diff
                animals=[i for i,s in enumerate(seen[t])if s&diff]
                types=tuple(sorted({kinds[i]for i in animals}))
                statuses='clear' if not types else 'both' if max(types)>=4 and min(types)<=3 else 'directed_only' if min(types)>=4 else 'passive_only'
                reasons[statuses]+=1
                by_species.update(types)
                gain=Fraction(alt['gain'])
                if not animals:best=max(best,gain)
                out.append(dict(turn=t,old=alt['old'],new=alt['new'],gain=str(gain),newly_forbidden=list(cells(diff)),
                                hazard_ids=animals,hazard_types=types,pass_=not animals))
            total+=best
            totals['cleared_rooms']+=bool(best)
            total_rooms+=1
        viable+=bool(total)
        summed+=total
        rows.append(dict(case=name,certified_gain=str(total),options=out))
    assert total_rooms==old['counts']['rooms_with_gain']==545
    assert sum(reasons.values())==old['counts']['gain_options']==591
    q=dict(boards=100,old_opportunities=total_rooms,options=dict(reasons),hazard_species_incidence=dict(by_species),
           certified_rooms=totals['cleared_rooms'],certified_boards=viable,certified_area=str(summed),
           gate=totals['cleared_rooms']>=20 and viable>=10,rows=rows)
    (D/'report.json').write_text(json.dumps(q,indent=2)+'\n')
    print(json.dumps({k:v for k,v in q.items()if k!='rows'},indent=2))
if __name__=='__main__':main()
