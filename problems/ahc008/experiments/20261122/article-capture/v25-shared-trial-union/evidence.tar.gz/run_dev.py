"""Read-only exact replay driver for the first-100-turn construction audit."""
import csv, hashlib, sys, tempfile
from pathlib import Path
P=Path(__file__).resolve().parent; W=P.parent
H=W/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark import replay
from benchmark_cases import run
T=W/'ahc008_focus_assets/tools/target/release/tester'
cases=W/'ahc008_v24_five_retention/m5-dev30/in'
hist={r['case']:r for r in csv.DictReader((W/'ahc008_v25_terminal_sets/dev30.csv').open()) if r['model']=='baseline'}
D=P/'raw'; D.mkdir(exist_ok=True)
assert len(hist)==30
for f in sorted(cases.glob('*.txt')):
 q=hist[f.name]; data=f.read_bytes()
 assert hashlib.sha256(data).hexdigest()==q['input_sha256']
 with tempfile.TemporaryDirectory() as temp:
  temp=Path(temp); a=temp/'actions'; log=temp/'audit'; tr=temp/'trace'
  b,e,r,_=run([str(T),'env','AHC008_UNION_AUDIT='+str(log),str(P/'solve')],data,4.5)
  assert r==0
  same=hashlib.sha256(b).hexdigest()==q['actions_sha256']
  if not same:
   print(f.name,'different action hash (excluded)',flush=True)
   continue
  assert e.decode().strip()==f"Score = {q['score']}"
  a.write_bytes(b)
  out,err,rc,_=run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',a,tr],data,12.)
  assert (out,err,rc)==(b,e,0)
  assert replay(data.decode(),tr.read_text().splitlines(),b.decode().splitlines(),detailed=True)[0]==int(q['score'])
  (D/(f.stem+'.log')).write_bytes(log.read_bytes())
  print(f.name,'exact',flush=True)
