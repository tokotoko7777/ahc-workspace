 bool unionAuditEnabled=getenv("AHC008_UNION_AUDIT")!=nullptr;
 ostringstream unionAuditLog;
 string unionBefore,unionAfter;
 int unionBeforeMask=0,unionAfterMask=0;
 void unionAuditSubmitted(){
  if(unionBefore.empty())return;
  bool firstIntact=true,collateral=false;
  for(int i=0;i<5;i++){
   if((unionBeforeMask>>i&1)&&act[i]!=unionBefore[i])firstIntact=false;
   if(!(unionBeforeMask>>i&1)&&(unionAfterMask>>i&1)&&act[i]!='.')collateral=true;
  }
  unionAuditLog<<turn<<" submitted "<<firstIntact<<' '<<collateral<<' '<<act<<'\n';
  unionBefore.clear();unionAfter.clear();
 }
 void unionAudit(const vector<vector<BankJob>>& jobs,const terry_mc::Paths& sample,
       const array<BankPath,10>& walk,bitset<terry_lane::MaxTubes> closed,const bitset<V>& build,
       const vector<array<double,Horizon+1>>& mean){
  const auto base=packBankJobs(jobs,2);
  if(base.size()!=2){unionAuditLog<<turn<<" single_or_empty\n";return;}
  using J=BankJob;
  auto mask=[](const J& q){return (1<<q.a)|(1<<q.b);};
  auto safe=[&](const J& a,const J& b){
   if(a.tube>=b.tube||!terryRoad.protects(a.tube,closed))return false;
   auto flags=closed;flags[a.tube]=true;
   return terryRoad.protects(b.tube,flags);
  };
  J b1=base[1],b2=base[0];
  if(b1.tube>b2.tube)swap(b1,b2);
  if(!safe(b1,b2)){unionAuditLog<<turn<<" base_connectivity_unproven\n";return;}
  struct SampleMask{array<uint32_t,128> ids{};bool ready=false;};
  vector<array<SampleMask,Horizon+1>> cache(banks.size());
  auto petsAt=[&](const J& z)->const auto&{
   auto& row=cache[z.tube][z.eta];
   if(row.ready)return row.ids;
   row.ready=true;
   const auto& t=banks[z.tube];
   bitset<V> bad,inside;
   for(int p:{t.g,t.k}){bad[p]=true;for(int q:nb[p])if(q>=0)bad[q]=true;}
   for(int p:t.inner)inside[p]=true;
   for(int i=0;i<sample.trials;i++){
    const auto& x=sample.at(i,z.eta);
    uint32_t m=0;
    for(int j=0;j<sample.n;j++){
     if(bad[x[j]]){m=0;break;}
     if(inside[x[j]])m|=uint32_t(1)<<j;
    }
    row.ids[i]=m;
   }
   return row.ids;
  };
  auto stats=[&](const J& a,const J& b){
   array<int,2> both{};
   // With same ETA and two distinct tube bodies, a head cannot be in two
   // tubes simultaneously. Also assert no geometry has overlapping bodies.
   if(a.eta==b.eta){
    const auto& x=banks[a.tube].inner;
    const auto& y=banks[b.tube].inner;
    for(int p:x)assert(find(y.begin(),y.end(),p)==y.end());
    return both;
   }
   auto& l=petsAt(a);auto& r=petsAt(b);
   for(int i=0;i<sample.trials;i++)both[i>=sample.trials/2]+=popcount(l[i]&r[i]);
   return both;
  };
  auto weight=[&](const J& z){return z.value/mean[z.tube][z.eta];};
  auto corrected=[&](const J& a,const J& b,array<int,2> both){
   return (a.value+b.value)-min(weight(a),weight(b))*(both[0]+both[1])/sample.trials;
  };
  const auto penalty=stats(b1,b2);
  double best=corrected(b1,b2,penalty);
  J z1=b1,z2=b2;
  array<int,2> zBoth=penalty;
  int combos=0,mixed=0,intersect=0;
  for(int i=0;i<int(jobs.size());i++)for(int j=i+1;j<int(jobs.size());j++)
   if(!jobs[i].empty()&&!jobs[j].empty()&&safe(jobs[i].front(),jobs[j].front()))
   for(const auto& a:jobs[i])for(const auto& b:jobs[j])if(!(mask(a)&mask(b))){
    ++combos;mixed+=a.eta!=b.eta;
    const auto hits=stats(a,b);intersect+=hits[0]+hits[1]>0;
    const auto sc=corrected(a,b,hits);
    // Keep the original plan on ties including exact zero-overlap equivalence.
    if(sc>best+1e-12){best=sc;z1=a;z2=b;zBoth=hits;}
   }
  auto cmd=[&](const J& a,const J& b){
   auto out=act;
   for(auto q:{a,b}){
    const auto& x=banks[q.tube];
    for(auto [i,p]:{pair{q.a,x.l},pair{q.b,x.h}}){
     int k=walk[i].step[p];
     if(k>=0&&!build[k])out[i]=MOVE[dir(humans[i],k)];
    }
   }
   return out;
  };
  auto tag=[](const J& a){return tuple(a.tube,a.a,a.b,a.eta);};
  const bool changed=tag(b1)!=tag(z1)||tag(b2)!=tag(z2);
  const auto before=cmd(b1,b2),after=cmd(z1,z2);
  if(before!=after){
   unionBefore=before;unionAfter=after;
   unionBeforeMask=mask(b1)|mask(b2);unionAfterMask=mask(z1)|mask(z2);
  }
  auto own=[&](const J& a,const J& b,int half){
   double total=0;
   auto& l=petsAt(a);auto& r=petsAt(b);
   const double w1=weight(a),w2=weight(b);
   const int lo=half?sample.trials/2:0,hi=half?sample.trials:sample.trials/2;
   for(int s=lo;s<hi;s++)
    total+=w1*popcount(l[s])+w2*popcount(r[s])-min(w1,w2)*popcount(l[s]&r[s]);
   return total/max(1,hi-lo);
  };
  bool h0=changed&&own(z1,z2,0)>own(b1,b2,0)+1e-12,
       h1=changed&&own(z1,z2,1)>own(b1,b2,1)+1e-12;
  unionAuditLog<<turn<<" double "<<combos<<' '<<mixed<<' '<<intersect<<' '
   <<penalty[0]<<' '<<penalty[1]<<' '<<zBoth[0]<<' '<<zBoth[1]<<' '
   <<changed<<' '<<(before!=after)<<' '<<h0<<' '<<h1<<' '<<before<<' '<<after<<' '
   <<b1.tube<<' '<<b2.tube<<' '<<z1.tube<<' '<<z2.tube<<' '
   <<b1.eta<<' '<<b2.eta<<' '<<z1.eta<<' '<<z2.eta<<' '
   <<setprecision(17)<<corrected(b1,b2,penalty)<<' '<<best<<'\n';
 }
