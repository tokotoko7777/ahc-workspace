from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);b=p.read_bytes()
assert hashlib.sha256(b).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=b.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' vector<BankJob> packBankJobs(',Path(__file__).with_name('audit.inc').read_text()+' vector<BankJob> packBankJobs(')
rep('   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;', '''   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;''') # phase anchors only
rep('     for(auto [a,b,d]:pairInfo[k]){const int mask=(1<<a)|(1<<b);auto& j=best[mask];\n      if(j.value>=0){jobs[k].push_back(j);j.value=-1;}}\n    }','''     for(auto [a,b,d]:pairInfo[k]){const int mask=(1<<a)|(1<<b);auto& j=best[mask];
      if(j.value>=0){jobs[k].push_back(j);j.value=-1;}}
    }
    if(unionAuditEnabled&&m==5&&!partial)
     unionAudit(jobs,pathsMC,paths,shut,build,mean);''')
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* p=getenv("AHC008_UNION_AUDIT")){
  ofstream f(p);f<<g.unionAuditLog.str();
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
rep("  cout<<g.act<<'\\n'<<flush;", "  if(g.unionAuditEnabled)g.unionAuditSubmitted();\n  cout<<g.act<<'\\n'<<flush;")
o.write_text(s)
