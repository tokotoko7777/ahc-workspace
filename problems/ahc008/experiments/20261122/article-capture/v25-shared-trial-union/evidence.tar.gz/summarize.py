import collections,json,sys
from pathlib import Path

def one(path):
    out=collections.Counter()
    rev={}
    for row in path.read_text().splitlines():
        t,kind,*z=row.split()
        out[kind]+=1
        if kind=='double':
            n,mixed,intersect,p0,p1,q0,q1,changed,cmd,h0,h1=map(int,z[:11])
            out['competing_different_eta_turns']+=n>=2 and bool(mixed)
            out['turns_any_positive_exact_overlap']+=bool(intersect)
            out['incumbent_overlap_turns']+=bool(p0+p1)
            out['incumbent_joint_occurrences']+=p0+p1
            out['selected_joint_occurrences']+=q0+q1
            out['selection_reversals']+=changed
            out['first_forecast_changes']+=cmd
            if cmd:rev[t]=dict(before=z[11],after=z[12],halves=[h0,h1],
                               incumbent_overlap=p0+p1,new_overlap=q0+q1)
        if kind=='submitted':
            original,collateral=map(int,z[:2]);r=rev[t]
            r.update(submitted=z[2],original_moves_intact=bool(original),collateral=bool(collateral))
            if original and not collateral:
                out['true_noncollateral_command_reversals']+=1
                if all(r['halves']):out['both_halves_support']+=1
    return dict(counts=dict(out),command_examples=rev)
out={Path(a).name:one(Path(a)) for a in sys.argv[1:]}
total=collections.Counter()
for x in out.values():total.update(x['counts'])
boards={k:sum(v['counts'].get(k,0)>0 for v in out.values()) for k in total}
print(json.dumps(dict(boards=len(out),counts=total,board_counts=boards,
                 passes_gate=boards.get('true_noncollateral_command_reversals',0)>=5,by_case=out),indent=2))
