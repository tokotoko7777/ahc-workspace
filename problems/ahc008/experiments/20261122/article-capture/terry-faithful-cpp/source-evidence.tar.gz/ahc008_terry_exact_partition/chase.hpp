#pragma once
#include "partition.hpp"
#include <cmath>
#include <string>

namespace terry_partition {
struct ChaseReport {
    Shape cut;
    std::vector<int> matching; // target wall cell or -1
    int oldScore=0,newScore=0;
};
// Hypothetical cut score intentionally groups contributions, matching the
// planner rather than the final judge's per-person floating evaluation.
inline int partitionScore(const Board& walls,std::span<const int> people,
                          std::span<const int> pets) {
    if(people.empty())return 0;
    std::array<int,size> group,area{},crew{},animals{},q;
    group.fill(-1);
    int parts=0;
    for(int a=0;a<size;++a)if(!walls[a]&&group[a]<0){
        int n=1;q[0]=a;group[a]=parts;
        for(int i=0;i<n;++i)for(int b:neighbors(q[i]))
            if(b>=0&&!walls[b]&&group[b]<0){
                group[b]=parts;q[n++]=b;
            }
        area[parts++]=n;
    }
    for(int p:people)if(group[p]>=0)++crew[group[p]];
    for(int p:pets)if(group[p]>=0)++animals[group[p]];
    double total=0.;
    for(int i=0;i<parts;++i)total+=std::ldexp(double(crew[i])*area[i],-animals[i]);
    return int(std::round(1e8/900.*total/people.size()));
}
inline std::vector<int> shortestRoute(const Board& walls,int start,int goal) {
    std::array<int,size> prev,q;
    prev.fill(-1);
    int n=1;q[0]=start;prev[start]=start;
    for(int i=0;i<n&&prev[goal]<0;++i)for(int p:neighbors(q[i]))
        if(p>=0&&!walls[p]&&prev[p]<0){prev[p]=q[i];q[n++]=p;}
    std::vector<int> path;
    if(prev[goal]<0)return path;
    for(int p=goal;p!=start;p=prev[p])path.push_back(p);
    std::reverse(path.begin(),path.end());
    return path;
}
inline char chaseCommand(int from,int to,bool build=false) {
    auto near=neighbors(from);
    int dir=int(std::find(near.begin(),near.end(),to)-near.begin());
    return dir<4?(build?"urdl":"URDL")[dir]:'.';
}

template<class MaxNetwork,class CostNetwork>
inline std::string executeChase(const Board& walls,const Board& configuredRoads,
                                std::span<const int> people,std::span<const int> pets,
                                int turn,Board placeable,ChaseReport* detail=nullptr) {
    std::string result(people.size(),'.');
    if(detail)*detail=ChaseReport{};
    if(people.empty())return result;
    auto targets=majorityPets(walls,people,pets);
    if(targets.empty())return result;
    auto cut=shape<MaxNetwork>(walls,configuredRoads,people,targets,turn);
    const int m=people.size(), w=cut.walls.size();
    if(detail)detail->cut=cut;
    if(!w)return result;
    int source=m+w,sink=source+1;
    CostNetwork net(sink+1);
    std::vector<int> ids(m*w);
    for(int p=0;p<m;++p){
        auto d=distances(walls,people[p]);
        for(int j=0;j<w;++j){
            const int dist=d[cut.walls[j]];
            ids[p*w+j]=net.add_edge(p,m+j,dist>=0?1:0,std::max(0,dist));
        }
    }
    for(int p=0;p<m;++p)net.add_edge(source,p,1,0);
    for(int j=0;j<w;++j){
        net.add_edge(m+j,sink,1,0);
        net.add_edge(m+j,sink,m,1000000); // enough for all workers; no practical upper bound
    }
    net.flow(source,sink,m);
    std::vector<int> matching(m,-1);
    std::vector<std::vector<int>> routes(m);
    for(int p=0;p<m;++p)for(int j=0;j<w;++j)
        if(net.get_edge(ids[p*w+j]).flow){
            matching[p]=cut.walls[j];
            routes[p]=shortestRoute(walls,people[p],matching[p]);
            break;
        }
    Board hypothetical=walls;
    for(int p:cut.walls)hypothetical.set(p);
    const int old=partitionScore(walls,people,pets);
    const int next=partitionScore(hypothetical,people,pets);
    const bool reasonable=double(next)>=double(old)*.95;
    if(detail){
        detail->matching=matching;detail->oldScore=old;detail->newScore=next;
    }
    // Reserve every remaining step for each person on the evasion side.
    if(turn<299)for(int p=0;p<m;++p)if(matching[p]>=0&&cut.evasion[people[p]])
        for(int z:routes[p])placeable.reset(z);
    Board shadow=walls;
    for(int p=0;p<m;++p)if(matching[p]>=0) {
        const int at=people[p];
        const auto& route=routes[p];
        if(route.empty()) {
            for(int z:neighbors(at))if(z>=0&&!shadow[z]&&!cut.evasion[z]){
                result[p]=chaseCommand(at,z);
                placeable.reset(z);
                // Original zero-distance escape reserves this cell in both
                // internal masks; it is still a MOVE in the returned action.
                shadow.set(z);
                break;
            }
        }else{
            int z=route.front();
            if(shadow[z])continue;
            if(route.size()==1&&!cut.evasion[at]) {
                if(placeable[z]&&reasonable){
                    result[p]=chaseCommand(at,z,true);
                    placeable.reset(z);shadow.set(z);
                }
            }else{
                result[p]=chaseCommand(at,z);
                placeable.reset(z);
            }
        }
    }
    return result;
}
}
