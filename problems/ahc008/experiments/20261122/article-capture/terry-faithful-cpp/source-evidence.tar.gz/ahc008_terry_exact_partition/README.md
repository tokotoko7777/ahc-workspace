# AHC008 late chase / rollout fidelity audit

This report and the independent C++ helper describe algorithms learned from the user's authorized local reference. They do not include or execute the raw reference. No official tester ran.

## Stage selection

The original performs a single comparison at zero-based turn 275. It starts normal and remains normal if no pets are connected to the component with the largest number of people (first row-major component breaks a tie). Otherwise it performs paired full simulations through turn 299, conditioned on comparison loop *start* while wall-clock time since initialization is below 2,700 ms. Virtual judges start from snapshot geometry/positions, reset all dog/cat targets, and use fresh ChaCha20 streams seeded with the same `iteration*998244353` on each branch (iteration starts at 1). Normal short-horizon decision randomness is separately reseeded to PCG 42 for every normal arm. Strictly larger cumulative chase score switches the policy; tie, no time, or no relevant pets means normal. If chosen, chase replaces every normal phase and remains the only phase even on a no-op turn.

Two literal reproducibility quirks, not improvements: the ordinary rollout mutates the remaining **live** construction queues (input state is cloned, this queue is passed by mutable reference to each normal trial). The chase rollout advances pets and board for all 25 turns but passes the initial 275 to its command planner every time. Live chase receives the actual turn. Virtual Judge final score follows the official per-human exact component formula and floating rounding, not the internal hypothetical-cut score accumulation.

The current frozen v24 is not equivalent: eligibility and pre-search before the decision, at most three target pets, rail proxy versus clustered late-cut plan, model belief initialization, up to 50 pairs with a roughly 120ms local CPU window and absolute CPU cap, and at least four completed pairs to select. For a selected plan returning no command it can fall through to old v24 policies instead of exclusive no-op chase. It also holds a candidate cut in a simulated arm, instead of rebuilding the original single current-state separator each turn.

## Cut shape

See `partition.hpp`; no dependency on mutable simulator or solver policies. `shape<MaxFlow<int>>(walls, allConfiguredAisles, people, majorityPetPositions, turn)` consumes zero-based 30×30 cell indices and bitset masks, and returns new wall cells and full evasion mask. Use the complete configured aisle mask, not a handful of row-center anchors. The cut graph has a padded fixed blocked border. In→out capacity is zero for existing walls, five for unoccupied cells reachable by a worker within the remaining deadline, and a dominating capacity otherwise. The reach bound is 300−t−2 through 295, then 300−t−1 through 298, then one. Adjacent out→in arcs are dominating. Each source-connected aisle cell and human contributes one unless Manhattan ≤1 from a target pet; overlaps intentionally add multiple arcs. Each targeted pet has a sink edge with prize equal to the ceiling of total source mass over number of targets, and receives dominating arcs from all reachable cells at distance ≤2. This is a balanced soft cut, not a mandatory capture or a score optimization. Evasion includes old walls, cut cells, and cells outside the residual source side.

The helper uses a finite large integer (100,000,000) instead of maximum i32; no source mass can approach it. It scans the radius-two pet neighborhood row-major via BFS rather than copying the reference offsets table. Both equivalent edge-order behavior for balanced mincuts and full policy matching still require differential checks; unit below only validates a clear separator and majority-component selection.

## Chase staffing and live actions still to wire

The original recomputes both cut and assignment every turn. Min-cost flow allows one unit per worker with path cost to the target **wall cell itself**. Each wall has a capacity-one zero-cost priority arc and a high-penalty overflow arc (one million), favoring covering distinct walls before allocating backups. Route planning is BFS current topology and tie order U,R,D,L. Previously matched workers on the evasion side mark the cells of their entire route unsafe for building until the final turn. A worker already on their own target steps to the first safe non-evasion neighbor. An adjacent worker on the safe side builds only when legal and plugging all proposed walls hypothetically scores at least 95% of the current snapshot. Other matched workers walk one step toward the wall. Postprocess removes movement/build clashes and handles same target cells; it does not impose a universal employee-cohesion invariant. On the final turn route protection is omitted, so helpers can be left behind if the predicted value justifies it. An empty target set issues no actions.

```sh
g++ -std=c++23 -Wall -Wextra -pedantic unit.cpp -o /tmp/terry-exact-part-unit
/tmp/terry-exact-part-unit
```

## Chase command wrapper

`chase.hpp` wires the staffing and live action rules listed above:
`executeChase<MaxFlow<int>,MinCostFlow<int,int>>(walls, fullAisleMask, humanPositions, allPetPositions, turn, physicallyPlaceableMask)`.
A bit of one in `physicallyPlaceableMask` allows a wall at that cell. It returns a regular string of planned moves/builds/idle; pass it through the caller's final command-processing stage. The optional `ChaseReport*` reports selected cut cells, assigned walls, and old/new rounded hypothetical scores. Capacity of the overflow arc is capped to the number of workers (behaviorally sufficient); external cost-flow tie order may differ from the reference ACL implementation. The zero-distance escape move deliberately reserves its destination in both temporary action masks, matching original behavior. Empty targets, empty cut and no viable action return all idle without requesting a separate policy.

```sh
g++ -std=c++23 -Wall -Wextra -pedantic chase-unit.cpp -o /tmp/terry-chase-unit
/tmp/terry-chase-unit
```

The synthetic fixture exercises duplicate target assignment (overflow), physical approach, positive hypothetical score, legal turn-299 build, blocked target no-op, and all-clear no-op. No official tester ran.
