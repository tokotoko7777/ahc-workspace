#pragma GCC optimize("O3")
#include "chase.hpp"
#include "../ahc008_partition_repo/library/max-flow.hpp"
#include "../ahc008_partition_repo/library/min-cost-flow.hpp"
#include <cassert>
#include <iostream>
int main(){
 namespace a=terry_partition;
 a::Board wall,road,ok;
 wall.set();ok.set();
 for(int r=9;r<=11;r++)for(int c=0;c<=10;c++){wall.reset(30*r+c);road.set(30*r+c);}
 for(int c=11;c<=16;c++)wall.reset(10*30+c);
 std::array people{10*30+8,9*30+9};
 std::array animals{10*30+15};
 a::ChaseReport t;
 auto chase=[&](int turn){
     return a::executeChase<MaxFlow<int>,MinCostFlow<int,int>>(wall,road,people,animals,turn,ok,&t);
 };
 auto start=chase(275);
 assert(t.cut.walls.size()==1&&t.cut.flowValue==5);
 auto goal=t.cut.walls.front();
 for(int c:{0,1})assert(t.matching[c]==goal);
 assert(start=="RR"||start=="RD"||start=="DR");
 assert(t.newScore>t.oldScore);
 for(int i=0;i<2;++i){
     auto near=a::neighbors(people[i]);
     int dir=int(std::string("URDL").find(start[i]));
     people[i]=near[dir];
 }
 start=chase(275);
 assert(start.size()==2);
 std::array testPeople{10*30+11,9*30+9};
 auto build=a::executeChase<MaxFlow<int>,MinCostFlow<int,int>>(wall,road,testPeople,animals,299,ok,&t);
 assert(build.size()==2&&build[0]=='r');
 auto blocked=ok;
 blocked.reset(10*30+12);
 build=a::executeChase<MaxFlow<int>,MinCostFlow<int,int>>(wall,road,testPeople,animals,299,blocked,&t);
 assert(build[0]=='.');
 wall.set(goal);
 assert(chase(299)=="..");
 std::cout<<"chase shape, overflow assignment, route, grouped fence score, all-clear no-op\n";
}
