#pragma GCC optimize("O3")
#include "partition.hpp"
#include "../ahc008_partition_repo/library/max-flow.hpp"
#include <cassert>
#include <iostream>
int main(){
 namespace a=terry_partition;
 a::Board wall,road;
 wall.set();
 for(int r=9;r<=11;r++)for(int c=0;c<=10;c++){wall.reset(30*r+c);road.set(30*r+c);}
 for(int c=11;c<=16;c++)wall.reset(10*30+c);
 std::array people{10*30+8,9*30+9};
 std::array animals{10*30+15};
 auto targets=a::majorityPets(wall,people,animals);
 assert(targets.size()==1);
 auto out=a::shape<MaxFlow<int>>(wall,road,people,targets,275);
 assert(out.sourceMass==35);
 assert(out.walls.size()==1&&out.flowValue==5);
 assert(out.evasion[animals[0]]&&!out.evasion[people[0]]);
 assert(a::deadlineRadius(295)==3&&a::deadlineRadius(296)==3&&a::deadlineRadius(299)==1);
 for(int p:out.walls)wall.set(p);
 assert(a::majorityPets(wall,people,animals).empty());
 std::cout<<"one affordable corridor separator, 5 capacity, no pets after cut\n";
}
