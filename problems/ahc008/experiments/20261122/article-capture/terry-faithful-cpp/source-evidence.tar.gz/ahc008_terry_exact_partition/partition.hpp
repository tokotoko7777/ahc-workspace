#pragma once
#include <algorithm>
#include <array>
#include <bitset>
#include <cstdlib>
#include <span>
#include <vector>

namespace terry_partition {
inline constexpr int side=30, size=side*side, P=side+2, padded=P*P;
using Board=std::bitset<size>;
struct Shape {
    std::vector<int> walls;
    Board evasion;
    int targetCount=0, sourceMass=0, flowValue=0, meetingRadius=0;
};
inline int mDist(int a,int b){
    return std::abs(a/side-b/side)+std::abs(a%side-b%side);
}
inline std::array<int,4> neighbors(int p) {
    int r=p/side,c=p%side;
    return {r>0?p-side:-1,c+1<side?p+1:-1,r+1<side?p+side:-1,c>0?p-1:-1};
}
inline std::array<int,size> distances(const Board& wall,int origin) {
    std::array<int,size> d,q;
    d.fill(-1);
    int n=1;q[0]=origin;d[origin]=0;
    for(int k=0;k<n;++k)
        for(int p:neighbors(q[k]))if(p>=0&&!wall[p]&&d[p]<0){
            d[p]=d[q[k]]+1;q[n++]=p;
        }
    return d;
}
inline std::vector<int> majorityPets(const Board& walls,std::span<const int> people,std::span<const int> pets) {
    std::array<int,size> label,crew{};
    label.fill(-1);
    int id=0;
    std::array<int,size> q;
    for(int v=0;v<size;++v)if(!walls[v]&&label[v]<0) {
        int n=1;q[0]=v;label[v]=id;
        for(int k=0;k<n;++k)for(int p:neighbors(q[k]))
            if(p>=0&&!walls[p]&&label[p]<0){label[p]=id;q[n++]=p;}
        ++id;
    }
    for(int h:people)if(label[h]>=0)++crew[label[h]];
    int best=int(std::max_element(crew.begin(),crew.begin()+id)-crew.begin());
    std::vector<int> targets;
    for(int p:pets)if(label[p]==best)targets.push_back(p);
    return targets;
}
inline int deadlineRadius(int turn) {
    return turn<=295?298-turn:turn<299?299-turn:300-turn;
}
// Network supplies constructor(n), add_edge(), flow(), min_cut() as in
// tokotoko7777/ahc-workspace library MaxFlow<int>. Distances and outputs use
// caller's 0-based 30×30 coordinates; keep a permanent padded border only
// inside the cut graph to preserve the separator's original semantics.
template<class Network>
inline Shape shape(const Board& walls,const Board& roads,
                   std::span<const int> crew,std::span<const int> targets,int turn) {
    Shape ans;
    ans.targetCount=targets.size();
    ans.meetingRadius=deadlineRadius(turn);
    if(targets.empty())return ans;
    constexpr int limit=100000000;
    int dep=2*padded, src=dep+targets.size(), snk=src+1;
    Network f(snk+1);
    auto front=[](int r,int c){return 2*(r*P+c);};
    auto node=[&](int p){return front(p/side+1,p%side+1);};
    Board occupied,reachable;
    for(int h:crew) {
        occupied.set(h);
        auto dist=distances(walls,h);
        for(int p=0;p<size;++p)if(dist[p]>=0&&dist[p]<=ans.meetingRadius)
            reachable.set(p);
    }
    for(int r=0;r<P;++r)for(int c=0;c<P;++c){
        int p=(r-1)*side+c-1;
        bool border=r==0||r==P-1||c==0||c==P-1;
        int cost=border||walls[p]?0:reachable[p]&&!occupied[p]?5:limit;
        int u=front(r,c);f.add_edge(u,u+1,cost);
    }
    auto sourceArc=[&](int p){
        for(int a:targets)if(mDist(a,p)<=1)return;
        f.add_edge(src,node(p),1);
        ++ans.sourceMass;
    };
    for(int p=0;p<size;++p)if(roads[p])sourceArc(p);
    for(int h:crew)sourceArc(h); // Multiplicity matters if humans overlap.
    const int prize=(ans.sourceMass+int(targets.size())-1)/int(targets.size());
    for(int j=0;j<int(targets.size());++j){
        auto d=distances(walls,targets[j]);
        for(int p=0;p<size;++p)if(d[p]>=0&&d[p]<=2)
            f.add_edge(node(p)+1,dep+j,limit);
        f.add_edge(dep+j,snk,prize);
    }
    constexpr int dr[4]={-1,0,1,0}, dc[4]={0,1,0,-1};
    for(int r=0;r<P;++r)for(int c=0;c<P;++c)
        for(int k=0;k<4;++k) {
            int rr=r+dr[k],cc=c+dc[k];
            if(rr>=0&&rr<P&&cc>=0&&cc<P)
                f.add_edge(front(r,c)+1,front(rr,cc),limit);
        }
    ans.flowValue=f.flow(src,snk);
    auto seen=f.min_cut(src);
    for(int p=0;p<size;++p){
        int v=node(p);
        bool differs=seen[v]!=seen[v+1];
        if(!walls[p]&&differs)ans.walls.push_back(p);
        if(walls[p]||!seen[v]||differs)ans.evasion.set(p);
    }
    return ans;
}
}
