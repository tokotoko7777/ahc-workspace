#include "hunt.hpp"
#include <cassert>
int main(){
 using namespace terry_exact_hunt;
 std::array<bool,900> can;
 can.fill(true);
 Room r; r.left=16*30+4; r.right=16*30+9; r.area=6; r.retention[0]=100; r.retention[1]=98;
 std::vector<int> p{16*30+3, 16*30+10, 16*30+10};
 std::vector<std::optional<char>> a(3); a[2]='.';
 auto j=choose(p,a,{r},can);
 assert(j.size()==1&&j[0].a==0&&j[0].b==1);
 auto other=a; emit(p,j,can,other);
 assert(other[0]=='r'&&other[1]=='l'&&other[2]=='.');
 can[r.left]=false;
 j=choose(p,a,{r},can);
 assert(j.size()==1);
 emit(p,j,can,a);
 assert(a[0]=='.'&&a[1]=='.');
 p[1]+=30; a[0]=a[1]=std::nullopt;
 j=choose(p,a,{r},can); emit(p,j,can,a);
 assert(a[0]=='.'&&a[1]=='U');
 a[0]=a[1]=std::nullopt; r.left=-1;
 j=choose(p,a,{r},can); emit(p,j,can,a);
 assert(!a[0]&&a[1]=='U');
 std::array<int,900> label; label.fill(-1); label[12]=0; label[13]=0; label[32]=1;
 std::vector<Room> rooms{r,r};
 count_retention(rooms,label,{12,11,32},{0,1},[](int i,int,auto report){
  assert(i==0);
  report(0,12); report(1,11); report(2,32); report(29,13);
 });
 assert(rooms[0].retention[0]==100&&rooms[0].retention[1]==0);
 assert(rooms[1].retention[2]==0&&rooms[0].retention[29]==100);
}
