#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <functional>
#include <optional>
#include <tuple>
#include <vector>

namespace terry_exact_hunt {
// Coordinates are zero-based row*30+column; -1 means missing door.
// Retention[d] is the accumulated number of same-initial-room sample occupancies.
struct Room { int left=-1, right=-1, area=0; std::array<int,30> retention{}; };
// sample(petIndex, trial, report) calls report(horizon, position) for 0..29.
template<class Sample>
inline void count_retention(std::vector<Room>& rooms, const std::array<int,900>& label,
    const std::vector<int>& petPos, const std::vector<int>& alive, Sample&& sample) {
    for(auto& room:rooms) room.retention.fill(0);
    for(int i:alive){
        const int id=label[petPos[i]];
        if(id<0||id>=(int)rooms.size()) continue;
        auto& counts=rooms[id].retention;
        for(int trial=0;trial<100;++trial){
            sample(i,trial,[&](int h,int q){
                if((unsigned)h<30&&(unsigned)q<900&&label[q]==id) ++counts[h];
            });
        }
    }
}
// Keep excluded entries indexed, so compressed or sparse original labels stay valid.
inline void filter_rooms(std::vector<Room>& rooms,const std::array<int,900>& label,
    const std::vector<int>& people,const std::array<bool,900>& wallNext,
    const std::array<bool,900>& articulation) {
    for(auto& room:rooms)
        for(int door:{room.left,room.right})
            if(door>=0&&(wallNext[door]||articulation[door])) room.area=0;
    for(int p:people){
        int id=label[p];
        if(id>=0&&id<(int)rooms.size()) rooms[id].area=0;
    }
}
struct Candidate {
    std::int64_t score; int left,right,a,b,room;
    auto key() const { return std::tuple{score,left,right,a,b,room}; }
};
// unset command = nullopt; a chosen explicit wait = '.'.
inline std::vector<Candidate> choose(const std::vector<int>& people,
    const std::vector<std::optional<char>>& actions,
    const std::vector<Room>& rooms, const std::array<bool,900>& canNext) {
    std::vector<Candidate> jobs;
    int n=people.size();
    for(int k=0;k<(int)rooms.size();++k){
        const auto& r=rooms[k];
        if(r.area<=0 || (r.left<0&&r.right<0)) continue;
        const int anchor=r.left>=0?r.left:r.right;
        const double penalty=1.0-std::abs((anchor/30+1)-15.5)/30.0;
        const int blocked=(r.left>=0&&!canNext[r.left])||(r.right>=0&&!canNext[r.right]);
        for(int a=0;a<n;++a)if(!actions[a])
        for(int b=0;b<n;++b)if(!actions[b]){
            if(r.left>=0 && people[a]%30!=r.left%30-1) continue;
            if(r.right>=0 && people[b]%30!=r.right%30+1) continue;
            if((a==b)!=(r.left<0||r.right<0)) continue;
            int eta=blocked;
            if(r.left>=0) eta=std::max(eta,std::abs(people[a]/30-r.left/30));
            if(r.right>=0) eta=std::max(eta,std::abs(people[b]/30-r.right/30));
            if(eta>=30) continue;
            const auto score=std::int64_t(r.retention[eta]*1e8*penalty/(r.area*double(eta+1)));
            if(score>0) jobs.push_back({score,r.left,r.right,a,b,k});
        }
    }
    std::sort(jobs.begin(),jobs.end(),[](const Candidate&a,const Candidate&b){return a.key()>b.key();});
    const int m=jobs.size();
    std::vector<std::int64_t> pref(m+1);
    for(int i=0;i<m;++i) pref[i+1]=pref[i]+jobs[i].score;
    std::int64_t best=0;
    std::vector<Candidate> stack, solution;
    std::vector<bool> occupied(rooms.size());
    // Keep the reference's deliberate heuristic bound even with one-person jobs.
    std::function<void(int,unsigned,std::int64_t)> dfs=[&](int i,unsigned used,std::int64_t sum){
        if(i==m){
            if(sum>best){best=sum;solution=stack;}
            return;
        }
        if(sum+pref[std::min(m,i+(n-std::popcount(used))/2)]-pref[i]<=best) return;
        const auto& j=jobs[i];
        unsigned mask=(1u<<j.a)|(1u<<j.b);
        if(!(used&mask)&&!occupied[j.room]){
            stack.push_back(j);occupied[j.room]=true;
            dfs(i+1,used|mask,sum+j.score);
            occupied[j.room]=false;stack.pop_back();
        }
        dfs(i+1,used,sum);
    };
    dfs(0,0,0);
    return solution;
}
inline void emit(const std::vector<int>& people, const std::vector<Candidate>& jobs,
    const std::array<bool,900>& canActual, std::vector<std::optional<char>>& actions) {
    auto vertical=[](int p,int door){return p/30>door/30?'U':p/30<door/30?'D':'.';};
    for(const auto& j:jobs){
        const char a=j.left<0?'.':vertical(people[j.a],j.left);
        const char b=j.right<0?'.':vertical(people[j.b],j.right);
        const bool ready=a=='.'&&b=='.';
        const bool close=ready&&(j.left<0||canActual[j.left])&&(j.right<0||canActual[j.right]);
        if(j.left>=0) actions[j.a]=close?'r':a;
        if(j.right>=0) actions[j.b]=close?'l':b;
    }
}
}
