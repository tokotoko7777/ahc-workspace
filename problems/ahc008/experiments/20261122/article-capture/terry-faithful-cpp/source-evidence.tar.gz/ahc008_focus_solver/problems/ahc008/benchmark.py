"""Run official tester against both arms and replay its live transcript."""
import argparse
import csv
import hashlib
from math import ldexp, modf
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time

STEPS = {"U": (-1, 0), "D": (1, 0), "L": (0, -1), "R": (0, 1)}


def relay(binary, trace):
    """Transparent protocol proxy; the official tester controls animal RNG."""
    with subprocess.Popen([binary], stdin=subprocess.PIPE, stdout=subprocess.PIPE) as child, \
            trace.open("wb") as log:
        nline = sys.stdin.buffer.readline()
        initial = nline + b"".join(sys.stdin.buffer.readline() for _ in range(int(nline)))
        mline = sys.stdin.buffer.readline()
        initial += mline + b"".join(sys.stdin.buffer.readline() for _ in range(int(mline)))
        child.stdin.write(initial)
        child.stdin.flush()
        for _ in range(300):
            action = child.stdout.readline()
            assert action, "solver terminated early"
            sys.stdout.buffer.write(action)
            sys.stdout.buffer.flush()
            reply = sys.stdin.buffer.readline()
            assert reply, "tester rejected output"
            child.stdin.write(reply)
            child.stdin.flush()
            log.write(action + reply)
        child.stdin.close()
        assert not child.stdout.read(), "trailing output after turn 300"
        assert child.wait() == 0


def add(p, step):
    r, c = STEPS[step]
    return p[0] + r, p[1] + c


def inside(p):
    return 1 <= p[0] <= 30 and 1 <= p[1] <= 30


def replay(case, trace, commands, *, detailed=False, topology=False, snapshots=None, interval=50, final_components=None):
    f = iter(case.splitlines())
    pet_rows = [tuple(map(int, next(f).split())) for _ in range(int(next(f)))]
    pets = [row[:2] for row in pet_rows]
    humans = [tuple(map(int, next(f).split())) for _ in range(int(next(f)))]
    assert len(trace) == 600 and trace[::2] == commands
    blocked = set()
    assert all(inside(p) for p in humans + pets)
    def snapshot(turn):
        labels = {}
        groups = []
        for human in humans:
            if human not in labels:
                side = len(groups)
                queue = [human]
                labels[human] = side
                for p in queue:
                    for step in STEPS:
                        v = add(p, step)
                        if inside(v) and v not in blocked and v not in labels:
                            labels[v] = side
                            queue.append(v)
                kinds = [0]*5
                for row, pet in zip(pet_rows, pets, strict=True):
                    if labels.get(pet) == side:
                        kinds[row[2]-1] += 1
                groups.append([0, len(queue), kinds])
            groups[labels[human]][0] += 1
        snapshots(turn, groups)

    if snapshots:
        snapshot(0)
    for turn, (cmd, reply) in enumerate(zip(trace[::2], trace[1::2], strict=True), 1):
        assert len(cmd) == len(humans)
        forbidden = set(humans + pets)
        forbidden |= {add(p, s) for p in pets for s in STEPS}
        newly = set()
        after = []
        for p, op in zip(humans, cmd, strict=True):
            if op == ".":
                after.append(p)
                continue
            q = add(p, op.upper())
            assert inside(q)
            if op.islower():
                assert q not in forbidden
                newly.add(q)
                after.append(p)
            else:
                after.append(q)
        blocked |= newly
        assert all(p not in blocked for p in after)
        humans = after
        pieces = reply.split()
        assert len(pieces) == len(pets)
        for i, steps in enumerate(pieces):
            for op in steps:
                if op != ".":
                    pets[i] = add(pets[i], op)
                    assert inside(pets[i]) and pets[i] not in blocked
        if snapshots and (turn % interval == 0 or turn == 300):
            snapshot(turn)
    component = {}
    groups = []

    def visit(start):
        if start in component:
            return groups[component[start]]
        todo = [start]
        seen = {start}
        while todo:
            p = todo.pop()
            for s in STEPS:
                q = add(p, s)
                if inside(q) and q not in seen and q not in blocked:
                    seen.add(q)
                    todo.append(q)
        stats = (len(seen), sum(p in seen for p in pets))
        component.update((p, len(groups)) for p in seen)
        groups.append(stats)
        return stats
    values = [visit(h) for h in humans]
    n = len(pets)
    numerator = 10**8 * sum(a << (n-k) for a, k in values)
    denominator = (900 * len(humans)) << n
    exact_score = (2 * numerator + denominator) // (2 * denominator)
    # The official tester applies binary64 operations in this order. Near a
    # half-integer its result can differ by one from exact rational rounding.
    score_sum = 0.0
    for a, k in values:  # preserve order even on Python versions with compensated sum()
        score_sum += ldexp(a / 900.0, -k)
    fraction, integral = modf(1e8 * score_sum / len(values))
    score = int(integral) + (fraction >= 0.5)
    assert abs(score - exact_score) <= 1
    if topology or final_components:
        for r in range(1, 31):
            for c in range(1, 31):
                p = r, c
                if p not in blocked:
                    visit(p)
        if final_components:
            counts = [0] * len(groups)
            for h in humans:
                counts[component[h]] += 1
            final_components([(h, area, npets)
                              for h, (area, npets) in zip(counts, groups, strict=True)])
        if topology:
            return score, values, len(blocked), max(a for a, _ in groups)
    if detailed:
        return score, values, len(blocked)
    return score, values[0][0], values[0][1], len(blocked)


def seeds(split, tag="cuts-v1"):
    return [int.from_bytes(hashlib.sha256(f"ahc008/{tag}/{split}/{i}".encode())
                          .digest()[:8], "little") for i in range(24)]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("gen", "tester", "base", "adaptive", "csv"):
        p.add_argument(name, type=Path)
    p.add_argument("--tag", default="cuts-v1")
    p.add_argument("--candidate-label", default="adaptive")
    args = p.parse_args()
    gen, tester, base, adaptive = (x.resolve() for x in
                                   (args.gen, args.tester, args.base, args.adaptive))
    with tempfile.TemporaryDirectory() as tmp, args.csv.open("w", newline="") as f:
        work = Path(tmp)
        script = Path(__file__).resolve()
        seedfile = work / "seeds.txt"
        trace = work / "trace.txt"
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(("split", "seed", "mode", "score", "h0_area", "h0_pets",
                         "walls", "direct_seconds", "relay_seconds"))
        for split in ("dev", "holdout"):
            seedfile.write_text("".join(f"{s}\n" for s in seeds(split, args.tag)))
            subprocess.run([gen, seedfile], cwd=work, check=True)
            for i, seed in enumerate(seeds(split, args.tag)):
                case = (work / "in" / f"{i:04}.txt").read_bytes()
                modes = [("base", base), (args.candidate_label, adaptive)]
                for mode, binary in (modes if i % 2 == 0 else modes[::-1]):
                    before = time.monotonic()
                    plain = subprocess.run([tester, binary], input=case, capture_output=True,
                                           check=True, timeout=3)
                    direct_sec = time.monotonic() - before
                    before = time.monotonic()
                    proxy = subprocess.run([tester, sys.executable, script, "--relay", binary, trace],
                                           input=case, capture_output=True,
                                           check=True, timeout=3)
                    relay_sec = time.monotonic() - before
                    assert direct_sec < 3 and relay_sec < 3
                    assert plain.stdout == proxy.stdout
                    score, *extra = replay(case.decode(), trace.read_text().splitlines(),
                                          plain.stdout.decode().splitlines())
                    assert plain.stderr == proxy.stderr
                    match = re.fullmatch(rb"Score = (\d+)\s*", plain.stderr)
                    assert match and int(match[1]) == score and score > 0
                    writer.writerow((split, seed, mode, score, *extra,
                                     f"{direct_sec:.6f}", f"{relay_sec:.6f}"))
                    f.flush()


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] == "--relay":
        relay(Path(sys.argv[2]), Path(sys.argv[3]))
    else:
        main()
