#include "terrain.hpp"
#include <iostream>
#include <map>
using namespace terry_exact_maps;
int main(){
 for(int g=0;g<5;g++){
  auto& t=terrain(g);
  auto a=classify(t,t.plannedWalls,t.plannedWalls,{t.aisleColumns[0]});
  uint64_t hash=1469598103934665603ULL;
  for(auto x:t.cells)hash=(hash^static_cast<uint8_t>(x))*1099511628211ULL;
  std::cout<<g<<" X="<<t.plannedWalls.count()<<" |="<<t.aisleCells.count()<<" gate="<<t.doorCells.count()
     <<" path="<<t.snake(true).size()<<" main="<<a.participates.count()<<" rooms="<<a.count()<<" hash="<<std::hex<<hash<<std::dec;
  std::map<std::pair<int,int>,int> stats;
  for(auto v:a.rooms)stats[{(v.left>=0)+(v.right>=0),v.size}]++;
  for(auto [k,n]:stats)std::cout<<' '<<k.first<<':'<<k.second<<'x'<<n;
  std::cout<<'\n';
 }
}
