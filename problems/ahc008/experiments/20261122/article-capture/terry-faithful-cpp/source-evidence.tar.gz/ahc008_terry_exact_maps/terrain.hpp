#pragma once
#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <cstdint>
#include <initializer_list>
#include <vector>

namespace terry_exact_maps {
inline constexpr int W=30,V=W*W;
using Board=std::bitset<V>;
using Ids=std::array<int,V>;
enum class Marker : uint8_t {Open='.', Wall='X', Aisle='|', Sweep='~', Room='-',
                             LeftOne='(', RightOne=')', LeftTwo='<', RightTwo='>'};
inline constexpr int cell(int r,int c){return r*W+c;}
inline constexpr std::array<int,4> adjacent(int p){
 return {p>=W?p-W:-1,p%W<W-1?p+1:-1,p+W<V?p+W:-1,p%W?p-1:-1};
}
inline constexpr bool leftDoor(Marker m){return m==Marker::LeftOne||m==Marker::LeftTwo;}
inline constexpr bool rightDoor(Marker m){return m==Marker::RightOne||m==Marker::RightTwo;}
inline constexpr bool door(Marker m){return leftDoor(m)||rightDoor(m);}

struct Terrain {
 std::array<Marker,V> cells{};
 std::vector<int> aisleColumns,aisleRows;
 Board plannedWalls,aisleCells,doorCells;
 bool planned(int p)const{return p>=0&&p<V&&plannedWalls[p];}
 bool aisle(int p)const{return p>=0&&p<V&&aisleCells[p];}
 bool leftDoor(int p)const{return p>=0&&p<V&&terry_exact_maps::leftDoor(cells[p]);}
 bool rightDoor(int p)const{return p>=0&&p<V&&terry_exact_maps::rightDoor(cells[p]);}
 bool constructionRow(int r)const{
  return r>=0&&r<W&&(r&1)&&cells[cell(r,W-1)]==Marker::Sweep;
 }
 // Independent geometric helper: both exact original construction tours'
 // target sequence prior to assignment; not movement commands.
 std::vector<int> snake(bool eastbound)const{
  std::vector<int> result;
  for(int r:aisleRows)if(constructionRow(r)){
   for(int i=0;i<W;i++){
    int c=eastbound?i:W-1-i;
    int p=cell(r,c);
    if(planned(p)||planned(p-W)||planned(p+W))result.push_back(p);
   }
   eastbound=!eastbound;
  }
  return result;
 }
};

namespace impl {
struct Pattern{uint32_t wall,oneL,oneR,twoL,twoR;};
struct Source{std::initializer_list<int> lanes;Pattern top,separator,sweep,room,secondSweep;};
inline const std::array<Source,5> source{{
#include "terrain_data.inc"
}};
inline Terrain build(int index){
 const auto& s=source[index];
 Terrain t;
 t.aisleColumns.assign(s.lanes);
 for(int r=0;r<W;r++){
  const bool odd=r%2, sweep=r%4==1;
  if(odd)t.aisleRows.push_back(r);
  const auto& p=r==0?s.top:!odd?s.separator:!sweep?s.room:
             (index==4&&r%8==5)?s.secondSweep:s.sweep;
  for(int c=0;c<W;c++){
   int u=cell(r,c);
   uint32_t bit=uint32_t(1)<<c;
   Marker m=odd?(sweep?Marker::Sweep:Marker::Room):Marker::Open;
   if(p.wall&bit)m=Marker::Wall,t.plannedWalls[u]=true;
   if(p.oneL&bit)m=Marker::LeftOne;
   if(p.oneR&bit)m=Marker::RightOne;
   if(p.twoL&bit)m=Marker::LeftTwo;
   if(p.twoR&bit)m=Marker::RightTwo;
   if(std::find(s.lanes.begin(),s.lanes.end(),c)!=s.lanes.end())m=Marker::Aisle,t.aisleCells[u]=true;
   if(door(m))t.doorCells[u]=true;
   t.cells[u]=m;
  }
 }
 return t;
}
}
inline const Terrain& terrain(int id){
 static const std::array<Terrain,5> all{impl::build(0),impl::build(1),impl::build(2),
                                       impl::build(3),impl::build(4)};
 assert(id>=0&&id<int(all.size()));
 return all[id];
}

struct Components {Ids labels{};int count=0;};
inline Components labels(const Board& wall){
 Components comp;
 comp.labels.fill(-1);
 std::array<int,V> visit{};
 for(int i=0;i<V;i++)if(!wall[i]&&comp.labels[i]<0){
  int count=1;visit[0]=i;comp.labels[i]=comp.count;
  for(int j=0;j<count;j++)for(int p:adjacent(visit[j]))
   if(p>=0&&!wall[p]&&comp.labels[p]<0){comp.labels[p]=comp.count;visit[count++]=p;}
  ++comp.count;
 }
 return comp;
}
inline int majority_group(const Components& c,const std::vector<int>& people){
 if(c.count==0)return -1;
 std::vector<int> populations(c.count);
 for(int p:people)if(p>=0&&p<V&&c.labels[p]>=0)++populations[c.labels[p]];
 return int(std::max_element(populations.begin(),populations.end())-populations.begin());
}

struct Room {int size=0,left=-1,right=-1;};
struct Rooms{
 Ids ids{};                  // paint even excluded last numeric id in legacy sentinel case
 std::vector<Room> rooms;     // valid ID iff 0 <= id < rooms.size()
 Board participates;         // observed actual majority component
 Board projected;            // next walls plus cells outside observed majority, NOT virtual gates
 int majority=-1;
 bool excludedSentinel=false;
 int count()const{return int(rooms.size());}
};
inline Rooms classify(const Terrain& t,const Board& actual,const Board& pending,
                      const std::vector<int>& humans){
 Rooms out;
 const auto act=labels(actual);
 const int major=out.majority=majority_group(act,humans);
 out.projected=actual|pending;
 for(int p=0;p<V;p++){
  if(major>=0&&act.labels[p]==major)out.participates[p]=true;
  else out.projected[p]=true;
 }
 auto split=labels(out.projected|t.doorCells);
 std::vector<uint8_t> excluded(split.count);
 for(int p=0;p<V;p++)if(t.aisle(p)){
  int g=split.labels[p];
  if(g<0)out.excludedSentinel=true;
  else excluded[g]=true;
 }
 std::vector<int> ids(split.count,-1);
 int roomCount=0;
 for(int i=0;i<split.count;i++)if(!excluded[i])ids[i]=roomCount++;
 // Rust's marker-component exclusion includes the sentinel if an aisle
 // marker itself was blocked. Preserve its one-count subtraction. Guard
 // only the undefined/underflow case of no remaining physical component.
 int valid=std::max(0,roomCount-int(out.excludedSentinel));
 out.rooms.resize(valid);
 out.ids.fill(-1);
 for(int p=0;p<V;p++)if(split.labels[p]>=0)out.ids[p]=ids[split.labels[p]];
 for(int p=0;p<V;p++){
  if(t.leftDoor(p)&&p%W+1<W)out.ids[p]=out.ids[p+1];
  else if(t.rightDoor(p)&&p%W>0)out.ids[p]=out.ids[p-1];
 }
 for(int id:out.ids)if(id>=0&&id<valid)++out.rooms[id].size;
 // Reproduce the door-discovery walk on the projected actual terrain,
 // treating door markers as terminal hits and never traversing them.
 Board seen;
 std::vector<int> stack;stack.reserve(V);
 for(int p=0;p<V;p++){
  int id=out.ids[p];
  if(id<0||id>=valid||seen[p]||door(t.cells[p]))continue;
  seen[p]=true;stack.push_back(p);
  while(!stack.empty()){
   int u=stack.back();stack.pop_back();
   for(int q:adjacent(u))if(q>=0&&!seen[q]&&!out.projected[q]){
    if(t.leftDoor(q))out.rooms[id].left=q;
    else if(t.rightDoor(q))out.rooms[id].right=q;
    else {seen[q]=true;stack.push_back(q);}
   }
  }
 }
 return out;
}
}
