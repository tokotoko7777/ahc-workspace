#include "terrain.hpp"
#include <iostream>
#include <map>
#include <numeric>
using namespace terry_exact_maps;
int main(){
 const std::array<uint64_t,5> verified{0x7cb40045a0576fe0ULL,0x2a11f591efc61149ULL,
  0x9933f5fefc22a3b0ULL,0x6c811ad2598eda4fULL,0xdd4236b9246a6810ULL};
 const std::array<int,5> nwall{335,290,260,233,284},ngate{60,90,120,135,96},
 roomCount{53,76,75,75,75},one{46,62,30,15,54},two{7,14,45,60,21},
 shortest{5,4,4,3,4},largest{14,11,8,8,7},snakeLen{192,168,144,128,168};
 for(int k=0;k<5;k++){
  const auto& t=terrain(k);
  uint64_t hash=1469598103934665603ULL;
  for(auto q:t.cells)hash=(hash^static_cast<uint8_t>(q))*1099511628211ULL;
  assert(hash==verified[k]);
  assert(t.plannedWalls.count()==nwall[k]&&t.doorCells.count()==ngate[k]);
  assert(t.aisleRows.size()==15);
  int count=0;
  for(int r=0;r<W;r++){assert(t.constructionRow(r)==(r%4==1));count+=t.constructionRow(r);}
  assert(count==8);
  auto f=t.snake(true),b=t.snake(false);
  assert(f.size()==snakeLen[k]&&b.size()==f.size());
  std::sort(f.begin(),f.end());std::sort(b.begin(),b.end());assert(f==b);
  auto room=classify(t,t.plannedWalls,{}, {t.aisleColumns[0]});
  assert(room.count()==roomCount[k]&&room.participates.count()==V-nwall[k]);
  assert(!room.excludedSentinel&&room.majority==0);
  int n1=0,n2=0,maxSize=0,minSize=V;
  for(int i=0;i<room.count();i++){
   const auto r=room.rooms[i];
   n1+=(r.left>=0)!=(r.right>=0);n2+=r.left>=0&&r.right>=0;
   maxSize=std::max(maxSize,r.size);minSize=std::min(minSize,r.size);
   assert(std::count(room.ids.begin(),room.ids.end(),i)==r.size);
   if(r.left>=0)assert(t.leftDoor(r.left)&&room.ids[r.left]==i);
   if(r.right>=0)assert(t.rightDoor(r.right)&&room.ids[r.right]==i);
  }
  assert(n1==one[k]&&n2==two[k]&&minSize==shortest[k]&&maxSize==largest[k]);
  // With no actual shoulders on the ground the virtual doors alone do
  // not make the completed-stock room catalogue; virtual aisles merge.
  assert(classify(t,{},{},{t.aisleColumns[0]}).count()==0);
  assert(classify(t,{},t.plannedWalls,{t.aisleColumns[0]}).rooms.size()==room.rooms.size());
  // Blocking an aisle marker includes the sentinel in original exclusion.
  Board pending;
  pending[t.aisleColumns[0]]=true;
  auto a=classify(t,t.plannedWalls,pending,{t.aisleColumns[0]});
  assert(a.excludedSentinel&&a.projected[t.aisleColumns[0]]);
 }
 assert(adjacent(0)==(std::array<int,4>{-1,1,30,-1}));
 Board split;
 for(int r=0;r<30;r++)split[cell(r,15)]=true;
 auto c=labels(split);
 assert(c.count==2&&majority_group(c,{16,0})==0&&majority_group(c,{16,17,0})==1);
 std::cout<<"all five detached terrain fingerprints, sizes, sweeps and dynamic classification pass\n";
}
