#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <numeric>

#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC push_options
#pragma GCC optimize ("fp-contract=off")
#endif

namespace terry_exact_selector {

inline constexpr std::array<double,3589> coefficients{
#include "weights.private.inc"
};

template<std::size_t Output, std::size_t Input>
inline auto affine(const std::array<double,Input>& x, std::size_t& pos) {
    std::array<double,Output> y{};
    for (double& yi : y) {
        for (double xi : x) yi += coefficients[pos++] * xi;
    }
    for (double& yi : y) yi += coefficients[pos++];
    return y;
}

inline std::array<double,5> scores(int humans,const std::array<int,5>& counts) {
    const int total = std::accumulate(counts.begin(),counts.end(),0);
    const std::array<double,7> features{
        (humans-5)/5.0, (total-10)/10.0,
        counts[0]/10.0, counts[1]/10.0, counts[2]/10.0,
        counts[3]/10.0, counts[4]/10.0
    };
    std::size_t pos=0;
    auto x=affine<32>(features,pos);
    for (int layer=0;layer<3;++layer) {
        for (double& v:x) v=std::max(v,0.0);
        x=affine<32>(x,pos);
    }
    for (double& v:x) v=std::max(v,0.0);
    auto y=affine<5>(x,pos);
    for (double& v:y) v=1.0/(1.0+std::exp(-v));
    return y;
}

inline int choose(int humans,const std::array<int,5>& counts) {
    auto y=scores(humans,counts);
    return static_cast<int>(std::max_element(y.begin(),y.end())-y.begin());
}

}  // namespace terry_exact_selector

#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC pop_options
#endif
