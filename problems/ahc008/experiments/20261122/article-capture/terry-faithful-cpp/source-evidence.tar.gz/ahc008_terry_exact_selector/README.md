# AHC008: local five-map reference selector

Independent GNU C++23 inference based on the authorized reference attachment.
The reference program is not run or copied. Model weights are read from the
original attachment as local data and are **not** part of this source tree.
Keep the generated `weights.private.inc` and any standalone diagnostic
executable/source carrying its coefficients local. A public/archive copy can
contain this header, importer, and verification script, not the generated
asset. The importer refuses a different attachment; it reads, does not execute.

Input is the number of humans and an array of five counts in cow, pig, rabbit,
dog, cat order. No initial coordinates, seed, or filename enter the choice.
The seven normalized features are `[(M-5)/5, (N-10)/10, counts/10]`. Four
32-unit hidden layers have ReLU; the five outputs use a sigmoid. Each layer
stores row-major double weights followed by its full bias vector. Compute
each dot product in input order, then add bias. Strict increase takes the
first output on a tie. The local C++ header exposes
`terry_exact_selector::choose(M, counts)` and `::scores(M, counts)`.

With the original attachment available in a private directory, run from here:

    python extract.py ../terry-reference-private/*.txt
    g++ -std=c++23 -O3 -Wall -Wextra verify.cpp -o verify
    python verify.py ../terry-reference-private/*.txt ./verify \
        ../ahc008_v24_five_retention/m5-dev30/in ../ahc008_focus_assets/tools/in

The reference verifier has its own Base64 decoder reproducing the original
zero-sextet padding and full-word floor, and a separately written scalar
Python inference. The importer instead uses validated standard Python Base64
and explicit little-endian IEEE binary64; the original padding leaves fewer
than eight extra bytes, so no extra coefficient is introduced.

| Input panel | Cases | Map 0 / 1 / 2 / 3 / 4 |
|---|---:|---:|
| Frozen five-person development | 30 | 0 / 24 / 2 / 0 / 4 |
| Official distributed inputs | 100 | 0 / 19 / 36 / 34 / 11 |

The two panels plus 1,650 synthetic legal count compositions gave 1,780/1,780
matching first choices and zero maximum double score difference. The original
Rust and official tester were not executed. This validates inference and panel
coverage, not performance or overall behavior of any of the five maps.
