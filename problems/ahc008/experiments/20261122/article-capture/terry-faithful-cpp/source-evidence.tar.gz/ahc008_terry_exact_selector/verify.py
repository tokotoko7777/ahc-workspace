"""Audit the selector against a separately implemented reference evaluation."""
import argparse
from collections import Counter
import hashlib
import math
from pathlib import Path
import random
import re
import struct
import subprocess

def unpack_reference_text(path):
    # Reproduce the Rust decoder's zero-pad sextets and final full-word floor.
    # This does not import/call the production extraction path.
    match = re.search(r'const WEIGHT_BASE64[^=]+= b"([A-Za-z0-9+/=]+)"', path.read_text())
    b64 = match[1]
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    decoded = bytearray()
    for i in range(0, len(b64), 4):
        values = [max(0, alphabet.find(v)) for v in b64[i:i+4]]
        chunk = (values[0]<<18) + (values[1]<<12) + (values[2]<<6) + values[3]
        decoded.extend(chunk.to_bytes(3, 'big'))
    words = [x for (x,) in struct.iter_unpack('<d', decoded[:len(decoded)//8*8])]
    assert len(words) == 3589
    return words

def eval_reference(words, features):
    people, *counts = features
    x = [(people - 5) / 5.0, (sum(counts) - 10) / 10.0] + [n / 10.0 for n in counts]
    at = 0
    for inputs, outputs in [(7,32),(32,32),(32,32),(32,32),(32,5)]:
        split = at + inputs*outputs
        y = []
        for j in range(outputs):
            value = 0.0
            for k in range(inputs):
                value += words[at+j*inputs+k] * x[k]
            y.append(value + words[split+j])
        at = split + outputs
        x = [max(v, 0.0) for v in y] if outputs==32 else [1.0/(1.0+math.exp(-v)) for v in y]
    assert at == 3589
    first, best = 0, 0.0
    for i, s in enumerate(x):
        if s > best:
            first, best = i, s
    return first, x

def read_features(directory):
    features = []
    manifest = hashlib.sha256()
    for f in sorted(directory.glob('*.txt')):
        with f.open() as stream:
            n = int(stream.readline())
            species = [0] * 5
            for _ in range(n):
                species[int(stream.readline().split()[2])-1] += 1
            m = int(stream.readline())
        features.append((m, *species))
        manifest.update(f.name.encode() + b'\0' + ','.join(map(str,features[-1])).encode() + b'\n')
    return features, manifest.hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference_txt',type=Path)
    parser.add_argument('binary',type=Path)
    parser.add_argument('inputs',nargs='+',type=Path)
    args=parser.parse_args()
    coefficients = unpack_reference_text(args.reference_txt)
    panels=[read_features(d) for d in args.inputs]
    rng=random.Random(8)
    synthetic=[]
    for m in range(5,11):
        for n in range(10,21):
            for animal in range(5):
                counts=[0]*5
                counts[animal]=n
                synthetic.append((m,*counts))
            for _ in range(20):
                counts=[0]*5
                for i in range(n):
                    counts[rng.randrange(5)] += 1
                synthetic.append((m,*counts))
    suite = [a for panel,_ in panels for a in panel] + synthetic
    results=[]
    output = subprocess.run([str(args.binary.resolve())], input=''.join(' '.join(map(str,a))+'\n' for a in suite),
                            text=True,check=True,capture_output=True).stdout.splitlines()
    assert len(output) == len(suite)
    worst = 0.
    for f, row in zip(suite,output):
        ans, *nums = row.split()
        index, scores = eval_reference(coefficients,f)
        assert index == int(ans),(f,index,ans)
        dist = max(abs(float(x)-y) for x,y in zip(nums,scores,strict=True))
        assert dist <= 2e-15,(f,row,scores)
        worst=max(worst,dist)
        results.append(index)
    start=0
    for d,(panel,key) in zip(args.inputs,panels):
        count = Counter(results[start:start+len(panel)])
        print(f'{d}: {len(panel)} cases selector histogram {[count[i] for i in range(5)]}, feature-list SHA256 {key}')
        start += len(panel)
    print(f'Synthetic {len(synthetic)}, all {len(suite)} matched independent inference; maximum absolute score difference {worst:.3g}')

if __name__ == '__main__':
    main()
