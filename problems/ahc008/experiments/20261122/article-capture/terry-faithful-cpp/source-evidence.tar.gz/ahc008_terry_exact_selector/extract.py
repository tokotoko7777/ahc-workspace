"""Convert the authorized source's opaque model bytes into a private local include."""
import argparse
import base64
import hashlib
import math
import os
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parent
PIN = 'f5cc224431345d53daeb062ca2cd23985fb600543340b549913ef0d3294b8dda'
COUNT = 3589

def source_bytes(path):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != PIN:
        raise ValueError("input is not the verified original attachment")
    match, = re.findall(rb'\bWEIGHT_BASE64:\s*&\[u8\]\s*=\s*b"([A-Za-z0-9+/=]+)";', raw)
    return match

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference_txt', type=Path)
    args = parser.parse_args()
    data = base64.b64decode(source_bytes(args.reference_txt), validate=True)
    if len(data) != 8 * COUNT:
        raise ValueError("unexpected tensor size")
    weights = struct.unpack(f'<{COUNT}d', data)
    if not all(map(math.isfinite, weights)):
        raise ValueError("unexpected nonfinite data")
    out = ROOT / 'weights.private.inc'
    tmp = out.with_suffix('.tmp')
    with os.fdopen(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w') as file:
        print('// Generated private model data: do not publish.', file=file)
        for i in range(0, COUNT, 8):
            print(', '.join(x.hex() for x in weights[i:i+8]) + ',', file=file)
    os.replace(tmp, out)
    print(f'{COUNT} binary64 values in private include; sha256(bytes)={hashlib.sha256(data).hexdigest()}')

if __name__ == '__main__':
    main()
