#include "selector.hpp"
#include <iomanip>
#include <iostream>

int main() {
    int humans;
    std::array<int,5> species{};
    std::cout<<std::setprecision(17);
    while (std::cin>>humans) {
        for (int& n:species) std::cin>>n;
        std::cout<<terry_exact_selector::choose(humans,species);
        for (double x:terry_exact_selector::scores(humans,species)) std::cout<<' '<<x;
        std::cout<<'\n';
    }
}
