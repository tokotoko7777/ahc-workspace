#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cstdlib>
#include <deque>
#include <limits>
#include <string>
#include <tuple>
#include <vector>
namespace exact_build {
constexpr int N=30,V=900,INF=100000000;
using Board=std::array<unsigned char,V>;
struct Layout { std::array<char,V> ascii{}; std::vector<int> aisleRows,aisleCols;};
inline std::array<int,4> nb(int p){return {p>=N?p-N:-1,p%N<N-1?p+1:-1,p+N<V?p+N:-1,p%N?p-1:-1};}
inline int md(int p,int q){return std::abs(p/N-q/N)+std::abs(p%N-q%N);}
inline int direction(int p,int q){auto a=nb(p);return std::find(a.begin(),a.end(),q)-a.begin();}
inline constexpr char Move[]="URDL",Put[]="urdl";
struct BFS{
 std::array<int,V> d,first;
 void run(int src,const Board& blocked){
  d.fill(INF);first.fill(-1);std::array<int,V> q;int s=1;q[0]=src;d[src]=0;
  // The source itself may be a hypothetical final wall; the legacy
  // estimated travel nevertheless permits exiting that starting cell.
  for(int k=0;k<s;++k)for(int z:nb(q[k]))if(z>=0&&!blocked[z]&&d[z]==INF){
   d[z]=d[q[k]]+1;first[z]=k?first[q[k]]:z;q[s++]=z;
  }
 }
};
struct Task{int at;unsigned mask;};
using Queue=std::deque<Task>;
struct Split{std::vector<Queue> q;int makespan=INF;bool right=true;std::vector<int> path;};
inline bool isWallMark(const Layout& l,int p){return p>=0&&p<V&&l.ascii[p]=='X';}
inline int verticalWork(const Layout& l,int p){
 return int(isWallMark(l,p-N))+int(isWallMark(l,p))+int(isWallMark(l,p+N));
}
inline std::vector<int> snake(const Layout& l,bool right){
 std::vector<int> p;
 for(int r:l.aisleRows)if(r>=0&&r<N&&l.ascii[r*N+N-1]=='~'){
  for(int i=0;i<N;++i){
   int c=right?i:N-1-i,v=r*N+c;
   if(verticalWork(l,v))p.push_back(v);
  }
  right=!right;
 }
 return p;
}
inline Queue tasks(const Layout& l,const std::vector<int>& path){
 Queue q;
 if(path.empty())return q;
 std::array<bool,V> owns{};for(int p:path)owns[p]=true;
 auto add=[&](int at){
  if(std::find(l.aisleRows.begin(),l.aisleRows.end(),at/N)==l.aisleRows.end())return;
  unsigned m=0;auto a=nb(at);
  for(int d=0;d<4;++d)if(a[d]>=0&&l.ascii[a[d]]=='X'&&(!(d&1)||owns[a[d]])){
   m|=1u<<d;
   for(auto& old:q){auto b=nb(old.at);for(int e=0;e<4;++e)if(b[e]==a[d])old.mask&=~(1u<<e);}
  }
  if(m)q.push_back({at,m});
 };
 int p=path.front();add(p);
 for(size_t i=1;i<path.size();++i)while(p!=path[i]){
  int t=path[i];int a=p/N,b=p%N;
  if(a!=t/N)a+=a<t/N?1:-1;else b+=b<t%N?1:-1;
  p=a*N+b;add(p);
 }
 return q;
}
inline Split split(const Layout& l,const std::vector<int>& people,bool right){
 Split ret;ret.right=right;ret.path=snake(l,right);
 int M=people.size(),L=ret.path.size();
 ret.q.resize(M);
 if(M<1||M>10||L<M)return ret;
 const auto& p=ret.path;
 std::vector<int> len(L+1),work(L+1);
 for(int j=0;j<L;++j){
  len[j+1]=len[j]+(j?md(p[j-1],p[j]):0);
  work[j+1]=work[j]+verticalWork(l,p[j]);
 }
 struct From{int a=-1,b=-1;bool forward=false;};
 int masks=1<<M,window=2*L/M;
 std::vector<std::vector<int>> dp(masks,std::vector<int>(L+1,INF));
 std::vector<std::vector<From>> prev(masks,std::vector<From>(L+1));
 dp[0][0]=0;
 for(int k=0;k<masks-1;++k)for(int from=0;from<L;++from)if(dp[k][from]<INF)
  for(int to=from+1;to<=std::min(L,from+window);++to)
   for(int j=0;j<M;++j)if(!(k>>j&1)){
    int x=k|1<<j, cost=work[to]-work[from]+len[to]-len[from+1];
    for(bool f:{true,false}){
     int z=std::max(dp[k][from],cost+md(people[j],p[f?from:to-1]));
     if(z<dp[x][to]){dp[x][to]=z;prev[x][to]={k,from,f};}
    }
   }
 ret.makespan=dp.back()[L];
 if(ret.makespan>=INF)return ret;
 for(int k=masks-1,b=L;k;){
  auto x=prev[k][b];int who=std::countr_zero(unsigned(k^x.a));
  std::vector<int> path(p.begin()+x.b,p.begin()+b);
  if(!x.forward)std::reverse(path.begin(),path.end());
  ret.q[who]=tasks(l,path);k=x.a;b=x.b;
 }
 return ret;
}
inline Split initialize(const Layout& l,const std::vector<int>& people){
 auto a=split(l,people,true),b=split(l,people,false);
 return a.makespan<=b.makespan?std::move(a):std::move(b);
}
struct Graph{
 struct E{int to,rev,cap;};
 std::vector<std::vector<E>> a;std::vector<int>d,it;
 explicit Graph(int n):a(n),d(n),it(n){}
 int add(int u,int v){int i=a[u].size();a[u].push_back({v,int(a[v].size()),1});a[v].push_back({u,i,0});return i;}
 int pull(int v,int s){
  if(v==s)return 1;
  for(int& j=it[v];j<(int)a[v].size();++j){
   auto &back=a[v][j];
   int u=back.to;
   if(d[u]<d[v]&&a[u][back.rev].cap&&pull(u,s)){
    ++back.cap;--a[u][back.rev].cap;return 1;
   }
  }
  return 0;
 }
 int flow(int s,int t){
  int f=0;
  while(true){
   std::fill(d.begin(),d.end(),-1);std::vector<int> q{s};d[s]=0;
   for(size_t j=0;j<q.size()&&d[t]<0;++j)for(auto e:a[q[j]])if(e.cap&&d[e.to]<0){
    d[e.to]=d[q[j]]+1;
    if(e.to==t)break;
    q.push_back(e.to);
   }
   if(d[t]<0)return f;
   std::fill(it.begin(),it.end(),0);while(pull(t,s))++f;
  }
 }

};
struct Handoff{std::vector<int> cols;int eta=INF;};
inline Handoff match(const Layout& l,const Board& w,const std::vector<int>& people,
                     const std::vector<Queue>& q){
 const int M=people.size();auto cols=l.aisleCols;
 if(cols.empty()||M==0)return {};
 std::stable_sort(cols.begin(),cols.end(),[](int a,int b){return std::abs(a-N/2)<std::abs(b-N/2);});
 std::vector<int> slots(M);
 for(int i=0;i<M;++i)slots[i]=cols[i%cols.size()];
 Board final=w;for(int p=0;p<V;++p)if(l.ascii[p]=='X')final[p]=1;
 std::vector<std::tuple<int,int,int>> edges;
 for(int i=0;i<M;++i){
  int p=people[i],cost=0;for(auto a:q[i]){cost+=md(p,a.at)+std::popcount(a.mask);p=a.at;}
  if(!q[i].empty())++cost;
  BFS d;d.run(p,final);
  for(int j=0;j<M;++j){
   int near=INF;for(int r=0;r<N;++r)near=std::min(near,d.d[r*N+slots[j]]);
   if(near<INF)edges.emplace_back(cost+near,i,j);
  }
 }
 std::sort(edges.begin(),edges.end());Graph g(2*M+2);
 const int start=2*M,finish=start+1;
 for(int i=0;i<M;++i)g.add(start,i);
 for(int j=0;j<M;++j)g.add(M+j,finish);
 std::vector<std::tuple<int,int,int>> idx;
 int f=0;
 for(size_t i=0;i<edges.size();){
  auto cost=std::get<0>(edges[i]);
  do{
   auto [v,a,b]=edges[i++];idx.emplace_back(a,b,g.add(a,M+b));
  }while(i<edges.size()&&std::get<0>(edges[i])==cost);
  f+=g.flow(start,finish);
  if(f==M){
   Handoff z;z.eta=cost;z.cols.assign(M,-1);
   for(auto [a,b,e]:idx)if(!g.a[a][e].cap)z.cols[a]=slots[b];
   return z;
  }
 }
 return {};
}
struct Turn {
 std::string action;
 std::vector<unsigned char> booked;
 Board walls{},moves{};
 Handoff staffing;
};
struct Crew {
 Layout layout;std::vector<Queue> q; int planned=INF;
 bool init(const Layout& in,const std::vector<int>& h){
  layout=in;auto z=initialize(layout,h);q=std::move(z.q);planned=z.makespan;return planned<INF;
 }
 // A caller's placeable veto mask can hold reserved real cells; existing
 // pets are represented by their actual flat positions.
 Turn act(const Board& wall,const std::vector<int>& h,const std::vector<int>& pet,
          const Board& veto={}){
  int m=h.size();
  Turn z;z.action.assign(m,'.');z.booked.assign(m,0);z.walls=wall;
  if(q.size()!=h.size()||planned>=INF)return z;
  Board occupied=veto;
  for(int p:h)occupied[p]=1;
  for(int p:pet){occupied[p]=1;for(int g:nb(p))if(g>=0)occupied[g]=1;}
  auto workload=q;
  for(int i=0;i<m;++i){
   while(!q[i].empty()){
    auto& a=q[i].front();auto n=nb(a.at);
    for(int d=0;d<4;++d)if(n[d]<0||wall[n[d]])a.mask&=~(1u<<d);
    if(!a.mask){q[i].pop_front();continue;}
    int p=h[i];
    if(p!=a.at){
     BFS path;path.run(p,z.walls);
     if(path.d[a.at]==INF){
      path.run(p,wall);
      if(path.d[a.at]==INF){q[i].pop_front();continue;}
      z.booked[i]=1; // earlier tentative wall cuts this route this turn
     }else{
      int g=path.first[a.at];z.moves[g]=1;occupied[g]=1;
      z.action[i]=Move[direction(p,g)];z.booked[i]=1;
     }
     workload[i]=q[i];break;
    }
    unsigned pending=a.mask;
    for(int d=0;d<4;++d)if(n[d]>=0&&(pending>>d&1)&&z.walls[n[d]])pending&=~(1u<<d);
    z.booked[i]=1;workload[i]=q[i];workload[i].front().mask=pending;
    for(int d=0;d<4;++d)if(pending>>d&1){
     int g=n[d];if(occupied[g]||z.walls[g])continue;
     z.walls[g]=1;occupied[g]=1;z.action[i]=Put[d];
     workload[i].front().mask&=~(1u<<d);
     break;
    }
    break;
   }
   if(q[i].empty())workload[i].clear();
  }
  z.staffing=match(layout,z.walls,h,workload);
  if(z.staffing.eta>0&&z.staffing.eta<INF){
   for(int i=0;i<m;++i)if(!z.booked[i]){
    BFS d;d.run(h[i],z.walls);int goal=-1,dist=INF;
    for(int r=0;r<N;++r){int p=r*N+z.staffing.cols[i];if(d.d[p]<dist){goal=p;dist=d.d[p];}}
    if(dist<=0||dist>=INF)continue;
    int p=d.first[goal];z.moves[p]=1;z.booked[i]=1;z.action[i]=Move[direction(h[i],p)];
   }
  }
  return z;
 }
 // Original-mode semantics are separate from the safer default: do not
 // acknowledge task bits on observation unless the worker processes its stance.
 Turn act_literal(const Board& wall,const std::vector<int>& h,const std::vector<int>& pet,
                  const Board& veto={}){
  int m=h.size();
  Turn z;z.action.assign(m,'.');z.booked.assign(m,0);z.walls=wall;
  if(q.size()!=h.size()||planned>=INF)return z;
  Board occupied=veto;
  for(int p:h)occupied[p]=1;
  for(int p:pet){occupied[p]=1;for(int g:nb(p))if(g>=0)occupied[g]=1;}
  for(int i=0;i<m;++i){
   while(!q[i].empty()){
    auto& a=q[i].front();
    if(!a.mask){q[i].pop_front();continue;}
    const int p=h[i];
    if(p!=a.at){
     BFS path;path.run(p,z.walls);
     if(path.d[a.at]>=INF){q[i].pop_front();continue;}
     int g=path.first[a.at];
     z.moves[g]=occupied[g]=1;z.action[i]=Move[direction(p,g)];z.booked[i]=1;
     break;
    }
    const auto adj=nb(p);
    for(int d=0;d<4;++d)if(a.mask>>d&1){
     int g=adj[d];
     if(g<0){a.mask&=~(1u<<d);continue;}
     if(z.walls[g])a.mask&=~(1u<<d);
     if(!z.walls[g]&&!occupied[g]){
      z.walls[g]=occupied[g]=1;
      z.action[i]=Put[d];
      a.mask&=~(1u<<d);
      break;
     }
    }
    // The original reserves even when every selected bit got cleared
    // by another earlier builder during this same loop.
    z.booked[i]=1;
    break;
   }
  }
  z.staffing=match(layout,z.walls,h,q);
  if(z.staffing.eta>0&&z.staffing.eta<INF){
   for(int i=0;i<m;++i)if(!z.booked[i]){
    BFS d;d.run(h[i],z.walls);int goal=-1,dist=INF;
    for(int r=0;r<N;++r){int p=r*N+z.staffing.cols[i];if(d.d[p]<dist){goal=p;dist=d.d[p];}}
    if(dist<=0||dist>=INF)continue;
    int p=d.first[goal];z.booked[i]=1;z.action[i]=Move[direction(h[i],p)];
    // Unlike the default, relay destination is deliberately absent
    // from z.moves: original phase 3 receives only phase 1 move vetoes.
   }
  }
  return z;
 }

};
}
