#include "exact_build.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <cassert>
#include <iostream>
using namespace exact_build;
constexpr int p(int r,int c){return 30*r+c;}
int main(){
 Layout l;l.ascii.fill('.');l.aisleRows={5,10,15};l.aisleCols={4,14,24};
 l.ascii[p(5,29)]=l.ascii[p(15,29)]='~';
 for(int c:{6,7,8,9}) l.ascii[p(4,c)]=l.ascii[p(16,c)]='X';
 l.ascii[p(9,7)]='X'; // row10 not a construction stem
 auto a=snake(l,true),b=snake(l,false);
 assert(a.front()==p(5,6)&&a.back()==p(15,6));
 assert(b.front()==p(5,9)&&b.back()==p(15,9));
 assert(std::find(a.begin(),a.end(),p(10,7))==a.end());
 Layout edges;edges.ascii.fill('.');edges.aisleRows={0,29};
 edges.ascii[p(0,29)]=edges.ascii[p(29,29)]='~';
 edges.ascii[p(1,0)]=edges.ascii[p(28,0)]=edges.ascii[p(28,29)]='X';
 assert(snake(edges,true)==std::vector<int>({p(0,0),p(29,29),p(29,0)}));
 assert(verticalWork(edges,p(0,0))==1&&verticalWork(edges,p(29,29))==1);
 auto edgeSplit=split(edges,{p(0,0),p(29,28)},true);
 assert(edgeSplit.makespan<INF&&edgeSplit.q.size()==2);
 for(int id=0;id<5;++id){
  const auto& t=terry_exact_maps::terrain(id);
  Layout d;d.aisleRows=t.aisleRows;d.aisleCols=t.aisleColumns;
  for(int p0=0;p0<V;++p0)d.ascii[p0]=char(t.cells[p0]);
  for(bool direction:{false,true})assert(snake(d,direction)==t.snake(direction));
 }
 std::vector<int> h{p(5,6),p(15,6),p(15,8)};
 Crew q;assert(q.init(l,h));assert(q.planned<INF);
 int n=0;for(auto& v:q.q)for(auto r:v)n+=std::popcount(r.mask);
 assert(n>=7);
 Board w{};q.q.assign(3,{});
 q.q[0].push_back({p(5,6),1});
 q.q[0].push_back({p(5,7),1});
 auto r=q.act(w,h,{p(3,6)});
 assert(r.booked[0]&&r.action[0]=='.'&&q.q[0].front().at==p(5,6));
 auto done=q.act(w,h,{p(3,5)});
 assert(done.action[0]=='u'&&q.q[0].front().mask==1);
 w[p(4,6)]=1;auto next=q.act(w,h,{});
 assert(next.action[0]=='R'&&q.q[0].front().at==p(5,7));
 assert(next.staffing.eta>=0&&next.staffing.cols.size()==3);
 Layout one=l;one.aisleCols={4,26};w={};
 auto direct=match(one,w,{p(7,4),p(7,26),p(7,5)},std::vector<Queue>(3));
 assert(direct.eta==1&&direct.cols==std::vector<int>({4,26,4}));
 Crew literal;assert(literal.init(l,h));
 literal.q.assign(3,{});
 literal.q[0].push_back({p(5,7),1}); // wall already observed, actor not at pivot
 Board observed{};observed[p(4,7)]=1;
 auto go=literal.act_literal(observed,h,{});
 assert(go.action[0]=='R'&&literal.q[0].front().mask==1&&go.moves[p(5,7)]);
 auto h2=h;h2[0]=p(5,7);
 auto consume=literal.act_literal(observed,h2,{});
 assert(consume.booked[0]&&consume.action[0]=='.'&&literal.q[0].front().mask==0);
 literal.q.assign(3,{});literal.q[0].push_back({p(5,6),1});
 auto emit=literal.act_literal(Board{},h,{});
 assert(emit.action[0]=='u'&&literal.q[0].front().mask==0);
 // Proposed-wall obstruction causes a different actor's pivot to pop.
 literal.q.assign(3,{});literal.q[0].push_back({p(5,6),1});
 literal.q[1].push_back({p(4,6),1});
 auto overlap=literal.act_literal(Board{},h,{});
 assert(overlap.action[0]=='u'&&literal.q[1].empty());
 // Actor 1 freely handing off: action is present, move veto is not.
 literal.q.assign(3,{});
 auto hand=literal.act_literal(Board{},h,{});
 bool moved=false;
 for(int j=0;j<3;++j)if(hand.action[j]!='.'){
  int d=std::find(Move,Move+4,hand.action[j])-Move;
  assert(d<4&&!hand.moves[nb(h[j])[d]]);
  moved=true;
 }
 assert(moved);
 std::cout<<"two snakes, selected rows, makespan DP, safe FIFO blockage and exact cyclic handoff pass\n";
}
