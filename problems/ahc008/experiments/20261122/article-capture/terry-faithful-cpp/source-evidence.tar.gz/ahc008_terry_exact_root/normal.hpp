#pragma once
#include "idle.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include "../ahc008_terry_exact_hunt/hunt.hpp"
#include <optional>

namespace terry_exact_root {
using namespace terry_exact_motion;
namespace terrain_lib=terry_exact_maps;
namespace hunt=terry_exact_hunt;
inline std::vector<int> pet_cells(const State& s){
 std::vector<int> v;v.reserve(s.pets.size());for(Pet p:s.pets)v.push_back(p.pos);return v;
}
inline std::array<bool,V> bits_to_array(const Mask& s){
 std::array<bool,V> a;for(int p=0;p<V;++p)a[p]=s[p];return a;
}
inline Mask door_articulation(const terrain_lib::Terrain& terrain,const Mask& walls){
 Mask blocked;
 std::array<int16_t,V> entry,lo; entry.fill(-1);
 int16_t tick=0;
 auto dfs=[&](auto&& dfs,int p,int parent)->void{
  lo[p]=entry[p]=tick++;int children=0;
  for(int q:nb[p])if(q>=0&&!walls[q]&&q!=parent){
   if(entry[q]>=0)lo[p]=std::min(lo[p],entry[q]);
   else{
    ++children;dfs(dfs,q,p);lo[p]=std::min(lo[p],lo[q]);
    if(parent>=0&&lo[q]>=entry[p])blocked[p]=true;
   }
  }
  if(parent<0&&children>=2)blocked[p]=true;
 };
 for(int p=0;p<V;++p)if(!walls[p]&&entry[p]<0)dfs(dfs,p,-1);
 // Cleared flags are geometric dead ends based on the config, not only
 // observed ends. At the board edge the original padded '#' stops scans.
 for(int p=0;p<V;++p)if(terrain.doorCells[p]){
  int side=terrain.leftDoor(p)?1:3;
  int q=p;
  while(q>=0&&!terrain.planned(q)&&
        !(side==1?terrain.rightDoor(q):terrain.leftDoor(q)))q=nb[q][side];
  if(q<0||terrain.planned(q))for(int t=p;t!=q;t=nb[t][side])blocked[t]=false;
 }
 return blocked;
}
struct NormalCount{
 int first_hunt_turn=-1,booked_turns=0,build_cmd=0,hunt_rooms=0,hunt_jobs=0,hunt_walls=0,idle_walks=0;
};
struct Normal {
 const terrain_lib::Terrain* terrain;
 exact_build::Crew crew;
 Pcg rng;
 Normal(const terrain_lib::Terrain& layout,const State& state):terrain(&layout),rng(42){
  exact_build::Layout x;
  for(int p=0;p<V;++p)x.ascii[p]=char(layout.cells[p]);
  x.aisleRows=layout.aisleRows;x.aisleCols=layout.aisleColumns;
  crew.init(x,state.people);
 }
 std::string step(const State& s,int turn,NormalCount* counter=nullptr){
  const auto ps=pet_cells(s);
  exact_build::Board actual_array{};
  for(int p=0;p<V;++p)actual_array[p]=s.walls[p];
  auto stage=crew.act_literal(actual_array,s.people,ps);
  Mask builds,moves;
  for(int p=0;p<V;++p){builds[p]=stage.walls[p];moves[p]=stage.moves[p];}
  const int m=s.people.size();
  std::vector<char> action(m,0);
  bool available=false;
  for(int i=0;i<m;++i){
   if(stage.booked[i])action[i]=stage.action[i];
   else available=true;
   if(counter&&build_dir(action[i])>=0)++counter->build_cmd;
  }
  if(available){
   if(counter)++counter->booked_turns;
   auto geometry=terrain_lib::classify(*terrain,s.walls,builds,s.people);
   std::vector<int> alive;
   for(int i=0;i<int(ps.size());++i)if(geometry.participates[ps[i]])alive.push_back(i);
   if(!alive.empty()&&!geometry.rooms.empty()){
    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng);
    std::vector<hunt::Room> rooms;
    rooms.reserve(geometry.count());
    for(int i=0;i<geometry.count();++i){
     const auto& q=geometry.rooms[i];rooms.push_back({q.left,q.right,q.size,freqs[i]});
    }
    const Mask actual=can_place(s);
    const auto legal=bits_to_array(actual);
    hunt::filter_rooms(rooms,geometry.ids,s.people,bits_to_array(builds),
                       bits_to_array(door_articulation(*terrain,builds)));
    std::vector<std::optional<char>> booked(m);
    for(int i=0;i<m;++i)if(action[i])booked[i]=action[i];
    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));
    hunt::emit(s.people,jobs,legal,booked);
    for(int i=0;i<m;++i)if(booked[i])action[i]=*booked[i];
    if(counter){
     for(auto& r:rooms)if(r.area&&r.retention[0])++counter->hunt_rooms;
     counter->hunt_jobs+=jobs.size();
     if(!jobs.empty()&&counter->first_hunt_turn<0)counter->first_hunt_turn=turn;
     for(const auto& j:jobs){
      if(j.left>=0&&build_dir(action[j.a])>=0)++counter->hunt_walls;
      if(j.right>=0&&build_dir(action[j.b])>=0)++counter->hunt_walls;
     }
    }
   }
   const auto before=counter?action:std::vector<char>{};
   idle_phase(s,terrain->aisleColumns,action);
   if(counter)for(int i=0;i<m;++i)if(!before[i]&&move_dir(action[i])>=0)++counter->idle_walks;
  }
  return sanitize(s,action);
 }
};
}
