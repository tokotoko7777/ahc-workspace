"""Flatten the independent C++ code. Output embeds local supplied coefficients, never publish."""
import argparse,re
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('output',type=Path)
a=p.parse_args()
seen=set();included=[]
def fold(file):
 file=file.resolve()
 if file in seen:return ''
 seen.add(file);included.append(file.name)
 contents=[]
 for line in file.read_text().splitlines(keepends=True):
  m=re.fullmatch(r'\s*#include\s*"([^"]+)"\s*',line.rstrip('\n'))
  if m:contents.append(fold(file.parent/m[1]))
  elif line.rstrip()!='#pragma once':contents.append(line)
 return ''.join(contents)+'\n'
a.output.write_text(fold(Path(__file__).with_name('solve.cpp')))
print(' / '.join(included))
