#pragma GCC optimize("O3")
#include "normal.hpp"
#include "../ahc008_terry_exact_partition/chase.hpp"
#include "../ahc008_terry_exact_selector/selector.hpp"
#include "../ahc008_focus_solver/library/max-flow.hpp"
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iostream>

namespace terry_exact_root {
using Clock=std::chrono::steady_clock;
std::string chase(const State& s,const terrain_lib::Terrain& layout,int turn){
 auto a=terry_partition::executeChase<MaxFlow<int>,terry_exact_ties::MinCostFlow<int,int>>(
       s.walls,layout.aisleCells,s.people,pet_cells(s),turn,can_place(s));
 return sanitize(s,std::vector<char>(a.begin(),a.end()));
}
struct Decision{int pairs=0;int64_t normal=0,chase_sum=0;bool chose=false;};
Decision decide(const State& live,Normal& ordinary,int cap,Clock::time_point stop){
 Decision answer;
 const auto targets=terry_partition::majorityPets(live.walls,live.people,pet_cells(live));
 if(targets.empty()||cap==0)return answer;
 for(int i=1;i<=cap&&Clock::now()<stop;++i){
  const uint64_t seed=998244353ULL*i;
  State s=live, t=live;
  auto rng_live=ordinary.rng;
  ordinary.rng=Pcg(42);
  ChaCha a(seed),b(seed);
  bool ok=true;
  for(int turn=275;turn<300;++turn){
   if(Clock::now()>=stop){ok=false;break;}
   people_step(s,ordinary.step(s,turn));actual_motion(s,a);
  }
  ordinary.rng=rng_live;
  if(ok)for(int turn=275;turn<300;++turn){
   if(Clock::now()>=stop){ok=false;break;}
   people_step(t,chase(t,*ordinary.terrain,275));actual_motion(t,b);
  }
  if(!ok)break;
  ++answer.pairs;answer.normal+=score(s);answer.chase_sum+=score(t);
 }
 answer.chose=answer.chase_sum>answer.normal;
 return answer;
}
}

int main(int argc,char** argv){
 using namespace terry_exact_root;
 std::ios::sync_with_stdio(false); std::cin.tie(nullptr);
 const auto started=Clock::now();
 int map=-1,cap=100000,limit_ms=2670;
 for(int i=1;i<argc;++i){
  std::string s=argv[i];
  if(s.starts_with("--map="))map=std::stoi(s.substr(6));
  else if(s.starts_with("--pairs="))cap=std::stoi(s.substr(8));
  else if(s.starts_with("--ms="))limit_ms=std::stoi(s.substr(5));
  else return 2;
 }
 if(map<-1||map>4||cap<0||limit_ms<0||limit_ms>2700)return 2;
 int n,m;
 if(!(std::cin>>n))return 0;
 State s;std::array<int,5> counts{};
 for(int i=0;i<n;++i){
  int r,c,k;std::cin>>r>>c>>k;s.pets.push_back({(r-1)*30+c-1,k,-1});++counts[k-1];
 }
 std::cin>>m;
 for(int i=0;i<m;++i){int r,c;std::cin>>r>>c;s.people.push_back((r-1)*30+c-1);}
 if(map<0)map=terry_exact_selector::choose(m,counts);
 const auto& cfg=terrain_lib::terrain(map);
 Normal policy(cfg,s);
 NormalCount metrics;Decision d;
 const auto stop=started+std::chrono::milliseconds(limit_ms);
 for(int turn=0;turn<300;++turn){
  if(turn==275)d=decide(s,policy,cap,stop);
  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);
  people_step(s,command);
  std::cout<<command<<'\n'<<std::flush;
  for(auto& p:s.pets){
   std::string str;if(!(std::cin>>str))return 0;
   for(char ch:str){int k=move_dir(ch);if(k>=0&&nb[p.pos][k]>=0)p.pos=nb[p.pos][k];}
  }
 }
 if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){
  std::ofstream f(path);
  f<<map<<' '<<cfg.plannedWalls.count()<<' '<<(cfg.plannedWalls&s.walls).count()<<' '
    <<policy.crew.planned<<' '<<metrics.first_hunt_turn<<' '<<metrics.hunt_rooms<<' '
    <<metrics.hunt_jobs<<' '<<metrics.hunt_walls<<' '<<metrics.build_cmd<<' '
    <<metrics.idle_walks<<' '<<d.pairs<<' '<<d.normal<<' '<<d.chase_sum<<' '<<d.chose<<' '<<score(s)<<'\n';
 }
}
