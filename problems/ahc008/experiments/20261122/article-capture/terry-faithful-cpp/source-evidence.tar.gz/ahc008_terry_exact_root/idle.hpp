#pragma once
#include "motion.hpp"
#include "../ahc008_terry_exact_ties/mincost_ties.hpp"

namespace terry_exact_motion {
inline void idle_phase(const State& s,const std::vector<int>& columns,std::vector<char>& action){
 // The reference reserves builders and guard waits. Only candidate fences
 // (not previously proposed human moves) affect this phase's path map.
 Mask w=s.walls;
 const int m=s.people.size(),n=s.pets.size(),source=m+n,sink=source+1;
 for(int i=0;i<m;++i){const auto d=build_dir(action[i]);if(d>=0){
  const int p=nb[s.people[i]][d];if(p>=0)w[p]=true;
 }}
 std::array<Dist,10> dist;
 std::vector<int> to(m,-1);
 for(int i=0;i<m;++i)if(!action[i])bfs(w,s.people[i],dist[i]);
 for(int col:columns){
  terry_exact_ties::MinCostFlow<int,long long> flow(sink+1);
  struct Link{int i,j,e;};std::vector<Link> pairs;
  for(int i=0;i<m;++i)if(!action[i]&&s.people[i]%30==col)
   for(int j=0;j<n;++j)if(int d=dist[i][s.pets[j].pos];d<=30)
    pairs.push_back({i,j,flow.add_edge(i,m+j,1,d)});
  if(pairs.empty())continue;
  for(int i=0;i<m;++i)flow.add_edge(source,i,1,0);
  for(int j=0;j<n;++j)flow.add_edge(m+j,sink,1,0);
  flow.flow(source,sink,m);
  for(Link l:pairs)if(flow.get_edge(l.e).flow)to[l.i]=s.pets[l.j].pos/30;
 }
 for(int i=0;i<m;++i)if(!action[i]){
  const int p=s.people[i],r=p/30;
  int t=to[i];
  if(t<0)t=r>=16?15:r<=13?14:r; // 1-based rows 15–16 are the middle hold
  if(r==t)continue;
  int k=t<r?0:2;int u=nb[p][k];
  if(u>=0&&!w[u])action[i]=k==0?'U':'D';
 }
}
}
