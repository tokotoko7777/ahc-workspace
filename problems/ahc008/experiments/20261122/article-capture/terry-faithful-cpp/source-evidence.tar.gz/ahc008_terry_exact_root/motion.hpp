#pragma once
#include <algorithm>
#include <array>
#include <bitset>
#include <bit>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <random>
#include <string>
#include <string_view>
#include <vector>

namespace terry_exact_motion {
constexpr int N=30, V=N*N, INF=10000;
using Mask=std::bitset<V>;
using Dist=std::array<int16_t,V>;
using Nb=std::array<std::array<int,4>,V>;
constexpr Nb make_neighbors(){
 Nb z{};
 for(int p=0;p<V;++p) z[p]={p>=N?p-N:-1,p%N<N-1?p+1:-1,p<V-N?p+N:-1,p%N?p-1:-1};
 return z;
}
inline constexpr Nb nb=make_neighbors(); // U,R,D,L
inline constexpr std::array<int,4> judge_order{0,2,3,1};
struct Pet{int pos=-1,type=0,target=-1;};
struct State{Mask walls; std::vector<int> people; std::vector<Pet> pets;};
inline void bfs(const Mask& walls,int start,Dist& d){
 d.fill(INF);
 if(start<0||start>=V)return;
 int q[V],e=1; q[0]=start; d[start]=0;
 for(int i=0;i<e;++i){int p=q[i]; const auto distance=int16_t(d[p]+1);
  for(int u:nb[p])if(u>=0&&!walls[u]&&d[u]==INF){d[u]=distance;q[e++]=u;}
 }
}
inline Mask can_place(const State& s) {
 Mask r=~s.walls;
 for(int h:s.people)r[h]=false;
 for(Pet p:s.pets){r[p.pos]=false;for(int x:nb[p.pos])if(x>=0)r[x]=false;}
 return r;
}
inline int move_dir(char c){auto z=std::string_view("URDL").find(c);return z<4?int(z):-1;}
inline int build_dir(char c){auto z=std::string_view("urdl").find(c);return z<4?int(z):-1;}
inline std::string sanitize(const State& s,const std::vector<char>& out){
 std::string cmd(s.people.size(),'.');
 Mask yes=can_place(s);
 for(int i=0;i<int(s.people.size());++i){
  const int d=move_dir(out[i]);
  if(d<0)continue;
  const int p=nb[s.people[i]][d];
  if(p>=0&&!s.walls[p]){cmd[i]=out[i];yes[p]=false;}
 }
 for(int i=0;i<int(s.people.size());++i){
  const int d=build_dir(out[i]);
  if(d<0)continue;
  const int p=nb[s.people[i]][d];
  if(p>=0&&yes[p]){cmd[i]=out[i];yes[p]=false;}
 }
 return cmd;
}
inline void people_step(State& s,std::string_view cmd){
 for(int i=0;i<int(s.people.size());++i){
  const int w=build_dir(cmd[i]),d=move_dir(cmd[i]); const int p=s.people[i];
  if(w>=0)s.walls.set(nb[p][w]);
  if(d>=0)s.people[i]=nb[p][d];
 }
}
inline int score(const State& s){
 std::array<int16_t,V> g;g.fill(-1);
 int sizes[10]{},animals[10]{},cnt=0;
 for(int start:s.people)if(g[start]<0){
  int q[V],n=1;q[0]=start;g[start]=cnt;
  for(int i=0;i<n;++i)for(int p:nb[q[i]])if(p>=0&&!s.walls[p]&&g[p]<0){g[p]=cnt;q[n++]=p;}
  sizes[cnt++]=n;
 }
 for(auto p:s.pets)if(g[p.pos]>=0)++animals[g[p.pos]];
 // Match the specified order of division/pow/multiplication/rounding.
 double v=0.;
 for(int h:s.people){int i=g[h];v+=std::ldexp(double(sizes[i])/900.,-animals[i]);}
 return int(std::round(v*1e8/s.people.size()));
}
struct Pcg {
 using U128=__uint128_t;
 U128 s;
 explicit Pcg(uint64_t seed=42):s(U128(seed)|1){}
 uint64_t operator()(){
  s*=(U128(0x2360ed051fc65da4ULL)<<64)|U128(0x4385df649fccf645ULL);
  return std::rotr(uint64_t(s>>64)^uint64_t(s),int(s>>122));
 }
};
// Independent PCG-seeded ChaCha for local game simulation. See references in README.
struct ChaCha {
 std::array<uint32_t,8> key{};
 std::array<uint32_t,16> block{};
 uint64_t count=0;int cursor=16;
 explicit ChaCha(uint64_t x){
  for(auto& k:key){
   x=x*6364136223846793005ULL+11634580027462260723ULL;
   k=std::rotr(uint32_t(((x>>18)^x)>>27),int(x>>59));
  }
 }
 void refill(){
  std::array<uint32_t,16> initial{0x61707865,0x3320646e,0x79622d32,0x6b206574};
  std::copy(key.begin(),key.end(),initial.begin()+4);
  initial[12]=uint32_t(count);initial[13]=uint32_t(count>>32);++count;
  block=initial;
  auto qr=[&](int a,int b,int c,int d){
   auto& v=block;
   v[a]+=v[b];v[d]=std::rotl(v[d]^v[a],16); v[c]+=v[d];v[b]=std::rotl(v[b]^v[c],12);
   v[a]+=v[b];v[d]=std::rotl(v[d]^v[a],8);  v[c]+=v[d];v[b]=std::rotl(v[b]^v[c],7);
  };
  for(int i=0;i<10;++i){
   qr(0,4,8,12);qr(1,5,9,13);qr(2,6,10,14);qr(3,7,11,15);
   qr(0,5,10,15);qr(1,6,11,12);qr(2,7,8,13);qr(3,4,9,14);
  }
  for(int i=0;i<16;++i)block[i]+=initial[i];
  cursor=0;
 }
 uint32_t next32(){if(cursor==16)refill();return block[cursor++];}
 uint64_t operator()(){uint32_t low=next32();return low|(uint64_t(next32())<<32);}
};
template<class RNG> inline int choose_small(RNG& rng,int n){
 assert(n>0);
 const uint32_t bound=n,zone=(bound<<std::countl_zero(bound))-1;
 while(true){
  uint32_t v;
  if constexpr(requires{rng.next32();})v=rng.next32();
  else v=uint32_t(rng());
  const uint64_t x=uint64_t(v)*bound;
  if(uint32_t(x)<=zone)return int(x>>32);
 }
}
template<class RNG> inline int choose_word(RNG& rng,int n){
 assert(n>0);
 const uint64_t bound=n,zone=(bound<<std::countl_zero(bound))-1;
 while(true){
  __uint128_t x=__uint128_t(rng())*bound;
  if(uint64_t(x)<=zone)return int(x>>64);
 }
}
template<class RNG> inline bool random_step(Pet& p,const Mask& walls,RNG& rng,bool judge=false){
 int avail[4],n=0;
 for(int i=0;i<4;++i){int dir=judge?judge_order[i]:i,q=nb[p.pos][dir];
  if(q>=0&&!walls[q])avail[n++]=q;
 }
 if(n)p.pos=avail[choose_small(rng,n)];
 return n>0;
}
template<class RNG> inline bool directed_step(Pet& p,const Mask& walls,const Dist& d,RNG& rng,bool judge=false){
 int choices[4],n=0;
 for(int i=0;i<4;++i){int dir=judge?judge_order[i]:i,q=nb[p.pos][dir];
  if(q>=0&&!walls[q]&&d[q]<d[p.pos])choices[n++]=q;
 }
 if(n)p.pos=choices[choose_small(rng,n)];
 return n>0;
}
struct HumanDistances {
 const State& s; const Mask& walls;
 std::array<bool,10> ready{};std::array<Dist,10> dist;
 const Dist& at(int i){
  if(!ready[i]){bfs(walls,s.people[i],dist[i]);ready[i]=true;}
  return dist[i];
 }
};
template<class RNG> void model_dog(Pet& p,const State& s,const Mask& walls,HumanDistances& ds,RNG& rng,bool judge){
 int t=p.target, m=int(s.people.size());
 if(t<0||t>=m||ds.at(t)[p.pos]<=0||ds.at(t)[p.pos]>=INF){
  int list[10],n=0;
  for(int i=0;i<m;++i){int d=ds.at(i)[p.pos];if(d>0&&d<INF)list[n++]=i;}
  if(n==0){p.target=-1;random_step(p,walls,rng,judge);return;}
  if(judge)t=list[choose_small(rng,n)];
  else do{t=choose_word(rng,m);}while(ds.at(t)[p.pos]<=0||ds.at(t)[p.pos]>=INF);
 }
 p.target=t; directed_step(p,walls,ds.at(t),rng,judge);
 if(p.pos==s.people[t])p.target=-1;
 random_step(p,walls,rng,judge);
 if(p.pos==s.people[t])p.target=-1;
}
using Retention=std::vector<std::array<int,30>>;
inline Retention retention(const State& s,const Mask& next,const std::array<int,V>& ids,int rooms,
                           const std::vector<int>& alive,Pcg& rng) {
 Retention result(rooms); HumanDistances ds{s,next};
 for(int i:alive){
  const Pet initial=s.pets[i];const int room=ids[initial.pos];
  if(room<0||room>=rooms)continue;
  for(int trial=0;trial<100;++trial){
   Pet p=initial;p.target=-1;
   for(int h=0;h<30;++h){
    result[room][h]+=ids[p.pos]==room;
    if(p.type==4)model_dog(p,s,next,ds,rng,false);
    else for(int k=0;k<(p.type==5?2:p.type);++k)random_step(p,next,rng);
   }
  }
 }
 return result;
}
template<class RNG> void actual_motion(State& s,RNG& rng){
 HumanDistances ds{s,s.walls};
 for(auto& p:s.pets){
  if(p.type==4){model_dog(p,s,s.walls,ds,rng,true);continue;}
  if(p.type!=5){for(int k=0;k<p.type;++k)random_step(p,s.walls,rng,true);continue;}
  Dist d;
  if(p.target>=0&&!s.walls[p.target]&&p.target!=p.pos){
   bfs(s.walls,p.target,d);
   if(d[p.pos]>=INF)p.target=-1;
  }else p.target=-1;
  if(p.target<0){
   bfs(s.walls,p.pos,d);int list[V],n=0;
   for(int j=0;j<V;++j)if(d[j]>0&&d[j]<INF)list[n++]=j;
   if(n==0)continue;
   p.target=list[choose_small(rng,n)];bfs(s.walls,p.target,d);
  }
  directed_step(p,s.walls,d,rng,true);
  if(p.pos==p.target)p.target=-1;
  random_step(p,s.walls,rng,true);
  if(p.pos==p.target)p.target=-1;
 }
}
}
