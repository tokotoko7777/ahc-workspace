#include "idle.hpp"
#include <iostream>
using namespace terry_exact_motion;
int main(){
 {
  State s; s.people={31,0,60}; s.pets={{899,2,-1}};
  std::vector<char> a={'l','D','.'};
  assert(sanitize(s,a)==".D."); // builder points at walk destination
  a={'r','D','.'};
  auto r=sanitize(s,a);assert(r=="rD.");
  people_step(s,r);assert(s.walls[32]&&s.people[1]==30);
  assert(!can_place(s)[899]&&!can_place(s)[898]&&!can_place(s)[869]);
  assert(score(State{{},{0},{{899,1,-1}}})==50000000);
 }
 {
  State s; s.people={0,5,20*30+5}; s.pets={{12*30+5,1,-1}};
  std::vector<char>a={'.',0,0};
  idle_phase(s,{5},a);
  assert(a[0]=='.'&&a[1]=='D'&&a[2]=='U');
 }
 {
  State s; s.people={31}; s.pets={{0,1,-1}};
  Mask next; next.set(); next.reset(0);next.reset(1);next.reset(31);
  std::array<int,V> ids;ids.fill(-1);ids[0]=0;
  Pcg r(42);
  auto x=retention(s,next,ids,1,{0},r);
  assert(x[0][0]==100&&x[0][1]==0&&x[0][3]==0&&x[0][2]>0);
  State t; t.people={1};t.pets={{0,4,-1},{0,5,-1}};
  t.walls=next;t.walls.set(31);
  std::mt19937_64 random(42);
  actual_motion(t,random);
  assert(t.pets[0].pos==0&&t.pets[0].target==-1);
  assert(t.pets[1].pos==0&&t.pets[1].target==-1);
 }
 {
  ChaCha raw(0);raw.key.fill(0);
  assert(raw.next32()==0xade0b876U&&raw.next32()==0x903df1a0U);
 }
 std::cerr<<"motion/retention/idle fixtures passed\n";
}
