# Scoped faithful min-cost tie backend
Header mincost_ties.hpp is an independent C++ implementation for the authorized faithful TERRY reproduction only. Queue priority is smaller distance, then larger vertex ID. Equal relaxations never replace the earlier predecessor. Stop as soon as sink is popped and update only settled vertices, retaining the reference's potential accounting and residual augment order. In particular, an idle single guard with two equal-distance pet rows chooses the greater-ID pet, unlike the existing generic workspace comparator. Keep the original network's edge insertion order when swapping backends. No generic library changes nor copied Rust.
    
    # Wait until exclusive timing slot releases before compiling/running.
    g++ -std=c++23 unit.cpp -o unit && ./unit

Fixture covers the exact aisle tie, a second augmentation that reroutes through the previous equal-cost decision's residual edge, and 1200 brute-force small assignments. No compile/run during the current official timed comparison.
