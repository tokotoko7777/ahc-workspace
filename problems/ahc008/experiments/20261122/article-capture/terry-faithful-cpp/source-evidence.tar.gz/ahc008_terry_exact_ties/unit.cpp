#include "mincost_ties.hpp"
#include <array>
#include <cassert>
#include <functional>
#include <random>
#include <vector>
using M=terry_exact_ties::MinCostFlow<int,long long>;
int main(){
 // Same aisle, two exactly equidistant targets. Higher pet vertex wins.
 {
  M m(5);
  int upper=m.add_edge(0,1,1,2),lower=m.add_edge(0,2,1,2);
  m.add_edge(3,0,1,0);m.add_edge(1,4,1,0);m.add_edge(2,4,1,0);
  assert(m.flow(3,4,1)==std::pair(1,2LL));
  assert(m.get_edge(upper).flow==0&&m.get_edge(lower).flow==1);
 }
 // Force the first tie decision to be revised by a residual augment.
 for(int cap:{1,2}){
  M m(6);
  int first=m.add_edge(0,3,1,2);
  int other=m.add_edge(1,2,1,2),take=m.add_edge(1,3,1,2);
  m.add_edge(4,0,1,0);m.add_edge(4,1,1,0);m.add_edge(2,5,1,0);m.add_edge(3,5,1,0);
  assert(m.flow(4,5,cap)==std::pair(cap,2LL*cap));
  if(cap==1)assert(m.get_edge(take).flow==1&&!m.get_edge(first).flow&&!m.get_edge(other).flow);
  else assert(!m.get_edge(take).flow&&m.get_edge(first).flow==1&&m.get_edge(other).flow==1);
 }
 // Major flow/min cost correctness over arbitrary small sparse assignment
 // instances; tie contract is checked explicitly in the fixtures above.
 std::mt19937 rng(0x0897);
 for(int u=0;u<1200;u++){
  int n=1+rng()%5,s=2*n,t=s+1;
  M m(2*n+2);
  std::vector<std::vector<int>> a(n,std::vector<int>(n));
  for(int i=0;i<n;i++)for(int j=0;j<n;j++){
   int v=int(rng()%9)-1;a[i][j]=v;
   if(v>=0)m.add_edge(i,n+j,1,v);
  }
  for(int i=0;i<n;i++)m.add_edge(s,i,1,0),m.add_edge(n+i,t,1,0);
  std::pair<int,long long> want{-1,0};
  auto dfs=[&](auto&& self,int i,int used,int cnt,long long cost)->void{
   if(i==n){
    if(cnt>want.first||(cnt==want.first&&cost<want.second))want={cnt,cost};
    return;
   }
   self(self,i+1,used,cnt,cost);
   for(int j=0;j<n;j++)if(!(used>>j&1)&&a[i][j]>=0)
    self(self,i+1,used|1<<j,cnt+1,cost+a[i][j]);
  };
  dfs(dfs,0,0,0,0);
  assert(m.flow(s,t,n)==want);
 }
}
