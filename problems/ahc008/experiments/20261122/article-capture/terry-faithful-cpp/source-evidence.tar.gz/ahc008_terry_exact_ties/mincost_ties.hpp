#pragma once
#include <algorithm>
#include <cassert>
#include <limits>
#include <queue>
#include <type_traits>
#include <utility>
#include <vector>

namespace terry_exact_ties {
// Dedicated replay compatibility backend, not a replacement for the generic
// workspace library. Equal-distance queue vertices are taken in DESCENDING
// ID order; the first settled sink ends this shortest-path phase.
template<class Capacity,class Cost>
class MinCostFlow {
 static_assert(std::is_integral_v<Capacity> && std::is_signed_v<Cost>);
 struct Arc {int to,reverse;Capacity cap;Cost fee;};
 struct Index {int origin,idx;};
 struct Entry {Cost distance;int vertex;};
 struct QueueOrder {
  bool operator()(const Entry& a,const Entry& b)const{
   if(a.distance!=b.distance)return a.distance>b.distance;
   return a.vertex<b.vertex;
  }
 };
 std::vector<std::vector<Arc>> g;
 std::vector<Index> edges;
 bool ran=false;
public:
 struct EdgeInfo{int from,to;Capacity capacity,flow;Cost cost;};
 explicit MinCostFlow(int n):g(n){assert(n>=0);}
 int add_edge(int u,int v,Capacity cap,Cost cost){
  assert(!ran&&u>=0&&u<int(g.size())&&v>=0&&v<int(g.size())&&u!=v&&cap>=0&&cost>=0);
  const int a=g[u].size(),b=g[v].size();
  g[u].push_back({v,b,cap,cost});
  g[v].push_back({u,a,0,-cost});
  edges.push_back({u,a});
  return int(edges.size())-1;
 }
 EdgeInfo get_edge(int i)const{
  assert(i>=0&&i<int(edges.size()));
  auto loc=edges[i];
  const auto& e=g[loc.origin][loc.idx];
  const auto moved=g[e.to][e.reverse].cap;
  return {loc.origin,e.to,moved+e.cap,moved,e.fee};
 }
 std::pair<Capacity,Cost> flow(int source,int sink,Capacity limit){
  assert(!ran&&source>=0&&sink>=0&&source<int(g.size())&&sink<int(g.size())&&source!=sink&&limit>=0);
  ran=true;
  const int n=g.size();
  const Cost inf=std::numeric_limits<Cost>::max();
  std::vector<Cost> balance(n),dist(n);
  std::vector<unsigned char> settled(n);
  std::vector<Index> entering(n);
  Capacity sent=0;
  Cost spent=0;
  while(sent<limit){
   std::fill(dist.begin(),dist.end(),inf);
   std::fill(settled.begin(),settled.end(),0);
   std::priority_queue<Entry,std::vector<Entry>,QueueOrder> queue;
   dist[source]=0;
   queue.push({0,source});
   while(!queue.empty()){
    const int u=queue.top().vertex;queue.pop();
    if(settled[u])continue;
    settled[u]=true;
    if(u==sink)break;
    for(int i=0;i<int(g[u].size());i++){
     const auto& a=g[u][i];
     if(!a.cap||settled[a.to])continue;
     const Cost reduced=a.fee+balance[u]-balance[a.to];
     assert(reduced>=0);
     // Preserve predecessor on equal length; avoid huge sentinel arithmetic.
     if(reduced>inf-dist[u])continue;
     const Cost proposed=dist[u]+reduced;
     if(proposed>=dist[a.to])continue;
     dist[a.to]=proposed;
     entering[a.to]={u,i};
     queue.push({proposed,a.to});
    }
   }
   if(!settled[sink])break;
   // Shift only the vertices settled before (or including) the sink.
   // This is equivalent to the original dual convention with sink at 0.
   for(int u=0;u<n;u++)if(settled[u])balance[u]+=dist[u]-dist[sink];
   Capacity amount=limit-sent;
   for(int v=sink;v!=source;){
    const auto at=entering[v];
    amount=std::min(amount,g[at.origin][at.idx].cap);
    v=at.origin;
   }
   for(int v=sink;v!=source;){
    const auto at=entering[v];
    auto& f=g[at.origin][at.idx];
    f.cap-=amount;g[v][f.reverse].cap+=amount;
    v=at.origin;
   }
   sent+=amount;
   spent+=Cost(amount)*(balance[sink]-balance[source]);
  }
  return {sent,spent};
 }
};
}
