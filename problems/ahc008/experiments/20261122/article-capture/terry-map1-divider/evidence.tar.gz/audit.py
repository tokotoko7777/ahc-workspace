"""Static one-X split enumeration plus original map1 captured room tape audit."""
import collections,csv,hashlib,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,cells,flat,flood,markers,near,observed,replay,wave
X,original_doors=markers()[1];walls=X|bitmask(original_doors)
aisles=bitmask(r*30+c for r in range(30) for c in (4,14,24))
def partitions(blocked,query):
    remain=query&~blocked; out=[]
    while remain:
        c=flood(remain&-remain,ALL^blocked)
        out.append(c&query);remain&=~c
    return out
def has_same_aisles(w,trial):
    return partitions(w,aisles)==partitions(trial,aisles)
def make_catalog():
    good={}
    for line in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        m,r,l,h,*cp=map(int,line.split())
        if m!=1 or l<0 or h<0:continue
        body=bitmask(cp); allowed=(ALL^walls); result=[]
        for q in cp:
            new=walls|B[q]
            remains=body&~B[q]
            if not (wave(B[l])&remains and wave(B[h])&remains):continue
            if (wave(B[l])&remains).bit_count()!=1 or (wave(B[h])&remains).bit_count()!=1:continue
            a=flood(wave(B[l])&remains,allowed^B[q]);b=flood(wave(B[h])&remains,allowed^B[q])
            if a&b or a|b!=remains or min(a.bit_count(),b.bit_count())<2:continue
            if not a&~wave(B[l]) or not b&~wave(B[h]):continue
            if not has_same_aisles(walls,new):continue
            if not has_same_aisles(X,X|B[q]):continue
            okay=True
            for g,c,g_other,s in [(l,a,h,b),(h,b,l,a)]:
                split=(new&~B[g_other])
                if flood(s&-s,ALL^split)&aisles==0:okay=False
                if flood(c&-c,ALL^split)!=c:okay=False
                if not has_same_aisles(walls&~B[g_other],split):okay=False
            if okay:result.append((q,a,b))
        assert result
        good[r]=(body,l,h,result)
    return good
def apply(q,catalog):
    f=q['case'];raw=(R/'ahc008_focus_assets/tools/in'/f).read_bytes()
    rp=R/'ahc008_terry_scaffold_audit/tapes'/f
    act=rp.with_suffix('.actions').read_bytes();acts=act.decode().splitlines()
    tr=rp.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==q['input_sha']
    assert hashlib.sha256(act).hexdigest()==q['commands_sha']
    assert replay(raw.decode(),tr,acts,detailed=True)[0]==int(q['score'])
    _,hist,_=observed(raw,tr)
    state=[(list(map(flat,p)),list(map(flat,h)),bitmask(map(flat,w))) for p,h,w in hist]
    trace=[]; trace_seen=set()
    for t in range(275 if q['telemetry'].split()[13]=='1' else 300):
        p,h,w=state[t];_,ah,aw=state[t+1]
        ph=flood(bitmask(h),ALL^w); after=flood(bitmask(ah),ALL^aw)
        for k,(b,l,r,opts) in catalog.items():
            gates=B[l]|B[r]
            if not gates&(aw^w) or gates&~aw:continue
            if k in trace_seen:continue
            if not b&ph or b&after or b&aw:continue
            ids=[i for i,e in enumerate(p) if B[e]&b]
            if not ids or not any(B[p[i]]&ph for i in ids):continue
            assert flood(B[p[ids[0]]],ALL^aw)==b
            pm=bitmask(p); trace_seen.add(k)
            vars_=[]
            for a,x,y in opts:
                left=bool(x&pm);right=bool(y&pm);center=bool(B[a]&pm)
                # All original caught pets remain on an occupied half and
                # both sides' original separate guards would be sufficient.
                # Ignore animal movement from prebuilt divider.
                size=0
                if not center and left!=right:
                    size=(y if left else x).bit_count()+1 # empty half and its unbuilt old gate
                legal=not center and not pm&(wave(B[l])|wave(B[r]))
                # Stock legal closure(s) may be staggered; count all-half
                # legality separately; opening previously placed other gate
                # is synthetic and allowed only for static retained-area hint.
                vars_.append(dict(divider=a,left=x.bit_count(),right=y.bit_count(),
                    both_halves_occupied=left and right,center_occupied=center,gross=size,all_gate_safe=legal))
            trace.append(dict(room=k,turn=t,ids=ids,opts=vars_))
    return dict(case=f,events=trace)
def main():
    cat=make_catalog()
    # Predetermine a balanced divider by fixed column tie, before any tape.
    choice={k:min(opts,key=lambda z:(abs(z[1].bit_count()-z[2].bit_count()),z[0]))
        for k,(_,_,_,opts) in cat.items()}
    out=[apply(q,cat) for q in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open())
         if q['arm']=='terry_independent' and q['telemetry'].split()[0]=='1']
    result=[]
    for k,(body,left,right,opts) in cat.items():
        ev=[e for q in out for e in q['events'] if e['room']==k]
        chose=[next(x for x in e['opts'] if x['divider']==choice[k][0]) for e in ev]
        geomopt=[(q,a.bit_count(),b.bit_count()) for q,a,b in opts]
        result.append(dict(room=k,row=left//30,geometry_options=geomopt,balanced_choice=choice[k][0],
                           events=len(ev),heads=sum(len(e['ids']) for e in ev),
                           both_halves=sum(x['both_halves_occupied'] for x in chose),center=sum(x['center_occupied'] for x in chose),
                           balanced_gross=sum(x['gross'] for x in chose),balanced_legal_gross=sum(x['gross'] for x in chose if x['all_gate_safe']),
                           hindsight_per_event_gross=sum(max(x['gross'] for x in e['opts']) for e in ev)))
    projected=X|bitmask(v[0] for v in choice.values())
    anyopen_same=has_same_aisles(X,projected)
    # A priori geometric guard: retain both original cross-aisle connectors
    # at the midpoint row (=15), independent of any trajectory outcome.
    remaining=[q for q in result if q['row']!=15]
    partial_x=bitmask(choice[q['room']][0] for q in remaining)
    check={kind:has_same_aisles(walls_,walls_|partial_x)
           for kind,walls_ in [('open',X),('all_closed',walls)]}
    # Hindsight summary only: possible reserved row's apparent arithmetic;
    # never choose the row from these values.
    byrow={}
    for row in sorted({q['row'] for q in result}):
        group=[q for q in result if q['row']==row]
        kept=[q for q in result if q['row']!=row]
        byrow[row]={
            'cut_nominal': len(group), 'events':sum(q['events'] for q in group),
            'gross':sum(q['balanced_gross'] for q in group),
            'net_after_reserving_this_row':sum(q['balanced_gross']-len(out) for q in kept)}
    exact_depth={k:sum(z[k] for z in result) for k in ('events','heads','both_halves','center','balanced_gross','balanced_legal_gross','hindsight_per_event_gross')}
    best_sample=sorted([(z['balanced_gross']-len(out),z['room']) for z in result],reverse=True)
    print(json.dumps(dict(cases=len(out),static_rooms=len(cat),combined_open_aisles_same=anyopen_same,total=exact_depth,
     fixed_all_net=exact_depth['balanced_gross']-len(out)*len(result),
     natural_preserve_midrow=dict(check=check,dividers=len(remaining),
        gross=sum(q['balanced_gross'] for q in remaining),
        net=sum(q['balanced_gross']-len(out) for q in remaining)),
     by_row=byrow,
     hindsight_best_subset_net_balanced=sum(max(0,a) for a,_ in best_sample),
     room_summaries=result,cases_detail=out),indent=2))
if __name__=='__main__':main()
