from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
s=(D.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
put('int main(int argc,char** argv){','''
namespace terry_exact_root {
unsigned global_live(const State& s){
 Mask reach;
 for(int p:s.people)if(!reach[p]){
  Dist d;bfs(s.walls,p,d);
  for(int q=0;q<V;++q)if(d[q]<INF)reach.set(q);
 }
 unsigned ids=0;
 for(int i=0;i<int(s.pets.size());++i)if(reach[s.pets[i].pos])ids|=1u<<i;
 return ids;
}
}
int main(int argc,char** argv){''')
put(' int map=-1,cap=100000,limit_ms=2670;',' int map=-1,cap=100000,limit_ms=2670;\n std::string phase;')
put('  else if(s.starts_with("--ms="))limit_ms=std::stoi(s.substr(5));','''
  else if(s.starts_with("--ms="))limit_ms=std::stoi(s.substr(5));
  else if(s.starts_with("--terminal="))phase=s.substr(11);''')
put(' NormalCount metrics;Decision d;',' NormalCount metrics;Decision d;\n unsigned live255=0;')
put('  if(turn==275)d=decide(s,policy,cap,stop);','''
  if(turn==255)live255=global_live(s);
  if(turn==265){
   if(cap!=0)return 2;
   const unsigned now=global_live(s);
   Dist ds;bfs(s.walls,s.people.front(),ds);
   const bool connected=std::all_of(s.people.begin(),s.people.end(),[&](int p){return ds[p]<INF;});
   const bool complete=(cfg.plannedWalls&~s.walls).none();
   const bool eligible=now!=0&&now==live255&&connected&&complete;
   if(phase=="scout"){
    const char* path=std::getenv("AHC008_TERMINAL_K8");if(!path)return 2;
    std::ofstream o(path);
    o<<eligible<<' '<<live255<<' '<<now<<' '<<connected<<' '<<complete<<'\\n';
    return 0;
   }
   if(phase!="early"||!eligible)return 2;
   d.chose=true;
  }''')
(D/'observer.private.cpp').write_text(s)
