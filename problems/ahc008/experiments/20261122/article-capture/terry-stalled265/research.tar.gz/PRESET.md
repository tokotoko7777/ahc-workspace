# Frozen stalled-at-t265 earlier-Chase trajectory contrast
Original unmodified f83 native normal-clock versus Chase on each actual turn t265..299. Same original Normal actions t0..264. First 100 qualifiers among max 2,048 unique official uniform seeds derived from SHA256 first little-endian uint64 namespace ahc008-stalled265-counterfactual-v1:dev:i (separate :fresh-confirm:i reserved strictly unopened). Exact original stock requires global reachable pet ID sets at pre-action t255 and t265 equal and nonempty, all humans in one physical component, and all original planned X installed at pre-action t265. No animal-count, species, worker-count, score or future actions in eligibility. Scout intentionally stops before turn266 (first 265 valid outputs); official zero is sentinel only, not scored. Stop if shortage, no widening. Pin f83 source/binary, tester/gen and predeclare before any generation.

Both official full tester + playback + independent score; exact early command SHA through t264 in both, deterministic true pre-branch state; direct independent replay rechecks equal exact sets + one component + actual chosen planned X complete through each baseline and alternate trace. Original live time-based t275 branch intact on native. Forced Chase planner uses each stock branch's true current actual turn starting 265; no virtual pairs; this is causal trajectory contrast for this isolated conditional100, not isolation of onset alone or proof of a bounded on-the-fly selector.

Gate exact aggregate ≥+0.2%, positive one-sided 95% board-resampled paired score bound (4k fixed seed 880265787), comparable full and useful300 nonlower, total residual nonincrease, zero individually full→nonfull, ≥5 boards with strictly improved exact score. Report strata descriptively only; no tuning or production even if pass. Forced clock runtime omits native decision and cannot certify deployment headroom. Approx exclusive 7–12 minutes assuming prevalence >=10%, perhaps 15–20 minutes near scout cap; native alone ~5 min due to rollout deadlines. No user/headroom claim outside conditional population.

After clearance:
    sha256sum -c SHA256SUMS && sha256sum -c FROZEN.sha256
    python make.py && g++ -std=gnu++23 observer.private.cpp -o observer
    python scout.py
    python native.py
    python early.py
    python assess.py
