"""Read-only measured paired score decomposition; no replay or scoring."""
from collections import defaultdict
from pathlib import Path
import json
P=Path('dev')
manifest=json.loads((P/'manifest.json').read_text())['selected']
load=lambda f:{r['case']:r for r in json.loads((P/f).read_text())}
a,b=load('native.json'),load('early.json')
assert len(a)==len(b)==len(manifest)==100
labels={(1,1):'both_full',(0,1):'new_full',(1,0):'lost_full',(0,0):'both_miss'}
out=defaultdict(lambda:dict(n=0,native_score=0,early_score=0,delta=0))
for r in manifest:
 c=r['case'];u,v=a[c],b[c]
 assert u['prefix_sha']==v['prefix_sha']==r['prefix_sha'] and u['input_sha']==v['input_sha']==r['sha256']
 x=out[labels[u['full'],v['full']]]
 x['n']+=1;x['native_score']+=u['score'];x['early_score']+=v['score'];x['delta']+=v['score']-u['score']
official=json.loads((P/'report.json').read_text())
assert sum(x['delta']for x in out.values())==official['delta']
(P/'score-decomposition.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out))
