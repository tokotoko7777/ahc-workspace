import collections,json,random
from pathlib import Path
P=Path('dev')
sel=json.loads((P/'manifest.json').read_text())['selected']
a,b=({r['case']:r for r in json.loads((P/f).read_text())} for f in ('native.json','early.json'))
assert len(a)==len(b)==len(sel)==100
D=[]; risks=collections.Counter()
keys=('score','full','useful300','final_residual')
met={z:{k:sum(r[k]for r in rows.values())for k in keys}for z,rows in [('native',a),('early',b)]}
strata=collections.defaultdict(collections.Counter)
for r in sel:
 c=r['case'];l=a[c];v=b[c];assert l['prefix_sha']==v['prefix_sha']==r['prefix_sha'] and l['input_sha']==v['input_sha']==r['sha256']
 d=v['score']-l['score'];D.append(d);k=strata[r['eligibility']['ids265'].bit_count()]
 risks['score_win']+=d>0;risks['score_loss']+=d<0;risks['full_to_miss']+=v['full']<l['full']
 risks['changed_actions']+=l['commands_sha']!=v['commands_sha']
 k['n']+=1;k['delta']+=d;k['base_full']+=l['full'];k['candidate_full']+=v['full']
gen=random.Random(880265787)
boot=sorted(sum(D[gen.randrange(100)]for _ in range(100))for _ in range(4000));low=boot[int(.05*(len(boot)-1))]
l=met['native'];v=met['early']
tests=dict(score=500*sum(D)>=l['score'], lower=low>0, wins=risks['score_win']>=5,
    captures=v['full']>=l['full'] and v['useful300']>=l['useful300'] and v['final_residual']<=l['final_residual'] and not risks['full_to_miss'])
res=dict(n=100,metrics=met,delta=sum(D),bootstrap95_one_sided_low=low,risks=dict(risks),t265_target_strata=dict(strata),
    wall={k:max(x['wall']for x in rows.values())for k,rows in [('native',a),('early',b)]},gates=tests,passed=all(tests.values()))
(P/'report.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res))
