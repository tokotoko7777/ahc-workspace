#pragma GCC optimize("O3")
#include "cap_build.hpp"
#include "../ahc008_terry_single_runs/terrain_patch.hpp"
#include <cstdint>
#include <ctime>
#include <iostream>
using namespace exact_build;
constexpr int limit=165;
uint64_t random_next(uint64_t& s){
 uint64_t z=(s+=0x9e3779b97f4a7c15ULL);
 z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;
 z=(z^(z>>27))*0x94d049bb133111ebULL;
 return z^(z>>31);
}
std::vector<int> spawn(int map,int m,int k){
 uint64_t s=0x45fb00bb2f14d307ULL^uint64_t(map*341+m*37+k);
 std::vector<int> out;
 while((int)out.size()<m){
  int p=random_next(s)%V;
  if(std::find(out.begin(),out.end(),p)==out.end())out.push_back(p);
 }
 return out;
}
struct Room{int anchor,gate,stance;std::array<int,3> body;};
std::vector<Room> getrooms(int map){
 std::vector<Room> z;
 for(auto b:terry_single_runs::runs(map))for(int r=b.lo;r<=b.hi;r+=2){
  bool left=b.surviving_side<0;
  int p=r*N+b.col,first=p+!left,g=p+(left?-1:4);
  z.push_back({first,g,g+(left?-1:1),{first,first+1,first+2}});
 }
 return z;
}
int main(int argc,char**argv){
 const std::string mode=argc>1?argv[1]:"";
 const auto cpu=clock();
 int ok=0,n=0,stockTotal=0,addedTotal=0,empty=0;
 std::cout<<"map,staff,repeat,last_wall,all_usable,missing,cap_stock,cap_added,cap_writers,first_room_ready,latest_room_ready,reason\n";
 for(int k=0;k<15;++k)for(int map:{2,3}){
  int m=5+k%6;
  if(!((map==2&&m==5&&(k/6==0||k/6==2))||(map==3&&((m==10&&k/6==1)||((m==5||m==6)&&k/6==2)))))continue;
  ++n;
  const auto h0=spawn(map,m,k/6);
  auto h=h0;
  const auto& terrain=mode=="original"?terry_exact_maps::terrain(map):terry_single_runs::for_solver(map);
  Layout l;l.aisleRows=terrain.aisleRows;l.aisleCols=terrain.aisleColumns;
  for(int p=0;p<V;++p)l.ascii[p]=char(terrain.cells[p]);
  Crew c;if(!c.init(l,h))return 2;
  auto q0=c.q;
  std::vector<single_cap::Cap> caps;
  for(auto a:terry_single_runs::caps(map))caps.push_back({a.tile,a.stance});
  auto extra=mode.empty()?single_cap::attach(c,h,caps):single_cap::Plan{};if(!extra.ok)return 3;
  // The documented original queues are fixed subsequences.
  for(int i=0;i<m;++i){
   auto j=q0[i].begin();
   for(auto a:c.q[i])if(j!=q0[i].end()&&a.at==j->at&&a.mask==j->mask)++j;
   if(j!=q0[i].end())return 4;
  }
  auto capq=c.q;
  bool firstLoss=false, firstPop=false;
  std::cerr<<"CASE "<<map<<" "<<m<<" "<<k/6<<"\n";
  for(auto x:extra.added)std::cerr<<"CAP "<<x.wall<<" "<<x.stance<<" "<<x.owner<<" "<<x.before<<"\n";
  Board w{};
  std::array<int,V> previousOwner;previousOwner.fill(-1);
  int last=-1,complete=-1,numw=0,stock=int(caps.size()-extra.added.size());
  int lost=0,cancel=0,invalid=0,unfinishedCap=0;
  std::vector<int> ready(caps.size(),-1);
  const auto rooms=getrooms(map);
  for(int t=1;t<=limit;++t){
   std::vector<int> writes;
   auto oldq=c.q;
   auto oldw=w;
   auto oldh=h;
   BFS before;before.run(h[0],w);
   auto cmd=c.act_literal(w,h,{}).action;auto v=h;
   if(!firstPop)for(int i=0;i<m;++i){
    const int removed=int(oldq[i].size())-int(c.q[i].size());
    for(int j=0;j<removed;++j){
     auto a=oldq[i][j];auto ad=nb(a.at);
     for(int d=0;d<4;++d)if((a.mask>>d&1)&&ad[d]>=0&&!w[ad[d]]){
      std::cerr<<"FIRST_POP "<<t<<" worker "<<i<<" pivot "<<a.at<<" missed "<<ad[d]
       <<" actor_pos "<<h[i]<<" already_blocked "<<int(w[a.at])
       <<" reachable_before "<<(before.d[a.at]<INF)<<" batch "<<cmd<<"\n";
      firstPop=true;
     }
    }
   }
   Board humans{},moves{};
   for(int p:h)humans[p]=1;
   for(int i=0;i<m;++i)if(cmd[i]>='A'&&cmd[i]<='Z'){
    auto d=std::find(Move,Move+4,cmd[i])-Move;
    if(d>=4||nb(h[i])[d]<0||w[nb(h[i])[d]]){++invalid;continue;}
    v[i]=nb(h[i])[d];moves[v[i]]=1;
   }
   bool changed=false;
   for(int i=0;i<m;++i)if(cmd[i]>='a'&&cmd[i]<='z'){
    auto d=std::find(Put,Put+4,cmd[i])-Put;
    if(d>=4||nb(h[i])[d]<0){++invalid;continue;}
    int p=nb(h[i])[d];
    if(w[p]||moves[p]||humans[p]){++cancel;continue;}
    if(!terrain.plannedWalls[p])++invalid;
    for(auto z:extra.added)if(p==z.wall&&(i!=z.owner||h[i]!=z.stance))++invalid;
    previousOwner[p]=i;w[p]=1;++numw;changed=true;writes.push_back(p);
   }
   h=std::move(v);
   BFS ext;ext.run(h[0],w);
   for(int p:h)if(w[p]||ext.d[p]>=INF)++lost;
   if(changed){
    for(int i=0;i<m;++i)for(auto a:c.q[i])if(a.mask){
     auto q=nb(a.at);bool need=false;
     for(int j=0;j<4;++j)if((a.mask>>j&1)&&q[j]>=0&&!w[q[j]])need=true;
     if(need&&(w[a.at]||ext.d[a.at]>=INF)){
      ++lost;
      if(!firstLoss&&before.d[a.at]<INF&&!oldw[a.at]){
       firstLoss=true;
       std::cerr<<"FIRST_LOSS "<<t<<" worker "<<i<<" pivot "<<a.at<<" now_blocked "<<int(w[a.at])
                <<" command "<<cmd<<" pending";
       for(int j=0;j<4;++j)if((a.mask>>j&1)&&q[j]>=0&&!w[q[j]])std::cerr<<" "<<q[j];
       std::cerr<<" writes";
       for(int p:writes){
        bool cap=false;for(auto x:caps)cap|=x.wall==p;
        std::cerr<<" "<<p<<":"<<previousOwner[p]<<":"<<cap;
       }
       std::cerr<<" before_h";for(int h:oldh)std::cerr<<" "<<h;
       std::cerr<<" after_h";for(int h:h)std::cerr<<" "<<h;
       std::cerr<<"\n";
       for(int p:writes){
        auto tmp=w;tmp[p]=0;BFS check;check.run(h[0],tmp);
        std::cerr<<"UNDO_ONE "<<p<<" reachable "<<(check.d[a.at]<INF)<<"\n";
       }
      }
     }
    }
   }
   bool all=true;
   for(int i=0;i<(int)rooms.size();++i){
    auto a=rooms[i];bool possible=ext.d[a.stance]<INF&&!w[a.gate]&&!w[a.stance];
    for(int p:h){if(p==a.gate||std::find(a.body.begin(),a.body.end(),p)!=a.body.end())possible=false;}
    if(possible){
     Board blocked=w;blocked[a.gate]=1;
     BFS b;b.run(a.anchor,blocked);
     int cells=0;for(int p=0;p<V;++p)cells+=b.d[p]<INF;
     possible=cells==3;
     for(int p:a.body)possible&=!w[p]&&b.d[p]<INF;
    }
    if(possible&&ready[i]<0)ready[i]=t;
    all&=possible;
   }
   if(numw==(int)terrain.plannedWalls.count()&&last<0)last=t;
   if(last>=0&&all){complete=t;break;}
  }
  int min=INF,max=-1,miss=0,writers=0;
  for(int p=0;p<V;++p)if(terrain.plannedWalls[p]&&!w[p]){
   ++miss;
   std::cerr<<"MISSING "<<p;
   for(int i=0;i<m;++i)for(auto a:capq[i]){
    auto q=nb(a.at);
    for(int d=0;d<4;++d)if((a.mask>>d&1)&&q[d]==p)std::cerr<<" owner_stance "<<i<<":"<<a.at;
   }
   for(auto x:caps)if(x.wall==p)std::cerr<<" cap";
   std::cerr<<"\n";
  }
  for(auto a:caps)if(previousOwner[a.wall]<0)++unfinishedCap;else writers|=1<<previousOwner[a.wall];
  for(int x:ready)if(x>=0){min=std::min(min,x);max=std::max(max,x);}
  std::string why=invalid?"invalid":cancel?"cancel":lost?"stranded":miss||unfinishedCap?"missing":complete<0?"room":"ok";
  ok+=why=="ok";stockTotal+=stock;addedTotal+=extra.added.size();empty+=extra.added.empty();
  std::cout<<map<<','<<m<<','<<k/6<<','<<last<<','<<complete<<','<<miss<<','<<stock<<','<<extra.added.size()<<','
   <<std::popcount(unsigned(writers))<<','<<(min==INF?-1:min)<<','<<max<<','<<why<<'\n';
 }
 std::cerr<<"boards "<<n<<" passed "<<ok<<" stock_caps "<<stockTotal<<" added_caps "<<addedTotal
  <<" no_add_cases "<<empty<<" cpu "<<double(clock()-cpu)/CLOCKS_PER_SEC<<" go "<<(n==30&&ok==30)<<'\n';
}
