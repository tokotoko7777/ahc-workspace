#pragma once
#include "../ahc008_terry_single_runs_build/cap_build.hpp"
namespace cap_normalize {
struct MoveTask{int owner,wall,oldPivot,newPivot;};
struct Report{bool ok=true;std::vector<MoveTask> moved;};
inline Report normalize(exact_build::Crew& c,const std::vector<int>& humans,
                        const std::vector<single_cap::Cap>& caps){
 using namespace exact_build;
 Report r;
 auto q=c.q;
 if(q.size()!=humans.size()){r.ok=false;return r;}
 Board cap{},full{},reach{};
 for(auto x:caps)cap[x.wall]=1;
 for(int p=0;p<V;++p)full[p]=c.layout.ascii[p]=='X';
 Board exterior=full;
 for(int p=0;p<V;++p){
  char a=c.layout.ascii[p];
  if(a=='('||a==')'||a=='<'||a=='>')exterior[p]=1;
 }
 for(int col:c.layout.aisleCols)for(int i=0;i<N;++i){
  int p=i*N+col;
  if(exterior[p]||reach[p])continue;
  BFS b;b.run(p,exterior);
  for(int x=0;x<V;++x)if(b.d[x]<INF)reach[x]=1;
 }
 for(int who=0;who<(int)q.size();++who){
  Queue out;int source=humans[who];
  for(int j=0;j<(int)q[who].size();++j){
   const auto a=q[who][j];
   if(!cap[a.at]||!a.mask){out.push_back(a);if(a.mask)source=a.at;continue;}
   int next=-1;
   for(int k=j+1;k<(int)q[who].size();++k)if(q[who][k].mask){next=q[who][k].at;break;}
   const auto z=nb(a.at);
   for(int d=0;d<4;++d)if((a.mask>>d)&1){
    int wall=z[d];
    if(wall<0||!full[wall]){r.ok=false;return r;}
    std::tuple<int,int> best{INF,-1};
    for(int p:nb(wall))if(p>=0&&!exterior[p]&&reach[p]){
     const int cost=md(source,p)+(next<0?0:md(p,next));
     best=std::min(best,std::make_tuple(cost,p));
    }
    auto [cost,p]=best;
    if(p<0){r.ok=false;return r;}
    out.push_back({p,1u<<direction(p,wall)});
    r.moved.push_back({who,wall,a.at,p});source=p;
   }
  }
  q[who]=std::move(out);
 }
 c.q=std::move(q);
 return r;
}
}
