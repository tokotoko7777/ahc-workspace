# Frozen cap-on-pivot normalization architecture

Keep modified maps fixed. Original literal stock split with public synthetic
starts; prior optional cap insertion unchanged and applied after normalization.
Only tasks with selected newly introduced cap X itself as a pivot may change.
Wall task and owner remain exact and same per-owner physical construction bit
order; unrelated task records unchanged. Split affected task by original direction
order. Candidate replacement stance must neighbor the identical target wall, be
unpainted and not a named gate on the final X board, and reach a configured
service aisle with all named gates shut.
Deterministic minimal Manhattan approach + outgoing leg from previous issued
queue stance towards next original nonempty queue stance (current human position if
first); cell ID breaks tie. Fail if none. This removes occupation dependency rather
than tuning placement order. No repeated normalization, wait, or geometry change.

Same exact validator and cutoff (165 turns) as prior frozen dry gate. Every
planned X placed, all writes legal and owned, explicit new cap and relocated
task at assigned stance/owner, no disconnected people or lost unfinished
stance, all converted true 3-cell bodies reachable/unoccupied with named open
mouths and crew access. Stock-split per-owner wall-bit order must be invariant;
optional cap insertion keeps exact normalized task tuples as subsequence.

Panel 30 fresh starts (map2/3 × 15, M5…10 cyclic; new fixed deterministic salt)
plus the five exact previously failed controls, labeled repeat 100–102.
Every 35 must pass, not a development tuning sweep. No official/live.
