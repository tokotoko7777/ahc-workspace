"""Read-only full-X geometry for future cap-on-pivot normalization."""
from pathlib import Path
import re,collections
r=Path(__file__).resolve().parent.parent
s=(r/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
def nb(p):
 x,y=divmod(p,30)
 return [a*30+b for a,b in ((x-1,y),(x,y+1),(x+1,y),(x,y-1)) if 0<=a<30 and 0<=b<30]
def geometry(m):
 lines=s.splitlines()[1:]
 a=lines[2*m].strip()
 cols=list(map(int,re.search(r'\{\s*\{([^}]*)\}',a)[1].split(',')))
 masks=[tuple(int(x,16) for x in re.findall(r'0x([0-9a-f]+)u',q))
        for q in re.findall(r'\{([^{}]+)\}',lines[2*m+1])]
 assert len(masks)==5 and all(len(q)==5 for q in masks)
 w=set();service=set();caps=set();doors=set()
 for x in range(30):
  q=masks[0 if x==0 else 1 if x%2==0 else 3 if x%4==3 else 2]
  for y in range(30):
   if q[0]>>y&1:w.add(x*30+y)
   if any(t>>y&1 for t in q[1:]):doors.add(x*30+y)
   if y in cols:service.add(x*30+y)
 for c,lo,hi in (((9,5,19),(20,11,25)) if m==2 else ((11,5,19),(21,11,25))):
  for x in range(lo,hi+1,2):
   caps.add(x*30+c);doors.remove(x*30+c+(1 if lo==5 else -1))
  for x in range(lo+1,hi,2):w.remove(x*30+c)
 w|=caps
 seen={p for p in service if p not in w|doors};q=collections.deque(seen)
 while q:
  for v in nb(q.popleft()):
   if v not in w|doors and v not in seen:seen.add(v);q.append(v)
 pairs=[]
 for cap in sorted(caps):
  for target in nb(cap):
   if target not in w:continue
   candidates=sorted(p for p in nb(target) if p not in w and p in seen)
   pairs.append((cap,target,candidates))
 return pairs
for m in (2,3):
 pairs=geometry(m)
 print('map',m,'count',len(pairs),'service-available',sum(bool(q) for _,_,q in pairs))
 for row in pairs:print(*row)
