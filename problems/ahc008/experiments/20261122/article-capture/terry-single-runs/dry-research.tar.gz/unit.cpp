#include "cap_build.hpp"
#include <cassert>
#include <iostream>
using namespace exact_build;
constexpr int at(int r,int c){return r*30+c;}
int main(){
 Crew c;
 c.layout.ascii.fill('.');
 c.planned=10;
 std::vector<int> h{at(3,9),at(5,10)};
 c.q.resize(h.size());
 c.q[0]={{at(3,10),2},{at(4,12),1}};
 c.q[1]={{at(5,11),1},{at(5,13),1}};
 const auto preserve=c.q;
 c.layout.ascii[at(3,8)]='X';c.layout.ascii[at(3,11)]='X';
 auto result=single_cap::attach(c,h,{{at(3,8),at(3,9)},{at(3,11),at(3,10)}});
 assert(result.ok&&result.added.size()==1);
 const auto a=result.added.front();
 assert(a.owner==0&&a.before==0&&a.ownerDelta==1&&a.wall==at(3,8));
 assert(c.q[0].front().at==at(3,9)&&c.q[0].front().mask==8);
 for(int j=0;j<2;++j){
  auto tries=c.q[j];if(!j)tries.pop_front();
  assert(tries.size()==preserve[j].size());
  for(int k=0;k<(int)tries.size();++k)assert(tries[k].at==preserve[j][k].at&&tries[k].mask==preserve[j][k].mask);
 }
 auto q=c.q;
 auto bad=single_cap::attach(c,h,{{at(3,8),at(3,10)}});
 assert(!bad.ok&&c.q[0].size()==q[0].size());
 std::cout<<"same-owner queue tuple subsequences and missing-cap-only deterministic insertion passed\n";
}
