# Dry preflight for count-preserving single-mouth run conversion

Build on only the already chosen modified maps 2 and 3. Original stock
literal split is run on the modified map and original synthetic human
positions: it may change relative to unmodified geometry, but is kept
fixed once split. Each explicitly added cap X not already covered by
a stock task receives exactly one extra one-bit task from its supplied
exterior stance. Existing worker task lists remain exact ordered
subsequences, original masks/stances/owners unchanged. Cap ordering is
ascending (cell, stance); choose insertion minimizing (change in
nominal global makespan, change in owner's own nominal Manhattan +
wall-work route, owner index, insertion index), no search or retuning.

Panel: exactly 30 fixed no-pet synthetic starts, both maps crossed with
M=5..10 once (12), then nine more per map using fixed independent spawn
salt and cyclic crew counts (18). Start sampling uses distinct uniform
grid IDs from a local SplitMix64 stream scoped by map, crew count and
replicate, no official input or seed. At most 165 literal turns per case,
no real responses, forecasts, capture commands or official interaction.

Per-case must install every planned actual X (including all caps) and no
other cells. Every original task list stays unaltered in same-owner
subsequence; compare human accessibility (all coherent) and check each
still-needed, previously reachable assigned stance is not lost by a
placed wall. Independent projection using actual human occupancy,
pending moves and all simultaneous walls; no illegal or canceled
proposed builds, cap writer and requested exterior stance exact.
At completion, every new intended room must be an exact declared
three-cell connected body behind its only open mouth, with its exterior
stance reachable by crew, and no human left in the body after handoff.
Room ready counts and first ready times are descriptive; do not claim live
captures. Any failure on the frozen panel means construction gate fails:
do not add wait/catch policy, move the stance or retune.
