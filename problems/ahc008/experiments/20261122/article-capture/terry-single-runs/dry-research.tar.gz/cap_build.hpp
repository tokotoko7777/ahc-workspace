#pragma once
#include "../ahc008_terry_exact_build/exact_build.hpp"
namespace single_cap {
struct Cap{int wall,stance;};
struct Added{int wall,stance,owner,before,nominalDelta,ownerDelta;};
struct Plan{bool ok=true;std::vector<Added> added;};
inline int cost(const exact_build::Queue& q,int p){
 int t=0;
 for(auto x:q)if(x.mask){
  t+=exact_build::md(p,x.at)+std::popcount(x.mask);p=x.at;
 }
 return t;
}
inline Plan attach(exact_build::Crew& crew,const std::vector<int>& h,std::vector<Cap> caps){
 using namespace exact_build;
 Plan log;
 if(h.size()!=crew.q.size()||h.empty()){log.ok=false;return log;}
 auto work=crew.q;
 Board assigned{};
 for(auto& queue:work)for(auto a:queue){
  auto b=nb(a.at);for(int d=0;d<4;++d)if((a.mask>>d&1)&&b[d]>=0)assigned[b[d]]=1;
 }
 std::sort(caps.begin(),caps.end(),[](auto a,auto b){return std::tie(a.wall,a.stance)<std::tie(b.wall,b.stance);});
 for(auto a:caps){
  if(a.wall<0||a.wall>=V||a.stance<0||a.stance>=V||md(a.wall,a.stance)!=1||
    crew.layout.ascii[a.wall]!='X'||crew.layout.ascii[a.stance]=='X'){
   log.ok=false;return log;
  }
  if(assigned[a.wall])continue;
  std::vector<int> c(h.size());int old=0;
  for(int i=0;i<(int)h.size();++i){c[i]=cost(work[i],h[i]);old=std::max(old,c[i]);}
  std::tuple<int,int,int,int> best{INF,INF,0,0};
  const unsigned mask=1u<<direction(a.stance,a.wall);
  for(int i=0;i<(int)h.size();++i)for(int j=0;j<=(int)work[i].size();++j){
   auto q=work[i];q.insert(q.begin()+j,{a.stance,mask});
   int v=cost(q,h[i]),all=v;
   for(int k=0;k<(int)h.size();++k)if(k!=i)all=std::max(all,c[k]);
   best=std::min(best,std::make_tuple(all-old,v-c[i],i,j));
  }
  auto [diff,pers,owner,at]=best;
  work[owner].insert(work[owner].begin()+at,{a.stance,mask});
  assigned[a.wall]=1;log.added.push_back({a.wall,a.stance,owner,at,diff,pers});
 }
 crew.q=std::move(work);
 return log;
}
}
