import collections,csv,json,sys
from fractions import Fraction
p=list(csv.DictReader(open(sys.argv[1])))
assert len(p)==200
pairs=collections.defaultdict(dict)
for x in p:pairs[x['case']][x['arm']]=x
assert len(pairs)==100 and all(len(x)==2 for x in pairs.values())
common=[]
cohorts=collections.defaultdict(list)
changes=[]
for case,z in sorted(pairs.items()):
    a,b=(z[k] for k in ('v25','terry_independent'))
    aa,bb=(list(map(int,x['telemetry'].split())) for x in (a,b))
    assert len(aa)==len(bb)==15 and a['input_sha']==b['input_sha'] and aa[0]==bb[0]
    g=aa[0]
    if g in (2,3):
        assert aa[1]+2==bb[1]
        if a['full']==b['full']=='1':
            common.append(Fraction(b['mean_human_area'])-Fraction(a['mean_human_area']))
    else:assert aa[1]==bb[1]
    if a['commands_sha']!=b['commands_sha'] or a['score']!=b['score']:
        changes.append(dict(case=case,map=g,full=[int(x['full'])for x in (a,b)],
                            score=[int(x['score']) for x in (a,b)],cut=[aa[13],bb[13]]))
    captures=lambda x:dict((k,(t,s,c)) for t,k,s,c in (map(int,q.split(':')) for q in x['captures'].split(';') if q))
    cohorts[g].append((a,b,aa,bb,captures(a),captures(b)))
allr=[x for xs in cohorts.values() for x in xs]
def summary(rows):
    ds={}
    for k in ('full','useful300','score','final_residual'):
        ds[k]=[sum(int(x[i][k]) for x in rows) for i in (0,1)]
    ds['full_wins']=sum(int(x[1]['full'])>int(x[0]['full'])for x in rows)
    ds['full_losses']=sum(int(x[1]['full'])<int(x[0]['full'])for x in rows)
    ds['built_plan']=[sum(x[i][2] for x in rows) for i in (2,3)]
    ds['chase_pairs']=[sum(x[i][10] for x in rows) for i in (2,3)]
    ds['max_wall']=[max(float(x[i]['wall']) for x in rows) for i in (0,1)]
    ds['n']=len(rows)
    ds['capture_changes_by_type']={
        str(k):[sum(v[1]==k and j not in x[5] for x in rows for j,v in x[4].items()),
                sum(v[1]==k and j not in x[4] for x in rows for j,v in x[5].items()),
                sum(v[1]==k and j in x[5] and x[5][j][0]<v[0] for x in rows for j,v in x[4].items()),
                sum(v[1]==k and j in x[5] and x[5][j][0]>v[0] for x in rows for j,v in x[4].items())] for k in range(1,6)}
    return ds
agg=summary(allr)
gain=(agg['score'][1]-agg['score'][0])/agg['score'][0]
floor=float(sum(common)/len(common)) if common else 0
gate=(max(agg['max_wall'])<2.95 and agg['full'][1]>=agg['full'][0] and agg['useful300'][1]>=agg['useful300'][0]
       and gain>=.0015 and floor>=3)
print(json.dumps(dict(total=agg,map={k:summary(v)for k,v in cohorts.items()},
    same_eligible_full=len(common),mean_gain_floor=floor,relative_gain=gain,gate=gate,changes=changes),indent=2))
