#!/usr/bin/env bash
set -euxo pipefail
D=ahc008_terry_single_runs
P=ahc008_focus_solver/problems/ahc008
B=ahc008_terry_split_bound/solve
T=ahc008_focus_assets/tools/target/release/tester
export PYTHONPATH="$PWD/ahc008_integrated_v11:$PWD/$P/experiments/20261122:$PWD/$P:$PWD/ahc008_bridge_audit"
test -f "$D/no-pet-PASS"
python "$D/prepare_live.py" dev100
g++ -std=gnu++23 "$D/solve.private.cpp" -o "$D/solve"
python ahc008_terry_exact_root/bench.py "$P" "$T" "$B" "$D/solve" "$D/dev100/in" "$D/dev100/pilot.csv" --n 100 >"$D/dev100/pilot.log" 2>&1
python "$D/analyze_live.py" "$D/dev100/pilot.csv" >"$D/dev100/summary.json"
