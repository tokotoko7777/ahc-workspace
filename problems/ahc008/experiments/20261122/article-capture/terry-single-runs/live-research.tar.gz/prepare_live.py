"""Freeze draft distinct tosses before geometry execution; generate only by explicit request."""
import hashlib
from pathlib import Path
import subprocess
import sys
p=Path(__file__).resolve().parent
pans=('dev100','held100')
for pan in pans:
    d=p/pan
    d.mkdir(exist_ok=True)
    raw=''.join('%d\n'%int.from_bytes(hashlib.sha256(f'ahc008/20261123/single-runs-v1/{pan}/{i}'.encode()).digest()[:8],'little') for i in range(100))
    seed=d/'seeds.txt'
    if seed.exists():assert seed.read_text()==raw
    else:seed.write_text(raw)
    print(pan, hashlib.sha256(raw.encode()).hexdigest())
    if sys.argv[1:]==[pan]:
        assets=p.parent/'ahc008_focus_assets/tools/target/release/gen'
        subprocess.run([str(assets),str(seed)],cwd=d,check=True)
        cases=sorted((d/'in').glob('*.txt'))
        assert len(cases)==100
        content=''.join(f'{hashlib.sha256(f.read_bytes()).hexdigest()}  in/{f.name}\n' for f in cases)
        f=d/'SHA256SUMS'
        if f.exists():assert f.read_text()==content
        else:f.write_text(content)
