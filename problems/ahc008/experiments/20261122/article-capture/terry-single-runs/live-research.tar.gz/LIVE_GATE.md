# Native pilot gate for the fixed count-preserving one-mouth runs
Do not compile live or generate a scored case until all planned walls
(including the eight ordinarily unswept caps on each edited map), room
labels, exact roles and constructor reach pass the no-pet dry admission.
Use just the verified fixed map-body/gate patch and the strictly necessary
new cap-job assignment. Leave original selector, policy, set-packing,
short forecasts, directed movement, Chase and late-clock cap unchanged.
Other maps are unchanged. The source baseline is the adopted split-bound
standalone; validate exact baseline and version SHAs. No outcomes tune
body placements, gate polarity, ownership or tie behavior.

Fresh unfiltered official-gen 100 dev, alternate serial execution order
or consistent paired serial same machine. Same 2670ms, no forced rollout
counts. Score official plus official playback and independent replay
for each arm. Freeze before generation: both capture indicators no worse
(count raw full, useful full ≥300 area), aggregate score at least +0.15%,
common affected full cases gain ≥3.0 mean worker floor tiles on average,
max local tester wall <2.95s; unchanged maps' early output should match
when no clock-driven variant choice. Otherwise no live verification on
reserve practice or tune from cases. Report separately planned/actual
wall work, count exact completed caps if exposed, species first-capture
timing/late misses, +2 nominal setup and area versus reachable-pet
penalty. Same final score alone is not an adoption criterion.

Only a passing dev run permits frozen independent reserve 100, and only
both passing same gates permits official distributed100; use predeclared
seed lists. Do not claim historical rank from any of these.
