"""Floor vs reachable-pet penalty from equal 100-case verified score/area rows."""
from collections import defaultdict
import csv
import json
import sys
z=defaultdict(dict)
for r in csv.DictReader(open(sys.argv[1])):
    z[r['case']][r['arm']]=r
assert len(z)==100
def x(r):
    return float(r['mean_human_area']),900*int(r['score'])/1e8
s=defaultdict(list)
for k,a in sorted(z.items()):
    w,q=a['v25'],a['terry_independent']
    m=int(w['telemetry'].split()[0])
    assert m==int(q['telemetry'].split()[0])
    aa,aw=x(w); ba,bw=x(q)
    if int(w['full']):assert abs(aa-aw)<=.000005
    if int(q['full']):assert abs(ba-bw)<=.000005
    s[m].append(dict(case=k,delta_mean_area=ba-aa,delta_penalty=(ba-bw)-(aa-aw),
        score=[int(w['score']),int(q['score'])],
        full=[int(w['full']),int(q['full'])],
        effective_mean=[aw,bw]))
def sample(rows):
    return {k:sum(r[k] for r in rows)for k in ('delta_mean_area','delta_penalty')}|{'n':len(rows),
         'full_lost':[r for r in rows if r['full']==[1,0]],
         'full_gained':[r for r in rows if r['full']==[0,1]]}
print(json.dumps({'total':sample([r for v in s.values() for r in v]),'map':{m:sample(v)for m,v in s.items()}},indent=2))
