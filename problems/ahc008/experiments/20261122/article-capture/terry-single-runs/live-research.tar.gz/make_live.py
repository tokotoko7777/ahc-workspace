"""Build private standalone only if frozen geometry and explicit cap dry pass."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
assert (d/'no-pet-PASS').is_file(), 'require explicit certified dry result'
s=(d.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
def body(path):
    return '\n'.join(line for line in path.read_text().splitlines()
                     if line!='#pragma once' and not line.startswith('#include'))
p=s.index('namespace terry_exact_root {')
h='\n'.join(body(pth) for pth in (d/'terrain_patch.hpp',
       d.parent/'ahc008_terry_single_runs_build/cap_build.hpp',
       d.parent/'ahc008_terry_single_runs_normalize/normalize.hpp'))
s=s[:p]+h+'\n'+s[p:]
old=''' const auto& cfg=terrain_lib::terrain(map);
 Normal policy(cfg,s);'''
new=''' const auto* selected=&terry_single_runs::for_solver(map);
 Normal policy(*selected,s);
 if(terry_single_runs::edited(map)){
  std::vector<single_cap::Cap> jobs;
  for(auto e:terry_single_runs::caps(map))jobs.push_back({e.tile,e.stance});
  const auto reloc=cap_normalize::normalize(policy.crew,s.people,jobs);
  const bool capOK=reloc.ok && single_cap::attach(policy.crew,s.people,std::move(jobs)).ok;
  if(!capOK){
   selected=&terrain_lib::terrain(map);
   policy=Normal(*selected,s);
  }
 }
 const auto& cfg=*selected;'''
assert s.count(old)==1
(d/'solve.private.cpp').write_text(s.replace(old,new))
