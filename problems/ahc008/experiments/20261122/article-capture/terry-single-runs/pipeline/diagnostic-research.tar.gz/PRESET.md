# Signed width3 pilot diagnosis
Adapted exact materializer only for this completed dev100 source+ledger
hashes, all and only map2/3 (77 pairs). Late clock cap replaced by
original finite completed pair counts; full signed actions, score,
telemetry and independent official playback are hard identity gates.
First mismatching arm stops, no aggregate from partial data.
Inspect pre-action t75/100/160 named-target readiness and actual cap
counts; shell readiness only for each own physical body and open gates,
actual reachable occupancy, legality separately. Compare actual
same-common-3-cell entries (not counterfactual pet motion).
Compute exact terminal mean floor, built planned X, other walls, pet-only,
empty and worker split plus actual reachable-pet tax, including nonfull
boards. Summarize all77 and separately the descriptive70 common full.
No selection, tuning, candidate edit or live rescue.
