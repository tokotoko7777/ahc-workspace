"""Exact physical readiness and area decomposition from the signed pilot only."""
import collections as C
import json
import math
from pathlib import Path
import sys
from materialize import A,D,R,sha,chosen
from guarded_entry_trace import observed,STEPS
from stochastic_lock_audit import ALL,B,idx,wave,flood,cells
from benchmark import replay
sys.path.insert(0,str(A))
from audit import MENUS,maps,rooms,strip,mask

MILESTONES=(75,100,160)
ARMS=('v25','terry_independent')
FIELDS=('built_X','other_walls','pet_only_floor','empty_floor','human_split',
        'physical_mean','pet_penalty','effective')
def geometry(m,arm):
    w,d,aisle=maps()[m]; rs=rooms()[m]; targets={}
    new=arm=='terry_independent'
    for c,lo,hi,side in MENUS[m]:
        end=c+3 if side==-1 else c
        for t in range(lo,hi+1,2):
            body=strip(t,c)
            rid=next(i for i,r in rs.items() if r['body']==body)
            room=rs[rid].copy();g=room['gates']
            assert len(g)==2
            cap=t*30+end
            shared=body&~B[cap]
            targets[rid]=dict(cap=cap,common=shared,surviving=g[0 if side==-1 else 1],
                              opposite=g[1 if side==-1 else 0])
            if new:
                w|=B[cap];d&=~B[targets[rid]['opposite']]
                room['body']=shared;room['gates']=(targets[rid]['surviving'],);rs[rid]=room
        if new:
            for t in range(lo+1,hi,2):
                assert w&B[t*30+end];w^=B[t*30+end]
    assert w.bit_count()==maps()[m][0].bit_count()+2*new
    assert len(targets)==16 and len(rs)==75
    for r in rs.values():
        r['gate_mask']=mask(r['gates'])
        r['support']=wave(r['body'])&~(r['body']|r['gate_mask'])
    return w,rs,targets

def snapshot(p,h,w,planned):
    opens=ALL^w; comps=[]; weighted=0; contribution=0
    for head in h:
        body=next((q for q in comps if q&B[head]),None)
        if body is None:
            body=flood(B[head],opens);comps.append(body)
        count=sum(bool(body&B[x]) for x in p)
        n=body.bit_count()
        weighted+=n
        contribution+=math.ldexp(n,-count)
    u=0
    for q in comps:u|=q
    pet_only=flood(mask(p)&~u,opens&~u);empty=opens&~(u|pet_only)
    nom=(w&planned).bit_count();extra=(w&~planned).bit_count()
    mean=weighted/len(h);e=contribution/len(h);split=u.bit_count()-mean
    assert abs(900-sum((nom,extra,pet_only.bit_count(),empty.bit_count(),split,mean)))<1e-7
    return dict(zip(FIELDS,(nom,extra,pet_only.bit_count(),empty.bit_count(),split,mean,mean-e,e)))

def walk(p,cmd):
    r,c=STEPS[cmd];return p+30*r+c

def ready(r,wall):
    gates=r['gate_mask'];body=r['body']
    if wall&(gates|body) or wall&r['support']!=r['support']:return False
    return flood(body&-body,ALL&~(wall|gates))==body

def counts(g,history,tr,arm):
    planned,rs,targets=g
    new=arm=='terry_independent'
    state=[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w))) for p,h,w in history]
    milestones={}; window=[C.Counter() for _ in MILESTONES]
    for t in MILESTONES:
        pp,hh,w=state[t]; hm=mask(hh); animal=mask(pp);reach=flood(hm,ALL^w)
        active=animal&reach
        q=C.Counter(installed_planned_X=(w&planned).bit_count())
        for rid,r in rs.items():
            is_target=rid in targets; name='target' if is_target else 'unchanged'
            b=r['body'];gas=r['gate_mask']
            opened=not bool(w&gas)
            shell=w&r['support']==r['support']
            if is_target and new:
                cap=targets[rid]['cap']
                cnt=int(bool(w&B[cap]))
                q['caps_installed']+=cnt
                q['caps_unswept' if cap//30%4==3 else 'caps_swept']+=cnt
            q[f'{name}_mouths_open']+=opened
            q[f'{name}_shell_ready']+=shell
            q[f'{name}_shell_ready_mouth_open']+=shell and opened
            if opened and not shell:
                q[f'{name}_incomplete_open']+=1
                if is_target and new and r['support']&~w==B[targets[rid]['cap']]:
                    q['target_missing_cap_only']+=1
            if ready(r,w) and b&reach:
                q[f'{name}_usable']+=1
                if active&b:q[f'{name}_occupied_usable']+=1
                if active&b and not hm&b and not (animal|wave(animal)|hm)&gas:
                    q[f'{name}_legal_occupied']+=1
            elif active&b:
                q[f'{name}_occupied_incomplete_or_closed']+=1
            if is_target:
                q['target_common_heads_now']+=sum(bool(B[p]&targets[rid]['common']&reach) for p in pp)
        milestones[str(t)]=dict(q)
    # Count same-footprint entries in independent actual stock/candidate
    # trajectories and classify by exact live local shell, no imagined ingress.
    common={p:rid for rid,v in targets.items() for p in cells(v['common'])}
    uniq=[set() for _ in MILESTONES]
    for t in range(MILESTONES[-1]):
        band=next(i for i,v in enumerate(MILESTONES) if t<v)
        pets,_,_=state[t]
        _,hum1,w1=state[t+1]
        reach=flood(mask(hum1),ALL^w1)
        q=window[band]
        for i,(p,reply) in enumerate(zip(pets,tr[2*t+1].split())):
            for d in reply:
                if d=='.':continue
                at=walk(p,d);rid=common.get(at)
                if rid is not None and common.get(p)!=rid and reach&B[at]:
                    marker=targets[rid]
                    q['same_common_entries']+=1;uniq[band].add(i)
                    q['same_common_shell_ready']+=ready(rs[rid],w1)
                    q['same_common_incomplete_or_closed']+=not ready(rs[rid],w1)
                    q['from_surviving_gate']+=p==marker['surviving']
                    q['from_original_opposite_gate']+=p==marker['opposite']
                    if p==marker['cap']:q['from_original_cap_cell']+=1
                p=at
            assert p==state[t+1][0][i]
    for q,i in zip(window,uniq):q['unique_heads_entered_common']=len(i)
    return milestones,[dict(q) for q in window],snapshot(*state[-1],planned)

def summarize(pairs):
    s={a:dict(n=len(pairs),areas=C.Counter(),milestones={str(t):C.Counter() for t in MILESTONES},
              windows=[C.Counter() for _ in MILESTONES]) for a in ARMS}
    for row in pairs:
        for a in ARMS:
            one=row[a]; q=s[a]
            q['areas'].update(one['final'])
            for t,v in one['milestones'].items():q['milestones'][t].update(v)
            for b,v in zip(q['windows'],one['windows']):b.update(v)
    return s
def main():
    expected={(q['case'],q['arm']):q for q in chosen()}
    manifest=json.loads((D/'materialized/manifest.json').read_text())
    assert len(manifest)==154
    rows=C.defaultdict(dict)
    for x in manifest:
        nm=x['case'];arm=x['arm'];r=expected.pop((nm,arm));tag=f'{Path(nm).stem}.{arm}'
        initial=(A/'dev100/in'/nm).read_bytes()
        acts=(D/'materialized'/(tag+'.actions')).read_bytes()
        tape=(D/'materialized'/(tag+'.trace')).read_bytes()
        assert sha(initial)==x['input_sha']==r['input_sha'] and sha(acts)==x['actions_sha']==r['commands_sha']
        assert sha(tape)==x['trace_sha'] and x['score']==int(r['score']) and x['telemetry']==list(map(int,r['telemetry'].split()))
        trace=tape.decode().splitlines()
        assert trace[::2]==acts.decode().splitlines() and len(trace)==600
        assert replay(initial.decode(),trace,acts.decode().splitlines(),detailed=True)[0]==x['score']
        _,history,_=observed(initial,trace)
        mid,win,z=counts(geometry(x['map'],arm),history,trace,arm)
        assert abs(z['physical_mean']-float(r['mean_human_area']))<1e-8
        assert abs(z['effective']*1e8/900-int(r['score']))<0.501
        rows[nm][arm]=dict(map=x['map'],full=bool(int(r['full'])),milestones=mid,windows=win,final=z)
    assert not expected and len(rows)==77 and all(len(q)==2 for q in rows.values())
    common=[q for q in rows.values() if all(v['full'] for v in q.values())]
    assert len(common)==70
    print(json.dumps(dict(bands=['0..74','75..99','100..159'],all=summarize(list(rows.values())),
        common_full=summarize(common),by_map={m:summarize([q for q in rows.values() if q['v25']['map']==m]) for m in (2,3)},rows=rows),indent=2))
if __name__=='__main__':main()
