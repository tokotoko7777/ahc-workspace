"""Reconstruct exact pilot tapes at recorded finite paired-rollout caps."""
import argparse
import csv
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

D=Path(__file__).resolve().parent
A=D.parent
R=A.parent
P=A/'dev100/pilot.csv'
P_SHA='9914ad040edec100dea804bf88d82a209f378073ad90cd9b794d123e2bbf9999'
MODELS={
  'v25':(R/'ahc008_terry_split_bound/solve.private.cpp',
          'f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'),
  'terry_independent':(A/'solve.private.cpp',
          'dcb5f9ca63e2cba0afa95ac654a31342279f1d243bb1659d75f81e9ed12ff7b5'),
}
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(R/'ahc008_integrated_v11'),str(H/'experiments/20261122'),
             str(H),str(R/'ahc008_bridge_audit')]
from benchmark_cases import run
from benchmark import replay

def sha(raw):return hashlib.sha256(raw).hexdigest()

def chosen():
    assert sha(P.read_bytes())==P_SHA
    with P.open(newline='') as fp:r=list(csv.DictReader(fp))
    assert len(r)==200 and len({(a['case'],a['arm']) for a in r})==200
    keep={a['case'] for a in r if int(a['telemetry'].split()[0]) in (2,3)}
    x=[a for a in r if a['case'] in keep]
    assert len(keep)==77 and len(x)==154
    for name in keep:
        rr=[a for a in x if a['case']==name]
        assert {a['arm'] for a in rr}==set(MODELS)
        assert len({a['telemetry'].split()[0] for a in rr})==1
    return x

def main():
    p=argparse.ArgumentParser()
    p.add_argument('tester',type=Path)
    p.add_argument('--execute',action='store_true')
    p.add_argument('--output',type=Path,default=D/'materialized')
    z=p.parse_args()
    assert z.execute, 'only run --execute after exclusive timing clearance'
    tester=z.tester.resolve()
    opts=chosen()
    out=z.output.resolve();out.mkdir(exist_ok=False)
    manifests=[]
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        binaries={}
        for arm,(src,pin) in MODELS.items():
            raw=src.read_bytes();assert sha(raw)==pin
            cpp=td/f'{arm}.cpp';binary=td/arm
            # Sole replay-source edit: enforce original completed pair count
            # via --pairs, rather than rolling a new wall-clock outcome.
            old=b' const auto stop=started+std::chrono::milliseconds(limit_ms);'
            assert raw.count(old)==1
            cpp.write_bytes(raw.replace(old,b' const auto stop=Clock::time_point::max();'))
            subprocess.run(['g++','-std=c++23',str(cpp),'-o',str(binary)],check=True)
            binaries[arm]=binary
        for rec in opts:
            name=rec['case'];arm=rec['arm'];tag=f'{Path(name).stem}.{arm}'
            try:
                initial=(A/'dev100/in'/name).read_bytes()
                assert sha(initial)==rec['input_sha']
                expected=list(map(int,rec['telemetry'].split()));assert len(expected)==15
                log=td/'telemetry'; log.unlink(missing_ok=True)
                cmd=[str(tester),'env','AHC008_TERRY_EXACT_LOG='+str(log),
                     str(binaries[arm]),f'--pairs={expected[10]}']
                action,error,rc,_=run(cmd,initial,15)
                m=re.fullmatch(rb'Score = (\d+)\s*',error)
                assert rc==0 and m and int(m[1])==int(rec['score']),(rc,error[-1000:])
                assert sha(action)==rec['commands_sha'],('full action mismatch',sha(action))
                assert list(map(int,log.read_text().split()))==expected,'telemetry mismatch'
                aa=td/'actions';tt=td/'trace'
                aa.write_bytes(action);tt.unlink(missing_ok=True)
                act,err,rc2,_=run([str(tester),sys.executable,
                                  str(H/'benchmark_cases.py'),'--playback',str(aa),str(tt)],initial,12)
                assert (act,err,rc2)==(action,error,rc)
                trace=tt.read_bytes()
                assert replay(initial.decode(),trace.decode().splitlines(),action.decode().splitlines(),
                              detailed=True)[0]==int(rec['score'])
            except Exception as ex:
                (out/'first_mismatch.json').write_text(json.dumps(
                    dict(case=name,arm=arm,reason=repr(ex),already_verified=len(manifests)),indent=2))
                raise SystemExit('Exact replay unsuccessful; stop; partial files are not evidence.') from ex
            (out/(tag+'.actions')).write_bytes(action)
            (out/(tag+'.trace')).write_bytes(trace)
            manifests.append(dict(case=name,arm=arm,map=expected[0],input_sha=rec['input_sha'],
                actions_sha=rec['commands_sha'],trace_sha=sha(trace),score=int(rec['score']),
                pairs=expected[10],telemetry=expected))
            print(tag,flush=True)
    (out/'manifest.json').write_text(json.dumps(manifests,indent=2)+'\n')

if __name__=='__main__':main()
