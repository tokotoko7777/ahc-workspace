# Two count-preserving one-mouth runs on stock maps 2/3
Fixed coordinates, zero-based. Map2 body starts c6 and c20; map3 c8 and c21.
First bank r5,7,...,19 faces left, second r11,13,...,25 faces right. Shift
the fourth body cell into a permanent cap and remove the same-column X on
the seven shared interior separator rows in that run; keep its two outside
braces, surviving original mouth/stance, and both unconverted end crossovers.
No further coordinates or alternative menu on failure. 16 original rooms
must remain exact 3-cell single-mouth bodies, each with both safe parities;
all other named rooms, mouths and roles unchanged, 75 total. Compare old
endpoint connectivity before or after any old one gate or matched whole-room
lock; full-closed no phantom. Record what happens if both runs' local end
crossovers close. Cap at r%4=3 is not available to ordinary same-bank
vertical sweep ownership; do not treat as an executable stock job.

Only signed frozen incoming held100 actual tapes on static pass. Count
original first-isolation events in exact targeted stock occupied bodies, not
all entries. Separately count visible mouth→body entries from each side and
through-crossings while intact original support and both old gates open.
The quantity 2×occupied events minus 2 setup X on each eligible case is a
deliberately optimistic area-only arithmetic diagnostic, not new score,
capture prediction, or preserve-traffic claim. Advance only on static
pass AND >=400 summed optimistic floor equivalent across all100, no
retuning, no deployment, no official run.
