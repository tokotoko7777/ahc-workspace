"""Frozen geometric + existing factual exposure screen."""
import collections as C
import hashlib,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_cap_swap'))
from static import maps,rooms,mask,md,split,reachable_checks,ALL,B,ADJ,wave,flood,cells
from guarded_entry_trace import observed,STEPS
from stochastic_lock_audit import idx
T=R/'ahc008_terry_hunt_wall_audit'
I=R/'ahc008_terry_incoming_shadow/held100'
MENUS={2:((6,5,19,-1),(20,11,25,1)),3:((8,5,19,-1),(21,11,25,1))}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def strip(r,c):return mask(r*30+x for x in range(c,c+4))
def static():
    result={}
    rr=rooms()
    for m,(w0,g0,aisles) in enumerate(maps()):
        if m not in MENUS:continue
        rs=rr[m]
        assert len(rs)==75
        at={r['body']:i for i,r in rs.items()}
        keep={i:dict(r) for i,r in rs.items()}
        targets={};w=w0;gates=g0
        risks=[];unswept=[];edited=0
        for b,(c,lo,hi,side) in enumerate(MENUS[m]):
            capcol=c+3 if side==-1 else c
            for t in (lo-2,hi+2):
                r=rs[at[strip(t,c)]]
                assert r['gates']==(30*t+c-1,30*t+c+4)
            for t in range(lo,hi+1,2):
                old=strip(t,c);rid=at[old];r=rs[rid]
                assert r['gates']==(30*t+c-1,30*t+c+4)
                cap=t*30+capcol;mouth=r['gates'][0 if side==-1 else 1]
                abandoned=r['gates'][1 if side==-1 else 0]
                assert not w&B[cap] and not edited&(B[cap]|B[abandoned])
                w|=B[cap];gates&=~B[abandoned];edited|=B[cap]|B[abandoned]
                body=old^B[cap]
                assert {(p//30+p%30)%2 for p in cells(body) if md(mouth,p)>=2}=={0,1}
                keep[rid]=dict(body=body,gates=(mouth,),stances=(mouth+side,),
                               left=mouth if side==-1 else -1,right=mouth if side==1 else -1)
                assert keep[rid]['stances'][0] in r['stances']
                targets[old]=dict(id=rid,bank=b,cap=cap,mouths=r['gates'],
                    support=wave(old)&~(old|mask(r['gates'])))
                if t%4==3:unswept.append(cap)
            for t in range(lo+1,hi,2):
                p=t*30+capcol
                assert w0&B[p] and w&B[p] and not edited&B[p]
                w^=B[p];edited|=B[p]
        assert len(keep)==75 and len(targets)==16
        assert w.bit_count()==w0.bit_count()+2 and gates.bit_count()==g0.bit_count()-16
        body_union=0;already=0
        op=ALL^(w|gates)
        for rid,r in keep.items():
            body=r['body']; assert body and not body&already
            for q in r['gates']:assert q in cells(gates) and wave(B[q])&body
            for s in r['stances']:assert not w&B[s]
            assert flood(body&-body,op)==body
            already|=body
        assert op&~(already|flood(aisles,op))==0
        anchors=aisles|mask(s for r in rs.values() for s in r['stances'])
        # Every stock reach relation remains after its corresponding action.
        for lock in (0,*[B[x] for x in cells(g0)],*[mask(r['gates']) for r in rs.values()]):
            a=ALL^(w0|lock);bb=ALL^(w|(lock&gates))
            for comp in split(a):
                x=anchors&comp
                if x and x&~flood(x&-x,bb):raise AssertionError(('lost reach',m,lock))
        for c,lo,hi,side in MENUS[m]:
            flanks=mask(v for t in (lo-2,hi+2) for v in rs[at[strip(t,c)]]['gates'])
            local=mask(r*30+x for r in range(lo-2,hi+3) for x in range(c-2,c+6))
            a=B[(lo-2)*30+c-2]; bb=B[(lo-2)*30+c+5]; op=local&~w
            assert flood(a,op)&bb
            for end in (lo-2,hi+2):assert flood(a,op&~mask(rs[at[strip(end,c)]]['gates']))&bb
            risks.append(dict(local_double_end_disconnect=not bool(flood(a,op&~flanks)&bb),
                  global_double_end_disconnect=not bool(flood(a,ALL&~(w|flanks))&bb)))
        result[m]=dict(targets=targets,setup_delta=2,rooms=75,unswept=unswept,risks=risks)
    return result
def step(p,c):
    r,k=STEPS[c];return p+30*r+k
def exposure(tapes,history,kinds,tgt):
    status=[None]*len(kinds);used=C.Counter();events=[]
    old_w=0;captured=set()
    at={v:(body,i) for body,x in tgt.items() for i,g in enumerate(x['mouths']) for v in [g]}
    body_at={p:b for b in tgt for p in cells(b)}
    for t,(ps,hs,ws) in enumerate(history):
        w=mask(map(idx,ws));reachable=flood(mask(map(idx,hs)),ALL^w)
        fresh=C.defaultdict(list)
        for i,p in enumerate(map(idx,ps)):
            if i not in captured and not reachable&B[p]:
                b=flood(B[p],ALL^w)
                fresh[b].append(i);captured.add(i)
        for b,ids in fresh.items():
            assert t and w!=old_w
            if b in tgt:events.append(dict(room=tgt[b]['id'],bank=tgt[b]['bank'],action=t-1,
                heads=ids,species=[kinds[i] for i in ids],all_first_inside_retained=all(idx(history[t-1][0][i])!=tgt[b]['cap'] for i in ids),all_first_inside_after_pet=all(idx(ps[i])!=tgt[b]['cap'] for i in ids)))
        old_w=w
        if t==300:break
        # Pet microsteps use physical graph after this action (new walls),
        # but pre-pet positions. Only intact old template crossings count.
        w1=mask(map(idx,history[t+1][2]))
        valid={b for b,x in tgt.items() if w1&x['support']==x['support'] and not w1&mask(x['mouths'])}
        for i,(orig,reply) in enumerate(zip(map(idx,ps),tapes[2*t+1].split())):
            p=orig
            if status[i] is not None and status[i][0] not in valid:status[i]=None
            for d in reply:
                if d=='.':continue
                q=step(p,d)
                if status[i] is not None:
                    b,side=status[i]
                    if not B[q]&b:
                        if q==tgt[b]['mouths'][1-side]:used['through_LR' if side==0 else 'through_RL']+=1
                        status[i]=None
                if p in at and body_at.get(q)==at[p][0] and at[p][0] in valid:
                    b,side=at[p]
                    used['entry_L' if side==0 else 'entry_R']+=1
                    status[i]=(b,side)
                p=q
    return dict(events=events,ingress=dict(used),heads_caught=len(captured),initial=len(kinds))
def main():
    atlas=static()
    ledger=json.loads((T/'recordings.json').read_text());assert len(ledger)==100
    stats=C.defaultdict(C.Counter);rows=[]
    for r in ledger:
        m=r['map'];nm=r['case']
        if m not in atlas:continue
        f=I/'in'/nm;a=(T/'tapes'/nm).with_suffix('.actions');t=a.with_suffix('.trace')
        assert [sha(x) for x in (f,a,t)]==[r[k] for k in ('input_sha','commands_sha','trace_sha')]
        tr=t.read_text().splitlines();assert len(tr)==600 and a.read_text().splitlines()==tr[::2]
        k,h,_=observed(f.read_bytes(),tr)
        q=exposure(tr,h,k,atlas[m]['targets']);assert bool(q['heads_caught']==q['initial'])==bool(r['actual_full'])
        cnt=len(q['events'])
        stats[m].update(boards=1,events=cnt,heads=sum(len(x['heads']) for x in q['events']),
            early=sum(x['action']<160 for x in q['events']),all_first_inside_retained=sum(x['all_first_inside_retained'] for x in q['events']),optimistic=2*cnt-2)
        stats[m].update(q['ingress'])
        rows.append(dict(case=nm,map=m,**q))
    gain=sum(x['optimistic'] for x in stats.values())
    print(json.dumps(dict(static={m:{k:v for k,v in q.items() if k!='targets'} for m,q in atlas.items()},
        exposure=dict(stats),total_over100=gain,gate=gain>=400,rows=rows),indent=2))
if __name__=='__main__':main()
