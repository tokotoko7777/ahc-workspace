#pragma once
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <array>
#include <cassert>
namespace terry_single_runs {
struct Run { int col, lo, hi, surviving_side; };
struct Cap { int tile, stance; };
inline bool edited(int map) { return map == 2 || map == 3; }
inline std::array<Run,2> runs(int map) {
 assert(edited(map));
 if(map==2)return {{{6,5,19,-1},{20,11,25,+1}}};
 return {{{8,5,19,-1},{21,11,25,+1}}};
}
inline std::array<Cap,16> caps(int map) {
 using terry_exact_maps::cell;
 std::array<Cap,16> out;int n=0;
 for(const auto& r:runs(map))for(int row=r.lo;row<=r.hi;row+=2){
   const bool left=r.surviving_side<0;
   out[n++]={cell(row,r.col+(left?3:0)),cell(row,r.col+(left?4:-1))};
 }
 assert(n==16);
 return out;
}
inline terry_exact_maps::Terrain make_terrain(int map){
 using namespace terry_exact_maps;
 auto x=terrain(map);
 if(!edited(map))return x;
 for(const auto& r:runs(map)){
  const bool left=r.surviving_side<0;
  int col=r.col+(left?3:0);
  for(int row=r.lo;row<=r.hi;row+=2){
   auto target=cell(row,col), remain=cell(row,r.col+(left?-1:4));
   auto retire=cell(row,r.col+(left?4:-1));
   assert(x.cells[remain]==(left?Marker::LeftTwo:Marker::RightTwo));
   assert(x.cells[retire]==(left?Marker::RightTwo:Marker::LeftTwo));
   assert(!x.plannedWalls[target]&&!x.aisleCells[target]&&!x.doorCells[target]);
   const auto floor=x.constructionRow(row)?Marker::Sweep:Marker::Room;
   x.cells[target]=Marker::Wall;x.plannedWalls.set(target);
   x.cells[remain]=left?Marker::LeftOne:Marker::RightOne;
   x.cells[retire]=floor;x.doorCells.reset(retire);
  }
  for(int row=r.lo+1;row<r.hi;row+=2){
   auto target=cell(row,col);
   assert(x.plannedWalls[target]&&!x.aisleCells[target]&&!x.doorCells[target]);
   x.cells[target]=Marker::Open;x.plannedWalls.reset(target);
  }
 }
 assert(x.plannedWalls.count()==terrain(map).plannedWalls.count()+2);
 assert(x.doorCells.count()==terrain(map).doorCells.count()-16);
 return x;
}
inline const terry_exact_maps::Terrain& for_solver(int map){
 if(map==2){static const auto x=make_terrain(2);return x;}
 if(map==3){static const auto x=make_terrain(3);return x;}
 return terry_exact_maps::terrain(map);
}
}
