#include "terrain_patch.hpp"
#include <iostream>
int main(){
 using namespace terry_exact_maps;
 for(int m:{2,3}) {
  const auto& a=terrain(m);const auto& b=terry_single_runs::for_solver(m);
  const int start=cell(0,a.aisleColumns.front());
  auto ra=classify(a,a.plannedWalls,{}, {start});
  auto rb=classify(b,b.plannedWalls,{}, {start});
  if(ra.count()!=75||rb.count()!=75)return 2;
  auto exact=[&](const Terrain& t,const Rooms& r) {
   std::vector<Board> mask(r.count());
   for(int p=0;p<V;++p)if(r.ids[p]>=0&&r.ids[p]<r.count()&&!t.doorCells[p])mask[r.ids[p]].set(p);
   return mask;
  };
  auto aa=exact(a,ra),bb=exact(b,rb);
  Board seen;int changed=0;
  for(int i=0;i<ra.count();++i){
    const auto old=ra.rooms[i];
    bool isnew=false;int l=old.left,r=old.right;
    Board expected=aa[i];
    for(auto cap:terry_single_runs::caps(m))if(expected[cap.tile]){
     ++changed;isnew=true;expected.reset(cap.tile);
     if(r==cap.stance)r=-1;
     else{assert(l==cap.stance);l=-1;}
     break;
    }
    int match=-1;
    for(int j=0;j<rb.count();++j)if(rb.rooms[j].left==l&&rb.rooms[j].right==r&&bb[j]==expected){
      assert(match==-1);match=j;
    }
    assert(match>=0&&!seen[match]);seen.set(match);
    if(isnew)assert(bb[match].count()==3);
  }
  assert(changed==16&&seen.count()==75);
  assert(a.aisleCells==b.aisleCells&&a.aisleRows==b.aisleRows&&a.aisleColumns==b.aisleColumns);
  std::cout<<m<<" planned="<<b.plannedWalls.count()<<" named="<<rb.count()<<" edited="<<changed<<"\n";
 }
}
