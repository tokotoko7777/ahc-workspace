# Static Map1 hybrid, exactly one geometry
Independent flood checks original compiled terrain and one exact translated hybrid. Aisles 7/14/24. Copy original c14..29 byte-for-byte, shift old c0..4 to c3..7, 14 odd apron c2 caps r3..29, retire only r1 west solo by removing its gate, keep old translated top cell. All of r1 c8..13 and r0 c9..12 are exterior/open: permanent connector. Exactly 14 new c9..12 horizontal four-body pens on odd r3..29, with mouths c8/13, separator walls c9..12 even r2..28. No extra marker/Sweep changes, solver, geometry selection, hidden connection or proxy score.

Gate all: <=270 X, >=65 exact usable named components with roles; exactly 14 narrow dual checkerboard-parity bodies; all unchanged east (wider and outer) and other west translated bodies, mouths, guard stances, safe cells unchanged; no unserved phantom component; apron and full lanes7/14 connected with empty, single and all compact closed, plus check all named closed; full lane24 reachable under each single closure (stock may split under all closed). Every named door demonstrably attached to one room, correct facing aisle stance and true whole isolation. As a second implementation, compile old stock terrain and nominal candidate semantically in compiled.cpp; compare every tile against independent Python mask interpretation, then exact graph floods. If static passes, separate dry construction task coverage/makespan work is still mandatory; r3,7,...,27 c2 new odd caps do not follow unchanged original literal sweep tasks. No zero score/constructor success implied.

After clearance:
    sha256sum -c FROZEN.sha256
    g++ -std=gnu++23 compiled.cpp -o compiled && ./compiled > boards.txt
    python verify.py boards.txt > report.json
