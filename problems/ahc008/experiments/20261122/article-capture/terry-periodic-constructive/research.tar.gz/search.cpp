#pragma GCC optimize("O3,unroll-loops")
#include <bits/stdc++.h>
using namespace std;
using U = __uint128_t;
using P = pair<int,int>;
using Shape = vector<P>;
constexpr U ALL=(U(1)<<100)-1;
constexpr int WIDTH=192, SHARED=36, FAR=8;
constexpr uint64_t KEY=0x942d618b6a9c0d23ULL;
const P D[]={{-1,0},{1,0},{0,-1},{0,1}};
P plusp(P a,P b){return {a.first+b.first,a.second+b.second};}
int wrap(int a){return (a%10+10)%10;}
int ix(P p){return 10*wrap(p.first)+wrap(p.second);}
int pc(U a){return __builtin_popcountll(uint64_t(a))+__builtin_popcountll(uint64_t(a>>64));}
int lsb(U a){return uint64_t(a)?__builtin_ctzll(uint64_t(a)):64+__builtin_ctzll(uint64_t(a>>64));}
uint64_t mix(uint64_t a){a+=0x9e3779b97f4a7c15ULL;a=(a^(a>>30))*0xbf58476d1ce4e5b9ULL;a=(a^(a>>27))*0x94d049bb133111ebULL;return a^(a>>31);}
int nx[100][4];
struct Type{Shape b,g,w,s,t;};
struct Room{U b,g,w,s,t;int type,anchor;};
vector<Room> rooms;vector<Type> types;
void generate(){
 for(int p=0;p<100;p++)for(int k=0;k<4;k++)nx[p][k]=ix(plusp({p/10,p%10},D[k]));
 set<Shape> cur{{{0,0}}};
 for(int j=1;j<4;j++){
  set<Shape> nxt;
  for(auto v:cur)for(P p:v)for(P d:D){
   P q=plusp(p,d);if(binary_search(v.begin(),v.end(),q))continue;
   auto w=v;w.push_back(q);int r=100,c=100;for(P z:w){r=min(r,z.first);c=min(c,z.second);}
   for(P &z:w){z.first-=r;z.second-=c;}sort(w.begin(),w.end());nxt.insert(w);
  }
  cur=move(nxt);
 }
 assert(cur.size()==19);
 for(auto b:cur){
  set<P> bs(b.begin(),b.end()), bound;
  for(P p:b)for(P d:D){P q=plusp(p,d);if(!bs.contains(q))bound.insert(q);}
  Shape bd(bound.begin(),bound.end());
  for(int i=0;i<(int)bd.size();i++)for(int j=i+1;j<(int)bd.size();j++){
   P a=bd[i],c=bd[j];int parity=0;Shape brace,s,t;
   auto adj=[](P p,P q){return abs(p.first-q.first)+abs(p.second-q.second)==1;};
   for(P q:b)if(!adj(q,a)&&!adj(q,c))parity|=1<<((q.first+q.second)&1);
   if(parity!=3)continue;
   for(P q:bd)if(q!=a&&q!=c)brace.push_back(q);
   for(P d:D){P x=plusp(a,d),y=plusp(c,d);if(!bs.contains(x)&&!bound.contains(x))s.push_back(x);if(!bs.contains(y)&&!bound.contains(y))t.push_back(y);}
   if(s.empty()||t.empty()||(s.size()==1&&s==t))continue;
   types.push_back({b,{a,c},brace,s,t});
  }
 }
 assert(types.size()==354);
 for(int a=0;a<100;a++)for(int t=0;t<(int)types.size();t++){
  auto mask=[&](const Shape &q){U m=0;for(P p:q)m|=U(1)<<ix(plusp(p,{a/10,a%10}));return m;};
  const auto &v=types[t];rooms.push_back({mask(v.b),mask(v.g),mask(v.w),mask(v.s),mask(v.t),t,a});
 }
}
struct State{U named=0,w=0;array<int,9> ids{};int n=0,weak=0,junction=0;uint64_t key=0;};
bool hall(const Room &r,U ext){return (r.s&ext)&&(r.t&ext)&&pc((r.s|r.t)&ext)>=2;}
int winding(U remain){
 int maxSize=0;array<int,100> x{},y{};int q[100];
 while(remain){
  int st=lsb(remain),h=0,n=1,w1=0,w2=0;bool rank=false;U pending=remain;
  remain^=U(1)<<st;q[0]=st;
  x[st]=st/10;y[st]=st%10;
  while(h<n){
   int p=q[h++];
   for(int k=0;k<4;k++){
    int z=nx[p][k];U bit=U(1)<<z;if(!(pending&bit))continue;
    int a=x[p]+D[k].first,b=y[p]+D[k].second;
    if(remain&bit){remain^=bit;q[n++]=z;x[z]=a;y[z]=b;}
    else{a-=x[z];b-=y[z];if(!a&&!b)continue;if(!w1&&!w2){w1=a;w2=b;}else if(a*w2-b*w1)rank=true;}
   }
  }
  if(rank)maxSize=max(maxSize,n);
 }
 return maxSize;
}
bool better(const State&a,const State&b){
 return tuple(pc(a.w),-a.junction,a.weak,a.key,a.ids)<tuple(pc(b.w),-b.junction,b.weak,b.key,b.ids);
}
bool push(const State &s,int i,State& out){
 const auto &r=rooms[i];U f=r.b|r.g;
 if((f&(s.named|s.w))||(r.w&s.named))return false;
 U wall=s.w|r.w;if(pc(wall)>25)return false;
 U named=s.named|f,ext=ALL^(wall|named);
 if(!hall(r,ext)) return false;
 int weak=(pc(r.s&ext)==1)+(pc(r.t&ext)==1);
 for(int k=0;k<s.n;k++){
  const auto &o=rooms[s.ids[k]];if(!hall(o,ext))return false;
  weak+=(pc(o.s&ext)==1)+(pc(o.t&ext)==1);
 }
 // Exact monotone total brace incidence pressure: count occupied bodies near braces
 // via pairwise shared requests, preferring consolidation around shared junctions.
 int reuse=0;for(int k=0;k<s.n;k++)reuse+=pc(rooms[s.ids[k]].w&r.w);
 out=s;out.named=named;out.w=wall;out.weak=weak;out.junction+=reuse;
 out.key^=mix(KEY+uint64_t(i));out.ids[s.n]=i;out.n++;
 sort(out.ids.begin(),out.ids.begin()+out.n);
 return true;
}
void output(const State &s){
 cout<<"WITNESS ";
 for(int k=0;k<s.n;k++){auto r=rooms[s.ids[k]];auto &v=types[r.type];P a={r.anchor/10,r.anchor%10};
  for(const Shape *shape:{&v.b,&v.g,&v.w}){
   cout<<shape->size()<<' ';for(P p:*shape){p=plusp(p,a);cout<<p.first<<' '<<p.second<<' ';}
  }
 }
 cout<<'\n';
}
int main(){
 auto start=chrono::steady_clock::now();
 auto seconds=[&]{return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 generate();
 vector<vector<int>> inv(100);
 for(int i=0;i<(int)rooms.size();i++)for(U w=rooms[i].w;w;w&=w-1)inv[lsb(w)].push_back(i);
 vector<State> beam(1);
 vector<int> seen(rooms.size(),-1);
 int generation=0;
 for(int dep=1;dep<=9;dep++){
  vector<State> next;
  long long tried=0, retained=0; int minwall=26;
  for(const State &s:beam){
   ++generation;
   if(seconds()>100){cerr<<"SEARCH_CLOCK_CAP "<<dep<<'\n';return 0;}
   priority_queue<State,vector<State>,decltype(&better)> shared(&better),far(&better);
   auto attempt=[&](int i,bool join){
    if(seen[i]==generation)return;
    seen[i]=generation;
    if(bool(s.w&rooms[i].w)!=join)return;
    ++tried;State c;if(!push(s,i,c))return;
    auto &q=join?shared:far;int cap=join?SHARED:FAR;
    if((int)q.size()<cap)q.push(c);
    else if(better(c,q.top())){q.pop();q.push(c);}
   };
   if(dep==1){
    for(int i=0;i<(int)types.size();i++){
     State c;if(push(s,i,c)&&winding(ALL^(c.named|c.w)))next.push_back(c);
    }
   }else{
    for(U w=s.w;w;w&=w-1)for(int i:inv[lsb(w)])attempt(i,true);
    // Fixed 521-placement nonsharing sample from full cyclic ID space;
    // stride coprime to 35400, offset is a stable per-state hash.
    int n=rooms.size(),i=(s.key^KEY)%n;
    for(int k=0;k<521;k++,i=(i+127)%n)attempt(i,false);
    for(auto *q:{&shared,&far})while(!q->empty()){
     State c=q->top();q->pop();U e=ALL^(c.named|c.w);
     int rw=winding(e);if(!rw)continue;
     if(dep==9){
      if(rw==pc(e)){output(c);return 0;}
     }else next.push_back(c);
     ++retained;minwall=min(minwall,pc(c.w));
    }
   }
  }
  sort(next.begin(),next.end(),better);
  next.erase(unique(next.begin(),next.end(),[](auto&a,auto&b){return a.ids==b.ids;}),next.end());
  if((int)next.size()>WIDTH)next.resize(WIDTH);
  cerr<<"DEPTH "<<dep<<" tried="<<tried<<" rank_survivors="<<retained
      <<" minwall="<<minwall<<" beam="<<next.size()<<" elapsed="<<seconds()<<'\n';
  if(next.empty())break;beam=move(next);
 }
 cerr<<"NO_WITNESS_WITHIN_BEAM\n";
}
