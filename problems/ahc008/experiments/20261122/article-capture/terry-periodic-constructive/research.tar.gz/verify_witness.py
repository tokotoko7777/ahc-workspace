#!/usr/bin/env python3
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ahc008_terry_periodic_relaxation'))
from search import verify, bounded, mod, draw
lines=Path(sys.argv[1]).read_text().splitlines()
witness=[line for line in lines if line.startswith('WITNESS ')]
if not witness:
    print(json.dumps(dict(witness=False)))
    raise SystemExit
assert len(witness)==1
it=iter(map(int,witness[0].split()[1:]))
def read():
    return {(next(it),next(it)) for _ in range(next(it))}
raw=[tuple(read() for _ in range(3)) for _ in range(9)]
assert next(it,None) is None
rooms=[tuple(set(map(mod,p)) for p in rr) for rr in raw]
walls=set().union(*(w for b,g,w in rooms))
verify(10,rooms,walls,True,False)
g=verify(10,rooms,walls,True,True)
print(json.dumps(dict(witness=True,torus_verified=True,rooms=len(rooms),walls=len(walls),
                      board=draw(10,rooms,walls),guards=g)),flush=True)
r=bounded(raw,walls)
print(json.dumps(dict(bounded_verified=r is not None,result=r)),flush=True)
