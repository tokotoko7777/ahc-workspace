# Single bounded constructive 10×10 periodic search

No game data, cases/scoring or MILP calls. One deterministic C++ beam.
Exactly 9 two-mouth size-four rooms, ≤25 planned X; all 19 tetrominoes,
arbitrary two boundary mouths preserving both endpoint parities, same exact
local Hall conditions as frozen relaxation. First anchor modulo translation
is 0; depth 1 inspect all 354 types before keeping top 192. Later enumerate
candidates on current brace inverted lists; per parent keep up to 36 sharing
and 8 nonsharing. Nonsharing uses a fixed cyclic 521-position sample with
stride 127. Hash order seed 0x942d618b6a9c0d23; no random clock entropy.
Prioritize low X, shared-brace pair incidence, then fewer tight guards,
then state hash and sorted template-ID tuple. Per depth retain at most 192
distinct template-ID sets. A second assembly order dedupes without
erasing physically distinct pairings. No exits/restarts into another search.

C++ rejects retained children lacking a residual exterior component with
two independent lifted windings; this is monotone as placements only
remove exterior sites. No connectedness demand until all 9 placed. The
first depth-9 candidate with one connected exterior component and rank 2
is output and the search stops. Independent Python then uses unchanged
frozen relaxation verifier: exact local geometry and legal stance pairs,
open/each one-lock/all-locked floods and lifted winding; only then
100 translation phases for 30×30 with ≥75 rooms / ≤225 X, exact bounded
verification. If verification fails, stop. No witness is not impossibility.
Pinned verifier dependency `../ahc008_terry_periodic_relaxation/search.py`:
`56abc7a55cdf250e5dd4781fccfecbb8f52cb4ebc3d00d67f940714232632f7b`.

Search clock checks at parent boundaries (100 seconds soft). Executable +
verification share a hard 120-second envelope; GNU C++23 compilation is a
separate bounded setup. With active root clearance only:

```sh
cd ahc008_terry_periodic_constructive
timeout -k 1s 19s g++ -std=gnu++23 search.cpp -o search
timeout -k 1s 119s bash -o pipefail -c   './search > witness.txt 2> search.log && python3 verify_witness.py witness.txt'
```
