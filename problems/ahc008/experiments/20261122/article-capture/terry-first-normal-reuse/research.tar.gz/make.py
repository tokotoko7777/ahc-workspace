"""Pin exact current predecessor; no public distribution of assembled private data."""
import sys
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
if sys.argv[1:]==['bound']:
    src=d.parent/'ahc008_terry_split_bound/solve.private.cpp'
    digest='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
else:
    assert len(sys.argv)==1
    src=d.parent/'ahc008_terry_first_chase_reuse/solve.private.cpp'
    digest='8f50dda74f578fc8ddbf8176d15172a80df96d23d82c57db8ae51aedce4294b7'
s=src.read_text()
assert hashlib.sha256(s.encode()).hexdigest()==digest
a=s.index('Decision decide(const State& live,Normal& ordinary,int cap,Clock::time_point stop){')
b=s.index('\n}\n}',a)+2
block=s[a:b]
(d/'ref.hpp').write_text(block.replace('Decision decide(', 'Decision decide_ref(', 1))
p=' if(targets.empty()||cap==0)return answer;'
assert block.count(p)==1
block=block.replace(p,p+'''
 const bool immutableConstruction=std::all_of(ordinary.crew.q.begin(),ordinary.crew.q.end(),
   [](const auto& q){return q.empty();});
 struct NormalPrefix {std::string action;Pcg rng_after;};
 std::optional<NormalPrefix> identicalNormalPrefix;''')
p='   people_step(s,ordinary.step(s,turn));actual_motion(s,a);'
assert block.count(p)==1
block=block.replace(p,'''   if(turn==275&&immutableConstruction){
    if(!identicalNormalPrefix){
     auto action=ordinary.step(s,turn);
     identicalNormalPrefix=NormalPrefix{std::move(action),ordinary.rng};
    }else ordinary.rng=identicalNormalPrefix->rng_after;
    people_step(s,identicalNormalPrefix->action);
   }else people_step(s,ordinary.step(s,turn));
   actual_motion(s,a);''')
(d/'solve.private.cpp').write_text(s[:a]+block+s[b:])
