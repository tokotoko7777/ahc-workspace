# Exact first simulated Normal step reuse: empty construction queues only

The stock work object deliberately persists across simulated Normal arms;
queued wall construction and its mutable acknowledgement cannot be
skipped or rewound. Admit reuse only if every live construction queue
is already empty **before** the decision. Those queues remain empty.
Every Normal arm begins at identically the same live state and resets
the forecast RNG to Pcg(42); cache the action and both words of its RNG
object from the first completed step and restore that RNG for the
subsequent identical first steps. Normal's topology cache is internally
keyed by exact physical inputs and never controls observable semantics.
Check that premise with fixtures where cached keys are deliberately
different when the first action is reused. Keep stop checks in the
same positions, skip no state mutation other than these exact transient
memo refreshes, and do not modify normal live action or virtual pet
RNG.

Before compile, verify all metadata and test independent prototype.
Fixed diagnostic subset AND official gates: original admitted
practice100 and independent100, identical commands and score, at least
2.0% aggregate CPU reduction within the positive-rollout stratum on
both, no worse whole-panel CPU and max local wall <2.95. Stop after
first failure. Variant not yet built or combined.
