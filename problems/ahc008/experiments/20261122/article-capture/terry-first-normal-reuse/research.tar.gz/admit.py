import csv,json,sys
rows=list(csv.DictReader(open(sys.argv[1])))
assert len(rows)==200 and len({(r['case'],r['arm']) for r in rows})==200
report={}
for label,usable in (('all',lambda x:True),('rollout',lambda x:int(x['draws'])>0),('none',lambda x:int(x['draws'])==0)):
    base,new=([x for x in rows if x['arm']==a and usable(x)] for a in ('baseline','fast'))
    assert len(base)==len(new) and base
    aa,bb=(sum(int(r['cpu_us']) for r in t)for t in (base,new))
    report[label]=dict(cases=len(base),cpu=[aa,bb],saving=1-bb/aa,max_wall=[max(float(r['wall']) for r in t)for t in (base,new)])
print(json.dumps(report,indent=2))
if report['all']['saving']<0 or report['rollout']['saving']<.02 or max(report['all']['max_wall'])>=2.95:raise SystemExit("frozen fixed-work gate failed")
