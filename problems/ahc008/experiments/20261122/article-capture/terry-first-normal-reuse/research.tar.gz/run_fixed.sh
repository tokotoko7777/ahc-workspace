#!/usr/bin/env bash
set -euo pipefail
D=ahc008_terry_first_normal_reuse
R=ahc008_terry_split_bound
C=ahc008_terry_first_chase_reuse
B=ahc008_terry_speed/bench.py
T=ahc008_focus_assets/tools/target/release/tester
g++ -std=gnu++23 "$D/solve.private.cpp" -o "$D/solve"
python "$B" "$T" ahc008_focus_assets/tools/in "$R/practice.default.csv" "$R/solve" "$D/solve" "$D/practice.speed.csv" >"$D/practice.speed.log" 2>&1
python "$D/admit.py" "$D/practice.speed.csv" >"$D/practice.speed.json"
python "$B" "$T" "$C/default-fresh100/in" "$R/fresh.default.csv" "$R/solve" "$D/solve" "$D/fresh.speed.csv" >"$D/fresh.speed.log" 2>&1
python "$D/admit.py" "$D/fresh.speed.csv" >"$D/fresh.speed.json"
