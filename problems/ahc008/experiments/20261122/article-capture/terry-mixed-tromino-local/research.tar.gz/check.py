"""Exhaustive local geometry only; no game cases, optimizer or simulation."""
import itertools as it
import json
N,M=10,8
ALL=(1<<(N*M))-1
L=sum(1<<(r*M) for r in range(N))
R=L<<(M-1)
def b(r,c):return 1<<(r*M+c)
def bits(ps):return sum({b(r,c) for r,c in ps})
def wave(x):return (((x&~L)>>1)|((x&~R)<<1)|(x>>M)|(x<<M))&ALL
def flood(x,allowed):
    assert x&allowed==x
    while True:
        q=x|wave(x)&allowed
        if q==x:return x
        x=q
def lo(x):return x&-x
def coords(x):
    return [divmod(q,M) for q in range(N*M) if x>>q&1]
ROWS=[bits((r,c) for c in range(M)) for r in range(N)]
FIXED=bits((0,c) for c in range(2,6))
AISLES=L|R
FORBID=AISLES|ROWS[9]|(ROWS[0]^FIXED)
BLACK=bits((r,c) for r in range(N) for c in range(M) if (r+c)%2==0)
def template(body,gates,guard):
    sep=wave(body)&~(body|gates)
    if sep&FORBID or (body|gates)&(AISLES|ROWS[0]|ROWS[9]) or sep&guard:
        return None
    safe=body&~wave(gates)
    if not safe&BLACK or not safe&~BLACK:return None
    return (body,gates,guard,sep)
def fixed_pair(r):
    return template(bits((r,c) for c in range(2,6)),b(r,1)|b(r,6),b(r,0)|b(r,7))
def orientations():
    ps={((0,0),)}
    for _ in range(2):
        next=set()
        for s in ps:
            for r,c in s:
                for i,j in ((1,0),(-1,0),(0,1),(0,-1)):
                    q=(r+i,c+j)
                    if q in s:continue
                    z=set(s)|{q}
                    y=min(r for r,c in z);x=min(c for r,c in z)
                    next.add(tuple(sorted((r-y,c-x) for r,c in z)))
        ps=next
    assert len(ps)==6
    return sorted(ps)
def solos(side):
    c=1 if side==0 else 6
    sc=0 if side==0 else 7
    inside=2 if side==0 else 5
    out=[]
    for shape in orientations():
        for a,d in it.product(range(1,9),range(2,6)):
            body=[(r+a,k+d) for r,k in shape]
            if any(r>8 or k>5 for r,k in body):continue
            for r,k in body:
                if k!=inside:continue
                q=template(bits(body),b(r,c),b(r,sc))
                if q and (wave(b(r,c))&q[0]).bit_count()==1:
                    out.append(q)
    return sorted(set(out))
def disjoint(rooms):
    solid=FIXED;body=doors=guard=0
    for x,g,s,w in rooms:
        if (x|g)&(body|doors|guard|solid) or (body|doors|guard|x|g|s)&w or s&(body|doors|solid):
            return None
        solid|=w;body|=x;doors|=g;guard|=s
    return solid
def independent(rooms,wall):
    body=doors=guard=0
    for x,g,s,w in rooms:
        if (x|g)&(body|doors|guard|wall) or s&(x|g|body|doors|wall):return False
        if flood(lo(x),x)!=x or wave(x)&~x!=(wave(x)&wall)|g:return False
        safe=x&~wave(g)
        if not safe&BLACK or not safe&~BLACK:return False
        for r,c in coords(g):
            q=b(r,c)
            if (wave(q)&s).bit_count()!=1 or (wave(q)&x).bit_count()!=1:return False
        body|=x;doors|=g;guard|=s
    if wall&FORBID or wall&FIXED!=FIXED or body&guard:return False
    for mask in range(16):
        cb=cg=0
        for i,(x,g,s,w) in enumerate(rooms):
            if mask>>i&1:cb|=x;cg|=g
        floor=ALL^(wall|cg)
        ext=flood(b(9,0),floor)
        if ext!=floor&~cb or (AISLES|ROWS[9]|guard)&~ext:return False
        for i,(x,g,s,w) in enumerate(rooms):
            if mask>>i&1 and flood(lo(x),floor)!=x:return False
    return True
def configure(rooms,wall,rr):
    layout=[['.']*M for _ in range(N)]
    for r,c in coords(wall):layout[r][c]='X'
    for i,(x,g,s,w) in enumerate(rooms):
        for r,c in coords(x):layout[r][c]=chr(97+i)
        for r,c in coords(g):layout[r][c]='g'
        for r,c in coords(s):layout[r][c]='s'
    return dict(walls=wall.bit_count(),pair_rows=rr,maze=[''.join(r)for r in layout],
                max_ordinary_reach=max(min(abs(y-r) for r in rr)for y in range(1,9)),
                rooms=[dict(body=coords(x),gates=coords(g),stances=coords(s))for x,g,s,w in rooms])
def main():
    control=[fixed_pair(r) for r in (1,3,5,7)]
    assert disjoint(control).bit_count()==20 and independent(control,disjoint(control))
    lp,rp=solos(0),solos(1)
    pairs=compatible=affordable=accepted=0; first=None
    minimum=None
    for rr in it.combinations(range(1,9),2):
        if max(min(abs(y-r) for r in rr)for y in range(1,9))>3:continue
        base=[fixed_pair(r) for r in rr]
        if None in base or disjoint(base) is None:continue
        pairs+=1
        for a,c in it.product(lp,rp):
            rooms=base+[a,c]
            w=disjoint(rooms)
            if w is None:continue
            compatible+=1
            if w.bit_count()>19:continue
            affordable+=1
            if not independent(rooms,w):continue
            accepted+=1
            if minimum is None or w.bit_count()<minimum:
                minimum=w.bit_count();first=configure(rooms,w,rr)
            for r in rr:assert flood(b(r,0),ROWS[r]&~w)==ROWS[r]
    print(json.dumps(dict(stock=configure(control,disjoint(control),(1,3,5,7)),
      template_left=len(lp),template_right=len(rp),pair_row_sets=pairs,
      locally_compatible=compatible,affordable=affordable,
      verified=accepted,minimum=minimum,witness=first),indent=2))
if __name__=='__main__':main()
