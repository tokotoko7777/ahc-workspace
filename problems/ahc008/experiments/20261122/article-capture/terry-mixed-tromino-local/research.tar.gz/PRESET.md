# Exhaustive two-through + opposite solo local 10×8 footprint

Static scoreless question. Reproduce the earlier 20-wall stock fixture:
physical c0/c7 side aisles and permanently open row9 crossing; shared
upper row0 stock brace c2..5 remains fixed and counted in both arms.
Edit only working rows 1..8. No other artificial outside/exterior link.
Same four nominal useful sites. Two exact straight 1×4 through rooms
placed on any distinct working rows, connected down both aisles to real
crossing row. Require max along-aisle distance to an ordinary through
row ≤3 over all eight working rows (the real connector is excluded from
this metric). One left- and one right-facing connected three-cell solo;
all six free grid orientations are considered, including straight and
L bends. Direct door and exterior stance in x1/x0 on left and x6/x7 on
right. Enumerate every body anchor and each possible inward adjacent
door. Corps may not step into recognized mouth/aisle columns or fixed
boundary rows; required roles preserve both gate-safe checkerboard
parities and only a true inward boundary neighbor for a gate. No
gate/body/brace overlap or non-owned room touch.

Use exact minimum required planned walls: the fixed row0 brace and
union of physical body boundaries excluding their own gates. A candidate
with an extra wall could only remove floor; this exhaustive census
is explicitly for required-shell geometry (no added phantom fillers).
Freeze ≤19 X. Advance independently to physical verifier: all 16
closure subsets have exact named connected bodies, every exterior and
guard tile accessible from row9, no worker trap or isolated empty floor,
both real ordinary crossings separately certified using each through row
alone. Additional free non-room longitudinal row, if any, is explicitly
not counted as one of the two measured guarded ordinary crossings.
Output exact counts, minimum among valid witnesses and first deterministic
witness at that count. Negative applies only to frozen 10×8 required
shell, not taller strips/guards, packing with optional additional walls,
or 30×30 score. No optimizer, simulation, execution or workload claims.

Once after explicit review; no alternative shapes or tuned budget:

    timeout -k 1s 14s python3 check.py > result.json
