"""Generate observation-only pinned fast faithful source, leaving stock actions unchanged."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_motion_cache/submission.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='d14f6471e5f64bf4a936f8cf27a0f585136a53e13f3e4a27af9fa21f6427b49c'
assert s.startswith('#pragma GCC optimize("O3")')
s=s.replace('#pragma GCC optimize("O3")','#pragma GCC optimize("O3")\n'+(d/'exact.hpp').read_text(),1)
def put(token,f):
    global s
    assert s.count(token)==1,token
    s=s.replace(token,f(token))
put('namespace terry_exact_hunt {',lambda old:old+'''
inline int packing_audit_turn=-1;
inline std::vector<std::array<long long,7>> packing_audit_rows;
''')
put('    return solution;',lambda old:'''
    if(packing_audit_turn>=0){
        int one=0;
        for(const auto& j:jobs)one+=j.a==j.b;
        if(one){
            auto opt=terry_exact_packing::improve<Candidate>(n,rooms.size(),jobs,best);
            int exone=0;
            audit_alternative.clear();
            for(int j:opt.jobs){
                exone+=jobs[j].a==jobs[j].b;
                audit_alternative.push_back(jobs[j]);
            }
            packing_audit_rows.push_back({packing_audit_turn,m,one,best,opt.exactScore,
                                        static_cast<long long>(solution.size()),exone});
        }
    }
'''+old)
put('// unset command = nullopt; a chosen explicit wait = \'.\'.',lambda old:'inline std::vector<Candidate> audit_alternative;\ninline std::vector<std::string> audit_commands;\n'+old)
put('    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));',lambda old:'''
    if(hunt::packing_audit_turn>=0)hunt::audit_alternative.clear();
'''+old+'''
    if(hunt::packing_audit_turn>=0&&!hunt::audit_alternative.empty()){
        auto alt_book=booked;
        hunt::emit(s.people,hunt::audit_alternative,legal,alt_book);
        auto proposal=action;
        for(int i=0;i<m;++i)if(alt_book[i])proposal[i]=*alt_book[i];
        idle_phase(s,terrain->aisleColumns,proposal);
        const auto as=sanitize(s,proposal);
        auto text=std::to_string(hunt::packing_audit_turn)+" "+as;
        for(const auto& j:hunt::audit_alternative)if(j.a==j.b){
            int g=j.left>=0?j.left:j.right;
            char c=j.left>=0?'r':'l';
            if(as[j.a]==c)text+=" "+std::to_string(j.a)+":"+std::to_string(g);
        }
        hunt::audit_commands.push_back(text);
    }
''')
put('  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);',lambda old:'''
  if(std::getenv("AHC008_TERRY_PACK_AUDIT")&&turn<275)
      hunt::packing_audit_turn=turn;
'''+old+'''
  hunt::packing_audit_turn=-1;
''')
put(' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){',lambda old:'''
 if(const char* path=std::getenv("AHC008_TERRY_PACK_AUDIT")){
    std::ofstream log(path);
    for(const auto& r:hunt::packing_audit_rows){
        log<<"S ";
        for(auto x:r)log<<x<<' ';
        log<<'\\n';
    }
    for(const auto& r:hunt::audit_commands)log<<"C "<<r<<'\\n';
 }
'''+old)
(d/'audit.private.cpp').write_text(s)
