#pragma once
#include <algorithm>
#include <bit>
#include <cassert>
#include <cstdint>
#include <span>
#include <vector>

namespace terry_exact_packing {
// Job has positive signed score and real nonnegative room, a and b.
// a==b uses exactly one actor. Candidate order is arbitrary; output
// indices are in original order. If no strict gain, jobs stays empty
// and the caller must keep its incumbent verbatim.
struct Result {
 std::int64_t exactScore=0;
 std::vector<int> jobs;
};
template<class Job>
Result improve(int n,int rooms,std::span<const Job> jobs,std::int64_t oldScore){
 assert(n>=0&&n<=10&&rooms>=0&&oldScore>=0);
 const unsigned width=1u<<n, full=width-1;
 // Only the best score for each (room,usedMask) matters. Keep earlier
 // job when equal, and do not copy room states with no actual jobs.
 std::vector<std::vector<int>> options(rooms);
 std::vector<unsigned> masks(jobs.size());
 std::vector<int> best(width,-1);
 std::vector<std::vector<int>> indexes(rooms);
 for(int j=0;j<int(jobs.size());++j){
  const auto& x=jobs[j];
  assert(x.room>=0&&x.room<rooms&&x.a>=0&&x.a<n&&x.b>=0&&x.b<n&&x.score>0);
  masks[j]=(1u<<x.a)|(1u<<x.b); indexes[x.room].push_back(j);
 }
 for(int r=0;r<rooms;++r){
  for(int j:indexes[r]){
   int& k=best[masks[j]];
   if(k<0||jobs[k].score<jobs[j].score)k=j;
  }
  for(int j:indexes[r]){
   int& k=best[masks[j]];
   if(k>=0){options[r].push_back(k);k=-1;}
  }
 }
 std::vector<std::int64_t> prev(width,-1), next(width);
 std::vector<std::vector<int>> histories;
 prev[0]=0;
 for(const auto& opt:options){
  if(opt.empty())continue;
  next=prev;
  histories.emplace_back(width,-1);
  auto& action=histories.back();
  for(int j:opt){
   unsigned sub=full^masks[j], u=sub;
   while(true){
    unsigned v=u|masks[j];
    if(prev[u]>=0){
     const auto value=prev[u]+jobs[j].score;
     if(value>next[v]){next[v]=value;action[v]=j;}
    }
    if(!u)break;
    u=(u-1)&sub;
   }
  }
  prev.swap(next);
 }
 const auto it=std::max_element(prev.begin(),prev.end());
 Result out{*it,{}};
 if(out.exactScore<=oldScore)return out;
 unsigned v=it-prev.begin();
 for(auto i=histories.rbegin();i!=histories.rend();++i){
  int j=(*i)[v];
  if(j>=0){out.jobs.push_back(j);v^=masks[j];}
 }
 assert(!v);
 std::sort(out.jobs.begin(),out.jobs.end());
 return out;
}
}
