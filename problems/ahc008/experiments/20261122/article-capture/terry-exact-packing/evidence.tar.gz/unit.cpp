#include "exact.hpp"
#include "../ahc008_terry_exact_hunt/hunt.hpp"
#include <functional>
#include <iostream>
#include <random>
namespace p=terry_exact_packing;
namespace h=terry_exact_hunt;
using Job=h::Candidate;
auto solve(int n,int r,const std::vector<Job>& a,std::int64_t old=0){
 return p::improve<Job>(n,r,a,old);
}
void validate(const std::vector<Job>& a,const p::Result& ret){
 unsigned workers=0,rooms=0;
 std::int64_t total=0;
 for(int j:ret.jobs){
  const auto& v=a[j];const auto m=(1u<<v.a)|(1u<<v.b),r=1u<<v.room;
  assert(!(m&workers)&&!(r&rooms));workers|=m;rooms|=r;total+=v.score;
 }
 assert(total==ret.exactScore);
}
std::int64_t brute(const std::vector<Job>& a){
 std::int64_t best=0;
 std::function<void(int,unsigned,unsigned,std::int64_t)> go=[&](int j,unsigned u,unsigned r,std::int64_t v){
  if(j==int(a.size())){best=std::max(best,v);return;}
  go(j+1,u,r,v);const auto& q=a[j];unsigned qm=(1u<<q.a)|(1u<<q.b),rm=1u<<q.room;
  if(!(u&qm)&&!(r&rm))go(j+1,u|qm,r|rm,v+q.score);
 };
 go(0,0,0,0);return best;
}
int main(){
 std::vector<Job> jobs={{10,1,3,0,1,0},{7,20,-1,2,2,1}};
 auto out=solve(3,2,jobs,10); validate(jobs,out); assert(out.exactScore==17&&out.jobs.size()==2);
 assert(solve(3,2,jobs,17).jobs.empty());
 assert(solve(3,2,jobs,18).jobs.empty());
 jobs.push_back({22,1,-1,0,0,0});
 jobs.push_back({15,1,-1,0,0,0});
 jobs.push_back({50,4,-1,2,2,0});
 out=solve(3,2,jobs);validate(jobs,out);assert(out.exactScore==50);
 std::mt19937 rng(743620);
 for(int trial=0;trial<4000;++trial){
  int N=5+rng()%6,R=1+rng()%9,J=rng()%18;
  jobs.clear();
  for(int j=0;j<J;++j){
   int a=rng()%N,b=rng()%N,r=rng()%R;
   if(rng()%3==0)b=a;
   jobs.push_back({std::int64_t(1+rng()%100),1,b==a?-1:3,a,b,r});
  }
  auto e=brute(jobs);out=solve(N,R,jobs);
  assert(out.exactScore==e);validate(jobs,out);
  assert(solve(N,R,jobs,e).jobs.empty());
 }
 std::cout<<"odd residual singleton, room collision, exact ties, 4000 exhaustive randomized fixtures passed\n";
}
