"""Offline taped audit. No official tester; --pairs=0, verify through t274."""
import csv,hashlib,json,os,subprocess,sys,tempfile
from collections import Counter
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parent
sys.path.insert(0,str(ROOT/'ahc008_terry_inward_gates'))
from screen import B,ALL,bitmask,flat,flood,near,observed,replay,wave
def simulate(ps,hs,w,cmd):
    p=bitmask(ps); forbidden=p|wave(p)|bitmask(hs)
    wh=w; out=[]
    for q,c in zip(hs,cmd,strict=True):
        v=q if c=='.' else near(q,c.upper())
        assert v is not None
        if c.islower():
            assert not B[v]&forbidden
            wh|=B[v];out.append(q)
        else:out.append(v)
    assert not wh&bitmask(out)
    return wh,flood(bitmask(out),ALL^wh)
def inspect(q):
    case=q['case']; f=ROOT/'ahc008_focus_assets/tools/in'/case
    tp=ROOT/'ahc008_terry_scaffold_audit/tapes'/case
    raw=f.read_bytes(); orig=tp.with_suffix('.actions').read_bytes(); tr=tp.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==q['input_sha']
    assert hashlib.sha256(orig).hexdigest()==q['commands_sha']
    actions=orig.decode().splitlines()
    assert replay(raw.decode(),tr,actions,detailed=True)[0]==int(q['score'])
    prelude=[]; rawl=iter(raw.decode().splitlines())
    n=next(rawl);prelude.append(n);prelude.extend(next(rawl) for _ in range(int(n)))
    m=next(rawl);prelude.append(m);prelude.extend(next(rawl) for _ in range(int(m)))
    with tempfile.TemporaryDirectory() as fd:
        f=Path(fd)/'audit.out'
        z=subprocess.run([str(D/'audit'),'--pairs=0'],input='\n'.join(prelude+tr[1::2])+'\n',
             text=True,capture_output=True,check=True,env=dict(os.environ,AHC008_TERRY_PACK_AUDIT=str(f)))
        assert z.stdout.splitlines()[:275]==actions[:275],case
        rows=f.read_text().splitlines()
    _,history,_=observed(raw,tr)
    stat=Counter(); show=[]
    for z in rows:
        k,*r=z.split()
        if k=='S':
            t,n,ones,oldscore,exactscore,oldcount,newones=map(int,r)
            assert exactscore>=oldscore and t<275
            stat['turns_with_singleton_choices']+=1
            stat['turns_strict_improvement']+=exactscore>oldscore
            if exactscore>oldscore:show.append(dict(t=t,oldscore=oldscore,exactscore=exactscore))
        else:
            assert k=='C'
            t=int(r[0]);alt=r[1];old=actions[t]
            if alt==old:continue
            stat['turns_first_command_changed']+=1
            item=next(s for s in show if s['t']==t)
            item.update(old=old,alt=alt)
            ps,hs,ws=history[t];ps=list(map(flat,ps));hs=list(map(flat,hs));w=bitmask(map(flat,ws))
            at=flood(bitmask(hs),ALL^w)
            oldw,oldh=simulate(ps,hs,w,old)
            neww,newh=simulate(ps,hs,w,alt)
            killed=lambda h:{i for i,p in enumerate(ps) if B[p]&at and not B[p]&h}
            oldids=killed(oldh);newids=killed(newh)
            lost=oldids-newids
            stat['turns_stock_isolates_displaced']+=bool(lost)
            kept_builds=not (oldw&~neww)
            for tok in r[2:]:
                i,g=map(int,tok.split(':')); op=alt[i]
                assert op in 'lr' and near(hs[i],op.upper())==g and B[g]&neww
                if B[g]&oldw:continue
                stat['new_legal_singleton_builds']+=1
                item.setdefault('singleton_gates',[]).append(g)
                inner=near(g,op.upper())
                room=flood(B[inner],ALL^neww) if inner is not None and not B[inner]&neww else 0
                caught={j for j in newids-oldids if B[ps[j]]&room}
                if caught:stat['new_legal_singleton_actual_catch']+=1
                if not lost:
                    stat['new_legal_singleton_no_old_catch_lost']+=1
                    if kept_builds:stat['new_legal_singleton_all_old_builds_preserved']+=1
                    if caught:stat['new_legal_singleton_actual_catch_no_displacement']+=1
                item.setdefault('actual_effects',[]).append(dict(lost=sorted(lost),new=sorted(caught),kept_all_stock_builds=kept_builds))
    return dict(case=case,stats=stat,strict_turns=show)
out=[];total=Counter()
for q in csv.DictReader((ROOT/'ahc008_terry_exact_root/practice100.csv').open()):
    if q['arm']!='terry_independent':continue
    z=inspect(q);total.update(z['stats']);out.append(z)
assert len(out)==100
print(json.dumps(dict(pinned_prefix=275,verified_boards=len(out),totals=total,
    board_counts=Counter(k for z in out for k,v in z['stats'].items() if v),cases=out),indent=2))
