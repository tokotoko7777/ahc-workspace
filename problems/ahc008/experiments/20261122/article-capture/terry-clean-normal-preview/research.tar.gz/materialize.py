"""Recreate previously verified forced Chase exactly, with detached preview sideband."""
import csv,hashlib,json,re,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
P=R/'ahc008_terry_terminal_k8'; X=P/'dev'
sys.path.insert(0,str(P))
from scout import short_prefix,sha,run
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark import replay
TESTER=R/'ahc008_focus_assets/tools/target/release/tester'
assert sha(TESTER.read_bytes())=='f95e04c6adacf82d51352ae1fcd32212ce9ba4d38bfa3e81156ca9580308ebfe'
assert sha((X/'manifest.json').read_bytes())=='5c2877a6733e3bb454096d3f2da17f830899a1bfd047c485b2707a3c6480399d'
assert sha((X/'official.csv').read_bytes())=='54ec41b7e157b8586841a019b4d71ba51ea7f2a289af5e2d3b31904f845bd218'
assert sha((X/"native-context.json").read_bytes())=="1a0c57e5c4825bbfe4e4b086586ca2a8805f773100b11586b082077714110666"
native=json.loads((X/'native-context.json').read_text())
selected=json.loads((X/'manifest.json').read_text())['selected']
forced={r['case']:r for r in csv.DictReader((X/'official.csv').open())if r['arm']=='terry_independent'}
nc={r['case']:r for r in native}; assert len(nc)==len(forced)==len(selected)==100
assert sum(x['mode']==1 for x in native)==69 and all(x['mode'] in x['matched_modes']for x in native)
out=[]; (D/'tapes').mkdir()
for one in selected:
    c=one['case']; f=forced[c]; n=nc[c]; p=(D/'tapes'/c).with_suffix('.actions'); t=p.with_suffix('.trace'); w=p.with_suffix('.preview')
    raw=(X/'selected'/c).read_bytes(); assert sha(raw)==one['sha256']==f['input_sha']==n['sha']
    a,e,code,cost=run([str(TESTER),'env','AHC008_CLEAN_NORMAL_PREVIEW='+str(w),str(D/'observer'),'--pairs=0'],raw,4.0)
    m=re.fullmatch(rb'Score = (\d+)\s*',e); assert code==0 and m and int(m[1])==int(f['score'])
    assert sha(a)==f['commands_sha']
    if n['mode']==1:assert sha(a)==n['command_sha']
    assert short_prefix(b'\n'.join(a.splitlines()[:275])+b'\n')==f['prefix_sha']==one['prefix_sha']==n['prefix']
    preview=[(int(t),c)for t,c in (l.split()for l in w.read_text().splitlines())]
    assert [t for t,c in preview]==list(range(275,300))
    assert all(len(c)==int(f['humans']) and set(c)<=set('.UDLRudlr') for _,c in preview)
    p.write_bytes(a)
    ar,er,cr,_=run([str(TESTER),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(p),str(t)],raw,12)
    assert (ar,er,cr)==(a,e,code)
    assert replay(raw.decode(),t.read_text().splitlines(),a.decode().splitlines(),detailed=True)[0]==int(f['score'])
    out.append(dict(case=c,native_chase=bool(n['mode']),input_sha=sha(raw),actions_sha=sha(a),trace_sha=sha(t.read_bytes()),
        preview_sha=sha(w.read_bytes()),elapsed=cost))
    print(c,flush=True)
(D/'recordings.json').write_text(json.dumps(out,indent=2)+'\n')
