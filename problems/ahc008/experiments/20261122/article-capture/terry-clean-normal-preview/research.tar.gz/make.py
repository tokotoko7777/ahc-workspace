from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
s=(D.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
put(' NormalCount metrics;Decision d;',''' NormalCount metrics;Decision d;
 std::optional<Normal> clean_before_decision;
 const char* obs=std::getenv("AHC008_CLEAN_NORMAL_PREVIEW");
 if(!obs||cap!=0)return 2;
 std::ofstream log(obs);
 if(!log)return 2;''')
put('  if(turn==275)d=decide(s,policy,cap,stop);','''  if(turn==275){
   clean_before_decision.emplace(policy); // No virtual mutation, pristine t275.
   d.chose=true; // Observationally reenact known forced Chase, never intervene.
  }''')
put('  people_step(s,command);','''  if(turn>=275){
   Normal branch=*clean_before_decision; // discard after every single preview
   log<<turn<<' '<<branch.step(s,turn)<<'\\n';
  }
  people_step(s,command);''')
(D/'observer.private.cpp').write_text(s)
