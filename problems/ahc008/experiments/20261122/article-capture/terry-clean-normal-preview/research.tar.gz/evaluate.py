import collections,json,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent; X=R/'ahc008_terry_terminal_k8/dev'
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import command_effect,snapshot,observed,idx,mask,B,cells,sha
def ids_in(reach,pets):
    return sum(B[i]for i,q in enumerate(pets)if reach&B[q])
def points(reach,petmask,N):
    return sum(a.bit_count()<<(N-b.bit_count())for a,b in zip(reach,petmask))
def one(rec,stats):
    c=rec['case'];raw=X/'selected'/c
    a=(D/'tapes'/c).with_suffix('.actions');t=a.with_suffix('.trace');f=a.with_suffix('.preview')
    assert [sha(p)for p in (raw,a,t,f)]==[rec[k]for k in ('input_sha','actions_sha','trace_sha','preview_sha')]
    at=a.read_text().splitlines();text=t.read_text().splitlines();assert at==text[::2]
    _,hist,_=observed(raw.read_bytes(),text)
    hist=[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w)))for p,h,w in hist]
    selected=[]
    previews=[(int(k),s)for k,s in (l.split()for l in f.read_text().splitlines())]
    assert [t for t,s in previews]==list(range(275,300))
    for t,normal in previews:
        stats['examined']+=1
        stock=at[t]
        if normal==stock:stats['command_equal']+=1;continue
        pets,hum,w=hist[t]
        bound,nh=command_effect(hum,w,pets,stock)
        assert (bound,nh)==(hist[t+1][2],hist[t+1][1])
        alt=command_effect(hum,w,pets,normal)
        if not alt:stats['preview_illegal']+=1;continue
        pre=snapshot(w,hum,pets)[0]
        old,oranges,_=snapshot(bound,nh,pets)
        new,nranges,_=snapshot(alt[0],alt[1],pets)
        if (old|pre)&~new:stats['lost_ids']+=1;continue
        if not new&~pre:stats['no_new_live_capture']+=1;continue
        if any(oranges[i]==oranges[j] and nranges[i]!=nranges[j] for i in range(len(hum))for j in range(i)):
            stats['worker_split']+=1;continue
        ps=[ids_in(r,pets)for r in oranges];ns=[ids_in(r,pets)for r in nranges]
        if any(x==y and not ps[i] and ((oranges[i]&~nranges[i]) or ns[i])
               for i,(x,y) in enumerate(zip(stock,normal))):
            stats['unrelated_pet_free_reach']+=1;continue
        oldpts=points(oranges,ps,len(pets));newpts=points(nranges,ns,len(pets))
        if newpts<=oldpts:stats['no_exact_weighted_gain']+=1;continue
        gain=Fraction(newpts-oldpts,len(hum)*(1<<len(pets)))
        mean=Fraction(sum(r.bit_count()for r in nranges)-sum(r.bit_count()for r in oranges),len(hum))
        selected.append(dict(turn=t,stock=stock,preview=normal,gain=str(gain),unweighted_floor_delta=str(mean),
           newly_isolated=list(cells(new&~pre)),extra_vs_stock=list(cells(new&~old))))
    return selected
rows=json.loads((D/'recordings.json').read_text());assert len(rows)==100
assert sum(row['native_chase']for row in rows)==69
statistics={k:collections.Counter()for k in ('native_Chase','forced_only_Chase')}
results={k:{}for k in statistics}
for q in rows:
    g='native_Chase' if q['native_chase'] else 'forced_only_Chase'
    z=one(q,statistics[g])
    if z:results[g][q['case']]=z
summary={}
for k,b in results.items():
    summary[k]=dict(boards=len(b),events=sum(len(x)for x in b.values()),
        first_per_board_effective_floor_gain=str(sum((Fraction(x[0]['gain'])for x in b.values()),Fraction(0))),
        extra_vs_stock_events=sum(bool(x['extra_vs_stock'])for xx in b.values()for x in xx),stats=dict(statistics[k]))
primary=summary['native_Chase']
gate=primary['boards']>=4 and primary['events']>=5 and Fraction(primary['first_per_board_effective_floor_gain'])>=20
(D/'report.json').write_text(json.dumps(dict(summary=summary,gate=gate,witnesses=results),indent=2)+'\n')
print(json.dumps(dict(summary=summary,gate=gate)))
