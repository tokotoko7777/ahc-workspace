#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include <chrono>
#include <iostream>
#include <numeric>
#include <random>
using namespace terry_exact_maps;
namespace e=exact_build;
using std::vector;
constexpr int H=140;
struct Stat {
 int missing=-1, ready=H+1, fill95=H+1, crew=H+1;
 auto key() const {return std::pair{missing,ready};}
};
e::Layout cv(const Terrain& s){
 e::Layout y;for(int p=0;p<V;++p)y.ascii[p]=char(s.cells[p]);
 y.aisleRows=s.aisleRows;y.aisleCols=s.aisleColumns;return y;
}
int dir(char a,const char* s){
 for(int d=0;d<4;++d)if(s[d]==a)return d;return -1;
}
Stat dry(const e::Layout& layout,const Terrain& t,const e::Split& sp,vector<int> h){
 e::Crew run;run.layout=layout;run.planned=sp.makespan;run.q=sp.q;
 e::Board w{};
 std::array<int,W> want{};
 auto cols=t.aisleColumns;std::stable_sort(cols.begin(),cols.end(),[](int a,int b){return std::abs(a-W/2)<std::abs(b-W/2);});
 for(int i=0;i<int(h.size());++i)++want[cols[i%cols.size()]];
 const int targets=t.plannedWalls.count();
 Stat stat;
 for(int tm=0;;++tm){
  int built=0;
  for(int p=0;p<V;++p)built+=w[p]&&t.planned(p);
  std::array<int,W> seen{};
  for(int p:h)++seen[p%W];
  const bool filled=100*built>=95*targets,staffed=seen==want;
  if(filled&&tm<stat.fill95)stat.fill95=tm;
  if(staffed&&tm<stat.crew)stat.crew=tm;
  if(filled&&staffed&&tm<stat.ready)stat.ready=tm;
  if(tm==H||built==targets&&staffed){stat.missing=targets-built;return stat;}
  auto z=run.act_literal(w,h,{});
  auto next=h;
  e::Board yes;
  for(int p=0;p<V;++p)yes[p]=!w[p];
  for(int p:h)yes[p]=0;
  // As in stock sanitize: keep valid move from observed board, then
  // exclude all its endpoints from construction alongside starts.
  for(int i=0;i<int(h.size());++i)if(int d=dir(z.action[i],"URDL");d>=0){
   int p=adjacent(h[i])[d];if(p>=0&&!w[p])next[i]=p,yes[p]=0;
  }
  for(int i=0;i<int(h.size());++i)if(int d=dir(z.action[i],"urdl");d>=0){
   int p=adjacent(h[i])[d];if(p>=0&&yes[p])w[p]=1,yes[p]=0;
  }
  for(int p:next)assert(!w[p]);h.swap(next);
 }
}
int main(){
 std::mt19937 rng(5213729);
 vector<int> perm(V);std::iota(perm.begin(),perm.end(),0);
 std::cout<<"map,m,trial,stockdir,nomin_r,nomin_l,r_missing,l_missing,r_ready,l_ready,r95,l95,r_staff,l_staff,prelude_ms,dry_ms\n";
 for(int g:{2,3}){
  const auto& t=terrain(g);auto layout=cv(t);
  for(int m=7;m<=10;++m)for(int sample=0;sample<6;++sample){
   std::shuffle(perm.begin(),perm.end(),rng);vector<int> h(perm.begin(),perm.begin()+m);
   auto a=std::chrono::steady_clock::now();
   auto r=e::split(layout,h,true),l=e::split(layout,h,false);
   auto b=std::chrono::steady_clock::now();
   assert(std::min(r.makespan,l.makespan)<e::INF);
   Stat rr=dry(layout,t,r,h),ll=dry(layout,t,l,h);
   auto c=std::chrono::steady_clock::now();
   auto ms=[](auto d){return std::chrono::duration<double,std::milli>(d).count();};
   std::cout<<g<<','<<m<<','<<sample<<','<<(r.makespan<=l.makespan?'R':'L')<<','<<r.makespan<<','<<l.makespan<<','
     <<rr.missing<<','<<ll.missing<<','<<rr.ready<<','<<ll.ready<<','<<rr.fill95<<','<<ll.fill95<<','
     <<rr.crew<<','<<ll.crew<<','<<ms(b-a)<<','<<ms(c-b)<<'\n'<<std::flush;
  }
 }
}
