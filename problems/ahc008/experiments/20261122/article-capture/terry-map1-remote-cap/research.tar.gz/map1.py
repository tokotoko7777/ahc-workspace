"""Signed, detached physical census and t−4 Map1 remote-cap evidence."""
import collections,hashlib,itertools,json,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import command_effect,snapshot,observed,idx,mask,B,cells,sha,step,flood,ALL,wave
DEN=12**12
ADJ=[wave(b)for b in B]
chambers=[]
for r in range(3,28,4):
 for m in (9,19):
  center=30*r+m
  body=mask([center+i for i in range(-3,4)]+[center-30,center+30])
  chambers.append((center,center-4,center+4,body))
def recorded(k):
 p=D/(k+'-map1')
 inp={'practice':R/'ahc008_focus_assets/tools/in','fresh':R/'ahc008_terry_first_chase_reuse/default-fresh100/in'}[k]
 for row in json.loads((p/'recordings.json').read_text()):
  case=row['case']; i=inp/case;a=(p/case).with_suffix('.actions');t=a.with_suffix('.trace');z=a.with_suffix('.roles')
  assert [sha(x)for x in (i,a,t,z)]==[row[x]for x in ('input_sha','commands_sha','trace_sha','roles_sha')]
  text=t.read_text().splitlines();c=a.read_text().splitlines();assert c==text[::2]
  kinds,h,_=observed(i.read_bytes(),text)
  H=[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w)))for p,h,w in h]
  spare={}; jobs=collections.defaultdict(list)
  for raw in z.read_text().splitlines():
   ty,u,*v=raw.split();u=int(u);vs=list(map(int,v));assert 0<=u<275
   if ty=='S':
    assert u not in spare and len(vs)==1;spare[u]=vs[0]
   else:
    assert ty=='J' and u in spare and len(vs)==4;jobs[u].append(tuple(vs))
  yield case,kinds,H,c,spare,jobs
def role_ok(t,far,l,r,spare,jobs):
 if spare.get(t,0)>>far&1:return True
 return any(gl==l and gr==r and ((gl>=0 and a==far)or(gr>=0 and b==far))
            for gl,gr,a,b in jobs[t])
def roles(t,l,r,H,c,jobs):
 p,h,w=H[t]
 return [(a,b)for gl,gr,a,b in jobs[t]if (gl,gr)==(l,r) and a!=b and h[a]==l-1 and h[b]==r+1 and c[t][a]=='r' and c[t][b]=='l']
def exact_open(w,center,l,r,body):
 doors=B[l]|B[r]
 return not (w&(body|doors)) and (wave(body)&~(body|w))==doors and flood(B[center],ALL^(w|doors))==body
def dist(start,kind,w):
 a={start:DEN}
 for _ in range(4*kind):
  n=collections.defaultdict(int)
  for p,pay in a.items():
   z=ADJ[p]&~w;d=z.bit_count()
   if d:
    assert pay%d==0
    for q in cells(z):n[q]+=pay//d
   else:n[p]+=pay
  a=n
 assert sum(a.values())==DEN
 return a
def paths(center,l,r,side):
 # Side means retained left/right captured lobe.
 if side==0:return l-1,r+1,center+1,'L','l',mask(range(l+1,center)),center-2
 return r+1,l-1,center-1,'R','r',mask(range(center+1,r)),center+2
def evaluate(t,ch,side,near,far,H,c,spare,jobs):
 center,l,r,body=ch
 near0,far0,stance,d,build,small,safe=paths(center,l,r,side)
 assert t>=4
 p,h,w=H[t-4]
 if h[near]!=near0 or h[far]!=far0:return 'initial_roles',None
 pose=h.copy()
 for u in range(t-4,t):
  p,h,w=H[u]
  if c[u][far].islower() or not role_ok(u,far,l,r,spare,jobs):return 'protected_role',None
  command=list(c[u]);command[far]=d
  stock=command_effect(h,w,p,c[u]); assert stock==(H[u+1][2],H[u+1][1])
  alt=command_effect(pose,w,p,command)
  if not alt or alt[0]!=stock[0]:return 'route_illegal',None
  io,ro,_=snapshot(stock[0],stock[1],p);ia,ra,_=snapshot(alt[0],alt[1],p)
  if io&~ia:return 'lost_ids',None
  if io!=ia or any(x&~y for x,y in zip(ro,ra)):return 'route_reach',None
  pose=alt[1]
 p,h,w=H[t]
 if not exact_open(w,center,l,r,body):return 'not_exact_open',None
 accepted=roles(t,l,r,H,c,jobs)
 if (near,far) not in (accepted if side==0 else [(b,a)for a,b in accepted]):return 'different_factual_closers',None
 assert pose[far]==stance and pose[near]==h[near]
 sw,sh=command_effect(h,w,p,c[t]); assert (sw,sh)==(H[t+1][2],H[t+1][1])
 gates=B[l]|B[r]
 if flood(B[center],ALL^sw)!=body or gates&sw!=gates:return 'unmatched_body',None
 pre=snapshot(w,h,p)[0];ids,reach,_=snapshot(sw,sh,p);caught=ids&~pre&sum(B[i]for i,q in enumerate(p)if body&B[q])
 if not caught:return 'no_factual_new_catch',None
 if any(p[i]!=safe for i in cells(caught)):return 'not_all_safe_core',None
 cmd=list(c[t]);cmd[far]=build
 alt=command_effect(pose,w,p,cmd)
 if not alt:return 'cap_illegal',None
 nw,nh=alt
 if flood(B[safe],ALL^nw)!=small:return 'wrong_small_body',None
 new,nr,_=snapshot(nw,nh,p)
 if ids&~new:return 'lost_ids',None
 if new!=ids:return 'different_ids',None
 if any(reach[i]==reach[j] and nr[i]!=nr[j]for i in range(len(h))for j in range(i)):return 'worker_split',None
 gain=Fraction(sum(n.bit_count()-s.bit_count()for s,n in zip(reach,nr)),len(h))
 if gain<=0:return 'no_area_gain',None
 return 'witness',dict(t=t,center=center,side=side,gain=str(gain),heads=list(cells(caught)),stock=c[t],alternative=''.join(cmd))

def causal(t,kinds,state,command,spare,jobs):
 # No access to any future tape entry or later original role.
 p,h,w=state; post=command_effect(h,w,p,command);assert post
 fixed=post[0];choice=None; cache={}
 for ch in chambers:
  q,l,r,b=ch
  if not exact_open(fixed,q,l,r,b):continue
  for side in (0,1):
   near0,far0,stance,d,cap,small,safe=paths(q,l,r,side)
   near=[i for i,x in enumerate(h)if x==near0]
   far=[i for i,x in enumerate(h)if x==far0 and not command[i].islower() and command[i]!=d and role_ok(t,i,l,r,spare,jobs)]
   if not near or not far:continue
   # Lower-bound distance prunes DP for pets whose speed cannot reach the
   # singleton safe core, while exact DP handles wall topology and parity.
   m=0
   for x,k in zip(p,kinds):
    if k>3 or abs(x//30-safe//30)+abs(x%30-safe%30)>k*4:continue
    if (x,k) not in cache:cache[x,k]=dist(x,k,fixed)
    m+=cache[x,k].get(safe,0)
   if not m:continue
   for a,z in itertools.product(near,far):
    mod=list(command);mod[z]=d
    q0=command_effect(h,w,p,mod)
    if q0 is None or q0[0]!=fixed:continue
    key=(m,-q,-side,-a,-z)
    if choice is None or key>choice[0]:choice=(key,ch,side,a,z)
 return choice

def board(kinds,H,c,spare,jobs):
 stat=collections.Counter(); upper=[]; selected=[]
 for t in range(4,275):
  p,h,w=H[t]; p1,h1,w1=H[t+1]
  for ch in chambers:
   q,l,r,b=ch
   acts=roles(t,l,r,H,c,jobs)
   if not acts:continue
   if not exact_open(w,q,l,r,b) or flood(B[q],ALL^w1)!=b:continue
   a=snapshot(w,h,p)[0]; z=snapshot(w1,h1,p)[0]
   caught=[i for i in cells(z&~a)if b&B[p[i]]]
   if not caught:continue
   stat['canonical_9_events']+=1;stat['canonical_9_heads']+=len(caught)
   stat['canonical_shared_head_events']+=len(caught)>1
   for side in (0,1):
    safe=paths(q,l,r,side)[-1]
    stat['factual_any_safe_core_heads']+=sum(p[i]==safe for i in caught)
    if all(p[i]==safe for i in caught):stat['factual_all_safe_side_rows']+=1
    for a,z in acts:
     near,far=(a,z) if side==0 else (z,a)
     why,v=evaluate(t,ch,side,near,far,H,c,spare,jobs)
     stat['upper_'+why]+=1
     if v:upper.append(v)
 for t in range(271):
  c0=causal(t,kinds,H[t],c[t],spare,jobs)
  if c0 is None:continue
  _,ch,side,a,b=c0;stat['causal_prepared']+=1
  why,v=evaluate(t+4,ch,side,a,b,H,c,spare,jobs);stat['causal_'+why]+=1
  if v:selected.append(v)
 return stat,upper,selected

def credit(rows):
 # Same board: earliest accepted occurrence per physical chamber, at most
 # one event per turn; choose best exact gain then coordinates for overlaps.
 cells_used=set(); turns=set(); accepted=[]
 for r in sorted(rows,key=lambda r:(r['t'],-Fraction(r['gain']),r['center'],r['side'])):
  if r['t'] in turns or r['center']in cells_used:continue
  turns.add(r['t']);cells_used.add(r['center']);accepted.append(r)
 return accepted
def main():
 panels={}; total=[0,0,Fraction(0),0]
 for tag in ('practice','fresh'):
  stats=collections.Counter(); witness={}; upper={}; n=0
  for c,kinds,H,cmd,spare,jobs in recorded(tag):
   n+=1;st,u,v=board(kinds,H,cmd,spare,jobs);stats.update(st)
   u=credit(u);v=credit(v)
   if u:upper[c]=u
   if v:witness[c]=v
  assert n=={'practice':19,'fresh':25}[tag]
  events=sum(len(z)for z in witness.values()); gain=sum((Fraction(r['gain'])for z in witness.values()for r in z),Fraction())
  total[0]+=events;total[1]+=len(witness);total[2]+=gain;total[3]+=stats['causal_lost_ids']
  panels[tag]=dict(original_denominator=100,target_map1=n,stats=dict(stats),upper=upper,causal=witness,
      exact_gain=str(gain),events=events,boards=len(witness))
 ev,b,g,l=total
 out=dict(panels=panels,causal_summary=dict(events=ev,boards=b,gain=str(g),lost=l,pass_gate=ev>=5 and b>=4 and g>=20 and l==0))
 (D/'map1-report.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:{x:v for x,v in z.items()if x not in ('upper','causal')}for k,z in panels.items()}))
 print(out['causal_summary'])
if __name__=='__main__':main()
