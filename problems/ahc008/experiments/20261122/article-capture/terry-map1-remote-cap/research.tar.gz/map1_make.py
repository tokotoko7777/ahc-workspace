from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
s=(D.parent/'ahc008_terry_virtual_chase_absorb/candidate.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='a237f7986e03ba94e98cfb6f1d2059f50d87305f6c8a82b1fa6d4ccd5f013f22'
a=' const auto stop=started+std::chrono::milliseconds(limit_ms);'
assert s.count(a)==1
s=s.replace(a,''' if(!std::getenv("AHC008_OVERSIZE_FIXED")||cap>10000)return 2;
 const auto stop=Clock::time_point::max();''')
(D/'replay.private.cpp').write_text(s)
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int cap_audit_turn=-1;\ninline std::vector<std::string> cap_audit_rows;\n'+s[i:]
a='    hunt::emit(s.people,jobs,legal,booked);'
put(a,a+'''
    if(cap_audit_turn>=0){
     unsigned spare=0;
     for(int i=0;i<m;++i)if(!booked[i])spare|=1u<<i;
     cap_audit_rows.push_back("S "+std::to_string(cap_audit_turn)+" "+std::to_string(spare));
     for(auto j:jobs)cap_audit_rows.push_back("J "+std::to_string(cap_audit_turn)+" "+std::to_string(j.left)+" "+
      std::to_string(j.right)+" "+std::to_string(j.a)+" "+std::to_string(j.b));
    }''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(map==1&&turn<275&&!d.chose)cap_audit_turn=turn;
'''+a+'''
  cap_audit_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* p=std::getenv("AHC008_CAPROLES")){
  std::ofstream f(p);
  for(const auto& row:cap_audit_rows)f<<row<<'\\n';
 }
'''+a)
(D/'map1.private.cpp').write_text(s)
