"""Common realized a237 tapes, not a new policy or interpretation of deadline."""
import csv,hashlib,json,re,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
V=R/'ahc008_terry_virtual_chase_absorb'
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark_cases import run
from benchmark import replay
def sha(b):return hashlib.sha256(b).hexdigest()
T=R/'ahc008_focus_assets/tools/target/release/tester'
pins={'practice':'0bd17793a6742076fc9a8aecb755162e87560cea1a83daa152e602751a1615e0',
      'fresh':'f76ed91d684707dcfd4d4f34052e6fa748933630f2c8d8279391bec9ccfe5911'}
I={'practice':R/'ahc008_focus_assets/tools/in','fresh':R/'ahc008_terry_first_chase_reuse/default-fresh100/in'}
assert sha(T.read_bytes())=='f95e04c6adacf82d51352ae1fcd32212ce9ba4d38bfa3e81156ca9580308ebfe'
k=sys.argv[1]; ledger=V/f'{k}.native.csv'
assert sha(ledger.read_bytes())==pins[k]
records=[r for r in csv.DictReader(ledger.open()) if r['arm']=='terry_independent']
assert len(records)==100
dst=D/(k+'-map1'); dst.mkdir()
rows=[]
for r in records:
 c=r['case']; f=(dst/c).with_suffix('.actions'); trace=f.with_suffix('.trace'); roles=f.with_suffix('.roles')
 a=(I[k]/c).read_bytes();assert sha(a)==r['input_sha']
 if int(r['map'])!=1: continue
 tel=list(map(int,r['telemetry'].split()))
 assert len(tel)==15 and tel[10]==int(r['pairs']) and tel[13]==int(r['mode'])
 with tempfile.TemporaryDirectory()as z:
  l=Path(z)/'log'
  o,e,rc,w=run([str(T),'env','AHC008_OVERSIZE_FIXED=1','AHC008_TERRY_EXACT_LOG='+str(l),'AHC008_CAPROLES='+str(roles),
          str(D/'map1'),f'--pairs={tel[10]}'],a,8)
  g=re.fullmatch(rb'Score = (\d+)\s*',e);assert rc==0 and g,(k,c,rc,e)
  n=list(map(int,l.read_text().split()))
  assert n==tel and int(g[1])==int(r['score']) and sha(o)==r['commands_sha'],(k,c,'native fixed receipt drift',n,tel)
  f.write_bytes(o)
  assert run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(f),str(trace)],a,12)[:3]==(o,e,rc)
  assert replay(a.decode(),trace.read_text().splitlines(),o.decode().splitlines(),detailed=True)[0]==int(g[1])
  rows.append(dict(case=c,map=tel[0],mode=tel[13],pairs=tel[10],input_sha=sha(a),commands_sha=sha(o),
                   trace_sha=sha(trace.read_bytes()),roles_sha=sha(roles.read_bytes()),score=int(g[1]),oversized=[c for c in r['captures'].split(';') if c and int(c.rsplit(':',1)[1])>4]))
 print(c,flush=True)
assert len(rows)=={'practice':19,'fresh':25}[k]
(dst/'recordings.json').write_text(json.dumps(rows,indent=2)+'\n')
