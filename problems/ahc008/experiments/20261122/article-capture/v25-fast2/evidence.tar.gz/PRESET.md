Only add previously exact static open-edge caching and trial-state reuse
to already adopted v25-fast. Compare sequential same-case wait4 and actions.
Advance from original dev30×2 on ≥2% additional solver CPU reduction and
exact actions. If promising, test both broad 100 against v25-fast, require
≥2% reduction in each, exact first 275, official plus replay all, no policy
change. Any late mismatch must be explained under original timing budget.
No gain in score or search count inferred; no main merge.
