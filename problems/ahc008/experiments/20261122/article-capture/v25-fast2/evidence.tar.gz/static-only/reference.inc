inline Paths reference_sample_paths(const State& initial,const Simulator& sim,int trials,int horizon,const DogWeights* belief=nullptr){
 Paths p;
 p.n=initial.pets.size();p.trials=std::clamp(trials,0,128);p.horizon=std::clamp(horizon,0,25);
 p.pos.resize(p.trials*(p.horizon+1));
 // Same terrain/humans in this phase: reuse BFS across all trials and ETAs.
 Simulator::Distances distances(sim,initial);
 for(int k=0;k<p.trials;++k){
  State s=initial;sim.initial_dogs(s,k,belief);
  for(int h=0;h<=p.horizon;++h){
   auto& out=p.pos[k*(p.horizon+1)+h];
   for(int i=0;i<p.n;++i)out[i]=s.pets[i].pos;
   if(h==p.horizon)break;
   for(int i=0;i<p.n;++i)sim.jump(s.pets[i],s,distances,i,k);
   ++s.turn;
  }
 }
 return p;
}
