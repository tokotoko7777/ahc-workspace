// Only used by sample_paths: wall and humans are immutable across its
// trial simulations. Compact neighbor order is exactly Simulator::nb order.
class StaticSampleSteps {
 struct Neighbors {std::array<int16_t,4> cell; uint8_t size;};
 const Simulator& sim;
 const Board& wall;
 std::array<Neighbors,V> entry;
 std::array<uint8_t,V> done{};
 const Neighbors& neighbors(int u){
  auto& row=entry[u];
  if(!done[u]){
   done[u]=1;row.size=0;
   for(int q:sim.nb[u])if(q>=0&&!wall[q])row.cell[row.size++]=q;
  }
  return row;
 }
public:
 StaticSampleSteps(const Simulator& ss,const Board& ww):sim(ss),wall(ww){}
 template<class Distance>
 void jump(Pet& p,const State& s,Distance& distances,int i,int trial){
  auto random_step=[&](int channel){
   const auto& r=neighbors(p.pos);
   if(r.size)p.pos=r.cell[sim.choice(r.size,trial,s.turn,i,channel)];
  };
  if(p.type!=4){
   int speed=p.type==5?2:std::clamp(p.type,1,3);
   for(int k=0;k<speed;++k)random_step(2+k);
   return;
  }
  const int m=s.humans.size();
  int target=p.target;
  if(target<0||target>=m||distances(target)[p.pos]==0||distances(target)[p.pos]==INF){
   int valid[MH],k=0;
   for(int j=0;j<m;++j){int d=distances(j)[p.pos];if(d>0&&d<INF)valid[k++]=j;}
   if(!k){p.target=-1;random_step(2);return;}
   target=valid[sim.choice(k,trial,s.turn,i,0)];
  }
  p.target=target;
  auto const& d=distances(target);
  const auto& row=neighbors(p.pos);
  int n=0,valid[4];
  for(int j=0;j<row.size;++j){int q=row.cell[j];if(d[q]<d[p.pos])valid[n++]=q;}
  if(n)p.pos=valid[sim.choice(n,trial,s.turn,i,1)];
  if(p.pos==s.humans[target])p.target=-1;
  random_step(2);
  if(p.pos==s.humans[target])p.target=-1;
 }
};
