# Exact static-path sample optimization

Prepared source (not compiled or run while root's timed comparison is active).
    python ahc008_v25_static_samples/make.py ahc008_v24_standby_early_seam/record/solve-v25.cpp ahc008_v25_static_samples/solve.cpp
    cd ahc008_v25_static_samples
    g++ -std=c++23 solve.cpp -o solve
    g++ -std=c++23 unit.cpp -o unit && ./unit

Only the statically held board/human sample_paths changes. Allocate/copy State once, then copy exactly the mutable pets (including latent target) and reset turn per trial; initial_dogs still receives unchanged belief/initial turn and same trial counter. Lazy static open neighbors filter the same immutable wall mask in exactly the original Simulator::nb order. Dynamic Simulator::jump and step, RNG draw/channels, unknown dog priors and distance cache/queue remain unchanged. The static selection code deliberately mirrors the original with no behavior change. Define AHC008_SAMPLE_STATE_ONLY at compilation if comparing the simpler reuse-only ablation; the primary standalone needs no flag.

Generator verifies stock v25's SHA and derives the reference fixture sampler literally from the original implementation (only its name changes). Unit compares full output byte buffers and path metadata on 3,500 deterministic worlds: densities up to 99%, duplicate entities, 0–10 humans, 0–20 pets, all five types, heavy dog mixtures, out-of-range/reachable targets, null/zero/mixed dog weights, isolated cells, zero and clamped trial/horizon requests. It also compares internal target/position/type after each real vs static jump. No sampling seeds, caller policy or geometry change. End-to-end exact official action/score equality and uninstrumented sequential timing are separate from this unit; global time-dependent search can change without sampled path differences.
