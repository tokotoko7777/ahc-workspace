from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);d=p.read_bytes()
assert hashlib.sha256(d).hexdigest()=='46f210cc5dd50b8a6088724861ae5c2b044d08edb109a891ee217352730fcb84'
s=d.decode()
a=s.index('inline Paths sample_paths(')
b=s.index('struct Window {',a)
stock=s[a:b]
Path(__file__).with_name('reference.inc').write_text(stock.replace('Paths sample_paths(', 'Paths reference_sample_paths(',1))
def rep(t,old,new):
 assert t.count(old)==1,old
 return t.replace(old,new)
fast=rep(stock,''' Simulator::Distances distances(sim,initial);
 for(int k=0;k<p.trials;++k){
  State s=initial;sim.initial_dogs(s,k,belief);''',''' Simulator::Distances distances(sim,initial);
 State s=initial;
#ifndef AHC008_SAMPLE_STATE_ONLY
 StaticSampleSteps steps(sim,initial.wall);
#endif
 for(int k=0;k<p.trials;++k){
  std::copy(initial.pets.begin(),initial.pets.end(),s.pets.begin());
  s.turn=initial.turn;
  sim.initial_dogs(s,k,belief);''')
fast=rep(fast,'''   for(int i=0;i<p.n;++i)sim.jump(s.pets[i],s,distances,i,k);''','''#ifdef AHC008_SAMPLE_STATE_ONLY
   for(int i=0;i<p.n;++i)sim.jump(s.pets[i],s,distances,i,k);
#else
   for(int i=0;i<p.n;++i)steps.jump(s.pets[i],s,distances,i,k);
#endif''')
o.write_text(s[:a]+Path(__file__).with_name('static.inc').read_text()+fast+s[b:])
