#define main original_entry
#include "solve.cpp"
#undef main
namespace terry_mc {
#include "reference.inc"
}
namespace sampler_test {
using namespace terry_mc;
void check(const State& s,const Simulator& sim,int n,int h,const DogWeights* belief){
 auto old=reference_sample_paths(s,sim,n,h,belief);
 auto fresh=sample_paths(s,sim,n,h,belief);
 assert(old.n==fresh.n&&old.trials==fresh.trials&&old.horizon==fresh.horizon);
 assert(old.pos.size()==fresh.pos.size()&&old.pos==fresh.pos);
 if(!old.pos.empty())assert(std::memcmp(old.pos.data(),fresh.pos.data(),
       old.pos.size()*sizeof(old.pos[0]))==0);
}
void fieldCheck(State a,const Simulator& sim,int trial,const DogWeights* weights){
 State b=a;
 sim.initial_dogs(a,trial,weights);
 sim.initial_dogs(b,trial,weights);
 Simulator::Distances da(sim,a),db(sim,b);
 StaticSampleSteps step(sim,b.wall);
 for(int t=0;t<4;t++){
  for(int i=0;i<int(a.pets.size());i++){
   sim.jump(a.pets[i],a,da,i,trial);
   step.jump(b.pets[i],b,db,i,trial);
   auto x=a.pets[i],y=b.pets[i];
   assert(x.pos==y.pos&&x.type==y.type&&x.target==y.target);
  }
  ++a.turn;++b.turn;
 }
}
void run(){
 std::mt19937_64 rng(0x35bfe77ae24);
 for(int it=0;it<3500;it++){
  Simulator sim(rng());
  State s;s.turn=rng()%300;
  int n=rng()%(MP+1),m=rng()%(MH+1);
  if(it%9==0)m=0;
  int wallPct=(it%7==0)?0:(it%7==1?99:rng()%94);
  std::vector<int> open;
  for(int i=0;i<terry_mc::V;i++){
   s.wall[i]=rng()%100<wallPct;
   if(!s.wall[i])open.push_back(i);
  }
  if(open.empty()){s.wall[444]=0;open.push_back(444);}
  for(int i=0;i<m;i++)s.humans.push_back(open[rng()%open.size()]);
  DogWeights belief{};
  for(int i=0;i<n;i++){
   int kind=(it%5==0)?4:(rng()%5+1);
   s.pets.push_back({open[rng()%open.size()],kind,int(rng()%(m+3))-1});
   for(int j=0;j<=m;j++)belief[i][j]=it%11==0?0.f:float(int(rng()%21)-5)/7.f;
  }
  auto w=it%3==0?nullptr:&belief;
  int ntrial=(it%29==0)?145:((it%9==0)?0:int(rng()%18));
  int horizon=(it%31==0)?28:((it%8==0)?0:int(rng()%9));
  if(it%101==0){ntrial=-1;horizon=-1;}
  check(s,sim,ntrial,horizon,w);
  fieldCheck(s,sim,it,w);
 }
}
}
int main(){sampler_test::run();}
