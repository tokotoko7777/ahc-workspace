# 10×10 necessary-condition relaxation, one run

No backbone, axis requirement, connected exterior or winding in the MILP.
All 19 one-sided grid orientations generated as connected tetromino sets
up to translation only (reflections retained). Choose any two distinct
physical boundary sites as doors, require a body endpoint of each parity
not orthogonally adjacent to either gate; all remaining orthogonal
boundary sites are planned walls. Each door must have a neighboring
exterior stance, distinct within a room, using conditional local Hall
constraints. Different rooms may share stances. Exact local exclusivity
for body/door/wall/exterior. Every wall must service some selected brace.
MILP cap 25 walls and exactly nine rooms; any locally feasible ≥9 set can
drop rooms, delete walls not required by the surviving bodies, and only
increase guard availability, so nine suffices as a necessary condition.
At least one selected room's canonical translated anchor at (0,0) by
global translation, no orientation restriction.

No Python dense two-dimensional model. ≤85,500 room columns (19 shapes
× C(10,2) doors × 100 offsets), +200 wall/exterior columns. Max
4,000,000 sparse nonzeros in array-backed triplets (64 MiB for raw 16
bytes/nonzero, plus converted sparse matrices, solver internals and
Python guard/brace structures); checked during row assembly; template
shape/type setup is constant. Check ~25s build deadline at anchor/row
group boundaries. Actual solver deadline ≤170s and ends by ~168s after
Python start to leave certificate time. External ≤180s, one model call:
```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout -k 1s 179s \
  python3 -u ahc008_terry_periodic_relaxation/search.py
```
Process exit 124/137 means external cap (note last printed stage).
SciPy/HiGHS status 2 infeasibility is restricted to the stated
necessary-condition local packing on a 10×10 period. Status 1 or build/
external cap means search limit, no infeasibility claim. Any incumbent
undergoes independent exact local physical verification from occupancy,
then separate open, every one-lock, and all-locked component floods.
Lift edge discrepancies on the all-locked exterior must generate two
linearly independent winding vectors. If either verifier fails, stop
without another solve. On physically positive torus only, attempt all
100 bounded 30×30 phases, same walls, keeping full body and gate pairs,
recomputing available physical guard pairs and checking ≥75 rooms ≤225
walls and all closures without wrap; dihedral maps of phases are
isomorphic. This does not cover construction/score or claim a bounded
negative from losing edge rooms in a single witness. No fixture, game
input, live testing, alternate thresholds or repeat after first outcome.
