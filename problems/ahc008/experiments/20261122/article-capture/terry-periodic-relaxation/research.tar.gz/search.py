#!/usr/bin/env python3
import itertools as it
import json
from array import array
from collections import defaultdict, deque
from time import monotonic

T=10
D=((1,0),(-1,0),(0,1),(0,-1))
CELLS=list(it.product(range(T),repeat=2))
def add(a,b): return a[0]+b[0],a[1]+b[1]
def norm(a): return tuple(sorted((r-min(x for x,y in a),c-min(y for x,y in a)) for r,c in a))
def nbr(p): return {add(p,d) for d in D}
def mod(p): return p[0]%T,p[1]%T
def idx(p): return (p[0]%T)*T+p[1]%T

def types():
    ss={((0,0),)}
    for _ in range(3):
        ss={norm(set(b)|{q}) for b in ss for p in b for q in nbr(p)-set(b)}
    assert len(ss)==19
    for b in sorted(ss):
        b=set(b); bd=set().union(*(nbr(p) for p in b))-b
        assert len(bd)<=10
        for a,c in it.combinations(sorted(bd),2):
            g={a,c}; z=bd-g
            safe=b-nbr(a)-nbr(c)
            if {sum(p)%2 for p in safe}!={0,1}: continue
            ga=nbr(a)-b-g-z; gc=nbr(c)-b-g-z
            if not ga or not gc or len(ga|gc)<2: continue
            yield frozenset(b),frozenset(g),frozenset(z),frozenset(ga),frozenset(gc)

def solve(start):
    import numpy as np
    from scipy.optimize import milp, Bounds, LinearConstraint
    from scipy.sparse import coo_matrix
    tt=list(types())
    n=len(tt)*100
    if n>85500:
        print(json.dumps(dict(stop='BUILD_TEMPLATE_CAP',n=n)),flush=True); return
    w=lambda p:n+p
    e=lambda p:n+100+p
    own=[array('i') for _ in CELLS]; brace=[array('i') for _ in CELLS]
    halls=defaultdict(lambda:array('i'))
    for a,p in enumerate(CELLS):
        for j,(b,g,z,h1,h2) in enumerate(tt):
            i=a*len(tt)+j
            for q in b|g: own[idx(add(q,p))].append(i)
            for q in z: brace[idx(add(q,p))].append(i)
            hh=[]
            for h in (h1,h2):
                hh.append((tuple(sorted(idx(add(q,p)) for q in h)),1))
            if h1&h2:
                hh.append((tuple(sorted(idx(add(q,p)) for q in h1|h2)),2))
            for h in set(hh): halls[h].append(i)
        if monotonic()-start>=25:
            print(json.dumps(dict(stop='BUILD_CLOCK_CAP')),flush=True); return
    row=array('i'); col=array('i'); dat=array('d'); low=array('d'); high=array('d')
    I=float('inf')
    def con(vals,lo=-I,hi=I):
        j=len(low)
        for i,v in vals: row.append(j);col.append(i);dat.append(v)
        low.append(lo);high.append(hi)
    con(((i,1) for i in range(n)),9,9)
    con(((w(p),1) for p in range(100)),hi=25)
    con(((i,1) for i in range(len(tt))),1)
    for p in range(100):
        con(it.chain(((i,1) for i in own[p]),((w(p),1),(e(p),1))),1,1)
        con(it.chain(((i,1) for i in brace[p]),((w(p),-4),)),hi=0)
        con(it.chain(((i,-1) for i in brace[p]),((w(p),1),)),hi=0)
    # Keep exact conditional rows per selecting template (shared site keys).
    for (sites,k),uses in sorted(halls.items()):
        for i in uses:
            con(it.chain(((e(p),1) for p in sites),((i,-k),)),0)
        if monotonic()-start>=25 or len(dat)>4_000_000:
            print(json.dumps(dict(stop='BUILD_SPARSE_CAP',elapsed=monotonic()-start,nnz=len(dat))),flush=True); return
    print(json.dumps(dict(build='complete',shapes=19,types=len(tt),placements=n,
                          variables=n+200,rows=len(low),nnz=len(dat),elapsed=monotonic()-start)),flush=True)
    a=coo_matrix((np.frombuffer(dat,dtype=np.float64),
                 (np.frombuffer(row,dtype=np.int32),np.frombuffer(col,dtype=np.int32))),
                shape=(len(low),n+200)).tocsc()
    end=168-(monotonic()-start)
    if end<=0:
        print(json.dumps(dict(stop='BUILD_LEFT_NO_SOLVE_BUDGET')),flush=True); return
    raw=milp(np.zeros(n+200),integrality=np.ones(n+200,dtype=np.uint8),
             bounds=Bounds(np.zeros(n+200),np.ones(n+200)),
             constraints=LinearConstraint(a,np.frombuffer(low,dtype=np.float64),
                                           np.frombuffer(high,dtype=np.float64)),
             options=dict(time_limit=min(170,end),presolve=True,threads=1))
    print(json.dumps(dict(solver_status=int(raw.status),message=raw.message,
                          incumbent=raw.x is not None,elapsed=monotonic()-start)),flush=True)
    if raw.x is not None:
        if np.max(abs(raw.x-np.rint(raw.x)))>1e-6: raise AssertionError("fractional incumbent")
        rooms=[]
        for i in np.flatnonzero(raw.x[:n]>.5):
            anchor=CELLS[i//len(tt)]
            rooms.append(tuple({add(p,anchor) for p in part} for part in tt[i%len(tt)][:3]))
        yield rooms,{CELLS[i] for i in range(100) if raw.x[w(i)]>.5}

def verify(n, rooms, walls, torus, physical):
    cell=set(it.product(range(n),repeat=2))
    def near(p):
        return {((r%n,c%n) if torus else (r,c)) for r,c in nbr(p)}&cell
    def flood(root,allow):
        got={root}; q=deque([root])
        while q:
            for a in near(q.popleft()):
                if a in allow and a not in got: got.add(a); q.append(a)
        return got
    assert walls<=cell and len(walls)<=(25 if torus else 225)
    assert len(rooms)>=(9 if torus else 75)
    named=set().union(*(b|g for b,g,z in rooms))
    assert len(named)==6*len(rooms) and named<=cell-walls
    blank=cell-walls; ext=blank-named
    gates=set().union(*(g for b,g,z in rooms))
    guards=[]
    for b,g,z in rooms:
        assert len(b)==4 and len(g)==2 and flood(min(b),b)==b
        assert (set().union(*(near(p) for p in b))-b)==g|z
        assert z<=walls
        a,c=sorted(g)
        safe=b-near(a)-near(c)
        assert {sum(p)%2 for p in safe}=={0,1}
        opts=sorted((p,q) for p in near(a)&ext for q in near(c)&ext if p!=q)
        assert opts
        guards.append(opts[0])
    if not physical: return
    root=min(ext)
    assert flood(root,blank)==blank
    assert flood(root,ext)==ext
    for b,g,z in rooms:
        assert flood(min(b),blank-g)==b
        assert flood(min(b),blank-gates)==b
        assert flood(root,blank-g)==blank-g-b
    if torus:
        # Track actual periodic lift coordinates through a spanning tree.
        # Every non-tree discrepancy is a winding in the closed exterior.
        lift={root:root}; q=deque([root]); wind=set()
        while q:
            p=q.popleft()
            for d in D:
                np=(p[0]+d[0])%n,(p[1]+d[1])%n
                if np not in ext: continue
                expected=add(lift[p],d)
                if np not in lift: lift[np]=expected; q.append(np)
                else:
                    v=(expected[0]-lift[np][0],expected[1]-lift[np][1])
                    if v!=(0,0):
                        assert v[0]%n==0 and v[1]%n==0
                        wind.add((v[0]//n,v[1]//n))
        assert any(a*d-b*c!=0 for (a,b),(c,d) in it.combinations(wind,2))
    return [list(pair) for pair in guards]

def draw(n, rooms, walls):
    out=[['.']*n for _ in range(n)]
    for r,c in walls: out[r][c]='#'
    for b,g,z in rooms:
        for r,c in b: out[r][c]='b'
        for r,c in g: out[r][c]='g'
    return [''.join(row) for row in out]

def bounded(rooms,walls):
    inside=lambda p: 0<=min(p) and max(p)<30
    cells=list(it.product(range(30),repeat=2))
    for ph in CELLS:
        tw={mod(add(q,ph)) for q in walls}
        bw={p for p in cells if mod(p) in tw}
        br=[]
        for i,j in it.product(range(-3,4),repeat=2):
            shift=add(ph,(i*T,j*T))
            for rb,rg,rz in rooms:
                b,g,z=({add(p,shift) for p in part} for part in (rb,rg,rz))
                if all(map(inside,b|g)):
                    br.append((b,g,{p for p in z if inside(p)}))
        if len(br)<75: continue
        try: guards=verify(30,br,bw,False,True)
        except AssertionError: continue
        return dict(phase=ph,rooms=len(br),walls=len(bw),board=draw(30,br,bw),
                    guards=guards)
    return None

def main():
    start=monotonic()
    for raw,walls in solve(start):
        rooms=[tuple(set(map(mod,s)) for s in rr) for rr in raw]
        try: verify(T,rooms,walls,True,False)
        except AssertionError:
            print(json.dumps(dict(local_verified=False))); return
        print(json.dumps(dict(local_verified=True,rooms=len(rooms),walls=len(walls),
                              board=draw(T,rooms,walls))),flush=True)
        try: guards=verify(T,rooms,walls,True,True)
        except AssertionError:
            print(json.dumps(dict(torus_physical_verified=False))); return
        print(json.dumps(dict(torus_physical_verified=True,guards=guards)),flush=True)
        r=bounded(raw,walls)
        print(json.dumps(dict(bounded_verified=r is not None,result=r)),flush=True)
if __name__=='__main__': main()
