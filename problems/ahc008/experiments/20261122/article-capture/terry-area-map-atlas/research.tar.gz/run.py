"""All original maps, same 100 fresh cases, exact Normal-only official replay."""
import csv,hashlib,json,re,subprocess,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
P=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(P),str(P/'experiments/20261122')]
from benchmark_cases import run
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood
T=R/'ahc008_focus_assets/tools/target/release/tester'
S=R/'ahc008_terry_incoming_shadow/live'
A=D/'atlas100'
manifest={v.split()[1].removeprefix('in/'):v.split()[0]for v in (A/'SHA256SUMS').read_text().splitlines()}
def sha(raw):return hashlib.sha256(raw).hexdigest()
rows=[]
for i,f in enumerate(sorted((A/'in').glob('*.txt'))):
 raw=f.read_bytes(); sha0=sha(raw)
 assert sha0==manifest[f.name]
 ref=int(subprocess.run([str(D/'selector')],input=raw,capture_output=True,check=True,timeout=2).stdout)
 assert 0<=ref<5
 for m in ([(j+i)%5 for j in range(5)]):
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp); acts=d/'actions'; tape=d/'tape'; log=d/'log'
   out,err,rc,wall=run([str(T),'env','AHC008_TERRY_EXACT_LOG='+str(log),str(S),'--pairs=0',f'--map={m}'],raw,4.5)
   p=re.fullmatch(rb'Score = (\d+)\s*',err)
   assert rc==0 and p,(f,m,err,rc)
   acts.write_bytes(out)
   rr,re_,rx,_=run([str(T),sys.executable,str(P/'benchmark_cases.py'),'--playback',str(acts),str(tape)],raw,12)
   assert (rr,re_,rx)==(out,err,rc)
   t=tape.read_text().splitlines();action=out.decode().splitlines()
   score=replay(raw.decode(),t,action,detailed=True)[0]
   assert score==int(p[1])
   k,hist,_=observed(raw,t)
   ps,hs,ws=hist[-1]
   op=ALL^sum(B[idx(q)] for q in ws)
   areas=[flood(B[idx(q)],op)for q in hs]
   live=0
   for x in areas:live|=x
   residue=sum(bool(B[idx(q)]&live)for q in ps)
   tile=sum(x.bit_count() for x in areas)
   tele=log.read_text().split()
   assert int(tele[0])==m and int(tele[10])==0 and int(tele[-1])==score
   rows.append(dict(case=f.name,sha=sha0,ref=ref,map=m,human_count=len(hs),
       command_sha=sha(out),score=score,tile=tile,residue=residue,wall=wall,
       x_built=int(tele[2]),h123_last_mode=int(tele[13])))
 with (D/'atlas.csv').open('w') as o:
  w=csv.DictWriter(o,rows[0].keys());w.writeheader();w.writerows(rows)
 print(f.name,ref,flush=True,file=sys.stderr)
assert len(rows)==500
hold={}
for z in rows:hold.setdefault(z['case'],{})[z['map']]=z
gain=[];nfull=0
for f,z in sorted(hold.items()):
 x=z[z[0]['ref']]
 if x['residue']:continue
 nfull+=1
 full=[u for u in z.values() if u['residue']==0]
 y=max(full,key=lambda u:(u['tile'],u['map']==x['map'],-u['map']))
 if y['tile']>x['tile']:
  gain.append(dict(case=f,m=x['human_count'],stock=x['map'],oracle=y['map'],
    gain=(y['tile']-x['tile'])/x['human_count']))
s=sum(c['gain']for c in gain)
print(json.dumps(dict(total=100,tester_runs=500,reference_full=nfull,witnesses=len(gain),floor_gain_sum=s,
 gate=s>=1000 and len(gain)>=20,by_map=[dict(map=m,full=sum(1 for x in rows if x['map']==m and not x['residue']),
  max_wall=max(x['wall'] for x in rows if x['map']==m))for m in range(5)],examples=gain),indent=2))
