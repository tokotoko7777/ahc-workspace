"""Diagnostic decomposition of hindsight gains, not a rank predictor."""
import csv
import json
import collections
from pathlib import Path
D=Path(__file__).resolve().parent
boards=collections.defaultdict(dict)
for x in csv.DictReader((D/'atlas.csv').open()):
    for k in ('ref','map','human_count','tile','residue','x_built'):
        x[k]=int(x[k])
    boards[x['case']][x['map']]=x
assert len(boards)==100 and all(len(x)==5 for x in boards.values())
out=collections.defaultdict(collections.Counter)
by=collections.Counter()
full=[]
for f,opt in boards.items():
 x=opt[opt[0]['ref']]
 key=(x['map'],x['human_count'])
 g=out[key]
 g['total']+=1
 if x['residue']:
  continue
 g['stock_full']+=1
 y=max([z for z in opt.values()if z['residue']==0],
       key=lambda z:(z['tile'],z['map']==x['map'],-z['map']))
 if y['tile']<=x['tile']:
  continue
 delta=(y['tile']-x['tile'])/x['human_count']
 g['positive']+=1
 g['floor_gain']+=delta
 g['planned_wall_savings']+=x['x_built']-y['x_built']
 by[f"{x['map']}->{y['map']}"]+=1
 full.append(delta)
print(json.dumps(dict(by_pair=by,strata=[dict(map=m,humans=n,**c)for (m,n),c in sorted(out.items())],
  wins_ge10=sum(d>=10 for d in full),wins_ge20=sum(d>=20 for d in full)),indent=2))
