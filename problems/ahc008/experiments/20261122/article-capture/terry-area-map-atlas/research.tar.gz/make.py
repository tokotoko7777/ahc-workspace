import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
key=' if(map<0)map=terry_exact_selector::choose(m,counts);'
assert s.count(key)==1
s=s[:s.index(key)]+key+"\n std::cout<<map<<'\\n';return 0;\n}\n"
(d/'selector.private.cpp').write_text(s)
