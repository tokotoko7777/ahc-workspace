# Floor ceiling in the original map family (hindsight, not a selector)

Current accepted incoming version preserved. Distinct uniform generated
atlas100. On every exact same case, run each of the five original fixed
maps using the identical accepted Normal controller and zero late Monte
Carlo pairs. This is a fixed semantic testbed, not new selection logic
or a comparison to normal-clock official practice. Reference per case
is the existing model's original map choice on its initial features;
statistics others can include all layouts only for this diagnostic.
No use of future results, scores or case IDs in any solver's decisions.
Verify all 500 outputs with official tester, official playback and
independent replay, serial and one equal fixed configuration. Use
input/output/score hashes; report invalid, incomplete or timed out cases
as failure, not zero favorable opportunities.

Among cases where the preset mapped reference (Normal-only) catches
everything, find the highest average retained worker floor across
layouts that also catch everything, allowing original if tied. This is
the optimistic retrospective area ceiling among tested existing maps,
not expected deployable gain. No improvement credited for baseline
non-full cases. Frozen bar for pursuing independent causal selector
research: ≥1,000 total summed mean-floor gains across these 100 cases
and ≥20 boards with positive gains; no widening based on this set if
it fails. Separately report raw/useful and floor 5-map distributions,
where gains are concentrated and if safe/non-full choices coexist.
Two paired virtual simulations under 900ms already failed a separate
preflight; do not change that scout's budget, shape or arm count.
Passing only justifies a new cheap feature/geometry hypothesis and
fresh held evaluation, not a ranked result, map choice or main merge.
