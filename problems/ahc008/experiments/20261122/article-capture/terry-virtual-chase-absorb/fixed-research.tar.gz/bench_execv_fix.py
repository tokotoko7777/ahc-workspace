"""Serial alternating fixed-work exact speed + shared independent replay."""
import csv,sys,re,tempfile,json,hashlib,shutil
from pathlib import Path
from statistics import median
D=Path(__file__).resolve().parent;R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark_cases import run
from benchmark import replay
T=R/'ahc008_focus_assets/tools/target/release/tester'; TIME=R/'ahc008_terry_speed/time'
A=R/'ahc008_terry_split_bound/solve';B=D/'candidate'
src,ledger,dst=(Path(p)for p in sys.argv[1:]);rows=[r for r in csv.DictReader(ledger.open())if r['arm']=='terry_independent'];assert len(rows)==100
out=[]
for i,r in enumerate(rows):
 name=r['case']; raw=(src/name).read_bytes(); assert hashlib.sha256(raw).hexdigest()==r['input_sha']
 mark=list(map(int,r['telemetry'].split())); assert len(mark)==15
 with tempfile.TemporaryDirectory()as q:
  q=Path(q); cpu=q/'cpu'; tel=q/'tel'; act=q/'act'; tape=q/'trace'; arms=[('baseline',A),('candidate',B)]
  for tag,binary in (arms if i%2==0 else arms[::-1]):
   args=[str(T),str(TIME),str(cpu),shutil.which('env'),'AHC008_TERRY_EXACT_LOG='+str(tel),str(binary),f'--pairs={mark[10]}']
   a,e,rc,w=run(args,raw,4.5)
   assert rc==0 and e.strip()==('Score = '+r['score']).encode()
   assert hashlib.sha256(a).hexdigest()==r['commands_sha'] and list(map(int,tel.read_text().split()))==mark,(name,tag)
   out.append(dict(case=name,arm=tag,score=int(r['score']),draws=mark[10],
       normal_sum=mark[11],chase_sum=mark[12],mode=mark[13],commands_sha=r['commands_sha'],cpu_us=int(cpu.read_text()),wall=w))
  act.write_bytes(a)
  assert run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(act),str(tape)],raw,12)[:3]==(a,e,rc)
  assert replay(raw.decode(),tape.read_text().splitlines(),a.decode().splitlines(),detailed=True)[0]==int(r['score'])
 with dst.open('w')as f:
  wr=csv.DictWriter(f,out[0].keys());wr.writeheader();wr.writerows(out)
 print(name,flush=True)
z={}
for label, eligible in [('all',lambda r:True),('positive_rollout',lambda r:r['draws']>0)]:
 a,b=([r for r in out if r['arm']==k and eligible(r)]for k in ('baseline','candidate'))
 u,v=(sum(r['cpu_us']for r in arm)for arm in (a,b))
 z[label]=dict(n=len(a),baseline_us=u,candidate_us=v,reduction=1-v/u,max_wall=max(r['wall']for r in a+b))
z['pass']=z['all']['reduction']>=.02 and z['positive_rollout']['reduction']>0 and z['all']['max_wall']<2.95
dst.with_suffix('.json').write_text(json.dumps(z,indent=2)+'\n')
print(json.dumps(z))
if not z['pass']:raise SystemExit(3)
