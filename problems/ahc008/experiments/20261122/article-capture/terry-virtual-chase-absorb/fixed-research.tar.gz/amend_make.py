from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
base=(D.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(base.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
a=' const auto stop=started+std::chrono::milliseconds(limit_ms);'
b=''' const bool frozen_audit=std::getenv("AHC008_VIRTUAL_ABSORB_FIXED")!=nullptr;
 if(frozen_audit&&cap>10000)return 2;
 const auto stop=frozen_audit?Clock::time_point::max():started+std::chrono::milliseconds(limit_ms);'''
for stem,src in [('baseline_fixed',base),('candidate_fixed',(D/'candidate.private.cpp').read_text())]:
 assert src.count(a)==1
 (D/f'{stem}.private.cpp').write_text(src.replace(a,b))
