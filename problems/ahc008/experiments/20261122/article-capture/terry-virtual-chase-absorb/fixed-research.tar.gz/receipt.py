"""After clearance: collect deterministic receipt on known fixed K8 work."""
import collections,csv,hashlib,json,re,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
K=R/'ahc008_terry_terminal_k8';P=K/'dev'
sys.path.insert(0,str(K))
from scout import run,short_prefix
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark import replay
T=R/'ahc008_focus_assets/tools/target/release/tester'
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=P/'manifest.json'
assert sha(manifest.read_bytes())=='5c2877a6733e3bb454096d3f2da17f830899a1bfd047c485b2707a3c6480399d'
shadow={r['case']:r for r in json.loads((P/'shadow.json').read_text())}
force=collections.defaultdict(dict)
for r in csv.DictReader((P/'official.csv').open()):force[r['case']][r['arm']=='terry_independent']=r
rows=[]
for r in json.loads(manifest.read_text())['selected']:
 c=r['case']; raw=(P/'selected'/c).read_bytes();assert sha(raw)==r['sha256']
 with tempfile.TemporaryDirectory()as d:
  d=Path(d);log=d/'exact';act=d/'acts';trace=d/'trace';leaf=d/'absorb'
  a,e,rc,w=run([str(T),'env','AHC008_TERRY_EXACT_LOG='+str(log),'AHC008_ABSORB_RECEIPT='+str(leaf),str(D/'receipt'),'--pairs=8'],raw,5)
  m=re.fullmatch(rb'Score = (\d+)\s*',e);assert rc==0 and m
  assert short_prefix(b'\n'.join(a.splitlines()[:275])+b'\n')==r['prefix_sha']
  v=list(map(int,log.read_text().split()));assert len(v)==15 and v[10]==8
  sums=[sum(p[i]for p in shadow[c]['pairs'])for i in (0,1)]
  assert v[11:13]==sums and v[13]==int(sums[1]>sums[0])
  if v[13]:
   f=force[c][True];assert sha(a)==f['commands_sha'] and int(m[1])==int(f['score'])
  # Receipt stock keeps original full virtual Normal effects; forced Normal
  # pairs=0 is not assumed equal, so verify real score directly.
  act.write_bytes(a)
  assert run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(act),str(trace)],raw,12)[:3]==(a,e,rc)
  assert replay(raw.decode(),trace.read_text().splitlines(),a.decode().splitlines(),detailed=True)[0]==int(m[1])==v[-1]
  hit,skip,*by=map(int,leaf.read_text().split())
  assert len(by)==25 and by[0]==0 and 0<=hit==sum(by)<=8 and skip==sum((25-i)*k for i,k in enumerate(by))
  rows.append(dict(case=c,absorbing=hit,skipped_equivalent=skip,by_first=by,commands_sha=sha(a),score=int(m[1]),mode=v[13],sums=sums))
assert len(rows)==100
out=dict(boards=100,pairs=800,virtual_turns=20000,absorbing=sum(r['absorbing']for r in rows),skipped=sum(r['skipped_equivalent']for r in rows),rows=rows)
(D/'receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items()if k!='rows'}))
