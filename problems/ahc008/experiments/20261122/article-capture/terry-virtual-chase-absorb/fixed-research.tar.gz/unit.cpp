#define main absorb_unused_main
#include "candidate.private.cpp"
#undef main
int main(){
 using namespace terry_exact_root;
 const auto& layout=terrain_lib::terrain(2);
 for(uint64_t seed=1;seed<=1000;++seed){
  State s;
  for(int r=0;r<30;++r)s.walls.set(r*30+15);
  // Stable majority in left; minority crew and directed/passive pets in
  // right side. Isolated singleton pockets deliberately injected.
  s.people={1,4,5,20};
  int p=31*20;
  if(seed%2==0){
   for(int v:nb[p])if(v>=0)s.walls.set(v);
  }
  s.pets={{23,1,-1},{29,2,-1},{78,3,-1},{p,4,-1},{889,5,-1}};
  if(seed%2)s.people.push_back(22); // majority left is still strict
  int score0=score(s);ChaCha rng(seed*712357);
  for(int t=276;t<300;++t){
   bool empty=false;
   const auto c=chase(s,layout,275,&empty);
   assert(empty&&c==std::string(s.people.size(),'.'));
   people_step(s,c);actual_motion(s,rng);
   assert(score(s)==score0);
  }
  // Distinguish an actual empty target predicate from an all-dot action.
  s.pets.push_back({0,3,-1});
  bool empty=true;
  (void)chase(s,layout,275,&empty);
  assert(!empty);
 }
 std::cout<<"1000 minority/live-directed absorbing states stable\n";
}
