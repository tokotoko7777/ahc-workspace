from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
base=(D.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(base.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
def make(mode):
 s=base
 def put(a,b):
  nonlocal s
  assert s.count(a)==1,a
  s=s.replace(a,b)
 put('int turn,Board placeable,ChaseReport* detail=nullptr) {','int turn,Board placeable,ChaseReport* detail=nullptr,bool* noTargets=nullptr) {')
 a='    auto targets=majorityPets(walls,people,pets);\n    if(targets.empty())return result;'
 put(a,'    auto targets=majorityPets(walls,people,pets);\n    if(noTargets)*noTargets=targets.empty();\n    if(targets.empty())return result;')
 put('std::string chase(const State& s,const terrain_lib::Terrain& layout,int turn){','std::string chase(const State& s,const terrain_lib::Terrain& layout,int turn,bool* empty=nullptr){')
 put('s.walls,layout.aisleCells,s.people,pet_cells(s),turn,can_place(s));','s.walls,layout.aisleCells,s.people,pet_cells(s),turn,can_place(s),nullptr,empty);')
 if mode=='receipt':
  put('struct Decision{int pairs=0;','struct Decision{int absorbing_pairs=0, skipped_equivalent=0; std::array<int,25> first{}; int pairs=0;')
  put('  if(ok)for(int turn=275;turn<300;++turn){','  int empty_at=-1;\n  if(ok)for(int turn=275;turn<300;++turn){')
  put('    people_step(t,chase(t,*ordinary.terrain,275));','''    bool empty=false;
    people_step(t,chase(t,*ordinary.terrain,275,&empty));
    if(empty&&empty_at<0)empty_at=turn;
''')
  put('  ++answer.pairs;answer.normal+=score(s);answer.chase_sum+=score(t);','''  if(empty_at>=0){
   ++answer.absorbing_pairs;answer.skipped_equivalent+=300-empty_at;
   ++answer.first[empty_at-275];
  }
  ++answer.pairs;answer.normal+=score(s);answer.chase_sum+=score(t);
''')
  a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
  put(a,''' if(const char* path=std::getenv("AHC008_ABSORB_RECEIPT")){
  std::ofstream z(path);
  z<<d.absorbing_pairs<<' '<<d.skipped_equivalent;
  for(int count:d.first)z<<' '<<count;
  z<<'\\n';
 }
'''+a)
 else:
  put('    people_step(t,chase(t,*ordinary.terrain,275));','''    bool empty=false;
    auto cmd=chase(t,*ordinary.terrain,275,&empty);
    if(empty)break;
    people_step(t,cmd);
''')
 return s
for m in ('receipt','candidate'):(D/f'{m}.private.cpp').write_text(make(m))
