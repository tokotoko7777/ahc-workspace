import collections,csv, json,sys
from pathlib import Path
p=Path(sys.argv[1]);panel=sys.argv[2]
ref={'practice':(6152805559,100,100,0),'fresh':(5998857137,97,97,4)}[panel]
x=collections.defaultdict(dict)
for r in csv.DictReader(p.open()):
 assert r['arm'] not in x[r['case']]
 x[r['case']][r['arm']]=r
assert len(x)==100 and all(len(y)==2 for y in x.values())
a,b=([r[k]for r in x.values()]for k in ('v25','terry_independent'))
keys=('score','full','useful300','final_residual')
s0,s1=(tuple(sum(int(r[k])for r in z)for k in keys) for z in (a,b))
def no_regret(l,r):return all(x>=y for x,y in zip(l[:3],r[:3])) and l[3]<=r[3]
assert all(u['input_sha']==v['input_sha'] and u['map']==v['map'] for u,v in zip(a,b))
pre=sum(u['prefix_sha']!=v['prefix_sha']for u,v in zip(a,b))
loss=sum(int(u['full'])>int(v['full'])for u,v in zip(a,b))
wall=max(float(r['wall'])for r in b)
passed=no_regret(s1,s0) and no_regret(s1,ref) and not loss and wall<2.95
out=dict(n=100,keys=keys,baseline=s0,candidate=s1,historical=ref,zero_full_loss=(not loss),full_losses=loss,
    peak_baseline=max(float(r['wall'])for r in a),peak_candidate=wall,
    total_pairs=[sum(int(r['pairs'])for r in z) for z in (a,b)],
    changed_pairs=sum(u['pairs']!=v['pairs']for u,v in zip(a,b)),
    changed_modes=sum(u['mode']!=v['mode']for u,v in zip(a,b)),
    changed_commands=sum(u['commands_sha']!=v['commands_sha']for u,v in zip(a,b)),prefix_divergent=pre,passed=passed)
p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
if not passed:raise SystemExit(3)
