#include "short_mass.hpp"
#include <algorithm>
#include <iostream>
#include <random>
namespace s=terry_exact_short_mass;
struct Row{std::array<int,4> cells{};int degree=0;};
using Table=std::array<Row,s::V>;
using Id=std::array<int,s::V>;
void link(Table& a,int x,int y){a[x].cells[a[x].degree++]=y;a[y].cells[a[y].degree++]=x;}
int main(){
 Table a{};Id id{};id[31]=1;constexpr auto D=s::denominator;
 assert((s::mass(a,id,31,1,1)==std::array<uint64_t,3>{D,D,D}));
 link(a,31,32);assert((s::mass(a,id,31,1,1)==std::array<uint64_t,3>{0,D,0}));
 assert((s::mass(a,id,31,1,2)==std::array<uint64_t,3>{D,D,D}));
 assert((s::mass(a,id,31,1,3)==std::array<uint64_t,3>{0,D,0}));
 link(a,31,30);link(a,31,1);link(a,32,33);
 assert((s::mass(a,id,31,1,1)==std::array<uint64_t,3>{0,5*D/6,0}));
 std::mt19937 rng(83973);
 for(int n=0;n<1000;++n){
  a={};id={};int r=2+rng()%4,c=2+rng()%4;
  for(int i=0;i<r;++i)for(int j=0;j<c;++j){
   int p=30*i+j;id[p]=rng()%3;
   if(i+1<r&&(rng()%3))link(a,p,p+30);
   if(j+1<c&&(rng()%3))link(a,p,p+1);
  }
  int z=30*(rng()%r)+rng()%c, speed=1+rng()%3;
  std::array<uint64_t,3> expected{};
  auto go=[&](auto&& go,int p,int k,uint64_t v)->void{
   if(k&&k%speed==0&&id[p]==id[z])expected[k/speed-1]+=v*s::pow12[9-k];
   if(k==3*speed)return;
   const auto& q=a[p];
   if(!q.degree)go(go,p,k+1,12*v);
   else for(int i=0;i<q.degree;++i)go(go,q.cells[i],k+1,(12/q.degree)*v);
  };
  go(go,z,0,1);assert(s::mass(a,id,z,id[z],speed)==expected);
 }
 std::cout<<"1000 exhaustive random same-room endpoint fixtures passed\n";
}
