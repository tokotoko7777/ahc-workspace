import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_topology_cache/submission.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='8fbfd770eeb2549346705fddb45172e31d3e0bde027ed2f891462073be5a083e'
header=(d/'short_mass.hpp').read_text().replace('#pragma once\n','')
def put(token,f):
 global s
 assert s.count(token)==1,token
 s=s.replace(token,f(token))
put('#pragma GCC optimize("O3")',lambda x:x+'\n'+header)
put('using Retention=std::vector<std::array<int,30>>;',lambda x:x+'''
struct ShortTap {
 std::array<int,3> sampled{};
 std::array<uint64_t,3> exact{};
};
inline int short_audit_turn=-1;
''')
put('const std::vector<int>& alive,Pcg& rng) {',lambda x:'const std::vector<int>& alive,Pcg& rng, std::vector<ShortTap>* tap=nullptr) {')
put('  for(int trial=0;trial<100;++trial){\n   Pet p=initial;p.target=-1;',lambda x:'''  const bool passive=tap&&initial.type<=3;
  if(passive){
    auto z=terry_exact_short_mass::mass(adjacency.table,ids,initial.pos,room,initial.type);
    for(int q=0;q<3;++q)(*tap)[room].exact[q]+=z[q];
  }
'''+x)
put('    result[room][h]+=ids[p.pos]==room;',lambda x:x+'''
    if(passive&&1<=h&&h<=3)(*tap)[room].sampled[h-1]+=ids[p.pos]==room;
''')
put('struct Room { int left=-1, right=-1, area=0; std::array<int,30> retention{}; };',lambda x:x.replace('retention{}; };','retention{}; std::array<double,3> override_short={-1.,-1.,-1.}; };'))
put('const auto score=std::int64_t(r.retention[eta]*1e8*penalty/(r.area*double(eta+1)));',lambda x:'''
            const auto score=(1<=eta&&eta<=3&&r.override_short[eta-1]>=0)?
                std::int64_t(r.override_short[eta-1]*1e8*penalty/(r.area*double(eta+1))):
                std::int64_t(r.retention[eta]*1e8*penalty/(r.area*double(eta+1)));
''')
put('    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng);',lambda x:'''
    const bool record=short_audit_turn>=0;
    std::vector<ShortTap> tap(record?geometry.count():0);
    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng,record?&tap:nullptr);
''')
put('    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));',lambda x:'''
    const auto openAfter=bits_to_array(actual & ~builds & ~moves);
    auto jobs=hunt::choose(s.people,booked,rooms,openAfter);
    if(record){
      constexpr uint64_t den=terry_exact_short_mass::denominator;
      auto mod=rooms;
      for(int i=0;i<int(rooms.size());++i)if(rooms[i].area>0)
        for(int q=0;q<3;++q){
          const auto ex=100*tap[i].exact[q];
          const auto count=rooms[i].retention[q+1];
          const auto older=tap[i].sampled[q];
          assert(count>=older);
          mod[i].override_short[q]=double(den*(count-older)+ex)/double(den);
          if(ex||older)short_audit_rows.push_back("M "+std::to_string(q+1)+" "+std::to_string(older)+" "+std::to_string(ex));
        }
      auto alt=hunt::choose(s.people,booked,mod,openAfter);
      auto cmd_for=[&](const std::vector<hunt::Candidate>& js){
          auto b=booked;auto a=action;
          hunt::emit(s.people,js,legal,b);
          for(int i=0;i<m;++i)if(b[i])a[i]=*b[i];
          idle_phase(s,terrain->aisleColumns,a);
          return sanitize(s,a);
      };
      auto equal=[](auto& a,auto& b){return std::tie(a.room,a.a,a.b)==std::tie(b.room,b.a,b.b);};
      auto jobline=[&](char mode,const hunt::Candidate& j){
         int eta=(j.left>=0&&!openAfter[j.left])||(j.right>=0&&!openAfter[j.right]);
         if(j.left>=0)eta=std::max(eta,std::abs(s.people[j.a]/30-j.left/30));
         if(j.right>=0)eta=std::max(eta,std::abs(s.people[j.b]/30-j.right/30));
         auto line=std::string("J ")+std::to_string(short_audit_turn)+" "+mode+" "+
             std::to_string(j.room)+" "+std::to_string(eta)+" "+std::to_string(j.left)+" "+
             std::to_string(j.right)+" "+std::to_string(j.a)+" "+std::to_string(j.b);
         for(int p=0;p<V;++p)if(geometry.ids[p]==j.room)line+=" "+std::to_string(p);
         short_audit_rows.push_back(std::move(line));
      };
      const auto cmd0=cmd_for(jobs),cmd1=cmd_for(alt);
      if(cmd0!=cmd1)short_audit_rows.push_back("C "+std::to_string(short_audit_turn)+" "+cmd0+" "+cmd1);
      for(auto& j:jobs)if(std::none_of(alt.begin(),alt.end(),[&](auto& z){return equal(j,z);}))jobline('O',j);
      for(auto& j:alt)if(std::none_of(jobs.begin(),jobs.end(),[&](auto& z){return equal(j,z);}))jobline('N',j);
    }
''')
s=s.replace('namespace terry_exact_root {','''namespace terry_exact_root {
inline std::vector<std::string> short_audit_rows;
''',1)
put('  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);',lambda x:'''
  if(turn<275&&std::getenv("AHC008_TERRY_SHORT_AUDIT"))short_audit_turn=turn;
'''+x+'''
  short_audit_turn=-1;
''')
put(' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){',lambda x:'''
 if(const char* path=std::getenv("AHC008_TERRY_SHORT_AUDIT")){
   std::ofstream f(path);
   for(const auto& line:short_audit_rows)f<<line<<'\\n';
 }
'''+x)
(d/'audit.private.cpp').write_text(s)
