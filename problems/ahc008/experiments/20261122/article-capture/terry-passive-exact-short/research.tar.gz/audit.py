"""Read-only exact retention derivative evaluation on the faithful practice tapes."""
import collections,csv,hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,flat,flood,near,observed,replay,wave
DEN=12**9
def projected(p,h,w,command):
    ban=bitmask(h+p)|wave(bitmask(p))|w
    after=[];new=0
    for x,c in zip(h,command,strict=True):
        q=x if c=='.' else near(x,c.upper())
        assert q is not None
        if c.islower():
            assert not B[q]&(ban|new)
            new |=B[q];after.append(x)
        else:after.append(q)
    assert not bitmask(after)&(w|new)
    return flood(bitmask(after),ALL^(w|new))
def inspect(q):
    f=q['case']
    raw=(R/'ahc008_focus_assets/tools/in'/f).read_bytes()
    hp=R/'ahc008_terry_scaffold_audit/tapes'/f
    a=hp.with_suffix('.actions').read_bytes();stock=a.decode().splitlines()
    tr=hp.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==q['input_sha']
    assert hashlib.sha256(a).hexdigest()==q['commands_sha']
    assert replay(raw.decode(),tr,stock,detailed=True)[0]==int(q['score'])
    inp=raw.decode().splitlines();n=int(inp[0]);m=int(inp[n+1])
    st=time.monotonic()
    with tempfile.TemporaryDirectory() as d:
        lg=Path(d)/'out'
        z=subprocess.run([str(D/'audit'),'--pairs=0'],input='\n'.join(inp[:n+2+m]+tr[1::2])+'\n',
            text=True,capture_output=True,check=True,env=dict(os.environ,AHC008_TERRY_SHORT_AUDIT=str(lg)))
        assert z.stdout.splitlines()[:275]==stock[:275]
        logs=lg.read_text().splitlines()
    wall=time.monotonic()-st
    kinds,hist,_=observed(raw,tr)
    state=[(list(map(flat,p)),list(map(flat,h)),bitmask(map(flat,w))) for p,h,w in hist]
    stat=collections.Counter(); all_m=collections.defaultdict(collections.Counter)
    changes={};jobs=[]
    for row in logs:
        k,*a=row.split()
        if k=='M':
            e,old,num=map(int,a)
            met=all_m[e]
            met.update(n=1,absolute_error_num=abs(old*DEN-num),
                       old_count=old,exact_count_num=num,
                       non_equal=int(old*DEN!=num))
        elif k=='C':
            t,old,alt=a; t=int(t)
            assert old==stock[t] and old!=alt
            p,h,w=state[t]
            unchanged=projected(p,h,w,old)
            alternative=projected(p,h,w,alt)
            before=flood(bitmask(h),ALL^w)
            def newly(x):
                return {i for i,z in enumerate(p) if B[z]&before and not B[z]&x}
            lost=newly(unchanged)-newly(alternative); added=newly(alternative)-newly(unchanged)
            stat.update(changed_first=1,lost_pets=len(lost),added_pets=len(added),
                        lost_seal_events=bool(lost),added_seal_events=bool(added))
            changes[t]=dict(old=old,new=alt,lost=sorted(lost),added=sorted(added))
        elif k=='J':
            t=int(a[0]);mode=a[1];rid,eta,left,right,i0,i1,*cells=map(int,a[2:])
            jobs.append((t,mode,rid,eta,left,right,i0,i1,cells))
        else:raise AssertionError(k)
    stat['proposal_change_turns']=len({v[0] for v in jobs})
    for t,mode,rid,eta,l,r,i0,i1,cells in jobs:
        label=f'{mode}_h{eta}' if eta<=3 else f'{mode}_h4plus'
        gates=bitmask(p for p in (l,r) if p>=0)
        room=bitmask(cells)
        body=room&~gates
        assert body
        p,h,w=state[t]; fp,fh,fw=state[t+eta]
        initial={j for j,v in enumerate(p) if B[v]&room}
        continuing={j for j,v in enumerate(fp) if j in initial and B[v]&body}
        ap=bitmask(fp)
        stat[label+'_job']+=1
        if continuing:stat[label+'_same_id_body']+=1
        handle=flood(bitmask(fh),ALL^fw)
        allow=not gates&(fw|ap|wave(ap)|bitmask(fh))
        path_ok=False
        if continuing and allow and not body&bitmask(fh):
            # Require exact physical old body remains as a gate-severable room.
            sub=body&~fw
            path_ok=bool(sub and flood(sub&-sub,ALL^(fw|gates))==sub and sub&handle)
        if path_ok:stat[label+'_legal_geom']+=1
        if t in changes:
            changes[t].setdefault('jobs',[]).append(dict(side=mode,room=rid,eta=eta,left=l,right=r,
                workers=[i0,i1],same_ids=sorted(continuing),legal_geom=path_ok))
    return dict(case=f,stats=stat,mass=all_m,changes=changes,offline_wall=wall)
def main():
    out=[];tot=collections.Counter();mass=collections.defaultdict(collections.Counter)
    for q in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open()):
        if q['arm']!='terry_independent':continue
        z=inspect(q);out.append(z);tot.update(z['stats'])
        for e,v in z['mass'].items():mass[e].update(v)
    assert len(out)==100
    print(json.dumps(dict(cases=len(out),totals=tot,board_counts=collections.Counter(
        k for z in out for k,v in z['stats'].items() if v),
        mass=mass,details=out),indent=2))
if __name__=='__main__':main()
