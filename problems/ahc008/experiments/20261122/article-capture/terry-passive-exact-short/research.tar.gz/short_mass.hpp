#pragma once
#include <array>
#include <cassert>
#include <cstdint>
#include <utility>
namespace terry_exact_short_mass {
inline constexpr int V=900;
inline constexpr std::array<uint64_t,10> pow12={1,12,144,1728,20736,248832,2985984,35831808,429981696,5159780352ULL};
inline constexpr uint64_t denominator=pow12[9];
template<class Table,class Labels>
std::array<uint64_t,3> mass(const Table& adj,const Labels& labels,int start,int room,int speed) {
 assert(start>=0&&start<V&&speed>=1&&speed<=3);
 struct Layer {
  std::array<uint64_t,V> weight{};
  std::array<uint16_t,181> support{};
  int n=0;
  void add(int p,uint64_t k){
   if(!weight[p]){assert(n<int(support.size()));support[n++]=uint16_t(p);}
   weight[p]+=k;
  }
 } store[2];
 auto *prev=&store[0], *next=&store[1];prev->add(start,1);
 std::array<uint64_t,3> out{};
 for(int k=1;k<=3*speed;++k){
  for(int z=0;z<prev->n;++z){
   int p=prev->support[z];uint64_t v=prev->weight[p];
   const auto& a=adj[p];prev->weight[p]=0;
   if(!a.degree)next->add(p,12*v);
   else{
    v*=12/a.degree;
    for(int i=0;i<a.degree;++i)next->add(a.cells[i],v);
   }
  }
  prev->n=0;std::swap(prev,next);
  if(k%speed==0){
   uint64_t g=0;
   for(int z=0;z<prev->n;++z){
    int p=prev->support[z];if(labels[p]==room)g+=prev->weight[p];
   }
   out[k/speed-1]=g*pow12[9-k];
  }
 }
 return out;
}
}
