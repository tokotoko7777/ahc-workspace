# Isolated real policy: exact short passive retention

Frozen before dev scores. Start from selected fastest faithful
8fbfd770, only replace the short-horizon h=1,2,3 **passive** contribution
to existing same-original-room retention by the exact expectation under
the same static simple-random movement model. Preserve full original
sampling and PCG consumption, all h=0/h>=4 bins, dog/cat contributions,
state/action controllers, initial map, reservation/role logic, actual
turn cap and paired terminal comparison. Independent unit and preflight
verify exact arithmetic, action counterfactuals and original unchanged
tapes; they do not guarantee improved stochastic behavior on real play.

Paired live dev100 is a freshly generated unfiltered input stream under
namespace ahc008/20261123/terry-passive-exact-h123/dev100/i, immutable
seeds plus SHA256SUMS recorded before scores. Distinct held100 seed list
committed now but not generated; test only if dev passes. Also verify
official practice100 only after promising held; none of those points are
historical same judge results. No changing time budgets or species gate.
Use two binaries unchanged default wall budget with every same case,
serial, exact official playback and independent score.

Advance only if official legal all, local tester time max below 2.95s,
raw/useful captures not lower, and score improves at least 0.1% (1/1000).
The small lower bound avoids declaring one marginal time-driven difference
a promising policy. If failed do not tune short bin selection or retest
different thresholds on this panel. If passed take exact unchanged source
through held100 and practice under same rules, report capture and scores.
