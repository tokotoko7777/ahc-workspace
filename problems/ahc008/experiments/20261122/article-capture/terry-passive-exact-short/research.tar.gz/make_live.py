"""Freeze isolated h1-3 passive variant, no audit IO in real solver."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_topology_cache/submission.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='8fbfd770eeb2549346705fddb45172e31d3e0bde027ed2f891462073be5a083e'
def edit(t,f):
 global s
 assert s.count(t)==1,t
 s=s.replace(t,f(t))
edit('#pragma GCC optimize("O3")',lambda x:x+'\n'+(d/'short_mass.hpp').read_text().replace('#pragma once\n',''))
edit('using Retention=std::vector<std::array<int,30>>;',lambda x:x+'''
struct ShortTap {
 std::array<int,3> sampled{};
 std::array<uint64_t,3> exact{};
};
inline double correctedCount(int total,int sampled,uint64_t exact){
 assert(total>=sampled);
 constexpr uint64_t D=terry_exact_short_mass::denominator;
 return double(D*(total-sampled)+100*exact)/double(D);
}
''')
edit('const std::vector<int>& alive,Pcg& rng) {',lambda x:'const std::vector<int>& alive,Pcg& rng, std::vector<ShortTap>* tap=nullptr) {')
edit('  for(int trial=0;trial<100;++trial){\n   Pet p=initial;p.target=-1;',lambda x:'''  const bool passive=tap&&initial.type<=3;
  if(passive){
    auto z=terry_exact_short_mass::mass(adjacency.table,ids,initial.pos,room,initial.type);
    for(int q=0;q<3;++q)(*tap)[room].exact[q]+=z[q];
  }
'''+x)
edit('    result[room][h]+=ids[p.pos]==room;',lambda x:x+'''
    if(passive&&1<=h&&h<=3)(*tap)[room].sampled[h-1]+=ids[p.pos]==room;
''')
edit('struct Room { int left=-1, right=-1, area=0; std::array<int,30> retention{}; };',lambda x:x.replace('retention{}; };','retention{}; std::array<double,3> override_short={-1.,-1.,-1.}; };'))
edit('const auto score=std::int64_t(r.retention[eta]*1e8*penalty/(r.area*double(eta+1)));',lambda x:'''
            const auto score=(1<=eta&&eta<=3&&r.override_short[eta-1]>=0)?
                std::int64_t(r.override_short[eta-1]*1e8*penalty/(r.area*double(eta+1))):
                std::int64_t(r.retention[eta]*1e8*penalty/(r.area*double(eta+1)));
''')
edit('    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng);',lambda x:'''
    std::vector<ShortTap> tap(geometry.count());
    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng,&tap);
''')
edit('     const auto& q=geometry.rooms[i];rooms.push_back({q.left,q.right,q.size,freqs[i]});',lambda x:x+'''
     for(int h=1;h<=3;++h)if(tap[i].exact[h-1]||tap[i].sampled[h-1])
      rooms.back().override_short[h-1]=correctedCount(freqs[i][h],tap[i].sampled[h-1],tap[i].exact[h-1]);
''')
(d/'live.private.cpp').write_text(s)
