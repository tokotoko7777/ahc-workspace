#define main faithful_entry
#include "live.private.cpp"
#undef main
#include <iostream>
using namespace terry_exact_motion;
namespace h=terry_exact_hunt;
int main(){
 // Cow at a degree-3 center. On graph two leaves and an extended
 // arm, its exact return at two elapsed moves is 5/6. A directed
 // dog and stock cat are sampled too, both in a separate label.
 State st;st.walls.set();
 for(int p:{31,30,1,32,33,91,92,93,121,122})st.walls[p]=false;
 st.people={93,121};st.pets={{31,1,-1},{91,4,-1},{122,5,-1}};
 std::array<int,V> labels;labels.fill(-1);labels[31]=0;
 for(int p:{91,92,93,121,122})labels[p]=1;
 std::vector<int> alive={0,1,2};
 Pcg off(734328),on=off;std::vector<ShortTap> taps(2);
 auto baseline=retention(st,st.walls,labels,2,alive,off);
 auto raw=retention(st,st.walls,labels,2,alive,on,&taps);
 assert(baseline==raw&&off.s==on.s);
 assert((taps[0].exact==std::array<uint64_t,3>{0,5*terry_exact_short_mass::denominator/6,0}));
 assert((taps[1].sampled==std::array<int,3>{0,0,0}&&taps[1].exact==std::array<uint64_t,3>{0,0,0}));
 auto expected=correctedCount(raw[0][2],taps[0].sampled[1],taps[0].exact[1]);
 assert(std::abs(expected-100.*5/6.)<1e-12);
 assert(correctedCount(raw[1][2],0,0)==raw[1][2]);
 // Feed the actual score path a synthetic competing singleton range,
 // both sharing the same left stance column, and independently force
 // each ETA. Original selector remains unchanged outside short override.
 auto dispatch=[&](int eta){
  std::vector<int> human={12*30+6,12*30+15};
  std::vector<std::optional<char>> booked(2);
  std::vector<h::Room> rooms(2);
  std::array<bool,V> legal;legal.fill(true);
  for(int i=0;i<2;++i){rooms[i].left=(12+eta)*30+7;rooms[i].area=3;}
  rooms[0].retention[eta]=80;rooms[1].retention[eta]=82;
  auto selected=h::choose(human,booked,rooms,legal);
  assert(selected.size()==1&&selected[0].room==1);
  if(eta>=1&&eta<=3)rooms[0].override_short[eta-1]=expected;
  else rooms[0].override_short.fill(expected);
  selected=h::choose(human,booked,rooms,legal);
  assert(selected.size()==1&&selected[0].room==(eta>=1&&eta<=3?0:1));
 };
 for(int h:{0,1,2,3,4,6})dispatch(h);
 std::cout<<"pipeline exact passive short bin use, untouched raw tallies and original PCG state passed\n";
}
