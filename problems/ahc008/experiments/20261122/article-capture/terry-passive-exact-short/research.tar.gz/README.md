# Exact short-passive room retention audit

Prerequisite fixed before looking at the tape results: at least 12 distinct
boards and 20 actual first-command changes, with no more immediately
confirmed isolation-event defeats than additions. Passing gives signal
for a separate paired trial, not adoption or a verified improvement.

```
g++ -std=gnu++23 -O2 ahc008_terry_passive_exact_short/unit.cpp -o /tmp/terry-short-mass-unit
/tmp/terry-short-mass-unit
python ahc008_terry_passive_exact_short/make_audit.py
g++ -std=gnu++23 ahc008_terry_passive_exact_short/audit.private.cpp -o ahc008_terry_passive_exact_short/audit
python ahc008_terry_passive_exact_short/audit.py > ahc008_terry_passive_exact_short/report.json
```

Pure `short_mass.hpp` weights each uniform transition by the common
denominator 12; scales ETA1–3 to common 12^9. Handles zero-degree stay,
parity, and same-room re-entry. Unit covered deterministic examples and
1,000 independent exhaustive random path enumerations.

`make_audit.py` pins newest 8fbfd770 faithful cache source. All stock
sampling operations remain in original order. It adds passive-only
counts and exact rational sums on existing tentative wall adjacency.
The second detached room selector changes only h1..3 passive weight in
the score. Its result is not issued; both proposals flow separately
through the same idle and sanitizer on copies. No official tester,
actual simulation of the new commands or post-switch policy comparison.
Each original input/full tape hash and independent replay score are
verified, and output prefix through t274 is asserted exactly unchanged.

Changed-job occupancy is evaluated from stock tapes at that job's
original estimated arrival. Require same original pet, physical inside
old room footprint excluding closing walls, non-wall gates, actual
gate/pet/person adjacency legality, and a pet-only body under projected
close that is still reachable on the old preclose state. Staff need not
be at an actual prospective stance; animal paths are factual, not
counterfactual to plan. Stock closures by then can censor these labels,
and differing selected-job cohorts/ETAs mean raw occupancies are not
predictive skill scores. Report actual immediate wall effects separately.

## Exact tape result

100/100 exact action prefixes. On each horizon, 25,685 eligible
nonempty passive/MC bins. Mean absolute difference between exact and
sampled masses in 100-trial animal-equivalent units: ETA1 2.591, ETA2
3.415, ETA3 3.385. Selected jobs differ on 107 turns / 58 boards,
submitted first commands on 73 / 48. Zero newly isolated pets/instant
seals added or lost on actual current boards; predeclared activation
gate passes but this does not prove benefit. Among differing jobs,
ETA1–3 entries stock 103 vs exact112; same initial IDs lie in the
body at recorded ETA 30 vs31, stricter actual legal and geometry
13 vs7. The selected-job group is not matched and uses factual stock
future, including closure censoring, so this is a caution not a live
outcome. Offline audit process wall median .349s, max1.245s, including
replaying the original, both selectors and logging, not a production
overhead estimate. No official tester or alternate policy execution.

## Isolated paired candidate (not evaluated here)

Compile live.private.cpp directly with g++ -std=gnu++23 after running
make_live.py. Its SHA256 is
08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c.
Normal scoring applies the isolated exact passive h1–3 change in both
actual and hypothetical games. PCG loop, directed sampling, candidate
sorting, geometry, timing cap and all other stages are unchanged.
Pipeline.cpp demonstrates unchanged raw sampled bins and full final PCG
state, and exercises actual selection at h0/1/2/3/4/6. Build is complete.
On changed-command tapes specifically, legal geometric occupancy was
11/72 stock versus 7/74 alternate; same-ID endpoints 25/72 vs20/74.
Descriptive only, no causal inference or promotion.
