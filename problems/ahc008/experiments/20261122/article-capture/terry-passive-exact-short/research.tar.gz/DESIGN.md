# Faithful normal-room retention, exact passive ETA 1–3
Design only while the parent is timing. No solver files, compiler or
tester used. Target today's stock retain function and use the same
projected `next` wall graph and exact dynamic room labels.

## Minimal pure helper interface and kernel

`array<uint64_t,3> short_mass(adj, labels, start, originalRoom, speed)`
has no dependency on policy or RNG. The input adjacency is the existing
`RetentionNeighbors::table` exact open orthogonal neighbors; `speed`
is 1/2/3 only. Conceptual pseudocode:

    cur[start] = 1
    for k = 1 .. 3*speed:
        clear the sparse next slot
        for (pos, weight) in cur:
            if degree[pos] == 0: next[pos] += weight * 12
            else for q in adj[pos]: next[q] += weight * (12 / degree[pos])
        swap cur,next
        if k % speed == 0:
            endpoint = sum(cur[q] for q with label[q] == originalRoom)
            out[k/speed-1] = endpoint * 12^(9-k)

All output denominators `D=12^9=5,159,780,352`. Intermediate sums are
exact integers because 1,2,3,4 divide 12. Total mass before scaling is
always 12^k, so uint64 is comfortably sufficient; even after summing
20 pets times 100 trials, numerator is at most ~1.032e13. Mass may
leave and return; DO NOT absorb outside-room positions or block virtual
gates, humans, or other pets: those are not blocked in stock transitions.
At step 9 the Manhattan support has <=181 cells (100 with no degree-zero
parity breaks); two timestamp/list buffers on 900 slots avoid clearing
whole board on each layer. Complexity per pet at most 9 × 181 × 4
transition visits, much lower in narrow built rooms. Within-call duplicate
start/speed can share helper output, but no global aging state or filter.

Keep every stock PCG sample call, including passive short steps, in its
exact original iteration order. During tally only, separately accumulate
passive MC bin counts for h=1..3 of each original room, while stock bins
continue untouched. Then use in just these three bins
`mc_total − mc_passive + 100 * exact_passive_mass / D`. Combine as a
uint64 numerator to preserve integrality and round only by conversion to
double at the existing objective calculation. Do not round to another
integer count before scoring. For h0 and h>=4, use original integer
count/score expression verbatim. Dogs and (stock surrogate unbiased)
cats remain sampled, no movement model changes. Keep stock integer
candidate score and job order/ties; no reinterpretation of dimensions,
penalties, routing, branch bounds, legality or stage selection.

## Fixtures to prepare only when released

1. Isolated allowed cell: all three outputs exactly D.
2. Two-cell corridor with only start labeled target and cat/dog not in
   helper: cow [0,D,0], pig [D,D,D], rabbit [0,D,0].
3. Branch/re-entry: a degree-three center (same-room only) with each
   arm dead-end except one arm extended one tile. Cow h1=0, h2=5/6,
   h3=0 by graph parity. This catches illegal absorbing treatment.
4. Multi-animal room combination with an exact animal plus sampled
   directed or long-horizon animal: all untouched counts/PCG words and
   h0, h>=4 must be byte-exact, mixed short sums use the same scale.
5. Independent recursion enumerates weighted path words up to length9
   on small random boards. Compare integer endpoint mass and after-step
   probability normalization to sparse DP. Check degree 0, edges,
   degree3 and same-room reentry. Vanilla helper has no random generator.

## Read-only stock-tape assessment before any alternate policy

Use exact current fast parent (pin hash, no hidden RNG inputs), actual
t0–274 Normal states. Run the existing stock sampling once, simultaneously
gather passive-short counts, evaluate two job vectors through unchanged
selector, emitter, idle proposal and legality sanitizer on detached
copies. Only output actual original command; compare exact prefix hashes,
full observed replay score separately. Ignore simulated t275 selection
and do not execute new planning or pet counterfactuals. Check that the
only differing objective inputs were passive h1–3, any state effect is
only a proposed new action and score scale preserved. Report by
board/turn: changed job selection versus real first movement/explicit
hold/closure after sanitize; actual immediately legal captures preserved,
added, or displaced (packing can affect eta0 indirectly despite exact
h0); distribution by species, horizons, occupied IDs and timing. Optionally
compare the factual future same-room endpoint for the same present pet
on compatible boards, explicitly not grading alternative paths, room
retention is not capture/legal closure.

Exact conditional probability removes sampling variance (~at most
5 sample-count standard deviation per pet at 100 trials), but will
mostly affect close competition between small-margin jobs. The stock
objective is an area-weighted proxy, not the probability of all legal
gates; improved numerical accuracy can still worsen action selection.
Meaningful action/coverage recurrence, not changed arithmetic alone,
would justify any separate frozen live A/B. Do not select cases, adjust
ETA support or add speed claims from a design-only fixture.
