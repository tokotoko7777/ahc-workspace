"""Relaxed exterior-merger screen, not nominal geometry acceptance."""
import csv,hashlib,json,sys
from collections import Counter
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'ahc008_terry_scaffold_audit'))
from audit import ALL,B,area,observed,replay,bitmask,idx,flood
D=Path(__file__).parent
maps={}
for line in (D/'geometry.tsv').read_text().splitlines():
    h,doors,rooms=line.split('|')
    mid,side,retired,nx,ng,strict,relax,*walls=map(int,h.split())
    doors=list(map(int,doors.split()));rooms=list(map(int,rooms.split()))
    assert nx==len(walls) and ng==len(doors) and not strict and relax
    maps[mid,side]=(walls,doors,rooms,retired)
a=[];alln=0
for q in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open()):
    if q['arm']!='terry_independent':continue
    alln+=1;case=q['case'];mid=int(q['telemetry'].split()[0])
    raw=(R/'ahc008_focus_assets/tools/in'/case).read_bytes()
    tp=R/'ahc008_terry_scaffold_audit/tapes'/case
    cmds=tp.with_suffix('.actions').read_bytes()
    tr=tp.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==q['input_sha'] and hashlib.sha256(cmds).hexdigest()==q['commands_sha']
    assert replay(raw.decode(),tr,cmds.decode().splitlines(),detailed=True)[0]==int(q['score'])
    kinds,hist,_=observed(raw,tr)
    slow=[i for i,k in enumerate(kinds) if k<=3]
    p0=hist[0][0]
    def band(r,i):return r>=26 if i else r<=3
    # At t0 no game walls and all pets accessible. Require a zero-density
    # longitudinal band for the sole variant; if both, top fixed by rule.
    eligible=[i for i in (0,1) if not any(band(p0[j][0],i) for j in slow)]
    if not eligible:continue
    side=eligible[0];xs,gs,rs,ret=maps[mid,side]
    x,g,r=map(bitmask,(xs,gs,rs))
    footprint=x|g|r
    visits=Counter(); pet_turns=0; later_dead=set()
    for ps,hs,ws in hist[:-1]:
        w=bitmask(map(idx,ws));root=flood(bitmask(map(idx,hs)),ALL^w)
        for j in slow:
            b=B[idx(ps[j])]
            if b&footprint:
                visits[j]+=1;pet_turns+=1
                if not root&b:later_dead.add(j)
    ps,hs,ws=hist[-1]
    w=bitmask(map(idx,ws));p=bitmask(map(idx,ps));h=list(map(idx,hs))
    old=area(w,h,p); xx=w&x;gg=w&g
    new=area(w&~(x|g),h,p);only_x=area(w&~x,h,p)
    assert old[0]==(q['full']=='1')
    a.append(dict(case=case,map=mid,side=side,nominal=len(xs),actual_x=xx.bit_count(),gates=gg.bit_count(),retired_rooms=ret,
        slow_visits=len(visits),slow_visits_ge2=sum(n>=2 for n in visits.values()),slow_pet_turns=pet_turns,
        isolated_slow_visitors=len(later_dead),original_full=old[0],counterfactual_full=new[0],x_only_full=only_x[0],
        delta_floor=(new[1]-old[1])/len(h)))
full=[r for r in a if r['original_full']];safe=[r for r in full if r['counterfactual_full']]
print(json.dumps(dict(cases=alln,strict_eligible=0,relaxed_zero_initial_slow_eligible=len(a),
    map_cases=Counter(r['map'] for r in a),
    nominal_x_ge12=sum(r['nominal']>=12 for r in a),actual_x_ge12=sum(r['actual_x']>=12 for r in a),
    boards_later_slow_footprint=sum(r['slow_visits']>0 for r in a),boards_repeated_same_slow=sum(r['slow_visits_ge2']>0 for r in a),
    slow_pet_turns=sum(r['slow_pet_turns'] for r in a),original_full=len(full),retained_full=len(safe),
    x_only_retained_full=sum(r['x_only_full'] for r in full),
    safe_frozen_added_floor_sum=sum(r['delta_floor'] for r in safe),
    safe_frozen_added_floor_ge10=sum(r['delta_floor']>=10 for r in safe),qualifiers=a),indent=2))
