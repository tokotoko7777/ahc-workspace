#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace terry_exact_maps;
int main(){
 for(int g=0;g<5;g++)for(int side=0;side<2;++side){
  const auto& t=terrain(g);auto old=classify(t,t.plannedWalls,{}, {t.aisleColumns[0]});
  std::vector<bool> skip(old.count()),inner(old.count());
  for(int p=0;p<V;++p) {
   int k=old.ids[p], r=p/W;
   if(k<0||k>=old.count())continue;
   // Exactly one longitudinal four-row periodic block at either end.
   if(side?(r>=26):(r<=3))skip[k]=true;
   else inner[k]=true;
  }
  for(int k=0;k<old.count();++k)skip[k]=skip[k]&&!inner[k];
  Board lostRoom,keptRoom,doors,freed;
  for(int i=0;i<V;i++)if(old.ids[i]>=0&&old.ids[i]<old.count()){
   if(skip[old.ids[i]])lostRoom[i]=true;
   else keptRoom[i]=true;
  }
  doors=lostRoom&t.doorCells;
  for(int p=0;p<V;p++)if(t.planned(p)){
   bool touches=false,protected_=false;
   for(int q:adjacent(p))if(q>=0){
    touches|=lostRoom[q];
    protected_|=keptRoom[q]||(t.doorCells[q]&&!doors[q]);
   }
   if(touches&&!protected_)freed[p]=true;
  }
  Terrain alter=t;alter.plannedWalls&=~freed;alter.doorCells&=~doors;
  for(int p=0;p<V;p++)if(freed[p]||doors[p])alter.cells[p]=Marker::Open;
  const auto now=classify(alter,alter.plannedWalls,{}, {alter.aisleColumns[0]});
  auto newShut=labels(alter.plannedWalls|alter.doorCells);
  auto oldShut=labels(t.plannedWalls|t.doorCells);
  std::vector<bool> aisles(newShut.count);
  for(int p=0;p<V;p++)if(alter.aisle(p))aisles[newShut.labels[p]]=true;
  int dropped=std::count(skip.begin(),skip.end(),true);
  std::array<int,8> reasons{};
  bool same=now.count()==old.count()-dropped&&(old.participates&~now.participates).none();
  reasons[0]=!same;
  std::vector<int> renumber(old.count(),-1),newUsed(now.count(),-1);
  for(int p=0;p<V;p++)if(keptRoom[p]){
   const int a=old.ids[p],b=now.ids[p];
   if(b<0||b>=now.count()){same=false;++reasons[1];continue;}
   if((renumber[a]>=0&&renumber[a]!=b)||(newUsed[b]>=0&&newUsed[b]!=a)){same=false;++reasons[2];}
   renumber[a]=b;newUsed[b]=a;
  }
  for(int k=0;k<old.count();k++)if(renumber[k]>=0){
   auto x=old.rooms[k],y=now.rooms[renumber[k]];
   if(x.left!=y.left||x.right!=y.right||x.size!=y.size){same=false;++reasons[3];}
  }
  std::vector<bool> oldAisle(oldShut.count);
  for(int p=0;p<V;p++)if(t.aisle(p))oldAisle[oldShut.labels[p]]=true;
  std::vector<int> identities(oldShut.count,-1),inverse(newShut.count,-1);
  for(int p=0;p<V;p++){
   if((lostRoom[p]||freed[p])&&
      (now.ids[p]>=0||newShut.labels[p]<0||!aisles[newShut.labels[p]])){same=false;++reasons[4];}
   if(!lostRoom[p]&&oldShut.labels[p]>=0){
    int a=oldShut.labels[p],b=newShut.labels[p];
    if(b<0){same=false;continue;}
    if(identities[a]>=0&&identities[a]!=b){same=false;++reasons[5];}
    if(inverse[b]>=0&&inverse[b]!=a){
     same=false;++reasons[5];
     if(!oldAisle[a]||!oldAisle[inverse[b]])++reasons[4];
    }
    identities[a]=b;inverse[b]=a;
   }
  }
  // Preserve old connected components including those we previously
  // compared only after virtual closure; do not merge retained pieces.
  const auto oldOpen=labels(t.plannedWalls),newOpen=labels(alter.plannedWalls);
  std::vector<int> oo(oldOpen.count,-1), oi(newOpen.count,-1);
  int h0=oldOpen.labels[t.aisleColumns[0]],h1=newOpen.labels[t.aisleColumns[0]];
  for(int p=0;p<V;++p){
   if(t.aisle(p)&&((oldOpen.labels[p]==h0)!=(newOpen.labels[p]==h1))){same=false;++reasons[6];}
   if(!lostRoom[p]&&oldOpen.labels[p]>=0){
    int a=oldOpen.labels[p],b=newOpen.labels[p];
    if(b<0){same=false;continue;}
    if((oo[a]>=0&&oo[a]!=b)||(oi[b]>=0&&oi[b]!=a)){same=false;++reasons[7];}
    oo[a]=b;oi[b]=a;
   }
  }
  bool onlyAisles=true;for(int i=0;i<8;i++)if(i!=5&&reasons[i])onlyAisles=false;
  std::cout<<g<<' '<<side<<' '<<dropped<<' '<<freed.count()<<' '<<doors.count()<<' '<<same<<' '<<onlyAisles;
  std::cerr<<g<<' '<<side<<' ';for(int x:reasons)std::cerr<<x<<' ';std::cerr<<'\n';
  for(int p=0;p<V;p++)if(freed[p])std::cout<<' '<<p;
  std::cout<<" |";
  for(int p=0;p<V;p++)if(doors[p])std::cout<<' '<<p;
  std::cout<<" |";
  for(int p=0;p<V;p++)if(lostRoom[p])std::cout<<' '<<p;
  std::cout<<'\n';
 }
}
