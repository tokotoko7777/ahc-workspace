"""Factual current-board three-step warning before stock full isolation."""
import csv,hashlib,json,sys
from collections import Counter
from pathlib import Path
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'ahc008_terry_scaffold_audit'))
from audit import ALL,B,observed,replay,bitmask,idx,flood,wave
D=Path(__file__).parent
maps={}
for line in (D/'geometry.tsv').read_text().splitlines():
    h,doors,rooms=line.split('|')
    mid,side,retired,nx,ng,strict,relax,*walls=map(int,h.split())
    assert nx==len(walls) and not strict and relax
    maps[mid,side]=tuple(map(bitmask,(walls,list(map(int,doors.split())),list(map(int,rooms.split())))))
alln=0;out=[]
for q in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open()):
    if q['arm']!='terry_independent':continue
    alln+=1;case=q['case'];mid=int(q['telemetry'].split()[0])
    raw=(R/'ahc008_focus_assets/tools/in'/case).read_bytes()
    tp=R/'ahc008_terry_scaffold_audit/tapes'/case
    cmds=tp.with_suffix('.actions').read_bytes()
    tr=tp.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==q['input_sha'] and hashlib.sha256(cmds).hexdigest()==q['commands_sha']
    assert replay(raw.decode(),tr,cmds.decode().splitlines(),detailed=True)[0]==int(q['score'])
    kinds,hist,_=observed(raw,tr)
    ps0=hist[0][0]
    sides=[d for d in (0,1) if not any(k<=3 and (r>=26 if d else r<=3)
                      for k,(r,c) in zip(kinds,ps0,strict=True))]
    if not sides:continue
    side=sides[0];x,g,r=maps[mid,side];foot=x|g|r
    alarm=first_full=None;who=[];installed_alarm=None
    for t,(ps,hs,ws) in enumerate(hist):
        w=bitmask(map(idx,ws));op=ALL^w
        union=flood(bitmask(map(idx,hs)),op)
        access=[i for i,p in enumerate(ps) if B[idx(p)]&union]
        if not access:first_full=t;break
        if alarm is not None or t==300:continue
        near=foot&op
        for _ in range(3):near|=wave(near)&op
        hits=[i for i in access if B[idx(ps[i])]&near]
        if hits:alarm=t;who=[kinds[i] for i in hits];installed_alarm=(w&x).bit_count()
    assert (first_full is not None)==(q['full']=='1')
    wstop=bitmask(map(idx,hist[first_full if first_full is not None else 300][2]))
    out.append(dict(case=case,map=mid,side=side,first_alarm=alarm,alarm_species=who,
                    first_full=first_full,nominal_x=x.bit_count(),installed_at_alarm=installed_alarm,
                    installed_at_full_or_terminal=(wstop&x).bit_count()))
def bucket(a):
    if a is None:return 'never'
    if a==0:return 't0'
    if a<60:return '1..59'
    if a<100:return '60..99'
    return '100..299'
never=[z for z in out if z['first_alarm'] is None]
print(json.dumps(dict(cases=alln,qualifies=len(out),no_initial_side=alln-len(out),
    buckets=Counter(bucket(z['first_alarm']) for z in out),alarm_before60=sum(z['first_alarm'] is not None and z['first_alarm']<60 for z in out),
    alarm_before100=sum(z['first_alarm'] is not None and z['first_alarm']<100 for z in out),
    nominal_all_qualifiers=sum(z['nominal_x'] for z in out),
    never_alarm_nominal_x=sum(z['nominal_x'] for z in never),
    never_alarm_installed_x=sum(z['installed_at_full_or_terminal'] for z in never),
    never_alarm_nominal_x_full_only=sum(z['nominal_x'] for z in never if z['first_full'] is not None),
    details=out),indent=2))
