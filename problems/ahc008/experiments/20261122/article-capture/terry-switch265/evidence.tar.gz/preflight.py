import csv,hashlib,json,sys
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ahc008_terry_scaffold_audit'))
from audit import B,ALL,bitmask,flood,observed,replay
T=265
FLOOR=300
def flat(p):return p[0]*30+p[1]
def state(h):
    ps,hs,ws=h
    return list(map(flat,ps)),list(map(flat,hs)),bitmask(map(flat,ws))
def inspect(r,inp,tapes):
    raw=(inp/r['case']).read_bytes(); p=tapes/r['case']
    action=p.with_suffix('.actions').read_bytes()
    tr=p.with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(raw).hexdigest()==r['input_sha']
    assert hashlib.sha256(action).hexdigest()==r['commands_sha']
    cmds=action.decode().splitlines()
    assert replay(raw.decode(),tr,cmds,detailed=True)[0]==int(r['score'])
    kinds,hist,_=observed(raw,tr)
    ps,hs,w=state(hist[T]);_,after,aw=state(hist[T+1])
    # Equal headcount tie: original scans components in ascending first cell.
    def group(h,w):
        left=bitmask(h); labels=[]
        while left:
            mask=flood(left&-left,ALL^w)
            labels.append((mask,sum(bool(B[p]&mask) for p in h)))
            left&=~mask
        return sorted(labels,key=lambda q:(-q[1],q[0]&-q[0]))
    sides=group(hs,w);main=sides[0][0]
    targets=[i for i,p in enumerate(ps) if B[p]&main]
    after_access=flood(bitmask(after),ALL^aw)
    no_normal_capture=not any(not (B[ps[i]]&after_access) for i in targets)
    cap=len(hs)<=8
    one=len(targets)==1
    conn=len(sides)==1
    area=main.bit_count()
    suitable=cap and one and conn and area>=FLOOR and no_normal_capture
    return dict(case=r['case'],humans=len(hs),cap=cap,targets=targets,
                species=[kinds[t] for t in targets],one=one,connected=conn,
                main_area=area,no_normal_capture=no_normal_capture,
                gate_cap_and_one=cap and one,all_conditions=suitable,
                normal_actual_action=cmds[T],is_failure=r['full']=='0')
def stats(panel):
    c=Counter()
    for r in panel:
        c['cases']+=1
        c['m_le_8']+=r['cap'];c['exact_one']+=r['one']
        if r['gate_cap_and_one']:
            c['gate_cap_one']+=1
            c['split_humans']+=not r['connected']
            c['small_main']+=r['main_area']<FLOOR
            c['stock_immediate_capture']+=not r['no_normal_capture']
        c['passes_all']+=r['all_conditions']
    return dict(c)
def main():
    all_={}
    for name,inp,tapes in [
        ('practice','ahc008_focus_assets/tools/in','ahc008_terry_scaffold_audit/tapes'),
        ('independent','ahc008-article-bench/full-capture-independent100/in','ahc008_terry_factual_late/tapes')]:
        rows=[]
        for r in csv.DictReader((ROOT/f'ahc008_terry_exact_root/{name}100.csv').open()):
            if r['arm']!='terry_independent' or (name=='independent' and r['full']!='0'):continue
            rows.append(inspect(r,ROOT/inp,ROOT/tapes))
        assert len(rows)==(100 if name=='practice' else 4)
        all_[name]=rows
    misses=[x for panel in all_.values() for x in panel if x['is_failure']]
    assert len(misses)==6
    print(json.dumps(dict(turn=T,floor=FLOOR,practice=stats(all_['practice']),failures=stats(misses),failure_rows=misses,panels=all_),indent=2))
if __name__=='__main__':main()
