"""Frozen detached outside-veto two-paid-hold census; no judge/scoring."""
import collections,hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
P=R/'ahc008_terry_hunt_wall_audit'; I=R/'ahc008_terry_incoming_shadow/held100/in'
LED=P/'recordings.json'; OBS=R/'ahc008_terry_inward_online/observer.py'
sys.path.insert(0,str(OBS.parent))
from observer import case_history,command_effect,step,B,ALL,mask,flood,wave
LANES=((8,21),(4,14,24),(4,11,18,25),(0,6,13,19,26),(4,11,18,25))
def readlog(path,m):
    jobs=collections.defaultdict(list); paid={}
    for line in path.read_text().splitlines():
        k,t,*f=line.split(); t=int(t)
        assert 0<=t<275
        if k=='R':
            assert t not in paid and len(f)==1 and len(f[0])==m and set(f[0])<={'0','1'}
            paid[t]=f[0]
        else:
            assert k=='J'
            l,r,a,b,hold,*body=map(int,f)
            assert 0<=l<900 and 0<=r<900 and l!=r and 0<=a<m and 0<=b<m and a!=b and hold in (0,1)
            jobs[t].append((l,r,a,b,hold,mask(body)))
    return jobs,paid
def comp(h,w):return flood(mask(h),ALL^w)
def room_equals(w,body,doors):
    return bool(body and not body&(w|doors) and flood(body&-body,ALL^(w|doors))==body)
def new_ids(p,orig,after):
    return {i for i,x in enumerate(p) if B[x]&orig and not B[x]&after}
def geometry(p,stock_w,stock_h,body,l,r):
    gates=B[l]|B[r]
    if gates&(stock_w|mask(stock_h)) or body&mask(stock_h):return False
    if not room_equals(stock_w,body,gates):return False
    return not (room_equals(stock_w,body,B[l]) or room_equals(stock_w,body,B[r]))
def screen(board,st,old,jobs,stats):
    anchors=mask(row*30+c for row in range(30) for c in LANES[board['map']])
    out=[];seen=set()
    for t,ordered in sorted(jobs.items()):
        if t>=274:continue
        p,h,w=st[t]; own=comp(h,w)
        stock=command_effect(h,w,p,old[t]);assert stock is not None
        pw,ph=stock; prior=comp(ph,pw); forbidden=mask(p)|wave(mask(p))
        for l,r,a,b,hold,body in ordered:
            if l>=r or l//30!=r//30 or not hold or h[a]!=step(l,'L') or h[b]!=step(r,'R') or old[t][a]!='.' or old[t][b]!='.':continue
            stats['dual_hold']+=1
            if not geometry(p,pw,ph,body,l,r):continue
            left=bool(B[l]&forbidden);right=bool(B[r]&forbidden)
            if left==right:continue
            gate,far,actor,partner,d=(l,r,a,b,'R') if left else (r,l,b,a,'L')
            veto=B[gate]|wave(B[gate])
            blockers={i for i,x in enumerate(p) if B[x]&veto}
            if not blockers or any(B[p[i]]&body for i in blockers):continue
            stats['outside_only_veto']+=1
            cap=step(gate,d)
            if cap is None or not B[cap]&body:continue
            candidates={i for i,x in enumerate(p) if B[x]&body&own}
            if not candidates or any(B[p[i]]&body and i not in candidates for i in range(len(p))):continue
            cb=B[cap];narrow=body&~cb
            if (cb|B[far])&(pw|forbidden|mask(h)|mask(ph)):continue
            uid=(l,r,tuple(sorted(candidates)))
            if uid in seen:continue
            prep=list(old[t]);prep[actor]=d;prep=''.join(prep)
            effect=command_effect(h,w,p,prep)
            if not effect or effect[0]!=pw:continue
            prep_h=effect[1]
            prep_root=comp(prep_h,pw)
            if prep_root!=prior:continue
            if any(flood(B[x],ALL^pw)!=flood(B[y],ALL^pw) for x,y in zip(ph,prep_h,strict=True)):continue
            if not geometry(p,pw,prep_h,narrow,cap,far):continue
            cap_w=pw|cb|B[far];alt=comp(prep_h,cap_w)
            if (anchors&prior)&~alt:continue
            if any(not B[p[i]]&narrow for i in candidates):continue
            # Preserve every remaining exterior component per actor, except
            # the newly shut footprint; the old mouth remains outside.
            shrink=narrow|cb|B[far]
            if any(flood(B[x],ALL^pw)&~shrink & ~flood(B[x],ALL^cap_w) for x in prep_h):continue
            seen.add(uid);stats['proposals']+=1
            out.append(dict(t=t,gate=gate,far=far,cap=cap,actor=actor,partner=partner,d=d,l=l,r=r,a=a,b=b,
                         body=narrow,inside=sorted(candidates),blockers=sorted(blockers),prep=prep,shadow=prep_h))
            break
    return out
def label(board,st,commands,jobs,paid,picks,stats):
    anchors=mask(row*30+c for row in range(30) for c in LANES[board['map']])
    details=[];early=set()
    for q in picks:
        t=q['t']+1;p,h,w=st[t];h0=q['shadow'];a,b=q['actor'],q['partner']
        gate,far,cap=q['gate'],q['far'],q['cap'];d=q['d']
        same=any(j[:4]==(q['l'],q['r'],q['a'],q['b']) for j in jobs[t])
        rs=paid.get(t,'1'*len(h));old=commands[t]
        st0=command_effect(h,w,p,old);assert st0
        ow,oh=st0;before=comp(h,w);stock_root=comp(oh,ow)
        captured=new_ids(p,before,stock_root)
        inside=set(q['inside']);current={i for i,x in enumerate(p) if B[x]&q['body']}
        draft=dict(start=t-1,selected_ids=sorted(inside),supported=False)
        own_op,far_op=d.lower(),('l' if d=='R' else 'r')
        old_same_close=same and old[a]==own_op and old[b]==far_op
        allowed=old_same_close or all(old[i]=='.' and (same or rs[i]=='0') for i in (a,b))
        # Even for an originally same role, no third action may replace its
        # active setup step; only the original same-room build or true dots.
        if inside<=current and allowed:
            op=list(old);op[a]=own_op;op[b]=far_op
            z=command_effect(h0,w,p,''.join(op))
            if z:
                nw,nh=z
                old_selected=(B[gate]|B[far]) if old_same_close else 0
                expected=(ow&~old_selected)|B[cap]|B[far]
                root=comp(nh,nw);new=new_ids(p,before,root)
                common=not ((stock_root&anchors)&~root) and captured<=new
                capbits=B[cap]|B[far]
                lost_ok=0 if old_same_close else q['body']|capbits
                exterior=all(not (flood(B[x],ALL^ow)&~lost_ok&~flood(B[y],ALL^nw))
                             for x,y in zip(oh,nh,strict=True))
                if (nw==expected and common and exterior and inside<=new and room_equals(nw&~capbits,q['body'],capbits)
                        and not q['body']&root):
                    if old_same_close:
                        # Same stock-caught IDs, exact smaller body; any
                        # extra newly caught pet separately accounted.
                        typ='smaller_same' if inside<=captured else 'earlier'
                    else:typ='earlier'
                    added=(new-captured)&inside
                    stats['supported']+=1;stats[typ]+=1
                    early|=added
                    draft.update(supported=True,kind=typ,earlier=sorted(added),alternate=''.join(op))
        if not draft['supported']:
            # Cancellation must restore identical stock absolute next poses,
            # walls and captures. Allow scout dot only if unclaimed or the
            # same paid room; no new paid work may be silently overridden.
            op=list(old);op[a]='L' if d=='R' else 'R'
            back=command_effect(h0,w,p,''.join(op)) if old[a]=='.' and (same or rs[a]=='0') else None
            if back!=st0:
                stats['protected_cancellation_conflicts']+=1
                draft['cancel_conflict']=True
            else:stats['safe_cancels']+=1
        details.append(draft)
    return details,early
def audit(exe):
    now=time.monotonic();d1=now+120;d2=now+180
    assert hashlib.sha256(LED.read_bytes()).hexdigest()=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
    assert hashlib.sha256(OBS.read_bytes()).hexdigest()=='0adb6fdafc77a7a778dbd5ff11a812ef95379124a2f8201dcebe527618409d70'
    cohort=json.loads(LED.read_text());assert len(cohort)==len({q['case'] for q in cohort})==100
    rows=[];c=collections.Counter()
    for q in cohort:
        _,state,old=case_history(q);nfile=q['case']
        raw=(I/nfile).read_text().splitlines();n=int(raw[0]);m=int(raw[n+1])
        taped=(P/'tapes'/nfile).with_suffix('.trace').read_text().splitlines()
        payload='\n'.join(raw[:n+2+m]+taped[1:550:2])+'\n'
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'trace'
            r=subprocess.run([str(exe.resolve()),'--pairs=0'],input=payload,text=True,capture_output=True,
                check=True,timeout=max(.001,d1-time.monotonic()),env=dict(os.environ,AHC008_DUAL_HOLD_TRACE=str(path)))
            assert r.stdout.splitlines()==old[:275],nfile
            jobs,paid=readlog(path,m)
        picks=screen(q,state,old,jobs,c)
        if picks:rows.append((q,state,old,jobs,paid,picks))
        if time.monotonic()>d1:raise TimeoutError('structural deadline')
    result=dict(verified=100,structural_boards=len(rows),counts=c,passes=False)
    if len(rows)<20 or c['proposals']<30:return result|dict(phase='structural-stop')
    supported=earlier_boards=heads=0;events=[]
    for q,st,old,jobs,paid,picks in rows:
        if time.monotonic()>d2:raise TimeoutError('total deadline')
        d,ids=label(q,st,old,jobs,paid,picks,c)
        supported+=any(x['supported']for x in d); earlier_boards+=bool(ids);heads+=len(ids)
        events.append(dict(case=q['case'],labels=d))
    if time.monotonic()>d2:raise TimeoutError('total deadline')
    assert c['proposals']==c['supported']+c['safe_cancels']+c['protected_cancellation_conflicts']
    passed=(c['supported']>=10 and supported>=8 and 2*c['supported']>=c['proposals']
            and heads>=5 and earlier_boards>=5 and not c['protected_cancellation_conflicts'])
    return result|dict(phase='signed-labels',supported_boards=supported,earlier_boards=earlier_boards,earlier_ids=heads,events=events,passes=passed)
if __name__=='__main__':
    try:print(json.dumps(audit(Path(sys.argv[1])),indent=2))
    except (AssertionError,TimeoutError,subprocess.SubprocessError,OSError) as e:
        raise SystemExit(f'incomplete: {type(e).__name__}: {e}') from e
