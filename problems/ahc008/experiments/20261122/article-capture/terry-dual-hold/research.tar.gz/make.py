"""Observation-only derivative. Run only after explicit detached-audit approval."""
import hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
raw=(D.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
s=raw.decode()
def put(a,txt):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,txt)
t='namespace terry_exact_root {'
s=s.replace(t,t+'''
inline int dual_hold_turn=-1;
inline std::vector<std::string> dual_hold_rows;
''',1)
t='    hunt::emit(s.people,jobs,legal,booked);'
put(t,t+'''
    if(dual_hold_turn>=0)for(const auto& j:jobs){
      if(j.left<0||j.right<0||j.a==j.b)continue;
      // Log all genuine paired roles; exact original post-emit hold status.
      auto z=std::string("J ")+std::to_string(dual_hold_turn);
      auto add=[&](int v){z+=" "+std::to_string(v);};
      add(j.left);add(j.right);add(j.a);add(j.b);
      add(booked[j.a].value_or(0)=='.'&&booked[j.b].value_or(0)=='.');
      for(int p=0;p<V;++p)if(geometry.ids[p]==j.room&&p!=j.left&&p!=j.right)add(p);
      dual_hold_rows.push_back(std::move(z));
    }
''')
t='   idle_phase(s,terrain->aisleColumns,action);'
put(t,'''
   if(dual_hold_turn>=0){
      auto z=std::string("R ")+std::to_string(dual_hold_turn)+" ";
      for(char a:action)z+=a?'1':'0';
      dual_hold_rows.push_back(std::move(z));
   }
'''+t)
t='  if(turn==275)d=decide(s,policy,cap,stop);'
put(t,'''
  const char* dual_hold_path=std::getenv("AHC008_DUAL_HOLD_TRACE");
  if(dual_hold_path&&turn==275){
    std::ofstream f(dual_hold_path);
    for(const auto& x:dual_hold_rows)f<<x<<'\\n';
    return f?0:3;
  }
  dual_hold_turn=dual_hold_path?turn:-1;
'''+t)
t='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(t,t+'\n  dual_hold_turn=-1;')
(D/'observer.private.cpp').write_text(s)
