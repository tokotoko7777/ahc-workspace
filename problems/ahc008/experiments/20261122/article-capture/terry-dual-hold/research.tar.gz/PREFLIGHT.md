# Already aligned paired paid holds, exterior-only veto (unexecuted)

One fixed signed accepted incoming held100 cohort. Source incoming_shadow
live.private.cpp SHA 6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40,
ledger dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5,
parser 0adb6fdafc77a7a778dbd5ff11a812ef95379124a2f8201dcebe527618409d70.
Observer records genuine selected two-mouth roles and whether BOTH phase3
outputs are explicitly reserved holds; logs full original pre-idle paid
mask (missing phase4 row conservatively means all reserved). Factual
moves must agree byte-for-byte t0–274 for all100; signed full action,
input and reply SHA checked without executing a scorer. No source,
RNG, or submitted command is altered; generated private assembly stays
local. Virtual cutoff is not exercised.

## Current-only eligibility

At a true paired hold, both exact distinct exterior stances already
occupied by their original actors, both original commands dots. Take
first eligible ordered stock job per turn. Exactly one old gate is
physically illegal solely because of one or more animals outside its
actual original room body; no walls, human/reserved movement or other
illegal cause on either mouth. In the actual post-command board both
original mouths together, and neither alone, must seal exactly named
old body. Inward cap is one step into that body, exact physical smaller
body is old body minus cap, both caps legal apart from linked guard
being one step away. Entire current reachable occupied roster fits the
smaller body. Replace only blocked-mouth guard's own explicit hold
with a move onto its old open mouth. Verify current original walls,
all other actual commands, all earlier newly-split stock IDs and
per-person component reach are unchanged; for certified hypothetical
close, never lose reachable exterior beyond the named smaller body
and new caps, and no existing service anchor loss. Dedup board, old
mouths, current exact roster; first eligible not-yet-counted per turn.
Current-only selection never reads the next animal response.

## Prospective gate, frozen before observation

Only continue to factual signed t+1 labels if at least 30 distinct
current proposals on at least 20 boards. For the single reserved turn
both actual old operations must be the same room's valid matching pair
close, or dots with the same original paid job (or unreserved), never
a different protected operation. Verify physically legal simultaneous
inward caps from changed stances, real same smaller occupied body and
all current intended IDs still inside. Keep every unrelated issued
command, stock wall and stock-captured ID, preserve per-actor exterior
and all service anchors. Label smaller-same separately from any
genuinely earlier distinct ID not isolated by factual stock that turn.
If unavailable, attempt one legal reverse into original outward stance
with paid-work protection; require exact old absolute post-poses and
wall sets. Count all incompatible cancels, not just supported actions.

Pass only if >=10 supported events on >=8 boards, >=50% of *all*
causal proposals supported, >=5 distinct earlier heads across >=5
boards, and zero incompatible cancellation/paid losses or dropped
stock captures. This is intentionally stronger than earlier 32.8%
inward prep screen. Factual signed movement is not a causal estimate;
a guard entering the old mouth can alter dog/cat motion, and outside
animals have nonzero reachability into shifted gate veto, not assumed
safe. No claims about later live guarantees.

Later approved workflow only: verify frozen source SHA manifest, run
make.py, GNU C++23 compile with external cap, run validate.py with
observer binary under 180s external timeout. Structural cap 120s;
any command/phase/hash failure or timeout is incomplete, never partial
promotion. Only independent artifact preparation was done, no
generation, compilation, score, solver run, or replay.
