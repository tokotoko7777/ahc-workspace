"""Verify signed accepted case/input/action/trace identity before interpreting audit."""
import csv,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parents[1]
p=r/'ahc008_terry_hunt_wall_audit'
h=r/'ahc008_terry_incoming_shadow/held100'
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert sha(p/'recordings.json')=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
a={z['case']:z for z in json.loads((p/'recordings.json').read_text())}
b={z['case']:z for z in csv.DictReader((h/'confirm.csv').open()) if z['arm']=='terry_independent'}
assert a.keys()==b.keys() and len(a)==100
for f,x in a.items():
 y=b[f]
 assert x['input_sha']==y['input_sha']==sha(h/'in'/f)
 assert x['commands_sha']==y['commands_sha']==sha((p/'tapes'/f).with_suffix('.actions'))
 assert x['trace_sha']==sha((p/'tapes'/f).with_suffix('.trace'))
 assert int(x['score'])==int(y['score'])
print('signed original input/actions/trace checks: 100/100')
