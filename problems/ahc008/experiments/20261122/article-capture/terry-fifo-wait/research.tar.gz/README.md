# Tier A: adjacent same-owner later wall on a genuinely pet-blocked wait

PREP ONLY. Do not run or compile until the root serial benchmark lock is released. No observer, alternative policy, compile, or judge was executed while staging these files. No solver/remote modifications. make.py pins current adopted split-bound source SHA f83fd834… and creates a private, observation-only derivative. No source/model values are included in this folder.

After exact literal FIFO, log real stance waits that began with at least one actually missing head X, all missing bits blocked by observed pet adjacency (not a person's occupancy), no earlier productive constructor action, and booked at the stock head. The eligible X list comes from strictly later tasks of this same worker, adjacent to the actual current stance. The detached audit requires actual final submitted action '.' for that worker and preserves every other actor's command. No movement detour variant. It applies the one added wall against actual current placements, original post-action movement destinations, configured gates, and service cells; certified it does not lose any currently stock-isolated animal ID. For each actor, preserve accessibility to original reachable people and real aisle cells, plus all originally reachable pending task stances of that actual owner. No future stock data selects a candidate.

Readiness credit requires one configured room with currently open gates, exact body connectivity if those gates were later sealed, reachable actual exterior stances, no humans in body and old merged geometry not already ready. Deduplicate by (board,configured room); one board can witness many possible rooms but no counterfactual execution or turns-saved claim. A separate descriptive count deduplicates eligible progress-only (actor,head,target), even when no room newly ready. Recorded stock X build turns are labeled factual only, never causally projected. GO threshold frozen: at least 12 distinct ready rooms across at least 8 signed held boards, zero lost stock isolate IDs, complete 100 valid matching prefixes. If lower, stop/no live/retune.

## Future serial run

1. Prefer existing exact accepted incoming held100 official action+replay transcripts, supplied as directory containing 0000.actions and 0000.trace etc. No partial dataset/alternate sample. If absent, recover solely when scheduler allows with existing materializer and accepted incoming binary, matching both score and signed action SHA-256:

       python ahc008_terry_scaffold_audit/materialize.py ahc008_focus_assets/tools/target/release/tester ahc008_terry_incoming_shadow/live ahc008_terry_incoming_shadow/held100/in ahc008_terry_incoming_shadow/held100/confirm.csv ahc008_terry_fifo_wait/held-tapes

   Archived official accepted arm is terry_independent. Materializer uses its logged late pair count solely to reproduce the reference tape; missing or mismatched cases are errors for the signed panel and cannot be substituted.
2. Observer runs only t0–159, consumes exactly those official returned replies and no seed or suffix. No --pairs or --ms flags. The source derivative exits before t160 and never reaches its first clock/late MC decision at t275. After seed/init, observer stdout must be exactly the first 160 replayed accepted action commands. Map ID, final END 160 marker, full input/action SHA and independently replayed official score are hard checks. The analyzer pins ledger/manifests and terrain room catalog.

       cd ahc008_terry_fifo_wait
       python make.py
       g++ -std=gnu++23 observer.private.cpp -o observer
       python audit.py held-tapes observer > results.json

Rough estimate, not measured: compilation 5–20 s, prefix replay/analyzer 15–60 CPU s total for 100, exact tape materialization if needed ≈270+ seconds serial from held ledger per-case 2.7 s; no budget collision with current pipeline. Keep private derivative/control artifacts in workspace only.
