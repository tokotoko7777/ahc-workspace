"""Prefix-authenticated detached Tier-A geometry audit. Never executes an alternative."""
import argparse,csv,hashlib,json,os,subprocess,sys
from pathlib import Path
from collections import Counter,defaultdict
D=Path(__file__).resolve().parent;R=D.parent
F=R/'ahc008_terry_incoming_shadow/held100'
CAT=R/'ahc008_terry_small_rooms/catalog.tsv'
sys.path.insert(0,str(R/'ahc008_focus_solver/problems/ahc008'))
from benchmark import replay
V=900;ALL=(1<<V)-1
B=[1<<p for p in range(V)]
NB=[tuple(q for q in (p-30 if p>=30 else -1,p+1 if p%30<29 else -1,
                       p+30 if p<870 else -1,p-1 if p%30 else -1) if q>=0) for p in range(V)]
NBIT=[sum(B[q] for q in row) for row in NB]
def bits(xs):
 k=0
 for p in xs:k|=B[p]
 return k
COL0=bits(range(0,V,30));COL29=COL0<<29
def wave(x):return ((x&~COL0)>>1)|((x&~COL29)<<1)|(x>>30)|((x<<30)&ALL)
def flood(x,open):
 x&=open
 while True:
  y=x|(wave(x)&open)
  if y==x:return y
  x=y
def target(p,c):
 d='URDL'.index(c.upper())
 row,col=divmod(p,30);r=row+(-1,0,1,0)[d];s=col+(0,1,0,-1)[d]
 assert 0<=r<30 and 0<=s<30
 return r*30+s
def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
 f=iter(raw.decode().splitlines())
 np=int(next(f));p=[tuple(map(int,next(f).split())) for _ in range(np)]
 nh=int(next(f));h=[tuple(map(int,next(f).split())) for _ in range(nh)]
 return [(r-1)*30+c-1 for r,c,_ in p],[(r-1)*30+c-1 for r,c in h],np+nh+2
def project(p,h,w,cmd):
 blocked=w|bits(h)|bits(p)|wave(bits(p))
 nxt=[];extra=0
 for a,c in zip(h,cmd,strict=True):
  if c=='.':nxt.append(a);continue
  q=target(a,c)
  if c.islower():
   assert not B[q]&(blocked|extra)
   extra|=B[q];nxt.append(a)
  else:nxt.append(q)
 assert not bits(nxt)&(w|extra)
 return nxt,w|extra
def footprints():
 assert sha(CAT.read_bytes())=='2d697e1b2cbf0cd9d754d38a18059e2fbcd484b7440868da8016f8310132ba06'
 out=defaultdict(list)
 for l in CAT.read_text().splitlines():
  m,r,a,b,*body=map(int,l.split())
  if body:out[m].append((r,bits(body),bits(p for p in (a,b) if p>=0),
                         bits(p for p in (a-1 if a>=0 else -1,b+1 if b>=0 else -1) if 0<=p<V)))
 return out
# Canonical actual aisle columns, checked against the independently derived map.
def service_masks():
 import re
 raw=(R/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
 cols=[tuple(map(int,m.split(','))) for m in re.findall(r'^\s*\{\s*\{([0-9, ]+)\},',raw,re.M)]
 assert len(cols)==5,cols
 return [bits(r*30+c for c in cs for r in range(30)) for cs in cols]
def ready(body,gates,w):
 return not (body|gates)&w and flood(body&-body,ALL^(w|gates))==body
def inspect(row, raw, actions, trace, obs, rooms, services):
 stock=actions.decode().splitlines()
 assert sha(raw)==row['input_sha'] and sha(actions)==row['commands_sha']
 assert len(stock)==300 and trace[::2]==stock
 assert replay(raw.decode(),trace,stock,detailed=True)[0]==int(row['score'])
 p,h,n=parse(raw)
 # Omit official seed line. Exactly the first 160 replies; no suffix enters the observer.
 payload='\n'.join(raw.decode().splitlines()[:n]+trace[1:320:2])+'\n'
 run=subprocess.run([str(obs.resolve())],input=payload,text=True,capture_output=True,check=True,timeout=4)
 assert run.stdout.splitlines()==stock[:160]
 tags=run.stderr.splitlines()
 mid=int(tags[0].split()[1]);assert tags[0]==f'MAP {mid}' and tags[-1]=='END 160'
 assert mid==int(row['telemetry'].split()[0])
 T={};W=defaultdict(list)
 for line in tags[1:-1]:
  a,t,*q=line.split();t=int(t);assert 0<=t<160
  if a=='T':
   b,book,*jobs=q
   assert t not in T and len(b)==len(book)==len(h)
   T[t]=(b,book,[tuple(map(int,p.split(':'))) for p in jobs])
  else:
   assert a=='W' and t in T
   W[t].append(tuple(map(int,q)))
 rby=rooms[mid];svc=services[mid]
 doors=0
 for _,_,g,_ in rby:doors|=g
 w=0;out=[];stats=Counter();credits=set();descriptive=set();lost=set()
 factual_walls={}
 for t,cmd in enumerate(stock):
  hh,ww=project(p,h,w,cmd)
  for i,x in enumerate(h):
   if cmd[i].islower():factual_walls.setdefault(target(x,cmd[i]),t)
  if t in W:
   tag,book,jobs=T[t]
   now=flood(bits(h),ALL^w)
   orig=flood(bits(hh),ALL^ww)
   pi=bits(p)
   ban=ww|bits(h)|bits(hh)|pi|wave(pi)|doors|svc
   for actor,head,*late in W[t]:
    assert h[actor]==head and tag[actor]=='.' and book[actor]=='1'
    if cmd[actor]!='.':continue
    stats['pet_only_wait_slots']+=1
    for z in late:
     if z not in NB[head] or ban&B[z]:continue
     ng=ww|B[z];free=ALL^ng
     after=flood(bits(hh),free)
     lostIDs=tuple(i for i,x in enumerate(p) if B[x]&now&~orig&after)
     if lostIDs:lost.update((t,actor,z,i) for i in lostIDs);continue
     # Preserve every stock-reachable person/service, and every later
     # original task stance previously reachable from its actual owner.
     keep=True
     graphs=[(flood(B[x],ALL^ww),flood(B[x],free)) for x in hh]
     required=bits(hh)|svc
     for g,a in graphs:keep&=not (g&required&~a)
     for i,x in jobs:keep&=not bool(B[x]&graphs[i][0]&~graphs[i][1])
     if not keep:continue
     descriptive.add((actor,head,z))
     # No rewards for merely advancing construction.
     found=[]
     for rid,body,gates,stances in rby:
      if not (wave(body)&B[z]) or body&bits(hh) or stances&~after:continue
      if ready(body,gates,ng) and not ready(body,gates,ww):
       if rid not in credits:found.append(rid)
       credits.add(rid)
     if found:out.append(dict(t=t,actor=actor,head=head,x=z,rooms=found))
  h,w=hh,ww
  for i,s in enumerate(trace[2*t+1].split()):
   for c in s:
    if c!='.':p[i]=target(p[i],c)
 for x in out:x['factual_stock_build_turn']=factual_walls.get(x['x'])
 return dict(case=row['case'],map=mid,stats=dict(stats),readiness=len(credits),
             readiness_witness=out,progress_distinct=len(descriptive),lost_isolate_ids=len(lost),
             prefix_sha=sha(('\n'.join(stock[:160])+'\n').encode()))
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('tapes',type=Path);p.add_argument('observer',type=Path)
 args=p.parse_args()
 assert sha((F/'confirm.csv').read_bytes())=='9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2'
 assert sha((F/'SHA256SUMS').read_bytes())=='a0727270a693c960a66a7f25b6393fbbd03e9d667a0f2483743c97fc799b1262'
 rows=[x for x in csv.DictReader((F/'confirm.csv').open()) if x['arm']=='terry_independent']
 assert len(rows)==100 and len({x['case'] for x in rows})==100
 manifest={name: digest for digest,name in (line.split() for line in
                    (F/'SHA256SUMS').read_text().splitlines())}
 assert len(manifest)==100 and all(manifest['in/'+x['case']]==x['input_sha'] for x in rows)
 rooms=footprints();svc=service_masks();out=[]
 for x in rows:
  f=x['case'];stem=args.tapes/f
  out.append(inspect(x,(F/'in'/f).read_bytes(),stem.with_suffix('.actions').read_bytes(),
                     stem.with_suffix('.trace').read_text().splitlines(),args.observer,rooms,svc))
 tot=sum(x['readiness'] for x in out);boards=sum(bool(x['readiness']) for x in out);lost=sum(x['lost_isolate_ids'] for x in out)
 print(json.dumps(dict(ready=tot,boards=boards,lost_isolate_ids=lost,passes=tot>=12 and boards>=8 and lost==0,
      progress_distinct=sum(x['progress_distinct'] for x in out),detail=out),indent=2))
if __name__=='__main__':main()
