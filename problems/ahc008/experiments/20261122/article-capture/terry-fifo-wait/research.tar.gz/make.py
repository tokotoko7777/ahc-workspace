"""Assemble private observation-only prefix; do not execute during another timed batch."""
from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
src=D.parent/'ahc008_terry_split_bound/solve.private.cpp'
raw=src.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
s='#include <iostream>\n'+raw.decode()
def patch(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
token='  auto stage=crew.act_literal(actual_array,s.people,ps);'
patch(token,'''  struct Wait {int actor,pivot; std::vector<int> wall;};
  std::vector<Wait> waits;
  exact_build::Board nearpet{}, human{};
  for(int p:ps){nearpet[p]=1;for(int r:exact_build::nb(p))if(r>=0)nearpet[r]=1;}
  for(int p:s.people)human[p]=1;
  for(int i=0;i<(int)crew.q.size();++i){
   const auto& q=crew.q[i];
   auto f=std::find_if(q.begin(),q.end(),[](auto job){return job.mask!=0;});
   if(f==q.end()||f->at!=s.people[i])continue;
   int missing=0;bool petOnly=true;
   const auto n=exact_build::nb(f->at);
   for(int d=0;d<4;++d)if((f->mask>>d&1)&&n[d]>=0&&!actual_array[n[d]]){
     ++missing;petOnly&=nearpet[n[d]]&&!human[n[d]];
   }
   if(!missing||!petOnly)continue;
   Wait a{i,f->at,{}};
   for(auto j=std::next(f);j!=q.end();++j){
    const auto r=exact_build::nb(j->at);
    for(int v=0;v<4;++v)if((j->mask>>v&1)&&r[v]>=0&&
      crew.layout.ascii[r[v]]=='X'&&!actual_array[r[v]]&&exact_build::md(f->at,r[v])==1)
      a.wall.push_back(r[v]);
   }
   std::sort(a.wall.begin(),a.wall.end());
   a.wall.erase(std::unique(a.wall.begin(),a.wall.end()),a.wall.end());
   waits.push_back(std::move(a));
  }
  '''+token+'''
  if(!waits.empty()){
   std::cerr<<"T "<<turn<<" "<<stage.action<<" ";
   for(auto b:stage.booked)std::cerr<<int(b);
   for(int i=0;i<(int)crew.q.size();++i)for(const auto& q:crew.q[i])
    if(q.mask)std::cerr<<" "<<i<<":"<<q.at;
   std::cerr<<'\\n';
   for(auto& w:waits)if(stage.booked[w.actor]&&stage.action[w.actor]=='.'){
    std::cerr<<"W "<<turn<<" "<<w.actor<<" "<<w.pivot;
    for(int p:w.wall)std::cerr<<" "<<p;
    std::cerr<<'\\n';
   }
  }
''')
patch(' for(int turn=0;turn<300;++turn){\n  if(turn==275)d=decide(s,policy,cap,stop);',
''' std::cerr<<"MAP "<<map<<'\\n';
 for(int turn=0;turn<160;++turn){
  if(turn==275)d=decide(s,policy,cap,stop); // unreachable in prefix mode
''')
patch(' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){',
''' std::cerr<<"END 160\\n";
 if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){''')
(D/'observer.private.cpp').write_text(s)
