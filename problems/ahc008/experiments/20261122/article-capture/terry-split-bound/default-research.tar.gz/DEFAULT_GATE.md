# Native-clock admission of feasible upper-bound pruning
After both fixed-work 100-case panels pass, pair the current adopted
first-Chase memo against that same code with this localized split
patch, native internal 2670 ms, serial, no forced pair caps. Reuse
official distributed and the preexisting precommitted separate fresh100
from first-Chase validation. Both have exact action/score ledgers and
were not used in constructing the bound or adjusting its parameters.
Require official score, playback and independent match on all; same or
higher full and useful counts and total score on each panel; tester
wall maximum below 2.95 s. This is solely an admission gate. An exact
fixed-work result does not authorize adoption with a worsening clocked
result. Do not tune from a failed native comparison.
