 // A concrete assignment gives a feasible bound, independent of the
 // exact DP's traversal. Keep every transition that can *tie* it.
 int upper=INF;
 for(bool balanceWork:{false,true}){
  std::array<std::array<int,10>,10> costs{};
  int from=0;
  for(int j=0;j<M;++j){
   const int remain=M-1-j;
   const int lower=std::max(from+1,L-remain*window);
   const int higher=std::min(from+window,L-remain);
   const int ideal=balanceWork?int(std::lower_bound(into.begin(),into.end(),into.back()*(j+1)/M)-into.begin()):L*(j+1)/M;
   const int to=std::clamp(ideal,lower,higher);
   const int span=into[to]-outof[from];
   for(int k=0;k<M;++k)costs[j][k]=span+std::min(approach[from][k],approach[to-1][k]);
   from=to;
  }
  std::array<int,1<<10> mb;
  std::fill_n(mb.begin(),full+1,INF);
  mb[0]=0;
  for(int used=0;used<full;++used){
   const int p=std::popcount(unsigned(used));
   for(unsigned u=unsigned(full^used);u;u&=u-1){
    const int k=std::countr_zero(u),next=used|(1<<k);
    const int c=std::max(mb[used],costs[p][k]);
    if(c<mb[next])mb[next]=c;
   }
  }
  upper=std::min(upper,mb[full]);
 }
