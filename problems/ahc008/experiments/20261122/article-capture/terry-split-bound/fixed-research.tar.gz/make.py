"""Pinned accepted incoming implementation -> split valid incumbent pruning."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_first_chase_reuse/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='8f50dda74f578fc8ddbf8176d15172a80df96d23d82c57db8ae51aedce4294b7'
a=s.index('inline Split split('); b=s.index('inline Split initialize(', a)
before=s[a:b]; patch=(d/'bound.hpp').read_text()
assert before.count(' const int full=(1<<M)-1,window=2*L/M,stride=L+1;\n')==1
after=before.replace(' const int full=(1<<M)-1,window=2*L/M,stride=L+1;\n',
                    ' const int full=(1<<M)-1,window=2*L/M,stride=L+1;\n'+patch)
after=after.replace('    const int span=into[to]-outof[from];','    const int span=into[to]-outof[from];\n    if(span>upper)break;').replace('     if(z<dp[at])','     if(z<=upper&&z<dp[at])')
(d/'control.hpp').write_text(before.replace('inline Split split(','inline Split split_control(',1))
(d/'solve.private.cpp').write_text(s[:a]+after+s[b:])
