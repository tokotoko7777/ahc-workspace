# Exact feasible-upper-bound pruning for ordered split
Current accepted incoming solver; one localized startup optimization.
Construct two valid partitions from evenly split lengths and from prefix
work/travel quantiles clamped to a positive length at most window.
Exactly assign workers to each fixed partition by subset bottleneck
matching; minimum of their concrete makespans is an admissible upper
bound. Skip only transitions strictly exceeding it. Preserve original
iteration order, predecessor and forward-first equality, including when
the optimum equals the upper bound. Fixed work otherwise unchanged.
Check all 360 old orientations and 240 new tie/boundary fixtures, comparing
makespan, path and every output action per worker; collect paired kernel
CPU on alternating call order. Require lower CPU by 12% on representative
original maps and no slowdown >10% in any staff-count group. Only after
that use serial official plus independent fixed-work panels; require both
hash and score equality and aggregate CPU gain by at least 2% on each.
Normal timing gate independent. No retuning based on official results.
