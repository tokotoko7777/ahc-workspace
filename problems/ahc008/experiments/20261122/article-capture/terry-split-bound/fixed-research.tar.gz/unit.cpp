#define main archive_submission_main
#include "solve.private.cpp"
#undef main
#include <numeric>
#include <random>
#include <cstdio>
#include <ctime>
namespace exact_build {
#include "control.hpp"
}
int main(){
 using namespace exact_build;
 namespace t=terry_exact_maps;
 std::mt19937 rng(7078821);
 int fixtures=0;
 std::array<std::array<double,2>,11> timing{};
 std::array<int,11> count{};
 bool timed=true;
 auto check=[&](const Layout& l,const std::vector<int>& people){
  for(bool f:{false,true}){
   Split a,b;
   auto record=[&](int axis,Split& target,auto fn){
    auto before=std::clock();
    target=fn(l,people,f);
    if(timed)timing[people.size()][axis]+=double(std::clock()-before)/CLOCKS_PER_SEC;
   };
   if((fixtures/2%2)^f){record(0,a,split_control);record(1,b,split);}
   else{record(1,b,split);record(0,a,split_control);}
   if(timed)++count[people.size()];
   assert(a.makespan==b.makespan&&a.right==b.right&&a.path==b.path&&a.q.size()==b.q.size());
   for(int j=0;j<(int)a.q.size();++j){
    assert(a.q[j].size()==b.q[j].size());
    for(int k=0;k<(int)a.q[j].size();++k)
     assert(a.q[j][k].at==b.q[j][k].at&&a.q[j][k].mask==b.q[j][k].mask);
   }
   ++fixtures;
  }
 };
 for(int i=0;i<5;++i){
  const auto& tt=t::terrain(i);
  Layout l; l.aisleRows=tt.aisleRows;l.aisleCols=tt.aisleColumns;
  for(int p=0;p<V;++p)l.ascii[p]=char(tt.cells[p]);
  for(int m=5;m<=10;++m)for(int q=0;q<2;++q){
   std::vector<int> people(m);
   if(q==0){for(auto& a:people)a=int(rng()%V);}
   else std::fill(people.begin(),people.end(),rng()%V);
   check(l,people);
  }
 }
 timed=false;
 for(int g=0;g<240;++g){
  const int m=1+g%5;
  Layout l;
  l.ascii.fill('.');l.aisleRows={1,3};
  l.aisleCols={8,21};
  l.ascii[N+N-1]=l.ascii[3*N+N-1]='~';
  for(int i=0;i<g%31;++i)l.ascii[rng()%(4*N)]='X';
  std::vector<int> people(m);
  for(auto& p:people)p=rng()%V;
  if(g>=120)std::fill(people.begin(),people.end(),g%2?0:V-1);
  check(l,people);
 }
 for(int m=5;m<=10;++m) std::printf("m=%d n=%d old=%.9f new=%.9f\n",m,count[m],timing[m][0],timing[m][1]);
 std::printf("%d exact orientations, makespan, and every queued action matched\n",fixtures);
}
