# Sequential fixed-work experiment on the current first-Chase baseline
Private pinned current parent first-Chase cache; the identical split
function was measured in the component test. Compilation requires
GNU C++23, optimization included in the solver. Use baseline candidate
rows of both already-validated native ledgers for diagnostic fixed pair
counts; per-input caps never go into live policy. Audit all output
action hashes and score against original native evidence. Tester wall
less than 2.95 s. Control/variant order alternates across input rows.
Require 2% lower summed standalone solver CPU on each 100-case panel.
If distributed fails, do not start fresh. Separated normal clock gate
only after fixed both, requires no decline in total, useful or full
on either panel; maximum tester wall less than 2.95 s.
