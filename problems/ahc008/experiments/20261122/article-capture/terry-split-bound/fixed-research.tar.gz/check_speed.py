import csv
import json
import sys
p=list(csv.DictReader(open(sys.argv[1])))
assert len(p)==200 and len({(r['arm'],r['case']) for r in p})==200
res={}
for name, q in [('total',p),('normal-only',[r for r in p if r['draws']=='0']),('rollout',[r for r in p if r['draws']!='0'])]:
    base,fast=([r for r in q if r['arm']==a] for a in ('baseline','fast'))
    cpua,cpub=(sum(int(r['cpu_us']) for r in x) for x in (base,fast))
    assert len(base)==len(fast) and base
    res[name]=dict(cases=len(base),cpu_us=[cpua,cpub],saving=1-cpub/cpua,
        max_wall=[max(float(r['wall']) for r in x) for x in (base,fast)])
print(json.dumps(res,indent=2))
if res['total']['saving']<.02 or max(res['total']['max_wall'])>=2.95:
    raise SystemExit("frozen aggregate CPU or wall admission gate failed")
