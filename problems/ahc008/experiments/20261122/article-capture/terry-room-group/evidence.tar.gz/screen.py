"""One-step delayed grouping: frozen-board opportunities, not a live policy."""
import csv,hashlib,json,sys
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ahc008_terry_inward_gates'))
from screen import B,ALL,bitmask,cells,flat,flood,markers,near,observed,replay,wave
def calc(row,raw,tape,door):
    case=row['case']; p=tape/case
    a=p.with_suffix('.actions').read_bytes()
    tr=p.with_suffix('.trace').read_text().splitlines();cmd=a.decode().splitlines()
    assert hashlib.sha256(raw).hexdigest()==row['input_sha']
    assert hashlib.sha256(a).hexdigest()==row['commands_sha']
    assert replay(raw.decode(),tr,cmd,detailed=True)[0]==int(row['score'])
    kinds,hist,_=observed(raw,tr)
    catches={i:(t,s) for t,i,k,s in (map(int,z.split(':')) for z in row['captures'].split(';') if z)}
    chase=bool(int(row['telemetry'].split()[13]))
    stats=Counter()
    for t in range(275 if chase else 299):
        ps,hs,ws=hist[t]; _,hn,wn=hist[t+1]
        ps=list(map(flat,ps));hs=list(map(flat,hs));hn=list(map(flat,hn))
        before=bitmask(map(flat,ws)); after=bitmask(map(flat,wn)); built=after^before
        old=flood(bitmask(hs),ALL^before);new=flood(bitmask(hn),ALL^after)
        caught={i for i,p in enumerate(ps) if B[p]&old and not B[p]&new}
        while caught:
            comp=flood(B[ps[min(caught)]],ALL^after)
            actual=tuple(i for i,p in enumerate(ps) if B[p]&comp)
            caught.difference_update(actual)
            # Use *all* new topological boundary walls; require configured mouths
            # from outward direction and no other simultaneous closure mandate.
            gate=wave(comp)&built
            if not gate or gate.bit_count()>2:continue
            actors={}
            for i,d in enumerate(cmd[t]):
                if d not in 'urdl':continue
                x=near(hs[i],d.upper())
                if x not in door or door[x]!=d.upper() or not (B[x]&gate):continue
                y=near(x,d.upper())
                if y is not None and B[y]&comp:actors[x]=i
            if bitmask(actors)!=gate or len(set(actors.values()))!=len(actors):continue
            stats['rooms']+=1; stats['heads']+=len(actual)
            # These workers just stay at their exact original stances; all
            # other actual t actions preserved. At t+1 those guards give same walls.
            gw=after^gate
            ban=gate|wave(gate)
            safe=comp&~ban
            assert safe
            outsiders=[i for i,p in enumerate(ps) if i in catches and catches[i][0]>t+1
                       and B[p]&old and not B[p]&comp]
            if not outsiders:continue
            stats['rooms_with_later_separate_outsider']+=1
            stats['later_separate_outsiders']+=len(outsiders)
            assert all(not (B[ps[i]]&ban) for i in outsiders), 'actual gate legality'
            # Any path from outside the original component to its strict safe
            # inside must use a restored gate. Both endpoint-to-gate distances
            # are >=2, since the original gates were legally built.
            near_safe=safe
            for _ in range(3):near_safe|=wave(near_safe)&~gw
            assert not any(B[ps[i]]&near_safe for i in outsiders)
    stats['eligible_rooms']=0
    stats['distinct_targeted_final_rooms']=0
    stats['unique_saved_final_area_upper']=0
    stats['passive_weighted_expected_area_upper']=0
    return dict(case=case,stats=stats)
def main():
    source=ROOT/'ahc008_terry_exact_root/practice100.csv'
    layout=markers(); result=[]; total=Counter(); bymap=defaultdict(Counter)
    for row in csv.DictReader(source.open()):
        if row['arm']!='terry_independent':continue
        i=int(row['telemetry'].split()[0]); _,door=layout[i]
        raw=(ROOT/'ahc008_focus_assets/tools/in'/row['case']).read_bytes()
        z=calc(row,raw,ROOT/'ahc008_terry_scaffold_audit/tapes',door)
        total.update(z['stats']);bymap[i].update(z['stats']);result.append(z)
    assert len(result)==100
    print(json.dumps(dict(totals=total,by_map=bymap,eligible_boards=sum(bool(z['stats']['eligible_rooms']) for z in result),
         whole_room_boards=sum(bool(z['stats']['unique_saved_final_area_upper']) for z in result),cases=result),indent=2))
if __name__=='__main__':main()
