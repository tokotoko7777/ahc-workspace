"""First possible two-turn grouping: frozen-board support upper bound."""
import csv,hashlib,json,math,sys
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ahc008_terry_inward_gates'))
from screen import B,ALL,bitmask,cells,flat,flood,markers,near,observed,replay,wave
def probability(pos,n,w,safe):
    dist={pos:1.}
    for _ in range(n):
        nxt=defaultdict(float)
        for pos,m in dist.items():
            qs=tuple(cells(wave(B[pos])&~w)) or (pos,)
            for q in qs:nxt[q]+=m/len(qs)
        dist=nxt
    return sum(m for q,m in dist.items() if B[q]&safe)
def calc(row,raw,tape,door):
    case=row['case']; p=tape/case
    a=p.with_suffix('.actions').read_bytes()
    tr=p.with_suffix('.trace').read_text().splitlines();cmd=a.decode().splitlines()
    assert hashlib.sha256(raw).hexdigest()==row['input_sha']
    assert hashlib.sha256(a).hexdigest()==row['commands_sha']
    assert replay(raw.decode(),tr,cmd,detailed=True)[0]==int(row['score'])
    kinds,hist,_=observed(raw,tr)
    catches={i:(t,s) for t,i,k,s in (map(int,z.split(':')) for z in row['captures'].split(';') if z)}
    chase=bool(int(row['telemetry'].split()[13]))
    ps,hs,ws=hist[-1]
    final_pets=list(map(flat,ps));final_walls=bitmask(map(flat,ws))
    final_human=flood(bitmask(map(flat,hs)),ALL^final_walls)
    final_comp={}
    for q in final_pets:
        if not B[q]&final_human:
            c=flood(B[q],ALL^final_walls)
            final_comp[c]=[j for j,k in enumerate(final_pets) if B[k]&c]
    speed=(0,1,2,3,2,2)
    stats=Counter(); witnesses=[]; upper=set(); strict={}; optimistic={}
    for t in range(275 if chase else 298):
        ps,hs,ws=hist[t]; _,hn,wn=hist[t+1]
        ps=list(map(flat,ps));hs=list(map(flat,hs));hn=list(map(flat,hn))
        before=bitmask(map(flat,ws)); after=bitmask(map(flat,wn)); built=after^before
        old=flood(bitmask(hs),ALL^before);new=flood(bitmask(hn),ALL^after)
        caught={i for i,p in enumerate(ps) if B[p]&old and not B[p]&new}
        while caught:
            comp=flood(B[ps[min(caught)]],ALL^after)
            actual=tuple(i for i,p in enumerate(ps) if B[p]&comp)
            caught.difference_update(actual)
            # Use *all* new topological boundary walls; require configured mouths
            # from outward direction and no other simultaneous closure mandate.
            gate=wave(comp)&built
            if not gate or gate.bit_count()>2:continue
            actors={}
            for i,d in enumerate(cmd[t]):
                if d not in 'urdl':continue
                x=near(hs[i],d.upper())
                if x not in door or door[x]!=d.upper() or not (B[x]&gate):continue
                y=near(x,d.upper())
                if y is not None and B[y]&comp:actors[x]=i
            if bitmask(actors)!=gate or len(set(actors.values()))!=len(actors):continue
            stats['rooms']+=1; stats['heads']+=len(actual)
            # These workers just stay at their exact original stances; all
            # other actual t actions preserved. At t+1 those guards give same walls.
            gw=after^gate
            ban=gate|wave(gate)
            safe=comp&~ban
            assert safe
            outsiders=[i for i,p in enumerate(ps) if i in catches and catches[i][0]>t+1
                       and B[p]&old and not B[p]&comp]
            if not outsiders:continue
            stats['rooms_with_later_separate_outsider']+=1
            stats['later_separate_outsiders']+=len(outsiders)
            assert all(not (B[ps[i]]&ban) for i in outsiders), 'actual gate legality'
            # All graph supports of exactly up to twice the official speed
            # (another deliberate relaxation, allowing endpoint waiting).
            supports={0:safe}
            for k in range(1,7):supports[k]=supports[k-1]|(wave(supports[k-1])&~gw)
            assert all(not B[ps[i]]&supports[3] for i in outsiders)
            if not all(B[ps[i]]&supports[2*speed[kinds[i]]] for i in actual):continue
            eligible={i for i in outsiders if B[ps[i]]&supports[2*speed[kinds[i]]]}
            if not eligible:continue
            assert all(kinds[i]!=1 for i in eligible)
            stats['eligible_rooms']+=1;stats['eligible_incoming_ids_across_events']+=len(eligible)
            groups=[]
            mass={i:probability(ps[i],2*speed[kinds[i]],gw,safe)
                  for i in set(actual)|eligible if kinds[i]<=3}
            incumbent_bound=math.prod(mass[i] for i in actual if i in mass)
            for q,ids in final_comp.items():
                if set(ids)<=eligible:
                    ids_involved=set(actual)|set(ids)
                    prob=math.prod(mass[i] for i in ids_involved if i in mass)
                    passive_only=ids_involved<=mass.keys()
                    optimistic[q]=max(optimistic.get(q,0.),prob)
                    if passive_only:strict[q]=max(strict.get(q,0.),prob)
                    groups.append(dict(ids=ids,area=q.bit_count(),passive_only=passive_only,probability_bound=prob))
                    upper.add(q)
            if groups:stats['whole_room_events']+=1
            witnesses.append(dict(turn=t,source_area=comp.bit_count(),current_ids=actual,
                                  outside={i:kinds[i] for i in sorted(eligible)},incumbent_bound=incumbent_bound,groups=groups))
    stats['distinct_targeted_final_rooms']=len(upper)
    stats['unique_saved_final_area_upper']=sum(q.bit_count() for q in upper)
    stats['passive_only_final_rooms_positive']=sum(p>0. for p in strict.values())
    stats['passive_only_expected_area_per_room_max']=sum(q.bit_count()*p for q,p in strict.items())
    stats['directed_free_expected_area_per_room_max']=sum(q.bit_count()*p for q,p in optimistic.items())
    return dict(case=case,stats=stats,witnesses=witnesses)
def main():
    source=ROOT/'ahc008_terry_exact_root/practice100.csv'
    layout=markers(); result=[]; total=Counter(); bymap=defaultdict(Counter)
    for row in csv.DictReader(source.open()):
        if row['arm']!='terry_independent':continue
        i=int(row['telemetry'].split()[0]); _,door=layout[i]
        raw=(ROOT/'ahc008_focus_assets/tools/in'/row['case']).read_bytes()
        z=calc(row,raw,ROOT/'ahc008_terry_scaffold_audit/tapes',door)
        total.update(z['stats']);bymap[i].update(z['stats']);result.append(z)
    assert len(result)==100
    print(json.dumps(dict(totals=total,by_map=bymap,eligible_boards=sum(bool(z['stats']['eligible_rooms']) for z in result),
         whole_room_boards=sum(bool(z['stats']['unique_saved_final_area_upper']) for z in result),cases=result),indent=2))
if __name__=='__main__':main()
