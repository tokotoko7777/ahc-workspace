#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=ahc008_terry_chase_hall
sha256sum -c "$D/FROZEN.sha256"
sha256sum -c ahc008_terry_chase_relative_area/FROZEN.sha256
case "${1:-}" in
 compile)
  test ! -e "$D/kernel" && test ! -e "$D/unit"
  python3 "$D/make.py"
  timeout 30 g++ -std=c++23 -O3 "$D/generated.cpp" -o "$D/kernel"
  timeout 20 g++ -std=c++23 -O2 "$D/unit.cpp" -o "$D/unit"
  timeout 15 "$D/unit" | tee "$D/unit.log"
  ;;
 materialize)
  test ! -e "$D/receipt.json" && test ! -e "$D/materialize.log"
  timeout 120 python3 "$D/materialize.py" | tee "$D/materialize.log"
  sha256sum "$D/receipt.json" "$D/snapshots.txt" > "$D/SNAPSHOTS.sha256"
  ;;
 audit)
  test ! -e "$D/report.json" && test ! -e "$D/raw.log"
  sha256sum -c "$D/SNAPSHOTS.sha256"
  timeout 120 "$D/kernel" < "$D/snapshots.txt" > "$D/raw.log"
  python3 "$D/analyze.py" "$D/raw.log" | tee "$D/result.log"
  ;;
 *) exit 2 ;;
esac
