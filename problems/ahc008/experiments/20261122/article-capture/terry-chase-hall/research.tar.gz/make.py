from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
s=(R/'ahc008_terry_chase_relative_area/kernel.cpp').read_text()
def put(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
put('unsigned old_isolated,unsigned newly){','unsigned old_isolated,unsigned newly,int64_t* value){')
put('    if(net.flow(src,snk,Hard)>=Hard)return std::nullopt;',
    '    *value=net.flow(src,snk,Hard);\n    if(*value>=Hard)return std::nullopt;')
put('int main() {','#include "hall.hpp"\n#include "search.inc"\nint main() {')
head='        const auto alt=propose('
assert s.count(head)==1
i=s.index(head)
s=s[:i]+'''        process_root({board,turn,w,common,blocked,tree,
                      eligible(w,common,blocked,tree,people,rem),areach,sw,
                      people,pets,stock.walls,d0,old_isolated,newly,sids,{}});
    }
    process_branches();
}
'''
(D/'generated.cpp').write_text(s)
