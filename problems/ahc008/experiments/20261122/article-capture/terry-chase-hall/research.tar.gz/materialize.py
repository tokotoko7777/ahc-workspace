"""Authenticate only stock a237 replay, no alternative plans or scores."""
from hashlib import sha256
from pathlib import Path
import csv,json,os,re,sys,tempfile
D=Path(__file__).resolve().parent; R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark_cases import run
from benchmark import replay
from guarded_entry_trace import observed
A=R/'ahc008_terry_virtual_chase_absorb'
T=R/'ahc008_focus_assets/tools/target/release/tester'
B=R/'ahc008_terry_idle_single_fixed/baseline_fixed'
def digest(b):return sha256(b).hexdigest()
def vec(x):
    a=[30*r+c for r,c in x]
    return ' '.join(map(str,[len(a),*a]))
receipts=[]; snapshots=[]
for i,(panel,inputs,expected) in enumerate((
    ('practice',R/'ahc008_focus_assets/tools/in',9),
    ('fresh',R/'ahc008_terry_first_chase_reuse/default-fresh100/in',14))):
    rows=[r for r in csv.DictReader((A/f'{panel}.native.csv').open()) if r['arm']=='terry_independent']
    assert len(rows)==100 and [r['case'] for r in rows]==[f'{j:04d}.txt' for j in range(100)]
    cohort=[r for r in rows if int(r['telemetry'].split()[13])==1]
    assert len(cohort)==expected
    for row in cohort:
        mark=list(map(int,row['telemetry'].split()))
        assert len(mark)==15 and mark[0]==int(row['map']) and mark[10]==int(row['pairs'])
        name=row['case']; num=int(Path(name).stem); raw=(inputs/name).read_bytes()
        assert digest(raw)==row['input_sha']
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp); acts=d/'actions'; tr=d/'trace'; tel=d/'telemetry'
            out,err,rc,wall=run([str(T),'env','AHC008_IDLE_SINGLE_FIXED=1',
                 'AHC008_TERRY_EXACT_LOG='+str(tel),str(B),f'--pairs={mark[10]}'],raw,4.5)
            mm=re.fullmatch(rb'Score = (\d+)\s*',err)
            assert rc==0 and mm and digest(out)==row['commands_sha'] and int(mm[1])==int(row['score']), (panel,name,rc,err,wall)
            assert list(map(int,tel.read_text().split()))==mark,(panel,name,'telemetry')
            acts.write_bytes(out)
            assert run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(acts),str(tr)],raw,12)[:3]==(out,err,rc)
            tape=tr.read_text().splitlines(); cmds=out.decode().splitlines()
            assert replay(raw.decode(),tape,cmds,detailed=True)[0]==int(mm[1])
            _,hist,_=observed(raw,tape)
            for t in range(275,300):
                pets,people,walls=hist[t]
                snapshots.append(f'{i*100+num} {t} {mark[0]} {vec(people)} {vec(pets)} {vec(sorted(walls))}')
            receipts.append(dict(panel=panel,case=name,input_sha=digest(raw),actions_sha=digest(out),
                  trace_sha=digest(tr.read_bytes()),score=int(mm[1]),telemetry=mark,wall=wall))
        print(panel,name,flush=True)
assert len(receipts)==23 and len(snapshots)==575
text='\n'.join(snapshots)+'\n'
(D/'snapshots.txt').write_text(text)
(D/'receipt.json').write_text(json.dumps(dict(rows=receipts,sha=digest(text.encode()),snapshots=575),indent=2)+'\n')
