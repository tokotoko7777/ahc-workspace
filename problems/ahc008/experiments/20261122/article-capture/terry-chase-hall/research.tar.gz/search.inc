// Detached Hall staffing branch search. Only old recut-stock-eligible
// snapshots are passed in. Geometry and staffing have separate verdicts.
struct Case {
    int board,turn;
    Board w,common,blocked,tree,can_gate,areach,sw;
    Cells people,pets,stock;
    int d0;
    unsigned old_isolated,newly,stock_ids;
    std::array<int,p::size> optimistic{};
};
struct Hit {
    Cells mask;
    int gain=0,shrink=0,stock_area=0,alt_area=0,eta=0;
};
struct SearchRun {
    Case s;
    Cells hall;
    int64_t root_flow;
};
std::vector<SearchRun> jobs;
int root_fails=0;
std::set<int> root_boards;
int root_feasible=0;
std::map<std::string,int> branch_reasons;
void initialize(Case& s){
    for(int h=0;h<int(s.people.size());++h){
        auto d=p::distances(s.w,s.people[h]);
        for(int v=0;v<p::size;++v)if(s.can_gate[v]){
            for(int q:p::neighbors(v))if(q>=0&&!s.w[q]&&d[q]>=0&&d[q]<=s.d0){
                s.optimistic[v]|=1<<h;break;
            }
        }
    }
}
std::string_view check_geometry(const Case& s,const Cells& x,Hit& h){
    if(x.empty())return "empty_recut";
    if(x==s.stock)return "same_walls";
    const Board bw=build_mask(x), b=s.w|bw,reached=get_component(b,s.people.front());
    if((bw&(s.blocked|s.tree|~s.common)).any()||(s.tree&~reached).any()||
       std::any_of(s.people.begin(),s.people.end(),[&](int u){return !reached[u];}))
        return "recut_illegal_or_split";
    if(ids_outside(reached,s.pets)!=s.stock_ids)return "recut_wrong_ids";
    if(reached.count()<=s.areach.count())return "recut_no_actual_crew_gain";
    const Board sa=animal_union(s.w|s.sw,s.pets,s.newly),sb=animal_union(b,s.pets,s.newly);
    if(sb.count()>=sa.count()||(sb|bw).count()>(sa|s.sw).count())return "recut_no_actual_animal_shrink";
    h={x,int(reached.count()-s.areach.count()),int(sa.count()-sb.count()),
        int(sa.count()),int(sb.count()),0};
    return {};
}
Cells clause(const Case& s,const Cells& wall){
    Cells masks;
    for(int v:wall)masks.push_back(s.optimistic[v]);
    auto picked=hall_clause(masks,s.people.size());
    for(int& i:picked)i=wall[i];
    return picked;
}
bool staff_exact(const Case& s,Hit& h){
    h.eta=eta(s.w|build_mask(h.mask),s.people,h.mask);
    return h.eta<=s.d0&&h.eta<300-s.turn;
}
bool better(const Hit& a,const Hit& b){
    if(a.gain!=b.gain)return a.gain>b.gain;
    if(a.shrink!=b.shrink)return a.shrink>b.shrink;
    if(a.eta!=b.eta)return a.eta<b.eta;
    return a.mask<b.mask;
}
void print_hit(const Case& s,const Hit& h,const char* type,int solves){
    std::cout<<s.board<<' '<<s.turn<<' '<<type<<' '<<h.gain<<' '<<h.stock_area
        <<' '<<h.alt_area<<' '<<s.d0<<' '<<h.eta<<' '<<s.newly<<' '<<solves
        <<' '<<s.stock.size();
    for(int z:s.stock)std::cout<<' '<<z;
    std::cout<<' '<<h.mask.size();
    for(int z:h.mask)std::cout<<' '<<z;
    std::cout<<'\n';
}
void process_root(Case s){
    auto end=[&](const char* reason){std::cout<<s.board<<' '<<s.turn<<' '<<reason<<'\n';};
    int64_t flow=0;
    auto x=propose(s.common,s.tree,s.can_gate,s.pets,s.old_isolated,s.newly,&flow);
    if(!x){end("infinite_recut");return;}
    Hit hit;
    if(auto rejection=check_geometry(s,*x,hit);!rejection.empty()){end(rejection.data());return;}
    initialize(s);
    auto bad=clause(s,*x);
    if(!bad.empty()){
        ++root_fails;
        root_boards.insert(s.board);
        end("root_hall_failure");
        jobs.push_back({std::move(s),std::move(bad),flow});
        return;
    }
    if(!staff_exact(s,hit)){end("root_exact_staff_failure");return;}
    ++root_feasible;
    print_hit(s,hit,"root_witness",1);
}
struct Node { int64_t lower; Cells forbid; };
struct Prioritize {
    bool operator()(const Node& a,const Node& b) const {
        if(a.lower!=b.lower)return a.lower>b.lower;
        if(a.forbid.size()!=b.forbid.size())return a.forbid.size()>b.forbid.size();
        return a.forbid>b.forbid;
    }
};
void explore(const SearchRun& root){
    const Case& s=root.s;
    std::priority_queue<Node,std::vector<Node>,Prioritize> q;
    std::set<Cells> tried;
    std::set<Cells> masks;
    int solves=1;
    auto add=[&](Cells existing,const Cells& bad,int64_t lower){
        for(int v:bad){
            Cells next=existing;
            next.insert(std::lower_bound(next.begin(),next.end(),v),v);
            if(tried.insert(next).second)q.push({lower,std::move(next)});
        }
    };
    add({},root.hall,root.root_flow);
    std::optional<Hit> best;
    while(!q.empty()&&solves<8){
        auto node=q.top();q.pop();
        Board gate=s.can_gate;
        for(int z:node.forbid)gate.reset(z);
        int64_t flow=0;
        ++solves;
        auto x=propose(s.common,s.tree,gate,s.pets,s.old_isolated,s.newly,&flow);
        if(!x){++branch_reasons["infinite"];continue;}
        Hit hit;
        if(auto rejection=check_geometry(s,*x,hit);!rejection.empty()){
            ++branch_reasons[std::string(rejection)];continue;
        }
        auto bad=clause(s,*x);
        if(!bad.empty()){
            ++branch_reasons["optimistic_deficiency"];
            if(node.forbid.size()<2)add(node.forbid,bad,flow);
            else ++branch_reasons["depth_limited"];
            continue;
        }
        if(!staff_exact(s,hit)){++branch_reasons["exact_staff_failure"];continue;}
        if(!masks.insert(hit.mask).second){++branch_reasons["duplicate_witness_mask"];continue;}
        ++branch_reasons["feasible"];
        if(!best||better(hit,*best))best=std::move(hit);
    }
    if(!q.empty())++branch_reasons["solve_limited_states"];
    if(best)print_hit(s,*best,"branch_witness",solves);
    else std::cout<<s.board<<' '<<s.turn<<" branch_no_witness "<<solves<<'\n';
}
void process_branches(){
    std::cout<<"support "<<root_fails<<' '<<root_boards.size()<<'\n';
    if(root_fails>=5&&root_boards.size()>=3)
        for(const auto& x:jobs)explore(x);
    for(const auto& [name,count]:branch_reasons)std::cout<<"branch_metric "<<name<<' '<<count<<'\n';
}
