import collections,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent
raw=Path(sys.argv[1]).read_text().splitlines()
receipt=json.loads((D/'receipt.json').read_text())
expected=[(100*(x['panel']=='fresh')+int(Path(x['case']).stem),t)
          for x in receipt['rows'] for t in range(275,300)]
assert len(expected)==575 and len(set(expected))==575
roots=[]; branches=[]; detail=[]; metrics={}; support=None
for line in raw:
    k,*cols=line.split()
    if k=='support':
        assert support is None and len(roots)==575
        support=tuple(map(int,cols)); continue
    if k=='branch_metric':
        name,value=cols; assert name not in metrics
        metrics[name]=int(value);continue
    turn,why,*values=cols
    row=dict(board=int(k),turn=int(turn),reason=why)
    (branches if why.startswith('branch_') else roots).append(row)
    if why in ('root_witness','branch_witness'):
        g,old,new,d0,d1,ids,solves,n,*wall=map(int,values)
        stock=wall[:n]; l,*alt=wall[n:]
        assert len(alt)==l and stock!=alt and g>0 and old>new>0
        assert 0<=d1<=d0<=299-int(turn) and 1<=solves<=8 and ids
        row.update(gain=g,stock_area=old,recut_area=new,stock_eta=d0,recut_eta=d1,
                   newly=ids,stock_walls=stock,recut_walls=alt,solves=solves)
        detail.append(row)
    elif why=='branch_no_witness':
        assert len(values)==1 and 2<=int(values[0])<=8
        row['solves']=int(values[0])
    else: assert not values
assert [(r['board'],r['turn']) for r in roots]==expected
fail=[(r['board'],r['turn']) for r in roots if r['reason']=='root_hall_failure']
assert support==(len(fail),len(set(x for x,t in fail)))
opened=support[0]>=5 and support[1]>=3
assert [(r['board'],r['turn']) for r in branches]==(fail if opened else [])
def headline(rows):
    keep=set();best={}
    for r in rows:
        b=r['board']; keep.add((b,tuple(r['stock_walls']),tuple(r['recut_walls']),r['newly']))
        best[b]=max(best.get(b,0),r['gain'])
    return dict(events=len(keep),boards=len(best),gain=sum(best.values()))
root=headline(r for r in detail if r['reason']=='root_witness')
gain=headline(r for r in detail if r['reason']=='branch_witness')
final=dict(snapshots_sha=receipt['sha'],snapshots=len(roots),boards=23,
   root_funnel=collections.Counter(r['reason'] for r in roots),root_witnesses=root,
   root_optimistic_failed=list(support),opened=opened,branch_steps=metrics,
   total_branch_solves=sum(r['solves']-1 for r in branches),incremental_branch_witnesses=gain,
   gate=opened and gain['events']>=5 and gain['boards']>=3 and gain['gain']>=50,
   all_rows=roots+branches)
(D/'report.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({k:v for k,v in final.items() if k!='all_rows'},indent=2))
