# Detached Hall staffing search, current a237 panel only

Not compiled or run before authorization. No alternate score, live
actions or model changes. All candidate-arm current native ledger
Chase-mode boards selected purely by stock mode=1: 9 practice plus
14 independent, all 25 turns t275–299, 575 snapshots. Neither the
old 40 failures nor a favorable board subset enter this panel.

Reconstruct those 23 stock tapes only. Exact signatures against both
sealed native ledgers: original inputs, official complete action stream,
all 15 telemetry fields (including fixed historical cap, Normal/Chase
sums and mode), official score, complete official playback, independent
score. Reuse the existing pinned a237-derived audit-only inactive-clock
binary from the fixed idle test; no other change, no cap adjustment.
If any mismatch, stop incomplete. External 120s materialization;
23 serial stock-only official+playback calls, estimated 80–100s.
Tapes are temporary, snapshots remain local. Fixed work here is only
authentication; no timing or native-score conclusion.

Stock stock-cut prefilter, crew connector, K=901/INF mincut, and exact
area/topology/ETA checks are the previous detached relative-area audit,
unchanged. One root recut per eligible snapshot. Only root masks which
pass the exact nonstaffing geometry checks but fail optimistic assignment
open a branch. If fewer than 5 such snapshots across 3 boards, stop
before all branching and report root funnel.

Optimistic gate-worker edge: from the real worker start, on currently
open terrain alone, shortest distance to any presently open adjacent
stance at most stock bottleneck approach ETA. This ETA already fits
remaining turns. Ignore proposed walls and any dynamic interference.
Exact final-board edges cannot be wider than this optimistic graph.
Let each gate encode its worker-neighbor set as a bit mask; subset-zeta
counts gates whose neighbors all lie in each worker subset S. Choose
smallest |S| then smallest mask with count>|S|; pick ascending row-major
|S|+1 such gates. Any feasible recut omits one of them, so one child per
gate forbids its split permanently. Empty adjacency row is allowed.
Only this optimistic certificate may branch, never final-path failure,
post-flood mismatch, or apparent gain. A standalone unit compares
witness validity/feasibility with brute distinct-worker assignment on
all graphs with ≤3 workers and ≤4 gates plus 8000 locked random graphs.

Bound: max eight total cuts per initial snapshot including root, max
two forbidden-gate depth; all nodes visited in smallest inherited
parent-flow lower bound, then lesser depth, then lexicographic forbidden
tile IDs. Dedup physical constraint tuples upon enqueue and witness
masks for the same state. Root finite lower bound remains valid under
added INF locks. Cut admissibility, shared crew floor, exact full isolated
IDs, strict newly isolated pet-component shrink, no larger pet-plus-wall
footprint and exact route matching ETA remain unchanged at each node.
Nodes whose optimistic matching passes but exact post-wall route matching
fails are rejected and not branched. Branch budget may leave unsearched
nodes, never a global feasibility certificate.

Report root and incremental branch witnesses separately with exact
gates/area/ETA and locked opportunities. Pick one best branch witness
per snapshot by actual crew gain, animal shrink, earlier ETA, then
row-major wall list. Advancement requires >=5 distinct NEW branch
events across >=3 boards and >=50 actual crew cells (best gain per
board); root witnesses do not count. No retune or widen after results.
Detached Hall search/analysis ≤120s separately, compile unit and kernel
separately. No archive of actual tape/board payload, private a237 code,
generated binary, or weights.
