#include "hall.hpp"
#include <iostream>
#include <random>
bool brute(const std::vector<int>& rows,int used=0,int i=0){
    if(i==int(rows.size()))return true;
    int e=rows[i]&~used;
    for(;e;e&=e-1)if(brute(rows,used|(e&-e),i+1))return true;
    return false;
}
void check(const std::vector<int>& a,int m){
    auto clause=hall_clause(a,m);
    assert(clause.empty()==brute(a));
    if(clause.empty())return;
    int scope=0,prev=-1;
    std::vector<int> chosen;
    for(int i:clause){assert(i>prev&&i<int(a.size()));prev=i;scope|=a[i];chosen.push_back(a[i]);}
    assert(std::popcount(unsigned(scope))<int(chosen.size())&&!brute(chosen));
}
int main(){
    int count=0;
    for(int m=1;m<=3;++m)for(int g=0;g<=4;++g)
        for(int x=0;x<(1<<(m*g));++x){
            std::vector<int> a;
            for(int i=0;i<g;++i)a.push_back((x>>(i*m))&((1<<m)-1));
            check(a,m);++count;
        }
    std::mt19937 rng(0xec9a9101u);
    for(int i=0;i<8000;++i){
        int m=1+rng()%8,g=rng()%11;
        std::vector<int> a(g);
        for(int& x:a)x=rng()%(1<<m);
        check(a,m);++count;
    }
    std::cout<<"Hall vs brute assignment cases: "<<count<<'\n';
}
