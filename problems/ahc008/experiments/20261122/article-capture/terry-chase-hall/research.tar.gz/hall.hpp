#pragma once
#include <algorithm>
#include <bit>
#include <cassert>
#include <vector>
// Every edge considered by exact staffing must also belong to this graph.
inline std::vector<int> hall_clause(const std::vector<int>& eligible, int workers) {
    assert(workers>=1&&workers<=10);
    const int n=1<<workers;
    std::vector<int> inside(n);
    for(int m:eligible){assert(0<=m&&m<n);++inside[m];}
    for(int i=0;i<workers;++i)for(int m=0;m<n;++m)
        if(m>>i&1)inside[m]+=inside[m^(1<<i)];
    int witness=-1;
    for(int m=0;m<n;++m)if(inside[m]>std::popcount(unsigned(m)))
        if(witness<0||std::popcount(unsigned(m))<std::popcount(unsigned(witness)))witness=m;
    if(witness<0)return {};
    std::vector<int> clause;
    for(int i=0;i<int(eligible.size());++i)if((eligible[i]&~witness)==0){
        clause.push_back(i);
        if(int(clause.size())==std::popcount(unsigned(witness))+1)break;
    }
    assert(!clause.empty());
    return clause;
}
