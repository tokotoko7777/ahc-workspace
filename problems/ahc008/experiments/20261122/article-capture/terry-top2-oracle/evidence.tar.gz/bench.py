"""Controlled read-only benchmark; no policy chosen or files outside output modified."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
import tempfile
from prepare import FROZEN_BINARY, HELD, DEV, N, sha

CONTROL = 'stock'
ALT = 'runner_up'

def summary(rows):
    fields = ('score','full','useful300','final_residual','exact4_100','exact4_160','exact4_final','completed_pairs')
    return dict({k:sum(int(v[k]) for v in rows) for k in fields},
                wall_max=max(float(v['wall']) for v in rows))

def finish(rows):
    by_case = {}
    for row in rows:
        by_case.setdefault(row['case'],{})[row['arm']] = row
    assert len(by_case) == N and all(set(p)=={CONTROL,ALT} for p in by_case.values())
    pairs = [(p[CONTROL],p[ALT]) for p in by_case.values()]
    top, second = map(list, zip(*pairs))
    win = [i for i,(a,b) in enumerate(pairs) if b['score']>a['score']]
    wins=set(win)
    best = [b if i in wins else a for i,(a,b) in enumerate(pairs)]
    aa = summary(top)
    bb = summary(second)
    cc = summary(best)
    n = cc['score'] - aa['score']
    # Test the exact fraction 1/40 = 2.5%; use float only for human presentation.
    result = dict(stock=aa,runner_up=bb,paired_score_oracle=cc,score_oracle_gain=n,
                  score_oracle_gain_pct=100*n/aa['score'],oracle_gate_2_5pct=40*n>=aa['score'],
                  runner_up_score_wins=len(wins),score_ties=sum(a['score']==b['score'] for a,b in pairs),
                  changed_commands=sum(a['commands_sha']!=b['commands_sha'] for a,b in pairs),
                  different_rollout_work=sum(a['completed_pairs']!=b['completed_pairs'] for a,b in pairs))
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for k in ('harness','tester','solver','panel','output'):p.add_argument(k,type=Path)
    a=p.parse_args()
    assert sha(a.solver) == FROZEN_BINARY
    assert not a.output.exists(), f'refusing to overwrite {a.output}'
    m=json.loads((a.panel/'manifest.json').read_text())
    assert m['dev_namespace']==DEV and m['held_namespace']==HELD
    assert m['faithful_solver_sha256']==FROZEN_BINARY
    assert sha(a.panel/'seeds.txt')==m['seedlist_sha256']
    locked=m['cases']
    assert len(locked)==N and [r['case'] for r in locked]==[f'{i:04}.txt' for i in range(N)]
    sys.path[:0]=[str(a.harness.resolve()),str(a.harness.resolve()/'experiments/20261122')]
    from benchmark_cases import run
    from benchmark import replay
    from guarded_entry_trace import observed
    from stochastic_lock_audit import ALL,B,idx,flood
    playback=a.harness.resolve()/'benchmark_cases.py'
    results=[]
    for i,row in enumerate(locked):
        path=a.panel/'in'/row['case']
        raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==row['sha256']
        arm_maps=[(CONTROL,row['stock_top'],[]),(ALT,row['diagnostic_runner_up'],[f'--map={row["diagnostic_runner_up"]}'])]
        if i&1: arm_maps.reverse()
        for arm,expected_map,extra in arm_maps:
            with tempfile.TemporaryDirectory() as d:
                d=Path(d); acts=d/'actions'; tape=d/'tape'; log=d/'terry'
                out,err,rc,wall=run([str(a.tester.resolve()),'env','AHC008_TERRY_EXACT_LOG='+str(log),
                                      str(a.solver.resolve()),*extra],raw,4.5)
                msg=re.fullmatch(rb'Score = (\d+)\s*',err)
                assert rc==0 and msg,(path,arm,rc,err)
                acts.write_bytes(out)
                rr,re_,rx,_=run([str(a.tester.resolve()),sys.executable,str(playback),
                                   '--playback',str(acts),str(tape)],raw,12.0)
                assert (rr,re_,rx)==(out,err,rc),(path,arm)
                t=tape.read_text().splitlines()
                actions=out.decode().splitlines()
                assert len(actions)==300
                score=replay(raw.decode(),t,actions,detailed=True)[0]
                assert score==int(msg[1]),(path,arm,score,msg[1])
                kinds,history,_=observed(raw,t)
                caught={}; areas=[]; residue={}
                for j,(ps,hs,ws) in enumerate(history):
                    op=ALL^sum(B[idx(p)] for p in ws)
                    group=flood(sum({B[idx(p)] for p in hs}),op)
                    for pet,loc in enumerate(ps):
                        if pet not in caught and not group&B[idx(loc)]:
                            caught[pet]=(j,pet,kinds[pet],flood(B[idx(loc)],op).bit_count())
                    if j in (75,100,160,225,275,300): residue[j]=len(ps)-len(caught)
                    if j==300: areas=[flood(B[idx(p)],op).bit_count() for p in hs]
                last=residue[300]; farea=sum(areas)/len(areas)
                stats=log.read_text().strip()
                telemetry=list(map(int,stats.split()))
                assert len(telemetry)==15 and telemetry[0]==expected_map and telemetry[-1]==score,(path,arm,stats)
                assert len(areas)==row['humans']
                results.append(dict(case=path.name,arm=arm,input_sha=row['sha256'],
                    stock_map=row['stock_top'],forced_second_map=row['diagnostic_runner_up'],actual_map=telemetry[0],
                    commands_sha=hashlib.sha256(out).hexdigest(),score=score,wall=wall,humans=len(areas),
                    full=int(last==0),useful300=int(last==0 and farea>=300),mean_human_area=farea,final_residual=last,
                    exact4_100=sum(e[0]<=100 and e[3]==4 for e in caught.values()),
                    exact4_160=sum(e[0]<=160 and e[3]==4 for e in caught.values()),
                    exact4_final=sum(e[3]==4 for e in caught.values()),
                    residue=json.dumps(residue,separators=(',',':')),
                    captures=';'.join(':'.join(map(str,e)) for e in sorted(caught.values())),
                    completed_pairs=telemetry[10],chase=telemetry[13],telemetry=stats))
        with a.output.open('w') as f:
            w=csv.DictWriter(f,list(results[0]))
            w.writeheader()
            w.writerows(results)
        print(path.name,flush=True)
    print(json.dumps(finish(results),indent=2),flush=True)

if __name__=='__main__':
    main()
