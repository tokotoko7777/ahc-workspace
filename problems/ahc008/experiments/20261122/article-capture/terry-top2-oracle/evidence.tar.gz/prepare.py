"""Generate only the preregistered uniform official development panel."""
import argparse
import collections
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT/'ahc008_terry_exact_selector'))
from verify import eval_reference

NS = 'ahc008/20261123/terry-top2-oracle-v1'
DEV = NS + '/dev'
HELD = NS + '/held-confirm'
N = 100
FROZEN_BINARY = '67f3e8559f4a3369551b31bf693f55b3bb739181fe05a4346df3d8cb583e5141'

def seed(namespace, i):
    return int.from_bytes(hashlib.sha256(f'{namespace}/{i}'.encode()).digest()[:8], 'little')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rank(weights, path):
    # No use of any later human-coordinate row or private tester metadata.
    with path.open() as f:
        n = int(f.readline())
        species = [0] * 5
        for _ in range(n):
            species[int(f.readline().split()[2]) - 1] += 1
        m = int(f.readline())
    best, values = eval_reference(weights, (m, *species))
    ordered = sorted(range(5), key=lambda i: (-values[i], i))
    assert ordered[0] == best and ordered[1] != best
    return m, species, ordered[0], ordered[1]

def load_weights():
    file=ROOT/'ahc008_terry_exact_selector/weights.private.inc'
    weights=list(map(float.fromhex,re.findall(r'-?0x[0-9a-f]+\.[0-9a-f]+p[+-][0-9]+',file.read_text())))
    assert len(weights) == 3589
    return weights

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('generator', type=Path)
    a = p.parse_args()
    gen = a.generator.resolve()
    seeds = [seed(DEV, i) for i in range(N)]
    assert len(set(seeds + [seed(HELD,i) for i in range(N)])) == 2*N
    weights=load_weights()
    out = HERE/'dev'
    out.mkdir(exist_ok=True)
    f = out/'seeds.txt'
    want = ''.join(f'{v}\n' for v in seeds)
    if f.exists():
        assert f.read_text() == want
    else:
        f.write_text(want)
    subprocess.run([str(gen),str(f.resolve())],cwd=out,check=True)
    cases = sorted((out/'in').glob('*.txt'))
    assert [s.name for s in cases] == [f'{i:04}.txt' for i in range(N)]
    manifest = []
    for i,path in enumerate(cases):
        m,c,top,second = rank(weights,path)
        manifest.append(dict(case=path.name,sha256=sha(path),humans=m,species=c,
            stock_top=top,diagnostic_runner_up=second))
    assert len({r['sha256'] for r in manifest}) == N
    report=dict(dev_namespace=DEV,held_namespace=HELD,cases=manifest,
                official_generator_sha256=sha(gen),seedlist_sha256=sha(f),
                faithful_solver_sha256=FROZEN_BINARY)
    text=json.dumps(report,indent=2)+'\n'
    p=out/'manifest.json'
    if p.exists():
        assert p.read_text()==text, 'manifest changed'
    else:
        p.write_text(text)
    print('manifest sha256',sha(p))
    for k in ('stock_top','diagnostic_runner_up','humans'):
        print(k,sorted(collections.Counter(r[k] for r in manifest).items()))
    print('map pair histogram:', sorted(collections.Counter((r['stock_top'], r['diagnostic_runner_up']) for r in manifest).items()))

if __name__ == '__main__':
    main()
