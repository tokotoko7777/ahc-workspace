# Stock TERRY map choice: preregistered top-two hindsight diagnostic

Use the exact original five map layouts and frozen behavior-faithful fastest
solver d14f6471 (executable SHA256
67f3e8559f4a3369551b31bf693f55b3bb739181fe05a4346df3d8cb583e5141).
Same executable and ordinary absolute 2,670ms clock for both arms. Default
selector is the control, and the **same executable** gets only
`--map=<that input's second-highest original selector sigmoid result>` for
its alternative. Ties among the original five scores favor the lower map
index for both ranks (consistent with the original strict-improvement rule).
There is no eligibility filter, input resampling or extra layout. Compute
ranks from the public prelude's five species counts and crew count before
any runs, using the independently audited faithful selector.

Uniform official generator on the exact seeded stream:
for i=0…99, the first eight SHA-256 bytes interpreted little endian of
UTF-8 `ahc008/20261123/terry-top2-oracle-v1/dev/{i}`.
The held counterpart `ahc008/20261123/terry-top2-oracle-v1/held-confirm/{i}`
is committed by namespace and indices before development; do not generate
it or inspect it during the diagnostic. No practice, previously generated
or eligibility-selected cases appear in this diagnostic. Every development
case enters both arms, serially alternating execution order by parity.
Compare genuine official status, replay and independent score, full
captures, useful ≥300 after full capture, final accessible animals, paired
score differences and local tester maximum duration. The terminal
controller can use different numbers of reviews because this compares
default clock rather than fixed rollout count.

The main diagnostic is the sum of the larger official score in each pair,
minus the sum of the automatic arm, divided by that automatic sum. A score
tie picks the automatic arm; score-oracle capture metrics use these same
choices. If also reporting metric-specific hindsight envelopes, label them
as separate and non-attainable simultaneously. Require **at least 2.5%**
gain before considering a deployable predictor. Even such an oracle is not
an algorithm improvement: actual predictor performance must later
cross-validate on the development data and then confirm the locked predictor
once on truly independent uniform held100. Do not infer a contest result
or change main; no fit, held generation, or policy is authorized by this
step. Keep all data and the complete paired table, not just selected wins.
