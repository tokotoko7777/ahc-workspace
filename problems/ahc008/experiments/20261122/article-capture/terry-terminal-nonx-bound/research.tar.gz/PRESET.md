# Fictional terminal non-X floor bound: frozen preflight

Older accepted incoming held100 exact signed recordings, manifest
`../ahc008_terry_hunt_wall_audit/recordings.json`; same inputs, complete
actions and traces, each re-hashed and replay score rechecked. 99 factual
full expected; every board verified, only these full endpoints scored
(no candidate arm, hence all feasible endpoints must also be full).
Map X classification uses pinned inherited exact terrain. No source
materialization, solver, tester, benchmark, new tapes, or gameplay claim.

Fix final wall set, workers and animals. Keep every installed X blocked.
Allow fictional opening of built non-X walls only. For each eligible set
(early first placement t<275, late only t>=275, both), give:

* **Loose upper:** open all eligible walls individually not leaking at
  factual state. Individually leaking eligible walls cannot be in any
  feasible set, by graph monotonicity. Score plain per-worker mean floor
  even if the joint relaxed opening leaks; penalized score would not
  upper-bound feasible plain area.
* **Exact fictional safe optimum:** identify terminal pet-component
  union P. Keep blocked all eligible cells adjacent to P, and open all
  others. No path from a worker to a pet can enter P because its first
  entry must traverse a still-blocked frontier wall. For any feasible
  subset, any opened P-adjacent wall is worker-unreachable (or leaks).
  Reblocking those cells preserves all workers' reachable sets. The
  remaining openings are a subset of the all-nonfrontier opening, so
  their individual areas are bounded by the constructed safe board.
  Thus the computed upper floor is attained under frozen endpoints.
* Decompose union gain vs change in worker splitting penalty; report
  merged worker components, one-sided/multi-touch/no-human wall counts,
  reached vs unreached openings, groups of openings joined through
  nonhuman old space without merging all groups through the old human
  union, mixed-time groups, and combined minus separate timing gains
  (overlap or synergy; do not add separate gains as if independent).
* Report full-only and all-signed mean gains (latter assigns zero to
  the excluded nonfull board; not a claim its true potential is zero),
  plus summed official-formula rounded score deltas for the fictional
  exact-feasible frozen endpoints, never an official execution or score.

Locked negative gate: exact both-window mean <9.95 added tiles on factual
full endpoints means this fictional mechanism cannot supply target-size
mean area under fixed endpoints and installed X. At/above 9.95 is only
headroom, not evidence legal omission or a causal/official score gain.
No fresh or official reevaluation. Run once only after explicit clearance:

```sh
python3 -u ahc008_terry_terminal_nonx_bound/audit.py \
  > ahc008_terry_terminal_nonx_bound/result.json
```
