"""Detached exact final-floor opening bound; never invokes a solver."""
import collections as C
from fractions import Fraction as F
import hashlib,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
H=R/'ahc008_terry_hunt_wall_audit'
T=R/'ahc008_terry_last_turn_subsets'
sys.path[:0]=[str(T),str(H)]
from audit import inspect
from analyze import terrain,snapshot,cells,mask
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood,wave

PINS={
    H/'recordings.json':'dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5',
    R/'ahc008_terry_exact_maps/terrain_data.inc':'8d1f703d67b9d16fb0ba6d3b20cd2bb4a2cf20aea33e4a7351d45fd129e256cf',
    H/'analyze.py':'8c8ec5d472ae8af00416cb7a8e6297bc3d509b056fff66d7a6eb2bcdb0e7b964',
}

def sha(b): return hashlib.sha256(b).hexdigest()

def groups(available,old_h,opened,early):
    # Keep genuinely coupled opening patches together through old empty
    # floors, but do not fuse unrelated patches through old human floors.
    candidate=available & ~old_h
    pending=opened
    out=C.Counter()
    while pending:
        start=pending&-pending
        cc=flood(start,candidate)
        wall=cc&opened
        pending&=~wall
        out['patches']+=1
        out['multitile_patches']+=wall.bit_count()>1
        out['mixed_early_late_patches']+=bool(wall&early) and bool(wall&~early)
        out['patch_wall_cells']+=wall.bit_count()
    return dict(out)

def board(rec,t,cmd,ts):
    _,history,_=observed(t,cmd)
    assert len(history)==301
    hist=[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w))) for p,h,w in history]
    pets,crew,wall=hist[-1]
    old=inspect(wall,crew,pets)
    assert old[1]==rec['score'] and old[3]==bool(rec['actual_full'])
    if not old[3]: return dict(case=rec['case'],full=False)
    x,doors=ts[rec['map']]
    options=wall&~x
    early=options&hist[275][2]
    late=options&~early
    assert not hist[0][2] and hist[275][2]&wall==hist[275][2]
    pet_bits=mask(pets)
    petfloor=flood(pet_bits,ALL^wall)
    fi,people_components,old_h=snapshot(wall,crew,pets)
    assert fi==(1<<len(pets))-1 and (old_h&petfloor)==0
    border=wave(petfloor)&options
    neighbors=[wave(B[q])&(ALL^wall) for q in cells(options)]
    opts=list(cells(options))
    safe_loose=mask(q for q,a in zip(opts,neighbors) if not(a&old_h and a&petfloor))
    feasible=options&~border
    assert feasible&safe_loose==feasible
    actual_split=F(old_h.bit_count())-old[-1]
    assert actual_split>=0
    timing={}
    for name,c in [('early',early),('late',late),('all',options)]:
        guess=wall^(safe_loose&c)
        _,up,union_up=snapshot(guess,crew,pets)
        upper=F(sum(u.bit_count() for u in up),len(crew))-old[-1]
        ub_full=not bool(union_up&petfloor)
        pick=feasible&c
        active=wall^pick
        iso,each,hu=snapshot(active,crew,pets)
        assert iso==fi and hu&petfloor==0 and all(a&b==a for a,b in zip(people_components,each))
        loss=F(hu.bit_count())-F(sum(u.bit_count() for u in each),len(crew))
        gain=F(sum(u.bit_count() for u in each),len(crew))-old[-1]
        assert 0<=gain<=upper
        new=inspect(active,crew,pets)
        assert new[3] and new[-1]-old[-1]==gain and new[1]>=old[1]
        touch=C.Counter()
        for q,a in zip(opts,neighbors):
            if not B[q]&c: continue
            n=sum(bool(a&cmp) for cmp in set(people_components))
            pet=bool(a&petfloor)
            tag=('no_human' if n==0 else 'one_human' if n==1 else 'multi_human')+('_pet' if pet else '_no_pet')
            touch[tag]+=1
        timing[name]=dict(candidate=c.bit_count(),excluded_pet_frontier=(border&c).bit_count(),
                          exact_gain=gain,rounded_fictional_score_gain=new[1]-old[1],loose_upper=upper,loose_union_full=ub_full,
                          human_components_before=len(set(people_components)),human_components_after=len(set(each)),
                          human_split_gain=actual_split-loss,union_gain=(hu&~old_h).bit_count(),
                          opened_reached=(pick&hu).bit_count(),opened_unreached=(pick&~hu).bit_count(),
                          touch=dict(touch),groups=groups(hu,old_h,pick&hu,early))
    combined=timing['all']['exact_gain']-timing['early']['exact_gain']-timing['late']['exact_gain']
    return dict(case=rec['case'],map=rec['map'],full=True,base_floor=old[-1],
                timing=timing,mixed_gain_minus_separate=combined)

def main():
    for p,d in PINS.items(): assert sha(p.read_bytes())==d
    rows=json.loads((H/'recordings.json').read_text())
    assert len(rows)==len({r['case'] for r in rows})==100
    ts=terrain()
    result=[]
    for r in rows:
        name=r['case']
        f=R/'ahc008_terry_incoming_shadow/held100/in'/name
        base=(H/'tapes'/name).with_suffix('')
        p=[f,base.with_suffix('.actions'),base.with_suffix('.trace')]
        data=[q.read_bytes() for q in p]
        assert [sha(q) for q in data]==[r[k] for k in ('input_sha','commands_sha','trace_sha')]
        a=data[1].decode().splitlines();z=data[2].decode().splitlines()
        assert len(a)==300 and len(z)==600 and a==z[::2]
        result.append(board(r,data[0],z,ts))
    full=[r for r in result if r['full']]
    assert len(full)==99
    stats={}
    for k in ('early','late','all'):
        vals=[r['timing'][k] for r in full]
        numerics=('exact_gain','loose_upper','candidate','excluded_pet_frontier','union_gain',
            'human_split_gain','opened_reached','opened_unreached')
        stats[k]={x:sum(v[x] for v in vals)/F(len(vals)) for x in numerics}
        stats[k]['all100_zero_nonfull_exact_gain']=sum(v['exact_gain'] for v in vals)/F(len(result))
        stats[k]['rounded_fictional_score_gain_total']=sum(v['rounded_fictional_score_gain'] for v in vals)
        stats[k]['loose_union_leaks_boards']=sum(not v['loose_union_full'] for v in vals)
        stats[k]['crew_rejoined_boards']=sum(v['human_components_before']>v['human_components_after'] for v in vals)
        for tag in ('touch','groups'):
            total=C.Counter()
            for v in vals: total.update(v[tag])
            stats[k][tag]=dict(total)
    numerical_target=F('9.95')
    print(json.dumps(dict(signed=len(result),full=len(full),arithmetic_target=numerical_target,
                reaches_target=(stats['all']['exact_gain']>=numerical_target),
                combined_mean_minus_separate=sum(r['mixed_gain_minus_separate'] for r in full)/F(len(full)),
                stats=stats,rows=result),default=str,indent=2))

if __name__=='__main__': main()
