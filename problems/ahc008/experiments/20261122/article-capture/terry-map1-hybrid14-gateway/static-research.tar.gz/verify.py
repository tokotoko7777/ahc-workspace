"""Concept's independent exact cell flood and named cap-role verifier."""
import itertools,json,re,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
N=30
def G(r,c):return 30*r+c
def neighbors(p):
 r,c=divmod(p,30)
 return [G(x,y)for x,y in ((r-1,c),(r+1,c),(r,c-1),(r,c+1))if 0<=x<30 and 0<=y<30]
def flood(p,open_):
 q=[p];seen={p}
 for z in q:
  for v in neighbors(z):
   if v in open_ and v not in seen:seen.add(v);q.append(v)
 return seen
def old_text():
 raw=(R/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
 src=re.split(r'// map \d\s*\n',raw)[1]
 rows=re.findall(r'\{((?:0x[0-9a-f]+u,){4}0x[0-9a-f]+u)\}',src)
 data=[[int(x[:-1],16)for x in s.split(',')] for s in rows]; assert len(data)==5
 flat=[]
 for r in range(30):
  pattern=data[0 if r==0 else 1 if r%2==0 else 2 if r%4==1 else 3]
  for c in range(30):
   z='.' if r%2==0 else '~' if r%4==1 else '-'
   for i,ch in enumerate('X()<>'):
    if pattern[i]>>c&1:z=ch
   flat.append('|' if c in (4,14,24)else z)
 return flat
def new_text(a):
 b=a.copy()
 for r in range(30):
  b[G(r,0):G(r,3)]=['.']*3
  b[G(r,3):G(r,8)]=a[G(r,0):G(r,5)]
  b[G(r,8):G(r,14)]=['.']*6
  if r>=2 and r%2==0:b[G(r,9):G(r,13)]=['X']*4
  if r>=3 and r%2==1:
   b[G(r,2)]='X';b[G(r,8):G(r,14)]=['<','-','-','-','-','>']
 b[G(1,6)]='.'
 b[G(29,2)]='.';b[G(29,6)]='.'
 return b
def items(grid):
 wall={i for i,x in enumerate(grid)if x=='X'}
 doors={i for i,x in enumerate(grid)if x in '()<>'}
 aisles={i for i,x in enumerate(grid)if x=='|'}
 open_=set(range(900))-wall
 data={};ghosts=[];named_doors=set()
 unvisited=open_-doors
 while unvisited:
  u=min(unvisited);body=flood(u,open_-doors)
  unvisited-=body
  if body&aisles:continue
  used={s for p in body for s in neighbors(p)if s in doors}
  if not used:ghosts.append(sorted(body));continue
  k=tuple(sorted(used))
  assert k not in data and not named_doors&used
  for g in k:
   sign=1 if grid[g] in '(< ' else -1
   stance=g-sign
   assert stance in aisles and g+sign in body
  assert len(k)<=2 and all((grid[g] in '<>')==(len(k)==2)for g in k)
  assert flood(u,open_-set(k))==body
  for g in k:assert flood(u,open_-(set(k)-{g}))&aisles
  safe=body-{x for g in k for x in neighbors(g)}
  assert safe
  named_doors|=used
  data[k]=(body,safe)
 assert named_doors==doors
 return wall,doors,aisles,data,ghosts
def signature(r):
 return {p//30%2 for p in r[1]}, {sum(divmod(p,30))%2 for p in r[1]}

def main():
 a=old_text();b=new_text(a)
 previous=(R/'ahc008_terry_map1_hybrid14/boards.txt').read_text().splitlines()
 assert len(previous)==60 and a==list(''.join(previous[:30]))
 old_hybrid=list(''.join(previous[30:]))
 assert {i for i,(l,r) in enumerate(zip(old_hybrid,b))if l!=r}=={G(29,2),G(29,6)}
 assert [old_hybrid[G(29,k)]for k in (2,6)]==['X',')']
 cmp=Path(sys.argv[1]).read_text().splitlines();assert len(cmp)==60 and all(len(r)==30 for r in cmp)
 assert a==list(''.join(cmp[:30])) and b==list(''.join(cmp[30:]))
 assert all(a[G(i,j)]==b[G(i,j)]for i in range(30)for j in range(14,30))
 aw,ad,ar,ac,ag=items(a);w,d,l,rooms,ghost=items(b)
 assert len(aw)==290
 compact={ (G(r,8),G(r,13)) for r in range(3,30,2)}
 assert len(compact)==14
 for x in compact:
  body,safe=rooms[x];r=x[0]//30
  assert body=={G(r,c)for c in range(9,13)}
  assert len(signature((body,safe))[1])==2
 def side(keys,axis):
  return {k for k in keys if all(axis(q%30)for q in k)}
 east=side(ac,lambda c:c>14); west=side(ac,lambda c:c<4)
 drop={(G(1,3),),(G(29,3),)}; left=west-drop
 assert drop<=west
 for k in east:assert rooms[k]==ac[k]
 for k in left:
  assert rooms[tuple(x+3 for x in k)]==tuple({x+3 for x in q}for q in ac[k])
 assert set(rooms)==east|{tuple(x+3 for x in k)for k in left}|compact
 assert not ghost
 O=set(range(900))-w; apron={G(r,c)for r in range(30)for c in range(3)}-w
 A7={G(r,7)for r in range(30)}; A14={G(r,14)for r in range(30)}; A24={G(r,24)for r in range(30)}
 all_compact=set(q for k in compact for q in k)
 exterior={}
 for k in [()]+list(rooms)+[tuple(sorted(all_compact)),tuple(sorted(d))]:
  reach=flood(G(1,7),O-set(k)); rel=(apron|A7|A14)<=reach
  assert rel
  if len(k)<=2:assert A24<=reach
  key='open' if not k else 'compact_closed' if set(k)==all_compact else 'all_closed' if set(k)==d else 'single_named_closures'
  exterior.setdefault(key,[]).append(len(reach))
 out=dict(walls=len(w),original_wall=len(aw),rooms=len(rooms),original_rooms=len(ac),compact_pairs=len(compact),retired_left=2,
     retained_east=len(east),retained_left=len(left),phantom=len(ghost),original_phantom=len(ag),apron=len(apron),
     new_single=sum(len(k)==1 for k in rooms),new_pairs=sum(len(k)==2 for k in rooms),
     exterior={k:[min(z),max(z)]for k,z in exterior.items()},
     planned_unswept_apron_caps=[G(r,2)for r in range(3,30,4)])
 def distances(grid,p):
  open_={i for i,a in enumerate(grid)if a!='X'}; q=[p]; d={p:0}
  for u in q:
   for v in neighbors(u):
    if v in open_ and v not in d:d[v]=d[u]+1;q.append(v)
  return [min(d[u]for u in d if u%30==c)for c in (7,14,24)]
 rowset=list(range(3,30,4))
 out['stance_to_lane_distances']={r:{'first':distances(old_hybrid,G(r,1)),'second':distances(b,G(r,1))}for r in rowset}
 out['pass']=len(w)==264 and len(rooms)==65 and len(compact)==14
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
