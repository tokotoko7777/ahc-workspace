#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <iostream>
using namespace terry_exact_maps;
int main(){
 const auto& old=terrain(1);
 auto trial=old.cells;
 for(int r=0;r<30;++r){
  for(int c=0;c<3;++c)trial[cell(r,c)]=Marker::Open;
  for(int c=3;c<=7;++c)trial[cell(r,c)]=old.cells[cell(r,c-3)];
  for(int c=8;c<=13;++c)trial[cell(r,c)]=Marker::Open;
  if(r>=2&&r%2==0)
   for(int c=9;c<=12;++c)trial[cell(r,c)]=Marker::Wall;
  if(r>=3&&r%2==1){
   trial[cell(r,2)]=Marker::Wall;
   trial[cell(r,8)]=Marker::LeftTwo;trial[cell(r,13)]=Marker::RightTwo;
   for(int c=9;c<=12;++c)trial[cell(r,c)]=Marker::Room;
  }
 }
 trial[cell(1,6)]=Marker::Open;
 trial[cell(29,2)]=Marker::Open;trial[cell(29,6)]=Marker::Open;
 for(auto& tiles:{old.cells,trial})
  for(int r=0;r<30;++r){
   for(int c=0;c<30;++c)std::cout<<char(tiles[cell(r,c)]);
   std::cout<<'\n';
  }
}
