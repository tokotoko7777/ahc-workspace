# Hybrid14, one fixed exterior bottom gateway, static only
Independently re-evaluate the validated first hybrid board using its immutable signed fixture. Exactly two semantic tile changes: remove exterior fence (29,2) and unmark retired translated left solo gate at (29,6), both to open. Existing top portal remains. All else unchanged including every compact r3–29 through-body and all east/right stock semantics. Expected exactly 264 X, 65 true physical named rooms, 14 compact 1×4 with both safe checkerboard parities. Preserve every old retained wide/east compartment and all translated left fixtures except the two explicitly retired original solo rooms r1/r29. No phantom; apron+c7+c14 connected in open/single/all-compact-closed (check all named closed too) and c24 connected with every single closure; actual safe tiles and nominal open exterior stances verified like previous static gate. Bottom portal may shorten approaches, but no claim about solving prior dry failures.

Compare exact final-X-only BFS stance-to-lane distances for all seven area-work stances from immutable first hybrid to candidate, separately for each true lane (7,14,24). Static map path numbers, not measured planning time, and do not change route gates. No optimization, constructor, solver, dry or official work here. New fresh36 matched dry with same original one/two-chunk algorithm/160/12/20 only after separate static and execution clearance, no old outcomes used.

After clearance:
    sha256sum -c FROZEN.sha256
    g++ -std=gnu++23 compiled.cpp -o compiled && ./compiled > boards.txt
    python verify.py boards.txt > report.json
