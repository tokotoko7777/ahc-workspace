"""Frozen 36 no-pet fixtures and measured dry verdict; no official inputs."""
import csv,hashlib,io,json,statistics,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent
b=(D/'boards.txt').read_bytes()
seeds=[]
for m in (5,6):
 for i in range(18):
  h=[];j=0
  while len(h)<m:
   q=int.from_bytes(hashlib.sha256(f'ahc008-map1-hybrid14-gateway-dry-v1:{m}:{i}:{j}'.encode()).digest()[:8],'little')
   j+=1
   if q>=2**64-2**64%900 or q%900 in h:continue
   h.append(q%900)
  seeds.append(str(m)+' '+' '.join(map(str,h)))
feed=b+ ('\n'.join(seeds)+'\n').encode()
(D/'dry-fixtures.txt').write_bytes(feed[len(b):])
r=subprocess.run([str(D/'dry')],input=feed,capture_output=True,check=True,timeout=100)
(D/'dry.csv').write_bytes(r.stdout)
groups={}
for x in csv.DictReader(io.StringIO(r.stdout.decode())):
 z={k:int(v)for k,v in x.items()}
 groups.setdefault(z['case'],[]).append(z)
assert sorted(groups)==list(range(36)) and all(len(v)==2 for v in groups.values())
valid=lambda r:r['assigned'] and 0<r['all']<=160 and 0<r['ready']<=160 and not (r['missing'] or r['invalid'] or r['unreachable'])
out={}
for k in ('all','5','6'):
 pairs=[(a,b)for a,b in groups.values() if k=='all' or str(a['m'])==k]
 assert all(a['arm']==0 and b['arm']==1 for a,b in pairs)
 delays=[b['ready']-a['ready']for a,b in pairs if valid(a) and valid(b)]
 out[k]=dict(n=len(pairs),valid_baseline=sum(bool(valid(a))for a,b in pairs),valid_candidate=sum(bool(valid(b))for a,b in pairs),
   paired_eligible=len(delays),median_delay=statistics.median(delays)if delays else None,max_delay=max(delays,default=None))
z=out['all']; output=dict(groups=out,setup_reasons={str(k):sum(b['setup_reason']==k for a,b in groups.values())for k in range(5)},fixture_sha=hashlib.sha256(feed[len(b):]).hexdigest())
output['pass']=z['paired_eligible']==36 and z['median_delay']<=12 and z['max_delay']<=20
(D/'dry-report.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output))
