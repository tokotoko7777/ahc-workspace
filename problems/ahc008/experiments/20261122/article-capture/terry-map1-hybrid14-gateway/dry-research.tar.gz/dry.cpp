#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include <iostream>
#include <tuple>
#include <optional>
using namespace exact_build;
constexpr int horizon=160;
const std::array<int,7> cap={92,212,332,452,572,692,812};
struct Option{
 int who,gap,lo,hi,reverse,extra;
 auto key()const{return std::tuple(who,gap,lo,hi,reverse);}
};
int lane(BFS& d,const std::vector<int>&cols){
 int out=INF;for(int x:cols)for(int r=0;r<30;++r)out=std::min(out,d.d[r*30+x]); return out;
}
int add_caps(Crew& crew,const std::vector<int>& pos,const Board& wall){
 int m=pos.size();
 auto old=crew.q;
 Board seen{};
 for(const auto&q:old)for(auto a:q)
  for(int d=0;d<4;++d)if(a.mask>>d&1){
   int v=nb(a.at)[d];if(v<0||!wall[v])return 2;seen[v]=1;
  }
 for(int p=0;p<V;++p)if(bool(wall[p]&&!seen[p])!=(std::find(cap.begin(),cap.end(),p)!=cap.end()))return 2;
 std::vector<std::optional<BFS>> cached(V);
 auto nav=[&](int a)->BFS&{if(!cached[a]){cached[a].emplace();cached[a]->run(a,wall);}return *cached[a];};
 auto travel=[&](int a,int b){
  if(wall[b])return INF;
  return nav(a).d[b];
 };
 auto handoff=[&](int a){
  return lane(nav(a),crew.layout.aisleCols);
 };
 std::vector<int> base(m);
 for(int i=0;i<m;++i){
  int p=pos[i];
  for(auto a:old[i]){base[i]+=md(p,a.at)+std::popcount(a.mask);p=a.at;}
  base[i]+=handoff(p);
 }
 std::array<std::array<std::vector<Option>,8>,7> op;
 for(int lo=0;lo<7;++lo)for(int hi=lo+1;hi<=7;++hi)
  for(int i=0;i<m;++i)for(int gap=0;gap<=(int)old[i].size();++gap)for(int rev=0;rev<2;++rev){
   if(hi-lo==1&&rev)continue;
   const int p=gap?old[i][gap-1].at:pos[i];
   if(gap&&wall[p])continue;
   const int a=cap[(rev?hi-1:lo)]-1,b=cap[(rev?lo:hi-1)]-1;
   int into=travel(p,a),tail,oldleg;
   if(gap<(int)old[i].size()){
    const int next=old[i][gap].at;
    tail=travel(b,next);oldleg=travel(p,next);
   }else{
    tail=handoff(b);oldleg=handoff(p);
   }
   const int inner=travel(a,b);
   if(std::max({into,tail,oldleg,inner})>=INF)continue;
   op[lo][hi].push_back({i,gap,lo,hi,rev,into+inner+tail-oldleg+hi-lo});
  }
 for(auto& row:op)for(auto& opts:row){
  std::sort(opts.begin(),opts.end(),[](const Option&a,const Option&b){
   return std::tuple(a.who,a.extra,a.key())<std::tuple(b.who,b.extra,b.key());
  });
  opts.erase(std::unique(opts.begin(),opts.end(),[](const Option&a,const Option&b){return a.who==b.who;}),opts.end());
 }
 std::vector<Option> best; int max0=INF,total0=INF;
 auto offer=[&](std::vector<Option> v){
  auto a=base;for(const auto& z:v)a[z.who]+=z.extra;
  int mx=*std::max_element(a.begin(),a.end()),sum=0;for(int x:a)sum+=x;
  auto key=[](const std::vector<Option>&s){std::vector<std::tuple<int,int,int,int,int>>k;for(auto&a:s)k.push_back(a.key());return k;};
  if(best.empty()||std::tuple(mx,sum,v.size(),key(v))<std::tuple(max0,total0,best.size(),key(best))){
   best=std::move(v);max0=mx;total0=sum;
  }
 };
 for(const auto&a:op[0][7])offer({a});
 for(int cut=1;cut<7;++cut)
  for(const auto&a:op[0][cut])for(const auto&b:op[cut][7])if(a.who!=b.who)offer({a,b});
 if(best.empty())return 3;
 for(auto a:best){
  Queue insert;
  for(int j=0;j<a.hi-a.lo;++j)insert.push_back({cap[a.reverse?a.hi-1-j:a.lo+j]-1,1u<<1});
  auto& q=crew.q[a.who];
  q.insert(q.begin()+a.gap,insert.begin(),insert.end());
 }
 for(int i=0;i<m;++i){
  auto j=old[i].begin();
  for(auto a:crew.q[i])if(j!=old[i].end()&&a.at==j->at&&a.mask==j->mask)++j;
  if(j!=old[i].end())return 4;
 }
 return 0;
}
struct Result{int all=-1,ready=-1,missing=0,invalid=0,unreachable=0,setup_reason=0;bool assigned=false;};
Result simulate(Layout l,std::vector<int> h,bool candidate){
 Result z; Board final{},w{};
 for(int p=0;p<V;++p)final[p]=l.ascii[p]=='X';
 Crew crew;
 if(!crew.init(l,h))z.setup_reason=1;
 else if(candidate)z.setup_reason=add_caps(crew,h,final);
 z.assigned=z.setup_reason==0;if(!z.assigned)return z;
 for(int t=1;t<=horizon;++t){
  auto cmd=crew.act_literal(w,h,{}).action;
  auto next=h;
  for(int i=0;i<(int)h.size();++i)if(cmd[i]>='A'&&cmd[i]<='Z'){
   auto d=std::find(Move,Move+4,cmd[i])-Move;
   if(d==4||nb(h[i])[d]<0||w[nb(h[i])[d]]){++z.invalid;return z;}
   next[i]=nb(h[i])[d];
  }
  for(int i=0;i<(int)h.size();++i)if(cmd[i]>='a'&&cmd[i]<='z'){
   auto d=std::find(Put,Put+4,cmd[i])-Put;
   if(d==4){++z.invalid;return z;}
   int p=nb(h[i])[d];
   if(p<0||!final[p]||w[p]||std::find(h.begin(),h.end(),p)!=h.end()||
      std::find(next.begin(),next.end(),p)!=next.end()){++z.invalid;return z;}
   w[p]=1;
  }
  h=std::move(next);
  for(int i=0;i<(int)h.size();++i){
   BFS b;b.run(h[i],w);
   for(auto a:crew.q[i]){
    bool needed=false;for(int k=0;k<4;++k)if(a.mask>>k&1){
     int p=nb(a.at)[k];if(p>=0&&!w[p])needed=true;
    }
    if(needed&&(w[a.at]||b.d[a.at]>=INF))++z.unreachable;
   }
  }
  if(w==final){
   if(z.all<0)z.all=t;
   std::array<int,3> counts{};bool all=true;
   for(int v:h){
    auto it=std::find(l.aisleCols.begin(),l.aisleCols.end(),v%30);
    if(it==l.aisleCols.end())all=false;else ++counts[it-l.aisleCols.begin()];
   }
   std::sort(counts.begin(),counts.end());
   auto demand=h.size()==5?std::array<int,3>{1,2,2}:std::array<int,3>{2,2,2};
   if(all&&counts==demand){z.ready=t;break;}
  }
 }
 for(int p=0;p<V;++p)z.missing+=final[p]&&!w[p];
 return z;
}
int main(){
 Layout a,b;a.aisleCols={4,14,24};b.aisleCols={7,14,24};
 for(int r=1;r<30;r+=2){a.aisleRows.push_back(r);b.aisleRows.push_back(r);}
 for(auto* m:{&a,&b})for(int r=0;r<30;++r){
  std::string row;std::cin>>row;if(row.size()!=30)return 2;
  std::copy(row.begin(),row.end(),m->ascii.begin()+30*r);
 }
 std::cout<<"case,m,arm,all,ready,missing,invalid,unreachable,assigned,setup_reason\n";
 for(int k=0;k<36;++k){
  int m;std::cin>>m;if(m!=(k<18?5:6))return 2;
  std::vector<int> h(m);for(int& p:h)std::cin>>p;
  for(int j=0;j<2;++j){
   auto z=simulate(j?b:a,h,j);
   std::cout<<k<<','<<m<<','<<j<<','<<z.all<<','<<z.ready<<','<<z.missing<<','<<z.invalid<<','<<z.unreachable<<','<<z.assigned<<','<<z.setup_reason<<'\n';
  }
 }
}
