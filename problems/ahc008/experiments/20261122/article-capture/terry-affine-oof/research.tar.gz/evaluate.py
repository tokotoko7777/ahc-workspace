import collections,csv,hashlib,json,random
from fractions import Fraction as F
from pathlib import Path
P=Path('../ahc008_terry_terminal_k8/dev')
pins={'manifest.json':'5c2877a6733e3bb454096d3f2da17f830899a1bfd047c485b2707a3c6480399d','official.csv':'54ec41b7e157b8586841a019b4d71ba51ea7f2a289af5e2d3b31904f845bd218','native-context.json':'1a0c57e5c4825bbfe4e4b086586ca2a8805f773100b11586b082077714110666','report.json':'c002efe7a942b4121ae679aa22da4af0bb12a533c9ad4391f8d5df872b69236f'}
for p,s in pins.items():assert hashlib.sha256((P/p).read_bytes()).hexdigest()==s
load=lambda f:json.loads((P/f).read_text())
man=load('manifest.json')['selected'];native={z['case']:z for z in load('native-context.json')}; model={z['case']:z for z in load('report.json')['cases']}
lab=collections.defaultdict(dict)
for r in csv.DictReader((P/'official.csv').open()):lab[r['case']][r['arm']=='terry_independent']=r
rows=[]
for z in man:
 c=z['case'];n=native[c];a,b=(lab[c][i]for i in (0,1))
 assert z['sha256']==n['sha']==a['input_sha']==b['input_sha'] and z['prefix_sha']==n['prefix']==a['prefix_sha']==b['prefix_sha']
 assert n['command_sha']==lab[c][n['mode']]['commands_sha']
 x=F(model[c]['model_sum'],800000000); y=F(int(b['score'])-int(a['score']),100000000)
 fold=int.from_bytes(hashlib.sha256(('ahc008-k8-affine-v1:fold:'+z['sha256']).encode()).digest()[:8],'little')%5
 rows.append((c,fold,x,y))
assert len(rows)==len(native)==len(lab)==len(model)==100
co={};out=[];deltas=[]
for k in range(5):
 train=[(x,y-x)for _,f,x,y in rows if f!=k];n=len(train); reg=F(n,100)
 xx=sum(x*x for x,y in train)+reg; sx=sum(x for x,y in train); sy=sum(y for x,y in train); xy=sum(x*y for x,y in train)
 det=(n+reg)*xx-sx*sx
 co[k]=((sy*xx-sx*xy)/det,((n+reg)*xy-sx*sy)/det)
for c,k,x,y in rows:
 a,b=co[k];h=x+a+b*x; native_mode=native[c]['mode']; raw=x>0; mode=h>0
 act=lab[c][mode]; stock=lab[c][native_mode]
 d=int(act['score'])-int(stock['score']);deltas.append(d)
 out.append((c,k,x,y,h,raw,mode,native_mode,act,stock))
def total(k,m):
 return sum(int(lab[c][r[m]][k])for r in out for c in [r[0]])
nonzero=sum(bool(y)for c,k,x,y,h,raw,mode,nm,a,s in out)
chg=sum(mode!=nm for c,k,x,y,h,raw,mode,nm,a,s in out)
chg_nonzero=sum(mode!=nm and bool(y)for c,k,x,y,h,raw,mode,nm,a,s in out)
mse0=sum((x-y)**2 for _,_,x,y,*_ in out)/100
mse1=sum((h-y)**2 for _,_,x,y,h,*_ in out)/100
rng=random.Random(81077131); bs=sorted(sum(deltas[rng.randrange(100)]for _ in range(100))for _ in range(4000)); low=bs[int(.05*(len(bs)-1))]
loss=sum(int(a['full'])<int(s['full'])for *_,a,s in out)
keys=('score','full','useful300','final_residual')
met={name:{k:total(k,m)for k in keys}for name,m in [('native',7),('raw_k8',5),('affine_oof',6)]}
n=met['native'];o=met['affine_oof']
g=dict(changes=chg>=12,changes_nonzero=chg_nonzero>=8,mse=mse1<mse0,score=500*sum(deltas)>=n['score'],
 bootstrap=low>0, capture=o['full']>=n['full'] and o['useful300']>=n['useful300'] and o['final_residual']<=n['final_residual'] and loss==0,
 slopes=all(1+b>0 for a,b in co.values()))
z=dict(n=100,fold_counts=dict(collections.Counter(r[1]for r in rows)),coef={k:[str(a),str(1+b)]for k,(a,b)in co.items()},
 changes=chg,changes_nonzero=chg_nonzero,sign_support=nonzero,
 sign_correct={n:sum(bool(y) and m==(y>0)for _,_,x,y,h,raw,mode,*_ in out for m in [raw if n=='raw' else mode])for n in ('raw','affine')},
 mse_raw=float(mse0),mse_oof=float(mse1),metrics=met,individual_full_to_miss=loss,bootstrap_one_sided_lower_sum=low,gates=g,passed=all(g.values()))
Path('report.json').write_text(json.dumps(z,indent=2)+'\n')
print(json.dumps(z))
