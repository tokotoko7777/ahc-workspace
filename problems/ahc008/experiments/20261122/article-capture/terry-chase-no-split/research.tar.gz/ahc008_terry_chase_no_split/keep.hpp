namespace chase_keep {
struct Snapshot {
   int parts=0, total=0;
   std::bitset<20> isolated;
};
inline Snapshot terrainScore(const State& x){
 Snapshot r;
 const auto c=terrain_lib::labels(x.walls);
 std::array<int,V> cells{};
 std::bitset<V> humanGroups;
 for(int id:c.labels)if(id>=0)++cells[id];
 for(int p:x.people){
  const int g=c.labels[p];
  assert(g>=0);
  humanGroups.set(g);r.total+=cells[g];
 }
 r.parts=humanGroups.count();
 for(int i=0;i<(int)x.pets.size();++i){
  const int g=c.labels[x.pets[i].pos];
  assert(g>=0&&i<(int)r.isolated.size());
  if(!humanGroups[g])r.isolated.set(i);
 }
 return r;
}
inline bool sameAreaCompFast(const State& x){
 Dist d;
 bfs(x.walls,x.people[0],d);
 for(int p:x.people)if(d[p]>=INF)return false;
 return true;
}
inline std::string omitIfSafe(const State& s,const std::string& stock,bool* changed=nullptr){
 if(changed)*changed=false;
 if(std::none_of(stock.begin(),stock.end(),[](char a){return build_dir(a)>=0;}))
  return stock;
 State old=s;
 people_step(old,stock);
 if(sameAreaCompFast(old)||!sameAreaCompFast(s))return stock;
 const auto base=terrainScore(old);
 const int minimumScore=score(old);
 std::string answer=stock;
 int bestArea=base.total;
 for(int i=0;i<(int)stock.size();++i){
  if(build_dir(stock[i])<0)continue;
  // All other sanitized actions and final human positions are identical.
  // Removing a wall cannot invalidate any of their movement or building.
  std::string commands=stock;
  commands[i]='.';
  State trial=s;
  people_step(trial,commands);
  if(!sameAreaCompFast(trial))continue;
  const auto now=terrainScore(trial);
  if(now.total>bestArea&&now.isolated==base.isolated&&score(trial)>=minimumScore){
   answer=std::move(commands);
   bestArea=now.total;
  }
 }
 if(changed)*changed=stock!=answer;
 return answer;
}
}
