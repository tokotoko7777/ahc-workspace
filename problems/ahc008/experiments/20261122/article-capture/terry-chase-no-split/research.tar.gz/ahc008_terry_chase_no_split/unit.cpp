#define main archive_submission_main
#include "live.private.cpp"
#undef main
#include <cstdio>
#include <random>

int main(){
 using namespace terry_exact_root;
 using namespace chase_keep;
 {
  State s;
  s.walls.set();
  for(int p=0;p<7;++p)s.walls.reset(p);
  s.walls.reset(60);
  s.people={1,5};s.pets.push_back({60,1,-1});
  bool changed=false;
  assert(omitIfSafe(s,"r.",&changed)==".."&&changed);
 }
 {
  State s;s.walls.set();
  for(int p=0;p<12;++p)s.walls.reset(p);
  s.people={2,9};s.pets.push_back({5,1,-1});
  // Two real fences put both workers outside and keep the cow isolated.
  bool changed=true;
  assert(omitIfSafe(s,"rl",&changed)=="rl"&&!changed);
 }
 std::mt19937 rng(81366322);
 for(int q=0;q<500;++q){
  State s;
  // Interior 7*7 plus generous random open/cut slots.
  s.walls.set();
  for(int k=0;k<49;++k)if(rng()%6)s.walls.reset((k/7)*30+k%7);
  std::vector<int> open;
  for(int p=0;p<V;++p)if(!s.walls[p])open.push_back(p);
  if(open.empty())continue;
  for(int i=0;i<8;++i)s.people.push_back(open[rng()%open.size()]);
  for(int i=0;i<8;++i)s.pets.push_back({open[rng()%open.size()],1,-1});
  std::vector<char> random;
  for(int i=0;i<8;++i)random.push_back("....URDLurdl"[rng()%12]);
  const auto stock=sanitize(s,random);
  const auto proposed=omitIfSafe(s,stock);
  if(stock==proposed)continue;
  State a=s,b=s;people_step(a,stock);people_step(b,proposed);
  assert(a.people==b.people && (b.walls&~a.walls).none() &&
         a.walls.count()==b.walls.count()+1);
  const auto orig=terrainScore(a),now=terrainScore(b);
  assert(orig.parts>1 && now.parts==1 && terrainScore(s).parts==1);
  assert(orig.isolated==now.isolated && now.total>orig.total && score(b)>=score(a));
 }
 std::puts("Protected same-ID cuts and 500 randomized legal command invariants pass");
}
