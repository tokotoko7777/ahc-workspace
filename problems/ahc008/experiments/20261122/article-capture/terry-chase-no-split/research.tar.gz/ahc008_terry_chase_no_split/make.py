"""Pinned arrival solver -> narrow Chase-only wall subset projection."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def edit(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
a='std::string chase(const State& s,const terrain_lib::Terrain& layout,int turn){'
edit(a,(d/'keep.hpp').read_text()+'\nstd::string chase(const State& s,const terrain_lib::Terrain& layout,int turn,bool* changed=nullptr){')
a=' return sanitize(s,std::vector<char>(a.begin(),a.end()));'
edit(a,a.replace('return sanitize(s,std::vector<char>(a.begin(),a.end()));',
                'return chase_keep::omitIfSafe(s,sanitize(s,std::vector<char>(a.begin(),a.end())),changed);'))
a=' NormalCount metrics;Decision d;'
edit(a,a+'\n int safeOmissions=0;')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
edit(a,'''  bool changed=false;
  auto command=d.chose?chase(s,cfg,turn,&changed):policy.step(s,turn,&metrics);
  safeOmissions+=changed;''')
a="    <<metrics.idle_walks<<' '<<d.pairs<<' '<<d.normal<<' '<<d.chase_sum<<' '<<d.chose<<' '<<score(s)<<'\\n';"
edit(a,a.replace("<<d.chose<<' '<<score","<<d.chose<<' '<<safeOmissions<<' '<<score"))
(d/'live.private.cpp').write_text(s)
