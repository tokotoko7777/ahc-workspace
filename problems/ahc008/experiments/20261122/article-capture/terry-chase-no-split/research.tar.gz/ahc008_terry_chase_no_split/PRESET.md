# New causal area guard, single-wall-only rescue of worker connectivity

Factual incoming held100 showed 3 irreversible first worker splits,
all actual Chase t280–281. Only one admitted an immediate wall
omission retaining all previously/newly isolated pet IDs; two other
splits are meaningful captures with no such known alternative. That
defines a problem pattern, not a case condition or proof that a true
omission would improve later results.

Only if sanitized stock Chase command contains a build and would split
a previously all-connected set of workers, try omitting one build,
preserving every original move and every other build. Recombine all
workers; require exact same pet IDs inaccessible from all workers
as in the full stock action, strict per-human total floor gain (same
human positions and weaker walls make every old floor set a subset),
and no lower real instantaneous score on those same positions.
Choose maximum gain, stable actor order; otherwise literal stock.
No extra plan, no use of observed future, same logic actual and in
paired virtual Chase. Future animal paths may differ despite local
invariants, so results must be established separately. Normal, timing
limit, layouts and incoming scoring are unchanged.

First compile C++23 standalone and unit invariants; default 2670ms
paired on precommitted unfiltered development100 before held100.
Require ≥0.1% more aggregate, raw/useful full not lower, all official
tester and exact playback/independent replay, max local <2.95s.
At least one actual command omission must happen in each evaluated
100; if novel aggregate without any actual omission, do not claim
this policy helps. Only both pass permits official distributed100
with the same gate. No tweaking threshold/scope/clocks after failure.
