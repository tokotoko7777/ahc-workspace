namespace areaProbe {
struct Eval {bool ok=false,full=false; int humanTiles=0,score=0;};
inline Eval play(State s,int map,uint64_t seed,Clock::time_point stop){
 if(Clock::now()>=stop)return {};
 Normal policy(terrain_lib::terrain(map),s);
 ChaCha rng(seed);
 for(int turn=0;turn<300;++turn){
  if(Clock::now()>=stop)return {};
  people_step(s,policy.step(s,turn));
  actual_motion(s,rng);
 }
 if(Clock::now()>=stop)return {};
 Eval r;r.ok=true;r.full=true;
 const auto comp=terrain_lib::labels(s.walls);
 std::vector<int> size(comp.count),human(comp.count);
 for(int j:comp.labels)if(j>=0)++size[j];
 for(int h:s.people){const int j=comp.labels[h];++human[j];r.humanTiles+=size[j];}
 for(const auto& p:s.pets)if(human[comp.labels[p.pos]]){r.full=false;break;}
 r.score=score(s);return r;
}
inline void run(const State& s,int map){
 const auto start=Clock::now();
 const auto stop=start+std::chrono::milliseconds(900);
 const std::array<uint64_t,2> seeds{0x85d1c345e1afd5cbULL,0x16f112383699f58aULL};
 std::array<Eval,4> out{};
 size_t pairs=0;
 int people=s.people.size();
 if(map==1)for(size_t i=0;i<2;++i){
  out[2*i]=play(s,1,seeds[i],stop);
  if(!out[2*i].ok)break;
  out[2*i+1]=play(s,2,seeds[i],stop);
  if(!out[2*i+1].ok)break;
  ++pairs;
 }
 bool would_switch=pairs==2;
 for(size_t i=0;i<2&&would_switch;++i) {
  const auto& a=out[2*i];const auto& b=out[2*i+1];
  would_switch=a.full&&b.full&&b.humanTiles>a.humanTiles;
 }
 std::cout<<map<<' '<<people<<' '<<pairs<<' '<<would_switch<<' '
  <<std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count();
 for(auto x:out)std::cout<<' '<<x.ok<<' '<<x.full<<' '<<x.humanTiles<<' '<<x.score;
 std::cout<<'\n';
}
}
