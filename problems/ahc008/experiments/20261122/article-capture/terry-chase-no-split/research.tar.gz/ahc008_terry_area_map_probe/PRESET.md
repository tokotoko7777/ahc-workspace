# Causal initial map pair runtime/proxy screen, not an official score run

New distinct preflight under the already accepted incoming model,
not blind switching previously rejected map1→4. Freeze one pair:
only when the original model top1 gives map1, compare it to original
stock map2 (one more aisle and 30 fewer planned walls), not a search
over shapes/outcomes. As causal observations use initial real person
and pet locations/types, no future moves or real judge seed. Both
simulated policies use one own accepted Normal controller per arm,
with the same two fixed ex ante seeds and their modeled full
interactive pet moves up to turn 299. Do not use the late time-based
Chase comparison (proxy only); insist ALL FOUR rollouts capture all
and candidate human floor beat baseline in BOTH paired trials.
Measure exact same clock cap 900ms total per input including both
plans; no use of partial arm. No state mutation of the accepted
solver or official test, normal opening user time reservation remains
an untested concern. Fallback to the original map
if either pair is incomplete.

One independently generated uniform probe100, case counts including
ineligible. Advance to a separate real frozen controller only if there
are ≥12 eligible, ≥80% of eligible finish both complete paired
rollouts within budget, ≥6 cases would switch, and the sum of minimum
paired projected floor leads over the whole100 is at least 400 mean
tiles (4 per board). This is an upper bound on displayed proxy value
only, not expected live benefit; false proxy captures/variability
must still be tested. If fail, do not change pair maps, round counts or
window. No real official practice input and no known case IDs.
