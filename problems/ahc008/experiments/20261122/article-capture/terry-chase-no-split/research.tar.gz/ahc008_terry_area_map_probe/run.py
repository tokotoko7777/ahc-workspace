from pathlib import Path
import hashlib,json,subprocess
D=Path(__file__).resolve().parent
I=D/'probe100'
M={f.split()[1].removeprefix('in/'):f.split()[0] for f in (I/'SHA256SUMS').read_text().splitlines()}
a=[]
for f in sorted((I/'in').glob('*.txt')):
 r=f.read_bytes()
 sha=hashlib.sha256(r).hexdigest()
 assert sha==M[f.name]
 p=subprocess.run([D/'observer'],input=r,capture_output=True,check=True,timeout=2.5)
 label,m,n,yes,us,*data=map(int,p.stdout.split())
 assert len(data)==16
 if label!=1:assert n==0 and yes==0
 if yes:assert n==2
 a.append(dict(case=f.name,sha=sha,map=label,m=m,usable_pairs=n,switch=bool(yes),us=us,projections=[data[i:i+4] for i in (0,4,8,12)]))
 assert not p.stderr
assert len(a)==100
eligible=[r for r in a if r['map']==1]
both=[r for r in eligible if r['usable_pairs']==2]
switch=[r for r in both if r['switch']]
def gain(r):
 z=r['projections']
 return min(z[1][2]-z[0][2],z[3][2]-z[2][2])/r['m']
minsum=sum(map(gain,switch))
gate=len(eligible)>=12 and 5*len(both)>=4*len(eligible) and len(switch)>=6 and minsum>=400
print(json.dumps(dict(n=len(a),eligible=len(eligible),two_pairs=len(both),switch=len(switch),min_floor_sum=minsum,gate=gate,rows=a),indent=2))
