from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int h46_turn=-1;\ninline std::vector<std::string> h46_rows;\n'+s[i:]
a='    hunt::emit(s.people,jobs,legal,booked);'
put(a,a+'''
    if(h46_turn>=0){
     unsigned spare=0, outside=0;
     for(int i=0;i<m;++i)if(!booked[i])spare|=1u<<i;
     for(int i:alive){
      int k=geometry.ids[ps[i]];
      if(s.pets[i].type<=3&&(k<0||k>=geometry.count()))outside|=1u<<i;
     }
     if(std::popcount(spare)>=2&&outside){
      std::vector<bool> used(rooms.size());
      for(auto j:jobs)used[j.room]=true;
      h46_rows.push_back("S "+std::to_string(h46_turn)+" "+std::to_string(spare)+" "+std::to_string(outside));
      for(int k=0;k<(int)rooms.size();++k){
       const auto& r=rooms[k];
       if(used[k]||r.area<=0||r.left<0||r.right<0)continue;
       std::string row="R "+std::to_string(h46_turn)+" "+std::to_string(r.left)+" "+std::to_string(r.right);
       for(int p=0;p<V;++p)if(geometry.ids[p]==k&&p!=r.left&&p!=r.right)row+=" "+std::to_string(p);
       h46_rows.push_back(std::move(row));
      }
     }
    }
''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn>=80&&turn<160&&std::getenv("AHC008_H46_LOG"))h46_turn=turn;
'''+a+'''
  h46_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* p=std::getenv("AHC008_H46_LOG")){
   std::ofstream f(p);
   for(const auto& row:h46_rows)f<<row<<'\\n';
 }
'''+a)
(d/'observer.private.cpp').write_text(s)
