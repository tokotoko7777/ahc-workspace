import collections,hashlib,itertools,json,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_late_reservation'))
from evaluate import ADJ, B, ALL, wave, mask, cells, step, snapshot, command_effect, case_history, flood, closure
DEN=12**18
MASKS=R/'ahc008_terry_small_poly_bounded'

def vertical(p,s,h,w):
    if p%30!=s%30:return None
    d=abs(p//30-s//30)
    if d>h:return None
    k='U' if p>s else 'D'
    cur=p
    for _ in range(d):
        cur=step(cur,k)
        if cur is None or w&B[cur]:return None
    return k*d+'.'*(h-d)

def mass_rows(p,k,w,hs):
    sub={k*h:h for h in hs}
    a={p:DEN}
    for i in range(1,max(sub)+1):
        b=collections.defaultdict(int)
        for q,n in a.items():
            reach=ADJ[q]&~w; d=reach.bit_count()
            if not d:b[q]+=n;continue
            assert n%d==0
            for v in cells(reach):b[v]+=n//d
        a=b
        if i in sub:yield sub[i],a

def pick(state,cmd,kinds,free,outs,rs,stats):
    p,hum,w0=state
    w,stock=command_effect(hum,w0,p,cmd)
    prior=set(cells(free)); os=list(cells(outs))
    assert all(kinds[i]<=3 for i in os)
    humans=mask(hum+stock); available={}
    for l,r,body in rs:
        gates=B[l]|B[r]
        if not body or (gates|body)&(w|humans):continue
        if wave(body)&~(body|w)!=gates:continue
        if flood(B[next(cells(body))],ALL^(w|gates))!=body:continue
        T=body&~(gates|wave(gates))
        if not T:continue
        ls,rr=step(l,'L'),step(r,'R')
        if None in (ls,rr):continue
        if any(vertical(hum[a],ls,3,w) is not None and vertical(hum[b],rr,3,w) is not None for a,b in itertools.permutations(sorted(prior),2)):continue
        for a,b in itertools.permutations(sorted(prior),2):
            first=vertical(hum[a],ls,6,w);second=vertical(hum[b],rr,6,w)
            if first is None or second is None:continue
            eta=max(len(first.rstrip('.')),len(second.rstrip('.')))
            if not 4<=eta<=6 or (first[0]==cmd[a] and second[0]==cmd[b]):continue
            available.setdefault((eta,l,r,body,T),[]).append((a,b,first,second))
    if not available:return None
    oldid,reach,_=snapshot(w,stock,p); active=collections.defaultdict(dict)
    for k in available:
        h,l,r,body,T=k
        for q in cells(T):active[h].setdefault(q,[]).append(k)
    from_keys={h:mask(a) for h,a in active.items()}
    masses=collections.Counter(); contributes=collections.defaultdict(set)
    for i in os:
        if oldid&B[i]:continue
        k=kinds[i]; support=B[p[i]];hs=[]
        for s in range(1,k*max(from_keys)+1):
            # Reachability prefilter includes waits; exact distribution below
            # naturally removes parity-invalid endpoints and models isolated stay.
            support=(support|wave(support))&~w
            if s%k==0 and s//k in from_keys and support&from_keys[s//k]:hs.append(s//k)
        if not hs:continue
        for h,rows in mass_rows(p[i],k,w,hs):
            for q,m in rows.items():
                for a in active[h].get(q,()):
                    masses[a]+=m;contributes[a].add(i)
    best=None
    for key,m in masses.items():
        eta,l,r,body,T=key
        for a,b,pa,pb in available[key]:
            changed=list(cmd);changed[a]=pa[0];changed[b]=pb[0]
            alt=command_effect(hum,w0,p,changed)
            if not alt or alt[0]!=w:continue
            ids,ar,_=snapshot(w,alt[1],p)
            if ids!=oldid or any(x&~y for x,y in zip(reach,ar)):continue
            rank=(Fraction(m,DEN*(body.bit_count()+2)*(eta+1)),-eta,-l,-r,-a,-b)
            if best is None or rank>best[0]:
                best=(rank,eta,l,r,body,T,a,b,pa,pb,alt[1],contributes[key])
    return best

def label(t,v,hist,cmds,masks,stats):
    rank,eta,l,r,body,T,a,b,pa,pb,pose,pets=v
    endpoint,h,w_end=hist[t+eta]
    factual_arrives={i for i in pets if T&B[endpoint[i]]}
    if factual_arrives: stats['factual_safe_arrival']+=1
    for u in range(1,eta):
        p,h0,w=hist[t+u];cmd=cmds[t+u]
        if not all(masks.get(t+u,0)>>i&1 for i in (a,b)):return 'protected_during_route',0
        ow,oh=command_effect(h0,w,p,cmd)
        c=list(cmd);c[a]=pa[u];c[b]=pb[u]
        alt=command_effect(pose,w,p,c)
        if not alt or alt[0]!=ow:return 'illegal_route',0
        ids,reach,_=snapshot(ow,oh,p); ni,nr,_=snapshot(alt[0],alt[1],p)
        if ids&~ni:return 'lost_ids',0
        if ni!=ids or any(x&~y for x,y in zip(reach,nr)):return 'prep_changes_current_reach',0
        pose=alt[1]
    t+=eta
    w=w_end
    if not factual_arrives:return 'no_factual_safe_arrival',0
    cmd=cmds[t]
    if not all(masks.get(t,0)>>i&1 for i in (a,b)):return 'protected_at_closure',0
    assert pose[a]==step(l,'L') and pose[b]==step(r,'R')
    ow,oh=command_effect(h,w,endpoint,cmd)
    ids,reach,_=snapshot(ow,oh,endpoint)
    gained,why=closure(endpoint,w,pose,cmd,[(a,'r'),(b,'l')],B[l]|B[r],body,ids,reach)
    gained &= mask(factual_arrives)
    if not gained:return why if why!='ok' else 'factual_already_isolated',0
    for i,j in itertools.permutations(range(len(h)),2):
        if h[i]!=step(l,'L') or h[j]!=step(r,'R') or cmd[i].islower() or cmd[j].islower():continue
        possible,_=closure(endpoint,w,h,cmd,[(i,'r'),(j,'l')],B[l]|B[r],body,ids,reach)
        gained &= ~possible
    return ('witness',gained) if gained else ('stock_already_possible',0)

def main():
    recfile=R/'ahc008_terry_hunt_wall_audit/recordings.json'
    assert hashlib.sha256(recfile.read_bytes()).hexdigest()=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
    pin=dict(x.split()for x in (MASKS/'masks_manifest.log').read_text().splitlines())
    jobpin=dict(x.split()for x in (D/'materialize.log').read_text().splitlines())
    recs=json.loads(recfile.read_text());assert len(recs)==len(pin)==len(jobpin)==100
    stats=collections.Counter(); subgroup=collections.defaultdict(collections.Counter); allrows={}
    for rec in recs:
        name=rec['case']; kinds,hist,cmds=case_history(rec)
        fp=MASKS/'masks'/name
        assert hashlib.sha256(fp.read_bytes()).hexdigest()==pin[name]
        masks=dict(tuple(map(int,l.split()))for l in fp.read_text().splitlines())
        path=(D/'logs'/name).with_suffix('.jobs')
        assert hashlib.sha256(path.read_bytes()).hexdigest()==jobpin[name]
        observed={}; rs=collections.defaultdict(list)
        for line in path.read_text().splitlines():
            tag,t,*z=line.split();t=int(t);v=list(map(int,z))
            assert 80<=t<160
            if tag=='S':
                assert t not in observed and v[0]==masks[t];observed[t]=v
            elif tag=='R':
                assert t in observed
                l,r,*body=v
                rs[t].append((l,r,mask(body)))
            else:assert False
        rows=[]; witnesses=set()
        for t in range(80,160):
            stats['examined']+=1
            if t not in observed or not rs[t]:continue
            stats['raw_dormant_rooms_and_spare']+=1
            free,outside=observed[t]
            ans=pick(hist[t],cmds[t],kinds,free,outside,rs[t],stats)
            if ans is None:continue
            rank,h,l,r,b,T,a,d,pa,pd,_,src=ans
            why,ids=label(t,ans,hist,cmds,masks,stats)
            subgroup[h][why]+=1;stats[why]+=1
            if ids:witnesses.add((t+h,l,r,b))
            rows.append(dict(t=t,eta=h,body=list(cells(b)),gates=[l,r],actors=[a,d],
                routes=[pa,pd],score=str(rank[0]),probability_sources=sorted(src),label=why,newids=list(cells(ids))))
        if rows:allrows[name]=dict(proposals=rows,witnesses=len(witnesses))
    summary=dict(changes=sum(len(r['proposals'])for r in allrows.values()),change_boards=len(allrows),
        closures=sum(r['witnesses']for r in allrows.values()),closure_boards=sum(bool(r['witnesses'])for r in allrows.values()),
        stats=dict(stats),by_h={str(h):dict(v)for h,v in subgroup.items()})
    summary['gate']=summary['changes']>=20 and summary['change_boards']>=10 and summary['closures']>=5 and summary['closure_boards']>=3 and not stats['lost_ids']
    (D/'report.json').write_text(json.dumps(dict(summary=summary,cases=allrows),indent=2)+'\n')
    print(json.dumps(summary))
if __name__=='__main__':main()
