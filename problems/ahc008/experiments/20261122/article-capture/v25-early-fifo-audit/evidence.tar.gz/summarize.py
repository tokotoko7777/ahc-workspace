import argparse,collections,json
from pathlib import Path

def lists(parts,n):
    out=[]
    for _ in range(n):
        sz=parts.pop(0)
        out.append(parts[:sz]);parts=parts[sz:]
    assert not parts
    return out

def summarize(files):
    out={};eligible=[]
    for file in files:
        c=collections.Counter()
        hits=collections.defaultdict(set)
        divert=collections.defaultdict(set)
        staffable_missing=collections.defaultdict(set)
        for line in file.read_text().splitlines():
            key,*parts=line.split(); cells=list(map(int,parts))
            if key=='W':
                t,i,from_,nextStance=cells[:4]
                head,pet,same,nxt=lists(cells[4:],4)
                c['reserved_dot_ticks']+=1
                c['pet_blocked_head_ticks']+=bool(pet)
                c['head_with_nonpet_blocked_job_ticks']+=len(pet)!=len(head)
                for label,opts in [('same_stance',same),('adjacent_next',nxt)]:
                    if opts:
                        c[label+'_ticks_all_causes']+=1
                        if len(pet)==len(head):
                            c[label+'_ticks_pure_pet']+=1
                            hits[label+'_cells_pure_pet'].update(opts)
                            if same:divert[t].update(same)
            else:
                assert key=='T'
                t,k,exact,use,dot,walk,build,other=cells[:8]
                missing,ids=lists(cells[8:],2)
                if missing:
                    label='shoulder_missing_staffable' if use else ('shoulder_missing_workers_reserved' if exact else 'shoulder_missing_and_no_pair')
                    if use:staffable_missing[t].update(missing)
                elif use:label='ready_free_exact_pair'
                elif not exact:label='ready_no_exact_pair'
                elif dot and not any((walk,build,other)):label='ready_blocked_only_by_dot'
                else:
                    label='ready_other_reservation'
                    if dot:c['ready_other_with_dot_ticks']+=1
                c[label+'_ticks']+=1
                hits[label+'_pet_tubes'].update((k,i) for i in ids)
        if hits['same_stance_cells_pure_pet']:eligible.append(file.name)
        out[file.name]=dict(c)|{k:len(v) for k,v in hits.items()}|dict(
            direct_missing_shoulder_intersections=sum(len(v&staffable_missing[t]) for t,v in divert.items()))
    sums=collections.Counter()
    for d in out.values():sums.update(d)
    return dict(cases=len(out),same_stance_case_count=len(eligible),
                prereg_5_case_screen_passed=len(eligible)>=5,
                same_stance_case_names=eligible,sums=dict(sums),by_case=out)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('logs',nargs='+',type=Path)
    a=p.parse_args()
    print(json.dumps(summarize(a.logs),indent=2))
