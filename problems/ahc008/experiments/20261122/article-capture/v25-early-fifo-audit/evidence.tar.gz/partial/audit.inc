 struct FifoCapacity {
  int first,fa,fb,second,a,b,eta,stepA,stepB;
  double value;
  char firstA,firstB;
  bool protects,unused=false,bankCompatible=false;
 };
 bool fifoCapacityEnabled=getenv("AHC008_PARTIAL_PAIR_AUDIT")!=nullptr;
 vector<FifoCapacity> fifoCapacityPending;
 ostringstream fifoCapacityHistory;
 void fifoCapacityTry(const vector<vector<BankJob>>& jobs,const BankJob& first,
      const array<BankPath,10>& paths,bitset<terry_lane::MaxTubes> shut){
  const bool firstSafe=terryRoad.protects(first.tube,shut);
  shut[first.tube]=true;
  fifoCapacityHistory<<"P "<<turn<<' '<<first.tube<<' '<<first.a<<' '<<first.b<<'\n';
  for(const auto& row:jobs)for(const auto& j:row){
   if(j.tube==first.tube||j.a==first.a||j.a==first.b||j.b==first.a||j.b==first.b||
      j.value<=0)continue;
   const auto& x=banks[j.tube];
   const auto& t=banks[first.tube];
   auto expected=[&](int i,int st){
    int q=paths[i].step[st];
    return q<0?'.':MOVE[dir(humans[i],q)];
   };
   fifoCapacityPending.push_back({first.tube,first.a,first.b,j.tube,j.a,j.b,j.eta,
       paths[j.a].step[x.l],paths[j.b].step[x.h],j.value,
       expected(first.a,t.l),expected(first.b,t.h),firstSafe&&terryRoad.protects(j.tube,shut)});
  }
 }
 void fifoCapacityBankEnd(const bitset<V>& used,const bitset<V>& build,const bitset<V>& moveTo){
  for(auto& z:fifoCapacityPending){
   z.unused=!used[z.a]&&!used[z.b];
   z.bankCompatible=act[z.a]=='.'&&act[z.b]=='.';
   for(int q:{z.stepA,z.stepB})if(q>=0&&(build[q]||moveTo[q]))z.bankCompatible=false;
  }
 }
 void fifoCapacityFinal(){
  if(!fifoCapacityEnabled)return;
  for(const auto& z:fifoCapacityPending){
   bool wait=act[z.a]=='.'&&act[z.b]=='.';
   bool conflicts=false;
   auto& x=banks[z.second];
   for(int i=0;i<int(act.size());i++)if(act[i]!='.'){
    if(islower(act[i])){
     int q=nb[humans[i]][find(BUILD,BUILD+4,act[i])-BUILD];
     if(q==z.stepA||q==z.stepB||q==x.g||q==x.k||q==x.l||q==x.h||
        find(x.inner.begin(),x.inner.end(),q)!=x.inner.end())conflicts=true;
    }else{
     int q=nb[humans[i]][find(MOVE,MOVE+4,act[i])-MOVE];
     if(q==z.stepA||q==z.stepB||q==x.g||q==x.k||q==x.l||q==x.h||
        find(x.inner.begin(),x.inner.end(),q)!=x.inner.end())conflicts=true;
    }
   }
   fifoCapacityHistory<<"S "<<turn<<' '<<z.first<<' '<<z.second<<' '<<z.a<<' '<<z.b<<' '
    <<z.eta<<' '<<z.stepA<<' '<<z.stepB<<' '<<z.value<<' '<<z.protects<<' '
    <<z.unused<<' '<<z.bankCompatible<<' '<<wait<<' '<<conflicts<<' '<<(act[z.fa]==z.firstA&&act[z.fb]==z.firstB)<<' '<<act<<'\n';
  }
  fifoCapacityPending.clear();
 }
