from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:])
data=p.read_bytes();assert hashlib.sha256(data).hexdigest()=='46f210cc5dd50b8a6088724861ae5c2b044d08edb109a891ee217352730fcb84'
s=data.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' vector<BankJob> packBankJobs(',Path(__file__).with_name('audit.inc').read_text()+' vector<BankJob> packBankJobs(')
rep('    for(auto j:packBankJobs(jobs,partial?1:m/2)){','''    const auto packed=packBankJobs(jobs,partial?1:m/2);
    if(partial&&fifoCapacityEnabled&&m==5&&turn>=35&&turn<=100&&!packed.empty())
     fifoCapacityTry(jobs,packed.front(),paths,shut);
    for(auto j:packed){''')
rep('   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);\n  }\n  return act;', '''   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);
  }
  fifoCapacityBankEnd(usedPeople,build,moveTo);
  return act;''')
rep("  cout<<g.act<<'\\n'<<flush;", "  g.fifoCapacityFinal();\n  cout<<g.act<<'\\n'<<flush;")
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* path=getenv("AHC008_PARTIAL_PAIR_AUDIT")){
  ofstream out(path);out<<g.fifoCapacityHistory.str();
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
