import collections,json,sys
from pathlib import Path

def case(p):
    ticks=collections.defaultdict(set)
    examples=[]
    for line in p.read_text().splitlines():
        key,*v=line.split()
        t=int(v[0])
        if key=='P':
            ticks['eligible_cap1'].add(t)
            continue
        assert key=='S'
        first,other,a,b,eta,sa,sb=map(int,v[1:8])
        value=float(v[8])
        protect,unused,bank,wait,collision,first_intact=map(int,v[9:15])
        ticks['raw_second_pair'].add(t)
        if protect:
            ticks['connected_companion'].add(t)
        if protect and unused and bank:
            ticks['no_bank_reservation'].add(t)
        if protect and unused and bank and wait and not collision and first_intact:
            ticks['eligible_including_holds'].add(t)
            if sa>=0 or sb>=0:
                ticks['eligible_extra_move'].add(t)
                examples.append(dict(t=t,first=first,second=other,workers=[a,b],eta=eta,
                                     extra_steps=[sa,sb],value=value,actual=v[15]))
    return dict(counts={k:len(v) for k,v in ticks.items()},examples=examples)

out={Path(a).name:case(Path(a)) for a in sys.argv[1:]}
tot=collections.Counter()
for d in out.values():tot.update(d['counts'])
boards={k:sum(d['counts'].get(k,0)>0 for d in out.values()) for k in tot}
print(json.dumps(dict(cases=len(out),totals=tot,board_count=boards,
                    passes_gate=boards.get('eligible_extra_move',0)>=5,by_case=out),indent=2))
