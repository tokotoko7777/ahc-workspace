import collections,json,sys
from pathlib import Path

out={}
for arg in sys.argv[1:]:
    ticks=collections.defaultdict(set)
    encounters=collections.defaultdict(set)
    raw=collections.Counter()
    for line in Path(arg).read_text().splitlines():
        t,armed,k,a,b,donor,eta,heads,ok,already=map(int,line.split()[:10])
        phase='armed' if armed else 'before_armed'
        access='blocked_dot' if donor>=0 else 'free'
        label='_'.join((phase,access,'one_step' if eta else 'on_stance'))
        raw[label+'_raw_pairs']+=1
        if not ok:
            raw[label+'_conflict_pairs']+=1
            continue
        label+='_already' if already else '_new'
        raw[label+'_compatible_pairs']+=1
        ticks[label].add((t,k))
        encounters[label].update((k,i) for i in range(20) if heads>>i&1)
    row=dict(raw)
    for label,seen in ticks.items():row[label+'_tube_ticks']=len(seen)
    for label,seen in encounters.items():row[label+'_pet_tubes']=len(seen)
    out[Path(arg).name]=row
totals=collections.Counter()
for d in out.values():totals.update(d)
print(json.dumps(dict(cases=len(out),sum=dict(totals),
                      cases_by_bucket={k:sum(v.get(k,0)>0 for v in out.values())
                         for k in totals if k.endswith('_tube_ticks')},per_case=out),indent=2))
