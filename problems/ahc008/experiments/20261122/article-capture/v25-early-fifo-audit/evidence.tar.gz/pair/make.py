from pathlib import Path
import hashlib,sys
a,b=map(Path,sys.argv[1:])
data=a.read_bytes()
assert hashlib.sha256(data).hexdigest()=='ded5ba3bbdb0c486975f0f3a225fded386420b192fbf4d1fcbfae4a08e882153'
s=data.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' bool fifoAuditEnabled=',Path(__file__).with_name('pair.inc').read_text()+' bool fifoAuditEnabled=')
rep('  for(int k=0;k<int(banks.size());k++){\n   const auto& x=banks[k];\n   if(wall[x.g]||wall[x.k]||build[x.g]', '''  fifoPairs(walls,build,moveTo,used,blockedDot,ready);
  for(int k=0;k<int(banks.size());k++){
   const auto& x=banks[k];
   if(wall[x.g]||wall[x.k]||build[x.g]''')
rep("  cout<<g.act<<'\\n'<<flush;", "  g.fifoPairFinal();\n  cout<<g.act<<'\\n'<<flush;")
rep(' if(const char* path=getenv("AHC008_FIFO_AUDIT")){',''' if(const char* path=getenv("AHC008_FIFO_PAIR_AUDIT")){
  ofstream out(path);out<<g.fifoPairHistory.str();
 }
 if(const char* path=getenv("AHC008_FIFO_AUDIT")){''')
rep(' bool fifoAuditEnabled=getenv("AHC008_FIFO_AUDIT")!=nullptr;', ''' bool fifoAuditEnabled=getenv("AHC008_FIFO_AUDIT")!=nullptr||fifoPairEnabled;''')
b.write_text(s)
