 struct FifoPair {
  int tube,a,b,donor,eta;
  bool armed;
  string moves;
  unsigned heads;
 };
 vector<FifoPair> fifoPairPending;
 ostringstream fifoPairHistory;
 bool fifoPairEnabled=getenv("AHC008_FIFO_PAIR_AUDIT")!=nullptr;
 void fifoPairs(const bitset<V>& walls,const bitset<V>& build,const bitset<V>& moveTo,
                const bitset<V>& used,const bitset<V>& blockedDot,const vector<int>& ready){
  if(!fifoPairEnabled)return;
  array<int,5> counts{};
  bitset<V> bodies;
  for(int k=0;k<int(banks.size());k++)if(ready[k]){
   ++counts[banks[k].b];
   for(int q:banks[k].inner)bodies[q]=true;
  }
  bool armed=turn>=35&&*max_element(counts.begin(),counts.end())>=5;
  const auto& tasks=terryBuild.tasks();
  const auto& cursor=terryBuild.auditCursors();
  auto petwait=[&](int i){
   if(!blockedDot[i])return false;
   bool has=false;
   for(int p:tasks[i][cursor[i]].walls)if(!walls[p]&&!build[p]){
    has=true;
    if(none_of(pets.begin(),pets.end(),[&](auto q){return md(q.p,p)<=1;}))return false;
   }
   return has;
  };
  for(int k=0;k<int(banks.size());k++)if(ready[k]&&!terryRoad.bridge[k]&&!crossing.reserves(k)){
   auto& x=banks[k];
   if(walls[x.g]||walls[x.k]||build[x.g]||build[x.k]||moveTo[x.g]||moveTo[x.k]||block[x.g]||block[x.k])continue;
   if(any_of(x.inner.begin(),x.inner.end(),[&](int q){
    return walls[q]||build[q]||moveTo[q]||find(humans.begin(),humans.end(),q)!=humans.end();
   }))continue;
   unsigned heads=0;
   for(int p=0;p<int(pets.size());p++)if(pets[p].p==x.inner[1]||pets[p].p==x.inner[2])heads|=1U<<p;
   if(!heads)continue;
   for(int a=0;a<5;a++)for(int b=0;b<5;b++)if(a!=b){
    int donor=-1,eta=0;bool ok=true;
    string moves(5,'.');
    for(auto [i,stance]:{pair(a,x.l),pair(b,x.h)}){
     int from=humans[i],d=md(from,stance);eta=max(eta,d);
     if(d>1||walls[stance]||build[stance]||bodies[stance]||bodies[from]||moveTo[stance]){ok=false;break;}
     if(used[i]){
      // Only a real, purely pet-blocked FIFO wait can be lent. The old
      // stance also remains open so the same one edge permits return.
      if(d!=1||donor>=0||!petwait(i)||build[from]||walls[from]){ok=false;break;}
      donor=i;
     }
     if(d)moves[i]=MOVE[dir(from,stance)];
    }
    if(ok)fifoPairPending.push_back({k,a,b,donor,eta,armed,moves,heads});
   }
  }
 }
 void fifoPairFinal(){
  if(!fifoPairEnabled||fifoPairPending.empty())return;
  for(auto& z:fifoPairPending){
   const auto& x=banks[z.tube];
   bool compatible=true,already=true;
   for(auto [i,stance]:{pair(z.a,x.l),pair(z.b,x.h)}){
    if(act[i]!='.'&&act[i]!=z.moves[i])compatible=false;
    if(act[i]!=z.moves[i])already=false;
   }
   for(int i=0;i<5;i++)if(act[i]!='.'){
    if(islower(act[i])){
     const int q=nb[humans[i]][find(BUILD,BUILD+4,act[i])-BUILD];
     if(q==x.g||q==x.k||q==x.l||q==x.h||
        find(x.inner.begin(),x.inner.end(),q)!=x.inner.end()||
        (z.donor>=0&&q==humans[z.donor]))compatible=false;
    }else{
     const int q=nb[humans[i]][find(MOVE,MOVE+4,act[i])-MOVE];
     if(q==x.g||q==x.k||find(x.inner.begin(),x.inner.end(),q)!=x.inner.end())
      compatible=false;
     if(i!=z.a&&i!=z.b&&(q==x.l||q==x.h))compatible=false;
    }
   }
   fifoPairHistory<<turn<<' '<<z.armed<<' '<<z.tube<<' '<<z.a<<' '<<z.b<<' '
     <<z.donor<<' '<<z.eta<<' '<<z.heads<<' '<<compatible<<' '<<already<<' '<<z.moves<<' '<<act<<'\n';
  }
  fifoPairPending.clear();
 }
