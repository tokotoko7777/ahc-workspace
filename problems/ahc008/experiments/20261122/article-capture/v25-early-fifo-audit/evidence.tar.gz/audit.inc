 bool fifoAuditEnabled=getenv("AHC008_FIFO_AUDIT")!=nullptr;
 ostringstream fifoHistory;
 void fifoAudit(const bitset<V>& walls,const bitset<V>& build,const bitset<V>& moveTo,
                const bitset<V>& earlier,const bitset<V>& used,const vector<int>& ready){
  if(!fifoAuditEnabled||turn>100||humans.size()!=5)return;
  const auto& sched=terryBuild.tasks();
  const auto& cur=terryBuild.auditCursors();
  bitset<V> blockedDot;
  if(terryBuild.inConstruction(turn)&&sched.size()==humans.size()&&cur.size()==humans.size())
  for(int i=0;i<int(humans.size());i++)if(!earlier[i]&&used[i]&&act[i]=='.'&&cur[i]<int(sched[i].size())){
   const auto& route=sched[i];const auto& head=route[cur[i]];int from=humans[i];
   if(head.from!=from)continue;
   vector<int> heads,petHeads,same,next;
   auto pending=[&](int w){return !walls[w]&&!build[w];};
   auto legal=[&](int w){return pending(w)&&!moveTo[w]&&!block[w];};
   for(int q:head.walls)if(pending(q)){
    heads.push_back(q);
    if(any_of(pets.begin(),pets.end(),[&](auto p){return p.p==q||md(p.p,q)==1;}))petHeads.push_back(q);
   }
   if(heads.empty())continue;
   blockedDot[i]=true;
   for(int j=cur[i]+1;j<int(route.size());j++){
    const auto& o=route[j];
    if(o.from!=from)continue;
    for(int q:o.walls)if(legal(q)&&md(from,q)==1)same.push_back(q);
   }
   int nextStance=-1;
   bitset<V> active;
   for(int k=0;k<int(banks.size());k++)if(ready[k]&&
      find(banks[k].inner.begin(),banks[k].inner.end(),from)==banks[k].inner.end())
    for(int q:banks[k].inner)active[q]=true;
   for(int j=cur[i]+1;j<int(route.size());j++){
    const auto& o=route[j];
    if(o.from==from||none_of(o.walls.begin(),o.walls.end(),pending))continue;
    if(md(from,o.from)==1&&!walls[o.from]&&!build[o.from]&&!moveTo[o.from]&&
       !terryBuild.braces()[o.from]&&!active[o.from]){
     nextStance=o.from;
     for(int q:o.walls)if(legal(q)&&md(o.from,q)==1)next.push_back(q);
    }
    break; // exact immediately next physically pending *distinct* scheduled stance
   }
   auto emit=[&](const vector<int>& v){fifoHistory<<' '<<v.size();for(int q:v)fifoHistory<<' '<<q;};
   fifoHistory<<"W "<<turn<<' '<<i<<' '<<from<<' '<<nextStance;
   emit(heads);emit(petHeads);emit(same);emit(next);fifoHistory<<'\n';
  }
  for(int k=0;k<int(banks.size());k++){
   const auto& x=banks[k];
   if(wall[x.g]||wall[x.k]||build[x.g]||build[x.k]||block[x.g]||block[x.k])continue;
   if(any_of(x.inner.begin(),x.inner.end(),[&](int q){return wall[q]||build[q]||find(humans.begin(),humans.end(),q)!=humans.end()||moveTo[q];}))continue;
   if(moveTo[x.g]||moveTo[x.k])continue;
   vector<int> ids;
   for(int p=0;p<int(pets.size());p++)if(pets[p].p==x.inner[1]||pets[p].p==x.inner[2])ids.push_back(p);
   if(ids.empty())continue;
   vector<int> missing;
   for(int q:x.side)if(!wall[q])missing.push_back(q);
   if(ready[k]&&terryRoad.bridge[k])continue;
   int exact=0,usable=0;
   unsigned dot=0,walking=0,building=0,other=0;
   for(int a=0;a<int(humans.size());a++)if(humans[a]==x.l)
   for(int b=0;b<int(humans.size());b++)if(a!=b&&humans[b]==x.h){
    ++exact;
    if(!used[a]&&!used[b])++usable;
    for(int i:{a,b})if(used[i]){
     if(blockedDot[i])dot|=1U<<i;
     else if(isupper(act[i]))walking|=1U<<i;
     else if(islower(act[i]))building|=1U<<i;
     else other|=1U<<i;
    }
   }
   fifoHistory<<"T "<<turn<<' '<<k<<' '<<exact<<' '<<usable<<' '<<dot<<' '<<walking<<' '<<building<<' '<<other;
   fifoHistory<<' '<<missing.size();for(int q:missing)fifoHistory<<' '<<q;
   fifoHistory<<' '<<ids.size();for(int p:ids)fifoHistory<<' '<<p;
   fifoHistory<<'\n';
  }
 }
