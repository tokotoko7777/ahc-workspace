from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:])
raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='46f210cc5dd50b8a6088724861ae5c2b044d08edb109a891ee217352730fcb84'
s=raw.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' const vector<vector<Order>>& tasks()const{return schedule;}',''' const vector<vector<Order>>& tasks()const{return schedule;}
 const vector<int>& auditCursors()const{return cursor;}''')
rep(' optional<string> terryLate(',Path(__file__).with_name('audit.inc').read_text()+' optional<string> terryLate(')
rep('  terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});','''  const auto fifoAuditBefore=usedPeople;
  terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});
  fifoAudit(walls,build,moveTo,fifoAuditBefore,usedPeople,ready);''')
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* path=getenv("AHC008_FIFO_AUDIT")){
  ofstream out(path);out<<g.fifoHistory.str();
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
