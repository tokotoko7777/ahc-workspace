#define main archive_submission_main
#include "solve.private.cpp"
#undef main
#include <numeric>
#include <random>
#include <cstdio>
namespace exact_build {
#include "control.hpp"
}
int main(){
 using namespace exact_build;
 namespace t=terry_exact_maps;
 std::mt19937 rng(7078821);
 int fixtures=0;
 auto check=[&](const Layout& l,const std::vector<int>& people){
  for(bool f:{false,true}){
   auto a=split_control(l,people,f),b=split(l,people,f);
   assert(a.makespan==b.makespan&&a.right==b.right&&a.path==b.path&&a.q.size()==b.q.size());
   for(int j=0;j<(int)a.q.size();++j){
    assert(a.q[j].size()==b.q[j].size());
    for(int k=0;k<(int)a.q[j].size();++k)
     assert(a.q[j][k].at==b.q[j][k].at&&a.q[j][k].mask==b.q[j][k].mask);
   }
   ++fixtures;
  }
 };
 for(int i=0;i<5;++i){
  const auto& tt=t::terrain(i);
  Layout l; l.aisleRows=tt.aisleRows;l.aisleCols=tt.aisleColumns;
  for(int p=0;p<V;++p)l.ascii[p]=char(tt.cells[p]);
  for(int m=5;m<=10;++m)for(int q=0;q<2;++q){
   std::vector<int> people(m);
   if(q==0){for(auto& a:people)a=int(rng()%V);}
   else std::fill(people.begin(),people.end(),rng()%V);
   check(l,people);
  }
 }
 for(int g=0;g<120;++g){
  const int m=1+g%5;
  Layout l;
  l.ascii.fill('.');l.aisleRows={1,3};
  l.aisleCols={8,21};
  l.ascii[N+N-1]=l.ascii[3*N+N-1]='~';
  for(int i=0;i<g%31;++i)l.ascii[rng()%(4*N)]='X';
  std::vector<int> people(m);
  for(auto& p:people)p=rng()%V;
  check(l,people);
 }
 std::printf("%d exact orientations, makespan, and every queued action matched\n",fixtures);
}
