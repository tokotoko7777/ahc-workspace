# Exact construction split planning, fixed-work gate
Phase profile of the accepted h123 source found initial build split
planning 55.3% of measured flow on 16 no-rollout boards, and 9.8%
on 14 positive-rollout boards. Test one isolated optimization of
that kernel only, preserving exact direction ties, worker traversal,
segment window, chosen path, each worker queue and all game semantics.
Flatten mask×prefix DP and compact predecessors, cache Manhattan
entry costs, test only prefixes that can assign exactly the remaining
workers with positive segments ≤window, and reduce orientation choice
to min-cost plus the original forward-first tie rule. Any pruned
prefix cannot lead to a valid full assignment. Table bytes fit
because fixed Manhattan ≤58 and path length ≤900.

Before any official comparison, pure original-vs-optimized equality
on 360 orientations (all original maps, each staff count 5–10 and
coincident ties, plus random small inputs). Both practice100 and
prior independent accepted held100 fixed-work panels must reproduce
every command SHA and score, and reduce aggregate wait4 CPU at least
2% per panel. No full timing control or quality changes; fixed cap
used only in diagnostic. Report no-rollout and with-rollout macro
results, machine uncertainty and max tester wall. If first panel
fails, do not go to held. Live default then separately validated.
