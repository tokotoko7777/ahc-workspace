"""Pinned accepted h123 -> exact fast initial two-orientation build DP."""
from pathlib import Path
import hashlib

d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_passive_exact_short/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
a=s.index('inline Split split('); b=s.index('inline Split initialize(',a)
(d/'control.hpp').write_text(s[a:b].replace('inline Split split(','inline Split split_control(',1))
(d/'solve.private.cpp').write_text(s[:a]+(d/'split.hpp').read_text()+'\n'+s[b:])
