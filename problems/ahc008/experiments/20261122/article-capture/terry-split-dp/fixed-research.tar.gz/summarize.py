"""Paired default-clock summaries including endgame rollout use."""
import csv
import json
import sys
from pathlib import Path

p=Path(sys.argv[1]); base={}
for x in csv.DictReader(p.open()):
    base.setdefault(x['case'],{})[x['arm']]=x
assert len(base)==100 and all(len(x)==2 for x in base.values())
diff=[]
for f,z in sorted(base.items()):
    a,b=z['v25'],z['terry_independent']
    aa,bb=a['telemetry'].split(),b['telemetry'].split()
    assert a['input_sha']==b['input_sha'] and len(aa)==len(bb)==15
    assert a['score']==aa[-1] and b['score']==bb[-1]
    assert aa[0]==bb[0]
    diff.append((f,a,b,aa,bb))
totals={k:[sum(int(d[i][k])for d in diff)for i in (1,2)]
       for k in ('score','full','useful300','final_residual','exact4_100','exact4_160','exact4_final')}
changed=[d[0] for d in diff if d[1]['commands_sha']!=d[2]['commands_sha']]
flips=[d[0] for d in diff if d[3][13]!=d[4][13]]
comparisons={f:[int(d['score']),int(d['full']),int(a[10]),int(a[13])]
             for f,d,_,a,b in diff if f in changed}
summ=dict(**totals,
    max_wall=[max(float(d[i]['wall']) for d in diff)for i in (1,2)],
    pairs=[sum(int(d[i][10])for d in diff)for i in (3,4)],
    more_equal_fewer_pairs=[sum(op(int(d[4][10]),int(d[3][10]))for d in diff)
       for op in (lambda a,b:a>b,lambda a,b:a==b,lambda a,b:a<b)],
    avg_pair_score=[sum(int(d[2]['score'])-int(d[1]['score'])for d in diff)/len(diff)],
    changed_cases=changed,choice_flips=flips,
    cases=[dict(case=f,base=dict(score=int(a['score']),full=int(a['full']),pair_count=int(aa[10]),chase=int(aa[13])),
               fast=dict(score=int(b['score']),full=int(b['full']),pair_count=int(bb[10]),chase=int(bb[13])))
           for f,a,b,aa,bb in diff if f in changed])
print(json.dumps(summ,indent=2))
