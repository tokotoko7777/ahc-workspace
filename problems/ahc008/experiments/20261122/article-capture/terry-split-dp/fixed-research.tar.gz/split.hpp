inline Split split(const Layout& l,const std::vector<int>& people,bool right){
 Split ret;ret.right=right;ret.path=snake(l,right);
 const int M=people.size(),L=ret.path.size();
 ret.q.resize(M);
 if(M<1||M>10||L<M)return ret;
 const auto& p=ret.path;
 std::vector<int> len(L+1),work(L+1);
 for(int j=0;j<L;++j){
  len[j+1]=len[j]+(j?md(p[j-1],p[j]):0);
  work[j+1]=work[j]+verticalWork(l,p[j]);
 }
 std::vector<int> into(L+1),outof(L);
 for(int j=0;j<=L;++j)into[j]=len[j]+work[j];
 for(int j=0;j<L;++j)outof[j]=len[j+1]+work[j];
 // Approach precomputed once per path endpoint and already-ordered worker.
 // row-major by endpoint so hot worker accesses are adjacent.
 std::vector<std::array<uint8_t,10>> approach(L);
 for(int i=0;i<L;++i)for(int j=0;j<M;++j)
  approach[i][j]=uint8_t(md(p[i],people[j]));
 struct Prev{uint16_t from;uint8_t who,forward;};
 const int full=(1<<M)-1,window=2*L/M,stride=L+1;
 std::vector<int> dp((full+1)*stride,INF);
 std::vector<Prev> prev((full+1)*stride);
 dp[0]=0;
 for(int used=0;used<full;++used){
  const int remaining=M-std::popcount(unsigned(used)),done=M-remaining;
  const int lo=std::max(done,L-remaining*window);
  const int hi=std::min(done*window,L-remaining);
  const int* const state=dp.data()+used*stride;
  std::array<int,10> worker{},base{};
  int n=0;
  for(unsigned u=unsigned(full^used);u;u&=u-1){
   const int j=std::countr_zero(u);
   worker[n]=j;base[n]=(used|1<<j)*stride;++n;
  }
  const int minEnd=L-(remaining-1)*window,maxEnd=L-(remaining-1);
  for(int from=lo;from<=hi;++from){
   const int costBefore=state[from];
   if(costBefore>=INF)continue;
   const auto& nearFront=approach[from];
   for(int to=std::max(from+1,minEnd),last=std::min(from+window,maxEnd);to<=last;++to){
    const int span=into[to]-outof[from];
    const auto& nearBack=approach[to-1];
    for(int q=0;q<n;++q){
     const int at=base[q]+to,j=worker[q];
     const int a=nearFront[j],b=nearBack[j];
     const int z=std::max(costBefore,span+std::min(a,b));
     if(z<dp[at]){
      dp[at]=z;
      // Forward visited first in the original, even if its own approach
      // is longer but both orientations tie at the parent's makespan.
      prev[at]={uint16_t(from),uint8_t(j),uint8_t(a<=b||costBefore>=span+a)};
     }
    }
   }
  }
 }
 ret.makespan=dp.back();
 if(ret.makespan>=INF)return ret;
 for(int used=full,b=L;used;){
  const auto z=prev[used*stride+b];
  std::vector<int> path(p.begin()+z.from,p.begin()+b);
  if(!z.forward)std::reverse(path.begin(),path.end());
  ret.q[z.who]=tasks(l,path);used^=1<<z.who;b=z.from;
 }
 return ret;
}
