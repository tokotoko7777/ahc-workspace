# Exact official-judge replay after one predetermined public skip

No solver; use the exact locally pinned official prebuilt tester and a
plain Python action dispatcher. Older accepted Incoming held100 signed
input/action/trace files (not current f83, unseen validation or new cases).
Stage 1: verify hashes then replay ALL 100 stocked 300-action scripts;
must reproduce every judge-emitted pet line byte-for-byte, every stock
action, official rounded score and full flag before enabling stage 2.
If any fails, stop, do not weaken checks or reconstruct RNG separately.

Stage 2: retain all judge RNG mechanics through the official tester.
Tester alone receives complete seeded case input; official Display sends
the dispatcher only public initial observations, then causal pet lines.
Only at most one omission per board, before t160. Static menu per map:
planned X bordering an exact straight paired-room body, neither on nor
adjacent to any configured mouth or guard stance, outside aisle columns.
For current submitted action only, consider new placements at menu cells
in row-major order. Compare pre-pet projected stock and skipped boards
using same current pet positions and projected crew. Require each person's
exact reachable pet IDs and crew pairwise connectivity unchanged.
Every still worker-reachable pet must be at graph distance strictly >6
from skipped cell on skipped projected board. Pick first qualifying
action and cell; replace all duplicate lowercases to that target by wait.
No subsequent restoration/reserve, trajectory repair or choosing again.
Selection function takes public state, frozen geometry and one same-turn
stock command; no memory of opponent trace or official private seed,
future command, final score or result labels. Subsequent stock commands
are fixed-policy playback, not presented as adaptive live decisions.

Every divergence arm keeps all other signed actions, then runs until
official first action rejection (record reason/diagnostic actor+target)
or legal completion. Compare opponent lines retrospectively, never via
selector. Record first changed observable pet IDs/species and actual
omitted-cell contacts by early/mid/late bands, without guessing latent
cause. For failed runs keep prefix only, don't treat missing floor as
zero or successful; legal finishing cases get official rounded score,
full, useful (full and mean human floor ≥300), unpenalized/effective
floor. Report all100 and exposed group denominators separately;
unexposed exact stays proven identical, illegal fails full/useful.
Nonnegative official-score average is not an acceptance condition; this
is a diagnosis, not solver quality. Direct added floor of one skipped
cell ≤1 per board, normalized ≤exposed/100; changes in entire captures
or splits can add or lose more indirectly, not one-cell savings.

Freeze support ≥20 exposed boards. Follow-up interpretation only if
≥90% legally complete among exposed, zero losses of baseline full or
useful among all 100 (including conflicts), ≥5 positive local floor
finishes among exposed and positive total floor delta on certified legal
finishes. Label conditional averages; no +10 target claim or automatic
follow-up. Stage-one failure or cap is inconclusive. No private seeds,
raw traces, temporary sidecars or official binaries in archive.

One run after clearance only (no compilation or build dependency):
```sh
timeout -k 1s 119s python3 -u ahc008_terry_x_exact_replay/replay.py \
  > ahc008_terry_x_exact_replay/result.jsonl
```
