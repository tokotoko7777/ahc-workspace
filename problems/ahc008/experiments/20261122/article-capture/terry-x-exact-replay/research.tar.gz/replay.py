"""Official judge, signed actions, one public-state-only omission. No solver."""
from pathlib import Path
from hashlib import sha256
from tempfile import TemporaryDirectory
from fractions import Fraction
from collections import Counter,deque
import json,re,subprocess,sys

D=Path(__file__).resolve().parent
R=D.parent
T=R/'ahc008_terry_hunt_wall_audit'
I=R/'ahc008_terry_incoming_shadow/held100/in'
J=R/'ahc008_focus_assets/tools/target/release/tester'
C=R/'ahc008_terry_small_rooms/catalog.tsv'
PINS={T/'recordings.json':'dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5',
 T/'analyze.py':'8c8ec5d472ae8af00416cb7a8e6297bc3d509b056fff66d7a6eb2bcdb0e7b964',
 C:'2d697e1b2cbf0cd9d754d38a18059e2fbcd484b7440868da8016f8310132ba06',
 R/'ahc008_terry_exact_maps/terrain_data.inc':'8d1f703d67b9d16fb0ba6d3b20cd2bb4a2cf20aea33e4a7351d45fd129e256cf',
 R/'ahc008_focus_assets/tools/src/lib.rs':'c0085cea776b5f444a3a4c16550055be3784ffb79f924ed9bf5f9840a20087f5',
 J:'f95e04c6adacf82d51352ae1fcd32212ce9ba4d38bfa3e81156ca9580308ebfe'}
ALL=(1<<900)-1
LEFT=sum(1<<(30*r) for r in range(30))
RIGHT=LEFT<<29
DIR={'L':(0,-1),'R':(0,1),'U':(-1,0),'D':(1,0)}
def bit(p):return 1<<p
def mask(c):return sum(bit(p) for p in set(c))
def wave(a):
    return (((a&~LEFT)>>1)|((a&~RIGHT)<<1)|(a>>30)|(a<<30))&ALL
def flood(p,op):
    cur=p
    assert cur&op==cur
    while True:
        q=cur|wave(cur)&op
        if q==cur:return q
        cur=q
def shift(p,c):
    x,y=divmod(p,30);r,s=DIR[c.upper()]
    if 0<=x+r<30 and 0<=y+s<30:return 30*(x+r)+y+s
    return None
def digest(b):return sha256(b).hexdigest()
def state(w,h,p):
    comp=[]
    for q in h:
        comp.append(next((a for a in comp if a&bit(q)),0) or flood(bit(q),ALL^w))
    hu=0
    for a in comp:hu|=a
    rel=tuple(a==b for i,a in enumerate(comp) for b in comp[:i])
    pets=tuple(tuple(i for i,x in enumerate(p) if a&bit(x)) for a in comp)
    return rel,pets,hu,comp
def finish(w,h,p):
    _,pets,_,c=state(w,h,p)
    areas=[a.bit_count() for a in c]
    full=not any(pets)
    floor=Fraction(sum(areas),len(h))
    eff=sum(Fraction(x,1<<len(q)) for x,q in zip(areas,pets))/len(h)
    return dict(full=full,useful=full and floor>=300,floor=str(floor),effective=str(eff))
def project(w,h,cmd):
    put={i:shift(h[i],c) for i,c in enumerate(cmd) if c.islower()}
    ww=w|mask(q for q in put.values() if q is not None)
    dest=[shift(x,c) if c.isupper() else x for x,c in zip(h,cmd)]
    return put,ww,dest
def choose(t,w,h,p,cmd,menu):
    # Complete dependency list: t, current public geometry/positions,
    # current causal stock proposal only, and frozen static map menu.
    if t>=160:return None
    put,ww,dest=project(w,h,cmd)
    if any(q is None for q in dest):return None
    cands=sorted({q for q in put.values() if q is not None and q in menu and not bit(q)&w})
    if not cands:return None
    s=state(ww,dest,p)
    for q in cands:
        wo=ww^bit(q)
        a=state(wo,dest,p)
        if a[:2]!=s[:2]:continue
        region=bit(q)
        for _ in range(6):region|=wave(region)&(ALL^wo)
        if region&mask(p)&a[2]:continue
        return q,''.join('.' if put.get(i)==q else c for i,c in enumerate(cmd))
    return None
def initial():
    p=[]; kinds=[]
    N=int(input())
    for _ in range(N):
        x,y,k=map(int,input().split()); p.append((x-1)*30+y-1);kinds.append(k)
    M=int(input())
    h=[]
    for _ in range(M):
        x,y=map(int,input().split());h.append((x-1)*30+y-1)
    return p,h,kinds
def concurrent_violations(w,h,p,cmd):
    put,ww,dest=project(w,h,cmd)
    why=[]; pm=mask(p); hm=mask(h)
    for i,q in put.items():
        if q is None:continue
        b=bit(q)
        if pm&b:why.append([i,q,'wall_pet_on'])
        elif hm&b:why.append([i,q,'wall_human_on'])
        elif wave(pm)&b:why.append([i,q,'wall_adjacent_pet'])
    for i,q in enumerate(dest):
        if q is None:why.append([i,q,'move_offboard'])
        elif bit(q)&ww:why.append([i,q,'move_blocked'])
    return why

def proxy(actions_path,menu_text,side,mode):
    cmds=Path(actions_path).read_text().splitlines()
    assert len(cmds)==300
    menu=frozenset(map(int,menu_text.split(','))) if menu_text else frozenset()
    p,h,types=initial(); w=0; omitted=None
    with open(side,'w',buffering=1) as log:
        def emit(x):print(json.dumps(x),file=log,flush=True)
        emit(dict(kinds=types))
        for t,stock in enumerate(cmds):
            a=stock
            if mode=='omit' and omitted is None:
                z=choose(t,w,h,p,stock,menu)
                if z:
                    omitted,a=z
                    emit(dict(omit=omitted,t=t))
            errs=concurrent_violations(w,h,p,a)
            if errs:emit(dict(violations=errs,t=t))
            print(a,flush=True)
            s=sys.stdin.readline()
            if not s:return
            _,w,h=project(w,h,a)
            s=s.rstrip('\n')
            path=s.split()
            assert len(path)==len(p) and not errs
            contact=[]
            for i,m in enumerate(path):
                for step,ch in enumerate(m):
                    if ch!='.':p[i]=shift(p[i],ch)
                    assert p[i] is not None
                    if omitted is not None and p[i]==omitted:contact.append((i,step))
            emit(dict(obs=s,contact=contact,t=t))
        emit(dict(final=finish(w,h,p)))

def menus():
    sys.path.insert(0,str(T))
    from analyze import terrain
    ts=terrain()
    lanes=({8,21},{4,14,24},{4,11,18,25},{0,6,13,19,26},{4,11,18,25})
    attached=[0]*5; guards=[0]*5
    for line in C.read_text().splitlines():
        k,i,l,r,*body=map(int,line.split())
        guards[k]|=mask([q for q,valid in ((l-1,l>=0),(r+1,r>=0)) if valid])
        if l>=0 and r>=0 and l//30==r//30 and body==list(range(l+1,r)):
            attached[k]|=mask(body)
    result=[]
    for k,(x,g) in enumerate(ts):
        opts=x&wave(attached[k])&~(g|guards[k]|wave(g|guards[k]))
        result.append(','.join(str(q) for q in range(900)
                               if bit(q)&opts and q%30 not in lanes[k]))
    return result

def official(inp,act,menu,side,mode):
    if side.exists():side.unlink()
    p=subprocess.run([str(J),sys.executable,str(Path(__file__).resolve()),'proxy',str(act),
                      menu,str(side),mode],input=inp,stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE,timeout=5,check=True)
    emitted=p.stdout.decode().splitlines()
    log=[json.loads(x) for x in side.read_text().splitlines()]
    end=[x['final'] for x in log if 'final' in x]
    obs=[x for x in log if 'obs' in x]
    diagnostics=p.stderr.decode().splitlines()
    num=re.findall(r'Score = (-?\d+)',p.stderr.decode())
    assert len(num)==1
    return emitted,log,end,obs,int(num[0]),diagnostics

def main():
    for p,d in PINS.items():assert digest(p.read_bytes())==d
    records=json.loads((T/'recordings.json').read_text())
    assert len(records)==len({r['case'] for r in records})==100
    menu=menus()
    baseline=[]
    with TemporaryDirectory() as temp:
        side=Path(temp)/'private-sidecar'
        for r in records:
            c=r['case']; a=(T/'tapes'/c).with_suffix('.actions')
            i,z=I/c,a.with_suffix('.trace')
            inp,act,tr=[p.read_bytes() for p in (i,a,z)]
            assert [digest(q) for q in (inp,act,tr)]==[r[k] for k in ('input_sha','commands_sha','trace_sha')]
            cmds=act.decode().splitlines();trace=tr.decode().splitlines()
            assert len(cmds)==300 and len(trace)==600 and cmds==trace[::2]
            em,log,end,obs,score,msg=official(inp,a,'',side,'stock')
            assert em==cmds and [o['obs'] for o in obs]==trace[1::2] and len(end)==1
            assert score==r['score'] and bool(r['actual_full'])==end[0]['full']
            baseline.append((r,inp,a,cmds,trace[1::2],end[0]))
        print(json.dumps(dict(parity=100,board_scores=100,opponent_lines=30000)),flush=True)
        result=[]
        for r,inp,a,cmds,old,base in baseline:
            em,log,end,obs,score,msg=official(inp,a,menu[r['map']],side,'omit')
            omitted=[o for o in log if 'omit' in o]
            assert len(omitted)<=1
            if not omitted:
                assert em==cmds and [o['obs'] for o in obs]==old and end==[base] and score==r['score']
                result.append(dict(case=r['case'],map=r['map'],exposed=False,legal=True,old=base,new=base,old_score=score,new_score=score))
                continue
            event=omitted[0]; j=event['t']
            assert all(cur==act for k,(cur,act) in enumerate(zip(em,cmds)) if k!=j)
            assert len(em)>j and em[j]!=cmds[j] and len(em[j])==len(cmds[j])
            assert all(x==y or (x=='.' and y.islower()) for x,y in zip(em[j],cmds[j]))
            assert [o['obs'] for o in obs[:j]]==old[:j]
            kinds=log[0]['kinds']
            drift=next(((i,[(k,kinds[k]) for k,(a,b) in enumerate(zip(o['obs'].split(),old[i].split())) if a!=b])
                         for i,o in enumerate(obs) if o['obs']!=old[i]),None)
            touch=[(o['t'],i,kinds[i],sub) for o in obs for i,sub in o['contact']]
            violations=[x for x in log if 'violations' in x]
            legal=bool(end)
            if legal:assert len(obs)==300 and len(em)==300 and not violations
            else:assert len(obs)+1==len(em) and len(violations)==1 and score==0
            result.append(dict(case=r['case'],map=r['map'],exposed=True,omit=event,
                 legal=legal,old=base,new=end[0] if legal else None,
                 old_score=r['score'],new_score=score,first_drift=drift,
                 first_contact=touch[0] if touch else None,
                 first_contact_early=next((x for x in touch if x[0]<160),None),
                 first_contact_mid=next((x for x in touch if 160<=x[0]<275),None),
                 first_contact_late=next((x for x in touch if x[0]>=275),None),
                 failure=None if legal else dict(turn=len(obs),actors=violations[0]['violations'],
                                                    official=[x for x in msg if 'Score' not in x])))
    exp=[r for r in result if r['exposed']]; legal=[r for r in exp if r['legal']]
    full=lambda r:bool(r['legal'] and r['new']['full'])
    useful=lambda r:bool(r['legal'] and r['new']['useful'])
    floor_gain=lambda r:Fraction(r['new']['floor'])-Fraction(r['old']['floor'])
    gain=sum((floor_gain(r) for r in legal),Fraction(0))
    lossf=sum(r['old']['full'] and not full(r) for r in result)
    lossu=sum(r['old']['useful'] and not useful(r) for r in result)
    print(json.dumps(dict(n=100,exposed=len(exp),legal_exposed=len(legal),
      legal_all=sum(r['legal'] for r in result),old_full_all=sum(r['old']['full'] for r in result),
      full_all=sum(full(r) for r in result),full_exposed=sum(full(r) for r in exp),
      old_useful_all=sum(r['old']['useful'] for r in result),
      useful_all=sum(useful(r) for r in result),useful_exposed=sum(useful(r) for r in exp),
      losses_full=lossf,losses_useful=lossu,positive_legal_exposed=sum(floor_gain(r)>0 for r in legal),
      mean_floor_gain_legal_exposed=str(gain/len(legal)) if legal else None,
      direct_opened_cell_ceiling_all=str(Fraction(len(exp),100)),
      support_gate=len(exp)>=20,
      proceed_gate=len(exp)>=20 and len(legal)*10>=9*len(exp) and lossf==lossu==0
                         and sum(floor_gain(r)>0 for r in legal)>=5 and gain>0,
      rows=result),indent=2))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='proxy':proxy(*sys.argv[2:])
    else:main()
