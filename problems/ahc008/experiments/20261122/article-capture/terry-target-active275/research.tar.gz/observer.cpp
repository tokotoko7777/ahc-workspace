#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>
constexpr int N=900,M=10;
constexpr auto nb=[]{
 std::array<std::array<int,4>,N> a{};
 for(int p=0;p<N;++p)a[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 return a;
}(); // UDLR
using Wall=std::array<bool,N>;
using Dist=std::array<int,N>;
using Prob=std::array<double,4>;
struct Graph {
 Dist d,mask,order;int n=1;
 Graph(int start,const Wall& w){
  d.fill(-1);mask.fill(0);order[0]=start;d[start]=0;
  for(int i=0;i<n;++i){
   const int p=order[i];
   for(int k=0;k<4;++k){
    int q=nb[p][k];if(q<0||w[q])continue;
    if(d[q]<0){d[q]=d[p]+1;order[n++]=q;}
    if(d[q]==d[p]+1)mask[q]|=i?mask[p]:1<<k;
   }
  }
 }
};
struct State{
 Wall walls{};
 std::vector<int> people,pet;
 void apply(const std::string& line){
  assert(line.size()==people.size());
  std::string dirs="UDLRudlr";
  for(int i=0;i<(int)line.size();++i)if(line[i]!='.'){
   size_t k=dirs.find(line[i]);assert(k<8);
   int q=nb[people[i]][k%4];assert(q>=0&&!walls[q]);
   if(k<4)people[i]=q;else walls[q]=true;
  }
 }
};
struct Steps{int dir=-1,mid=-1,end=-1,len=0;};
Steps decode(int p,const Wall& w,const std::string& token){
 Steps s;s.end=p;s.len=token.size();
 for(char c:token){
  size_t k=std::string_view("UDLR").find(c);assert(k<4);
  s.end=nb[s.end][k];assert(s.end>=0&&!w[s.end]);
  if(s.dir<0){s.dir=int(k);s.mid=s.end;}
 }
 return s;
}
struct Prediction{
 Prob legacy{},post{};
};
Prediction cat(const State& s,int p,Steps x,std::array<double,N+1>& prior,bool update){
 Graph g(p,s.walls);
 Prediction out;
 assert(g.n>=2&&x.len==2);
 double sum=0;
 for(int i=1;i<g.n;++i)sum+=prior[g.order[i]];
 const double u=1./(g.n-1),reset=std::max(0.,1.-sum);
 std::array<double,N+1> next{};
 for(int i=1;i<g.n;++i){
  int z=g.order[i];unsigned mask=g.mask[z];int k=std::popcount(mask);
  assert(k>0);
  double a=u/k,b=(prior[z]+reset*u)/k;
  for(;mask;mask&=mask-1){int j=std::countr_zero(mask);out.legacy[j]+=a;out.post[j]+=b;}
  if(update&&(g.mask[z]&(1<<x.dir)))next[z==x.mid||z==x.end?N:z]+=b;
 }
 if(update){
  assert(out.post[x.dir]>0);
  for(auto& x0:next)x0/=out.post[x.dir];
  prior=next;
 }
 return out;
}
Prediction dog(const State& s,int p,Steps x,std::array<double,M+1>& prior,
 const std::vector<Dist>& ds,bool update){
 Prediction out;
 int n=0;double kept=0;
 for(int i=0;i<(int)ds.size();++i)if(ds[i][p]>0){++n;kept+=prior[i];}
 if(!n){
  assert(x.len==1);int k=0;
  for(int z:nb[p])k+=z>=0&&!s.walls[z];
  assert(k>0);
  for(int j=0;j<4;++j)if(nb[p][j]>=0&&!s.walls[nb[p][j]])out.legacy[j]=out.post[j]=1./k;
  if(update){prior.fill(0);prior[M]=1;}
  return out;
 }
 assert(x.len==2);
 std::array<double,M+1> next{};
 for(int i=0;i<(int)ds.size();++i){
  int d=ds[i][p];if(d<=0)continue;
  int k=0;
  for(int z:nb[p])k+=z>=0&&ds[i][z]==d-1;
  assert(k>0);
  double a=1./n/k, b=(prior[i]+std::max(0.,1.-kept)/n)/k;
  for(int j=0;j<4;++j)if(nb[p][j]>=0&&ds[i][nb[p][j]]==d-1){
   out.legacy[j]+=a;out.post[j]+=b;
   if(update&&j==x.dir)next[(s.people[i]==x.mid||s.people[i]==x.end)?M:i]+=b;
  }
 }
 if(update){
  assert(out.post[x.dir]>0);
  for(double& z:next)z/=out.post[x.dir];
  prior=next;
 }
 return out;
}
int main(int argc,char** argv){
 if(argc!=4)return 2;
 std::ifstream f(argv[1]),tape(argv[2]);
 std::string mode=argv[3];
 assert(f&&tape&&(mode=="exposure"||mode=="4"||mode=="5"||mode=="45"));
 State s;
 int n,m;f>>n;
 std::vector<int> species(n);
 s.pet.resize(n);
 for(int i=0;i<n;++i){int a,b;f>>a>>b>>species[i];s.pet[i]=(a-1)*30+b-1;}
 f>>m;s.people.resize(m);
 for(auto& q:s.people){int a,b;f>>a>>b;q=(a-1)*30+b-1;}
 assert(f); // stop before hidden seed suffix
 std::array<State,276> states;
 std::array<std::vector<Steps>,276> events;
 for(int t=0;t<=275;++t){
  std::string cmd,line;
  assert(std::getline(tape,cmd)&&std::getline(tape,line));
  states[t]=s;
  s.apply(cmd);
  events[t].resize(n);
  std::istringstream ss(line);
  for(int i=0;i<n;++i){
   std::string token;ss>>token;assert(ss);
   events[t][i]=decode(s.pet[i],s.walls,token);s.pet[i]=events[t][i].end;
  }
 }
 const auto& pre=states[275];
 std::array<bool,N> visited{},majority{};int best=-1,first=N;
 for(int p:pre.people)if(!visited[p]){
  Graph g(p,pre.walls);
  int count=0,low=N;
  for(int i=0;i<g.n;++i){int q=g.order[i];visited[q]=true;low=std::min(low,q);}
  for(int q:pre.people)count+=g.d[q]>=0;
  if(count>best||(count==best&&low<first)){
   best=count;first=low;
   for(int q=0;q<N;++q)majority[q]=g.d[q]>=0;
  }
 }
 std::vector<int> active;
 for(int i=0;i<n;++i)if((species[i]==4||species[i]==5)&&majority[pre.pet[i]]){
  if(mode=="exposure"){std::cout<<species[i]<<','<<i<<'\n';continue;}
  if(mode.find(char('0'+species[i]))!=std::string::npos)active.push_back(i);
 }
 if(active.empty())return 0;
 std::vector<std::array<double,N+1>> cat_prior(n);
 std::vector<std::array<double,M+1>> dog_prior(n);
 bool has_dog=false;
 for(int i:active){cat_prior[i][N]=1;dog_prior[i][M]=1;has_dog|=species[i]==4;}
 std::cout<<std::setprecision(17);
 for(int t=0;t<=275;++t){
  const State& after=t==275?s:states[t+1];
  const State& before=states[t];
  std::vector<Dist> ds;
  if(has_dog)for(int q:after.people)ds.push_back(Graph(q,after.walls).d);
  for(int i:active){
   int p=before.pet[i];auto x=events[t][i];
   auto pr=species[i]==4?dog(after,p,x,dog_prior[i],ds,t<275)
                        :cat(after,p,x,cat_prior[i],t<275);
   if(t!=275)continue;
   double a=0,b=0;
   for(int j=0;j<4;++j){a+=pr.legacy[j];b+=pr.post[j];}
   assert(std::abs(a-1)<1e-8&&std::abs(b-1)<1e-8);
   bool preok=after.walls==before.walls&&(species[i]==5||after.people==before.people);
   std::cout<<species[i]<<','<<i<<','<<x.dir<<','<<x.len<<','<<preok;
   for(double q:pr.legacy)std::cout<<','<<q;
   for(double q:pr.post)std::cout<<','<<q;
   std::cout<<'\n';
  }
 }
}
