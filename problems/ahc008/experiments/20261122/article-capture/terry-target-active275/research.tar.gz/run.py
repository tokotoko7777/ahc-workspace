"""Pinned tape-only counts then conditional first-directed-step scoring."""
import collections
import csv
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

W=Path(__file__).resolve().parents[1]
D=W/'ahc008_terry_clean_normal_preview'
I=W/'ahc008_terry_terminal_k8'/'dev'
pins={
 D/'recordings.json':'4d45b441e35e56287ddaad4986c78bed0deba07057fa29a52bc40b2bbff42f2c',
 I/'manifest.json':'5c2877a6733e3bb454096d3f2da17f830899a1bfd047c485b2707a3c6480399d',
 I/'official.csv':'54ec41b7e157b8586841a019b4d71ba51ea7f2a289af5e2d3b31904f845bd218',
 W/'ahc008_focus_assets'/'tools'/'src'/'lib.rs':'c0085cea776b5f444a3a4c16550055be3784ffb79f924ed9bf5f9840a20087f5',
}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def lines(exe,inp,tape,mode):
    return list(csv.reader(subprocess.check_output([exe,inp,tape,mode],text=True,timeout=4).splitlines()))
def positive_exposure(cats,s):return len({c for c,_ in cats})>=12 and (s==5 or len(cats)>=25)
def score(rows,unchanged_only):
    groups=collections.defaultdict(list)
    excluded=0
    for c,r in rows:
        d,L,same=map(int,r[2:5])
        if unchanged_only and not same:continue
        if L!=2:
            excluded+=1
            continue
        assert 0<=d<4
        a=list(map(float,r[5:9]));b=list(map(float,r[9:13]))
        assert len(a)==len(b)==4
        groups[c].append((math.log(max(b[d],1e-12))-math.log(max(a[d],1e-12)),
             sum((a[k]-(k==d))**2-(b[k]-(k==d))**2 for k in range(4))))
    n=len(groups);events=sum(map(len,groups.values()))
    dn=[sum(x for x,_ in r)/len(r) for r in groups.values()]
    db=[sum(y for _,y in r)/len(r) for r in groups.values()]
    return dict(cases=n,scored=events,no_directed_event=excluded,
        nll_gain=sum(dn)/max(n,1), brier_gain=sum(db)/max(n,1), wins=sum(k>0 for k in dn))

def main():
    assert len(sys.argv) in (2,3)
    exe=Path(sys.argv[1]).resolve()
    for p,d in pins.items(): assert sha(p.read_bytes())==d,p
    rec={r['case']:r for r in json.loads((D/'recordings.json').read_bytes())}
    selected={r['case']:r for r in json.loads((I/'manifest.json').read_bytes())['selected']}
    official={r['case']:r for r in csv.DictReader((I/'official.csv').open()) if r['arm']=='terry_independent'}
    assert len(rec)==100 and rec.keys()==selected.keys()==official.keys()
    observed={4:set(),5:set()};cases={}
    for c,m in rec.items():
        a=(D/'tapes'/c).with_suffix('.actions')
        t=a.with_suffix('.trace');inp=I/'selected'/c
        ib,ab,tb=inp.read_bytes(),a.read_bytes(),t.read_bytes()
        assert m['input_sha']==selected[c]['sha256']==official[c]['input_sha']==sha(ib)
        al,tl=ab.splitlines(),tb.splitlines()
        assert len(al)==300 and len(tl)==600 and tl[::2]==al
        assert m['actions_sha']==official[c]['commands_sha']==sha(ab)
        assert m['trace_sha']==sha(tb)
        assert selected[c]['prefix_sha']==official[c]['prefix_sha']==sha(b'::'.join(al[:275]))
        cases[c]=(inp,t)
        for s,p in lines(exe,inp,t,'exposure'):
            observed[int(s)].add((c,int(p)))
    good={s for s,o in observed.items() if positive_exposure(o,s)}
    out={s:dict(cases=len({c for c,_ in o}),ids=len(o),exposure_pass=s in good)
         for s,o in observed.items()}
    raw={s:[] for s in good}
    if good:
        for c,(inp,tape) in cases.items():
            mode=''.join(str(s) for s in sorted(good) if any(a==c for a,_ in observed[s]))
            if not mode:continue
            for row in lines(exe,inp,tape,mode):raw[int(row[0])].append((c,row))
        for s,rr in raw.items():
            assert {(c,int(r[1])) for c,r in rr}==observed[s]
            primary=score(rr,False);same=score(rr,True)
            q=out[s]
            q.update(primary=primary,pre_action_invariant=same,
                pass_gate= primary['cases']>=12 and (s==5 or primary['scored']>=25)
                    and primary['nll_gain']>=.05 and primary['wins']>primary['cases']/2
                    and primary['brier_gain']>0)
    print(json.dumps(dict(verified_tapes=len(cases),species=out),indent=2))
    if len(sys.argv)==3:Path(sys.argv[2]).write_text(json.dumps(raw,separators=(',',':'))+'\n')
if __name__=='__main__':main()
