# t275-active forced-Chase first-step predictive QA (untimed, no policy)

Previously frozen independent enriched set, precisely 100 terminal-k8 selected
inputs and clean-normal-preview materialized forced-Chase tapes. Recorded games
match official test/playback and independent replay. Verify source book/manifest,
input, whole action bytes, exact action projection within tape, tape hashes, and
verified same t<275 prefix against forced-Chase and selected ledgers. No solver
or external service is invoked. Hidden judge seed suffix is authenticated only
as part of the input hash; it is not parsed by the observer. No new submissions.

Species are treated independently. Eligible = every type4/type5 pet in the
largest human component just before action t275, first row-major component
breaking human-count ties. Exposure gate: 12 distinct cases for each species
and additionally 25 distinct dog IDs, before any predictive results are
computed. Primary scoring requires 12 cases of directed labels and for dogs
25 such labels (one label per ID); dog one-symbol random-only fallback is
counted but not scored, with no predictive distinction. Advance only with
case-macro NLL gain >=.05 nat, strict majority case wins and strict Brier gain.
No widening or adjusting these gates. Fixed NLL clipping 1e-12 both arms.
The selected set is active-state enriched; no extrapolation to all games.

Replay Bayesian posterior updates from official t0–274 actions and animal
strings, after each human phase. Dog unreachable/coincident/unknown mass
reselects among reachable noncoincident human IDs; if none, fallback is one
uniform move and reset. Cat unreachable/current/unknown mass uniformly
reselects over reachable positive-distance cells. Directed ties are uniform
over shortest first directions, and the second random substep cancels
likelihood conditional on the first; either substep reaching target resets.
At t275 no field from its pet observation enters the predicted probability;
the actual first direction labels it. The known factual human action is used
to put both forecasts on the same observed post-human wall/people state, so
this conditional QA makes no clairvoyant victory, closure or policy claim.
As a separately descriptive pre-action-invariant subset, restrict to no
factual wall change for cats and no wall or person change for dogs. Do not
use this subset to rescue a failed primary gate.

Compare exact prior-uniform target (not uniform neighbor) vs the whole-history
posterior. Retain per-case first-direction probability vectors, score with
case macros and case wins; multiple pets on one board are correlated. No
mode/branch score, no capturability interpretation, no timing of the solver.

After explicit CPU clearance only:
```sh
D=ahc008_terry_target_active275
g++ -std=c++23 -O2 "$D/observer.cpp" -o "$D/observer"
python "$D/run.py" "$D/observer" "$D/events.local.json" > "$D/result.json"
```
