"""Independent finite physical graph check, no game/action/solver data."""
from pathlib import Path
import itertools as it
import json

N,M=10,8
CELLS=set(it.product(range(N),range(M)))
SIDE={p for p in CELLS if p[1] in (0,7)}
CONNECTOR={(9,c) for c in range(8)}
DIR=((1,0),(-1,0),(0,1),(0,-1))
def adj(p):return {(p[0]+a,p[1]+b) for a,b in DIR}&CELLS
def flood(start,floor):
    assert start in floor
    seen={start};f={start}
    while f:
        f=set().union(*(adj(p) for p in f))&floor-seen
        seen|=f
    return seen
def mk_pair(r):
    return (frozenset((r,c) for c in range(2,6)),
            frozenset(((r,1),(r,6))),frozenset(((r,0),(r,7))))
stock=[mk_pair(r) for r in (1,3,5,7)]
mixed=[mk_pair(1),mk_pair(6),
       (frozenset(((3,2),(3,3),(4,2))),frozenset(((4,1),)),frozenset(((4,0),))),
       (frozenset(((3,5),(4,5),(4,4))),frozenset(((3,6),)),frozenset(((3,7),)))]
old_wall={(r,c) for r in (0,2,4,6,8) for c in range(2,6)}
new_wall=({(r,c) for r in (0,2,5,7) for c in range(2,6)}|
          {(3,1),(3,4),(4,3),(4,6)})

def verify(rooms,walls):
    masks=[b|g for b,g,s in rooms]
    s=set().union(*(s for b,g,s in rooms))
    assert sum(map(len,masks))==len(set().union(*masks))
    assert not (SIDE|CONNECTOR|s|set().union(*masks))&walls
    assert not CONNECTOR&set().union(*masks)
    assert s<=SIDE and not s&set().union(*masks)
    paired=[]
    for b,g,s in rooms:
        assert flood(min(b),b)==b and len(g)==len(s)
        assert {sum(p)%2 for p in b-set().union(*(adj(q) for q in g))}=={0,1}
        assert set().union(*(adj(p) for p in b))-b <= walls|g
        for q in g:
            assert len(adj(q)&s)==len(adj(q)&b)==1
        if len(g)==2:
            assert len(b)==4 and len({p[0] for p in b|g|s})==1
            r=min(g)[0]
            assert {(r,c) for c in range(8)}<=b|g|s
            paired.append(r)
            # Remove all other floor except the row: the through crossing
            # must be physically traversable without the common connector.
            row={(r,c) for c in range(8)}
            assert (r,7) in flood((r,0),row-walls)
        else:
            assert len(b)==3 and len(g)==1
    for action in range(1<<len(rooms)):
        close=[v for i,v in enumerate(rooms) if action>>i&1]
        doors=set().union(*(g for b,g,s in close))
        bodies=set().union(*(b for b,g,s in close))
        floor=CELLS-walls-doors
        main=flood((9,0),floor)
        assert main==floor-bodies
        assert all(flood(min(b),floor)==b and s<=main for b,g,s in close)
        assert SIDE|CONNECTOR<=main
        for i,(b,g,s) in enumerate(rooms):
            if not action>>i&1:assert b|g|s<=main
    grid=[['.']*M for _ in range(N)]
    for r,c in walls:grid[r][c]='X'
    for id,(b,g,s) in enumerate(rooms):
        for r,c in b:grid[r][c]=chr(ord('a')+id)
        for r,c in g:grid[r][c]='g'
        for r,c in s:grid[r][c]='s'
    reach=[min(abs(y-r) for r in paired) for y in range(1,9)]
    return dict(walls=len(walls),named_rooms=len(rooms),paired_rows=paired,
      actual_longitudinal_reach_rows_1_to_8=reach,max_crossing_reach=max(reach),
      mouth_count=sum(len(g) for b,g,s in rooms),
      closed_body_tiles=sum(len(b) for b,g,s in rooms),
      closed_body_plus_mouth_tiles=sum(len(b|g) for b,g,s in rooms),
      patterns_checked=1<<len(rooms),grid=[''.join(row) for row in grid])
def main():
    a,b=verify(stock,old_wall),verify(mixed,new_wall)
    assert a['named_rooms']==b['named_rooms']==4
    assert len(b['paired_rows'])==2 and len(a['paired_rows'])==4
    assert b['walls']<=a['walls'] and b['mouth_count']<a['mouth_count']
    assert b['closed_body_tiles']<a['closed_body_tiles']
    print(json.dumps(dict(stock=a,mixed=b,boundary=dict(shared_brace_row=0,
          common_real_connector=9,editable_rows=[1,8])),indent=2))
if __name__=='__main__':main()
