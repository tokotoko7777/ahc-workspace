# Opposite-side three-cell solo packet between actual through rooms

Static comparison of two 8-row edits sharing the same row-0 upper brace
and row-9 permanently open real connector, all counted on a 10×8 local
physical board. Left and right aisles are columns 0 and 7. No virtual
outside connector or teleport. The common connector is charged explicitly:
one genuine permanently vacant crossing row in both arms, e.g. a
deliberately reserved physical row29 in a corresponding vertical band.
It is not presumed available in the existing stock full-board layout:
this fixture is not a zero-cost drop-in conversion.

Stock: four straight paired rooms on rows 1,3,5,7, four body cells each,
with unchanged direct aisle guard roles. Mixed: paired rows 1 and 6;
opposite-facing staggered bent three-cell solos in rows 3/4. Each solo
takes one mouth at its body endpoint, leaving both safe pig parities.
Compare exact physical walls including common upper brace. Gate: at most
stock X, same four useful named rooms, lower sum of closed bodies and
mouth count, and two explicit genuinely open through room rows. Exact
flood checks all 16 subsets of complete room closures in each arm, with
all exterior/guard poses connected through the common physical connector,
and all individual named bodies isolated exactly when their own gates
close. No phantom open room, ghost exterior, or trap for a worker at a
stance. Report max longitudinal unweighted aisle distance from working
rows 1..8 to nearest open through-room row, excluding connector/unused row,
and explicit mouth/footprint counts. No throughput equivalence claim.

## Frozen analytical scaling condition (not another fixture search)
With k>=1 two-row solo packets alternating their vertical mirror,
neighboring packets can meet across one separator row with three brace
cells; the packet interior uses four X. If one intact paired row per
group remains and charges a full four-X separator on either side of
the solo run, the repeating strip period is 3k+2 rows, 2k+1 rooms,
7k+5 X, and only one real paired-body crossing per period. A separate
permanent cross-aisle connector is not included in that periodic count
and requires its physical row/space on a finite board. This is a local
scaling expression, not layout search or a verified 30×30 extraction.
No model, judge, solver, dry construction, pet dynamics or score.

After review and explicit clearance, one standard-library Python run:
    timeout -k 1s 10s python3 check.py > result.json
