#include <bits/stdc++.h>
#define main stock_unused_main
#include "stock.instrumented.inc"
#undef main
using namespace terry_exact_root;
using M=VirtualCatMemoStats;

struct Step { Mask wall; std::vector<int> crew; };
struct Offer { std::vector<int> crew,walls; };
struct Test {
 State start;
 uint64_t seed=0;
 std::array<Offer,25> offer;
 std::array<Step,25> step;
};
auto vec(std::istream& f) {
 int n;f>>n; assert(f&&n>=0&&n<=900);
 std::vector<int> a(n);
 for(auto& x:a){f>>x;assert(f&&x>=0&&x<900);}
 return a;
}
using Cases=std::pair<std::vector<Test>,std::vector<Test>>;
Cases real() {
 std::ifstream f("factual.txt"); assert(f);
 Cases r;
 int id,n=0;
 for(;f>>id;++n){
  assert(id==n);
  Test t;
  auto k=vec(f),p=vec(f);assert(k.size()==p.size());
  for(int i=0;i<int(k.size());++i){assert(k[i]>=1&&k[i]<=5);t.start.pets.push_back({p[i],k[i],-1});}
  t.start.people=vec(f);
  for(int x:vec(f))t.start.walls.set(x);
  for(auto& o:t.offer){o.crew=vec(f);o.walls=vec(f);}
  bool cat=std::find(k.begin(),k.end(),5)!=k.end();
  for(int j=1;j<=4;++j){t.seed=998244353ULL*j;(cat?r.first:r.second).push_back(t);}
 }
 assert(n==100&&f.eof());
 return r;
}
void save_vec(std::ostream& o,const std::vector<int>& a) {
 o<<' '<<a.size();for(int x:a)o<<' '<<x;
}
auto tiles(Mask b){
 std::vector<int> a;
 for(int x=0;x<V;++x)if(b[x])a.push_back(x);
 return a;
}
void freezeSynthetic(){
 std::mt19937 rng(0xbc719075u);
 auto r=[&](unsigned n){return rng()%n;};
 std::ofstream out("synthetic.txt");assert(out);
 for(int i=0;i<160;++i){
  Test t;auto& s=t.start;
  t.seed=998244353ULL*(i+101);
  for(int x=0;x<V;++x){
   int y=x/30,z=x%30;auto coin=r(100);
   bool wall=false;
   switch(i%6){
    case 1:wall=coin<8;break;
    case 2:wall=coin<50;break;
    case 3:wall=y%4==0&&z!=3;break;
    case 4:wall=y%5==0&&z%4!=2;break;
    case 5:wall=z==15||y==15||(z<=3&&y%2==0);break;
   }
   s.walls.set(x,wall);
  }
  auto open=tiles(~s.walls);
  int n=10+i%21,m=5+i%6;
  for(int j=0;j<m;++j)s.people.push_back(open[r(open.size())]);
  out<<t.seed<<' '<<n;
  for(int j=0;j<n;++j){
   int k=i%8==0?1+r(4):i%8==1?5:1+r(5);
   int x=open[r(open.size())],target=-1;
   if(k==5&&j%4!=0)target=j%4==1?x:open[r(open.size())];
   if(target<0)target=V;
   out<<' '<<x<<' '<<k<<' '<<target;
  }
  save_vec(out,s.people);save_vec(out,tiles(s.walls));
  for(int j=0;j<25;++j){
   save_vec(out,s.people);
   std::vector<int> w;
   if(j%3==0)for(int b=0;b<4;++b)w.push_back(open[r(open.size())]);
   save_vec(out,w);
  }
  out<<'\n';
 }
}
std::vector<Test> synth(){
 std::ifstream f("synthetic.txt");assert(f);
 std::vector<Test> a; Test t;
 for(;f>>t.seed;){
  t.start={};int n;f>>n;assert(n>=10&&n<=30);
  while(n--){
   Pet p;f>>p.pos>>p.type>>p.target;assert(f&&p.target>=0&&p.target<=V);
   if(p.target==V)p.target=-1;
   t.start.pets.push_back(p);
  }
  t.start.people=vec(f);
  for(int x:vec(f))t.start.walls.set(x);
  for(auto& o:t.offer){o.crew=vec(f);o.walls=vec(f);}
  a.push_back(t);
 }
 assert(a.size()==160&&f.eof());return a;
}
void equal(const State& x,const State& y,const ChaCha& a,const ChaCha& b) {
 assert(x.people==y.people&&x.walls==y.walls&&x.pets.size()==y.pets.size());
 for(std::size_t i=0;i<x.pets.size();++i){
  const auto& p=x.pets[i];const auto& q=y.pets[i];
  assert(p.pos==q.pos&&p.type==q.type&&p.target==q.target);
 }
 assert(a.key==b.key&&a.block==b.block&&a.count==b.count&&a.cursor==b.cursor);
}
void offer(State& s,const Offer& o) {
 assert(s.people.size()==o.crew.size());
 for(std::size_t i=0;i<s.people.size();++i){
  const auto a=nb[s.people[i]];int z=o.crew[i];
  if(!s.walls[z]&&std::find(a.begin(),a.end(),z)!=a.end())s.people[i]=z;
 }
 auto allowed=can_place(s);
 for(int z:o.walls)if(allowed[z])s.walls.set(z);
}
void prep(std::vector<Test>& v,const char* label) {
 M c;
 uint64_t physical=0;
 for(auto& t:v){
  State x=t.start,y=x;
  ChaCha a(t.seed),b(t.seed);
  VirtualCatMemo cache(y);
  for(int j=0;j<25;++j){
   Mask before=x.walls;
   offer(x,t.offer[j]);
   physical+=before!=x.walls;
   t.step[j]={x.walls,x.people};
   y.walls=x.walls;y.people=x.people;
   actual_motion(x,a);actual_motion_memo<true>(y,b,cache,&c);
   equal(x,y,a,b);
  }
 }
 std::cout<<"parity "<<label<<" scenarios="<<v.size()<<" physical_changes="<<physical
  <<" cat_turns="<<c.turns<<" epochs="<<c.epochs<<" resets="<<c.reset<<" singleton="<<c.singleton
  <<" goal_wall="<<c.wall<<" disconnected="<<c.disconnected<<" hit="<<c.hit<<" miss="<<c.miss
  <<" component_builds="<<c.components<<std::endl;
 if(c.turns)assert(c.reset&&c.hit&&physical);
}
State corridor(std::initializer_list<int> open, Pet p){
 State s;s.walls.set();for(int x:open)s.walls.reset(x);
 s.people={p.pos};s.pets={p};return s;
}
auto once(State x,uint64_t seed) {
 State y=x;ChaCha a(seed),b(seed);VirtualCatMemo c(y);M m;
 actual_motion(x,a);actual_motion_memo<true>(y,b,c,&m);equal(x,y,a,b);
 return std::pair{x.pets[0],m};
}
void boundary(){
 auto [p,a]=once(corridor({0},{0,5,1}),1);assert(p.pos==0&&p.target==-1&&a.wall==1&&a.singleton==1);
 auto [q,b]=once(corridor({0,2},{0,5,2}),1);assert(q.pos==0&&q.target==-1&&b.disconnected==1&&b.singleton==1);
 auto [u,c]=once(corridor({0,1},{0,5,1}),1);assert(u.pos==0&&u.target==-1&&c.reset==0);
 bool second=false;
 for(int seed=1;seed<=32;++seed){
  auto [v,d]=once(corridor({0,1,2},{0,5,2}),seed);
  if(v.pos==2){assert(v.target==-1&&d.reset==0);second=true;}
 }
 assert(second);
 // Real cache life across an open route losing its latent end goal.
 State x=corridor({0,1,2,3,4},{0,5,4}),y=x;ChaCha xg(29),yg(29);
 VirtualCatMemo cm(y);M stats;
 actual_motion(x,xg);actual_motion_memo<true>(y,yg,cm,&stats);equal(x,y,xg,yg);
 assert(x.pets[0].target==4&&x.pets[0].pos!=4);
 x.walls.set(4);y.walls.set(4);
 actual_motion(x,xg);actual_motion_memo<true>(y,yg,cm,&stats);equal(x,y,xg,yg);
 assert(stats.epochs==2&&stats.wall==1);
 std::cout<<"boundary exact ok"<<std::endl;
}
double cpu(){
 timespec t{};assert(clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t)==0);
 return t.tv_sec+t.tv_nsec*1e-9;
}
template<bool Memo> auto pass(const std::vector<Test>& a){
 uint64_t digest=0;
 double before=cpu();
 for(const auto& t:a){
  State s=t.start;ChaCha r(t.seed);
  auto moves=[&](auto motion){
   for(auto& st:t.step){s.walls=st.wall;s.people=st.crew;motion();}
  };
  if constexpr(Memo) {
   VirtualCatMemo c(s);
   moves([&]{actual_motion_memo(s,r,c);});
  }else moves([&]{actual_motion(s,r);});
  for(const auto& p:s.pets)digest=digest*133+p.pos+int64_t(p.target)*V;
  digest=digest*133+r.cursor+r.count;
 }
 return std::pair{cpu()-before,digest};
}
auto timed(const std::vector<Test>& a,const char* label){
 double old=0,next=0;
 assert(!a.empty());
 for(int i=0;i<8;++i){
  std::pair<double,uint64_t>x,y;
  if(i&1){y=pass<true>(a);x=pass<false>(a);}
  else{x=pass<false>(a);y=pass<true>(a);}
  assert(x.second==y.second);
  old+=x.first;next+=y.first;
  std::cout<<std::fixed<<std::setprecision(7)<<"pair "<<label<<' '<<i<<' '<<x.first<<' '<<y.first<<' '<<x.second<<'\n';
 }
 std::cout<<"total "<<label<<' '<<old<<' '<<next<<' '<<next/old<<std::endl;
 return std::pair{old,next};
}
int main(int argc,char** argv){
 if(argc==2&&std::string_view(argv[1])=="--freeze"){freezeSynthetic();return 0;}
 assert(argc==1);
 boundary();
 auto [cats,nocats]=real();auto random=synth();
 prep(cats,"real-cats");prep(nocats,"real-no-cat");prep(random,"synthetic");
 auto [x,y]=timed(cats,"real-cats");
 auto [u,v]=timed(nocats,"real-no-cat");
 auto [a,b]=timed(random,"synthetic");
 bool pass=y<=x*.80&&(y+v)<=(x+u)*.92&&v<=u*1.03&&b<=a*.92;
 std::cout<<"real combined "<<x+u<<' '<<y+v<<' '<<(y+v)/(x+u)<<"\ngate "<<(pass?"PASS":"REJECT")<<std::endl;
 return pass?0:1;
}
