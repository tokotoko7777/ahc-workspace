# Detached virtual cat cache experiment

This archive includes the independently written cache, experiment driver,
fixture materializer, frozen protocol, and measured result. It does not
include any solver, reference, model, fixture data or binary. The
accepted source and signed historical traces are required from the local
workspace named by the hash pins. Without those inputs the factual
result cannot be recreated solely from this archive.

From the workspace root, check the anchors, then in the experiment folder
run the materializer and compile the detached probe:

    sha256sum -c ahc008_terry_virtual_cat_memo/ANCHORS.sha256
    cd ahc008_terry_virtual_cat_memo
    python3 materialize.py
    g++ -std=c++23 -O3 probe.cpp -o probe
    ./probe --freeze
    sha256sum factual.txt synthetic.txt stock.instrumented.inc probe

The first three resulting fixture/source hashes must match FIXTURES.sha256.
Binary SHA is recorded for the actual measured build and may vary with
compiler/build environment. The one measured invocation was
`timeout 240 ./probe`; the exit status was 1 because the prespecified
minimum speedup was missed. Exact parity passed. No official runs were
part of the experiment.

Synthetic whole-motion CPU improved substantially on the predeclared
synthetic board families only, not end-to-end solver CPU. Factual-anchor
virtual trajectories improved much less and failed the real-board gates.
The stock default solver was not changed.
