# Detached exact virtual cat memo: frozen prep, not executed

No compilation, fixture generation, or timing before clearance. No solver
execution or official tester in this probe. Keep detached private sources
and all existing weights local.

The archived ordered-neighbor cache optimized PCG retention only,
explicitly not actual_motion. True ChaCha cat motion in f83 does a
target-origin BFS each valid goal turn. Reset adds current-origin BFS
and a 900-tile row-major scan before the new target BFS.

## Only candidate

One last-target cache row per cat ordinal with original Dist/int16 BFS
and INF. Allocate once per arm/rollout when cats exist, no allocation or
wall compare on no-cat states. Exact physical wall mask change clears
row keys and component index; never share across arms or rollouts.
Maintain stable pet order. Do not change dog/passives or scoring.

On first redraw in an epoch, enumerate connected components and index
their exact sorted row-major members in flat storage with offsets, lengths
and per-tile rank. Use the original choose_small bound equal to component
size minus one; add one to sampled index iff it reaches the current tile's
rank. On singleton, stock consumes no RNG and does not move. Existing
component labels may reject disconnected goals; otherwise check the cached
stock row as usual. Preserve directed_step, random_step, judge order, wall
and self target rejection, and both target on-arrival resets. Existing
stock int16 Dist fits board distances with same sentinel; no new encoding.

## Cohorts, verification and timing

- Real anchors: all 100 signed accepted incoming held boards from
  ahc008_terry_hunt_wall_audit recordings and existing input/action/trace.
  Check all hashes against manifests; use pre-command turn275 factual
  positions, types, walls and crew. Four counterfactual 25-turn trajectories
  per board, ChaCha seeds 998244353 times 1..4, all initial latent goals -1
  as live. Offer actual tape's wall additions each corresponding turn only
  when currently legal (not occupied and not adjacent to a current
  simulated pet); offer factual worker destination only when a legal
  adjacent move on present board, else stay. Factual anchor, virtual suffix.
- Synthetic: independent MT19937 seed 0xbc719075; 160 x 25 turns cycling
  open, sparse, dense, stripes, dead-end and split/isolated geometries,
  varied mixed and cats-only and no-cat initial counts, warm goals with
  open disconnected and current-cell cases, small deterministic legal
  additions. Explicit non-timed boundary fixtures for walling a latent
  goal, disconnecting it, singleton redraw and target arrival on each
  substep. Freeze materialized fixture hash before timing.
- Compare every step's all pet positions/types/latent targets, complete
  ChaCha key/block/refill counter/cursor, humans and walls. Count cat
  turns, redraws, singleton cases, previous goal wall/disconnection,
  target-row hits/misses, component builds and topology epochs in an
  untimed diagnostic pass only.
- Precompute identical physical wall/crew transitions from verified
  baseline during parity, then replay them as fixed exogenous inputs to
  both sides, excluding scripting and assertion cost from measured loops.
  Eight serial paired process-CPU passes alternating current-first and
  candidate-first. Include whole actual_motion (all species, cache
  lifecycle) and digest of final state/RNG. Real report aggregate and
  cat-containing/no-cat strata; synthetic report aggregate. No discards.

## Frozen minimum signal

All exact parity and explicit boundary cases pass; actual nonzero redraw
and row hits plus actual topology invalidations in at least one cohort.
Real cat-containing stratum CPU down >=20%, real aggregate >=8%, no-cat
slowdown <=3%; synthetic aggregate down >=8%. Otherwise no-go, no retune
or rerun based on timing. This is fixed-work component speed only, not
native policy/replay or score evidence; extra time could buy more
rollouts but can also change the decision adversely, as in Chase CSR.
