from pathlib import Path
from hashlib import sha256
import csv,json,sys
D=Path(__file__).resolve().parent
R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008'
A=R/'ahc008_terry_hunt_wall_audit'
I=R/'ahc008_terry_incoming_shadow/held100'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from guarded_entry_trace import observed
from benchmark import replay
def sh(b): return sha256(b).hexdigest()
r=json.loads((A/'recordings.json').read_text())
p={q['case']:q for q in csv.DictReader((I/'confirm.csv').open()) if q['arm']=='terry_independent'}
assert len(r)==len(p)==100 and set(p)=={q['case'] for q in r}
def emit(a): return ' '.join(map(str,[len(a),*a]))
def cells(a): return [30*x+y for x,y in a]
result=[]
for q in r:
    name=q['case']; start=(I/'in'/name).read_bytes()
    t=(A/'tapes'/Path(name).with_suffix('.trace')).read_bytes()
    a=(A/'tapes'/Path(name).with_suffix('.actions')).read_bytes()
    assert sh(start)==q['input_sha']==p[name]['input_sha']
    assert sh(a)==q['commands_sha']==p[name]['commands_sha']
    assert sh(t)==q['trace_sha']
    trace=t.decode().splitlines(); acts=a.decode().splitlines()
    assert replay(start.decode(),trace,acts,detailed=True)[0]==q['score']==int(p[name]['score'])
    kinds,history,_=observed(start,trace)
    pet,crew,wall=history[275]
    row=[str(int(Path(name).stem)),emit(kinds),emit(cells(pet)),emit(cells(crew)),emit(sorted(cells(wall)))]
    for turn in range(275,300):
        _,crew,w=history[turn+1]
        row.extend([emit(cells(crew)),emit(sorted(cells(w-history[turn][2])))])
    result.append(' '.join(row))
(D/'factual.txt').write_text('\n'.join(result)+'\n')
s=(R/'ahc008_terry_split_bound/solve.private.cpp').read_text()
needle='  if(p.pos==p.target)p.target=-1;\n }\n}\n}\n'
assert s.count(needle)==1
s=s.replace(needle,needle[:-2]+'#include "cat_cache.inc"\n}\n')
(D/'stock.instrumented.inc').write_text(s)
