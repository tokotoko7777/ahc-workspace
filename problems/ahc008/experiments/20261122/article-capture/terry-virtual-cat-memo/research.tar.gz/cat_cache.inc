// Detached experiment; include after accepted actual_motion declaration,
// within its namespace. Uses the existing 30x30 types and movement only.
struct VirtualCatMemo {
 struct Row { int key=-1; Dist dist; };
 std::vector<Row> rows;
 Mask epoch;
 bool known=false, indexReady=false;
 std::array<int16_t,V> label, rank, member;
 std::array<int16_t,V+1> offset;
 explicit VirtualCatMemo(const State& s) {
  int cats=0;
  for(const auto& p:s.pets) cats+=(p.type==5);
  rows.resize(cats);
 }
 void update(const Mask& walls) {
  if(known&&walls==epoch)return;
  known=true;epoch=walls;indexReady=false;
  for(auto& row:rows)row.key=-1;
 }
 void buildIndex(const Mask& walls) {
  if(indexReady)return;
  label.fill(-1);
  int groups=0;
  offset[0]=0;
  std::array<int,V> q;
  for(int p=0;p<V;++p)if(!walls[p]&&label[p]<0){
   int n=1;q[0]=p;label[p]=groups;
   for(int i=0;i<n;++i)for(int z:nb[q[i]])
    if(z>=0&&!walls[z]&&label[z]<0){label[z]=groups;q[n++]=z;}
   offset[groups+1]=offset[groups]+n;
   ++groups;
  }
  std::array<int16_t,V> position{};
  for(int p=0;p<V;++p)if(label[p]>=0){
   int group=label[p],j=position[group]++;
   rank[p]=j;member[offset[group]+j]=p;
  }
  indexReady=true;
 }
 const Dist& get(int i,int target,const Mask& walls){
  Row& r=rows[i];
  if(r.key!=target){bfs(walls,target,r.dist);r.key=target;}
  return r.dist;
 }
};
struct VirtualCatMemoStats {
 uint64_t turns=0, epochs=0, reset=0, singleton=0, wall=0,
          disconnected=0, hit=0, miss=0, components=0;
};
template<bool Track=false,class RNG>
void actual_motion_memo(State& s,RNG& rng,VirtualCatMemo& cache,
                        VirtualCatMemoStats* stats=nullptr) {
 if(cache.rows.empty()){
  actual_motion(s,rng);
  return;
 }
 if constexpr(Track)stats->epochs+=!cache.known||s.walls!=cache.epoch;
 cache.update(s.walls);
 HumanDistances ds{s,s.walls};
 int cat=0;
 for(auto& p:s.pets){
  if(p.type==4){model_dog(p,s,s.walls,ds,rng,true);continue;}
  if(p.type!=5){for(int k=0;k<p.type;++k)random_step(p,s.walls,rng,true);continue;}
  const int i=cat++;
  if constexpr(Track)++stats->turns;
  auto get=[&](int target)->const Dist& {
   if constexpr(Track){
    if(cache.rows[i].key==target)++stats->hit;
    else ++stats->miss;
   }
   return cache.get(i,target,s.walls);
  };
  const Dist* d=nullptr;
  if(p.target>=0&&!s.walls[p.target]&&p.target!=p.pos){
   bool separate=cache.indexReady&&cache.label[p.target]!=cache.label[p.pos];
   if(!separate)d=&get(p.target);
   if(separate||(*d)[p.pos]>=INF){
    if constexpr(Track)++stats->disconnected;
    p.target=-1;
   }
  }else{
   if constexpr(Track)stats->wall+=p.target>=0&&s.walls[p.target];
   p.target=-1;
  }
  if(p.target<0){
   if constexpr(Track){
    ++stats->reset;
    stats->components+=!cache.indexReady;
   }
   cache.buildIndex(s.walls);
   const int g=cache.label[p.pos];
   const int n=cache.offset[g+1]-cache.offset[g]-1;
   if(!n){
    if constexpr(Track)++stats->singleton;
    continue;
   }
   const int choice=choose_small(rng,n);
   p.target=cache.member[cache.offset[g]+choice+(choice>=cache.rank[p.pos])];
   d=&get(p.target);
  }
  directed_step(p,s.walls,*d,rng,true);
  if(p.pos==p.target)p.target=-1;
  random_step(p,s.walls,rng,true);
  if(p.pos==p.target)p.target=-1;
 }
}
