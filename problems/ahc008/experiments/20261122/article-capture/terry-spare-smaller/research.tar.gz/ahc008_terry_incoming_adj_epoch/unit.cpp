#define main archive_submission_main
#include "solve.private.cpp"
#undef main
#include <cstdio>
#include <random>

int main(){
 using namespace terry_exact_root;
 RetentionAdjacencyMemo memo;
 Mask w;
 std::mt19937 rng(5410187);
 int comparisons=0;
 auto check=[&](const Mask& q){
  const auto& actual=memo.get(q);
  RetentionNeighbors orig;orig.prepare(q);
  for(int i=0;i<V;++i){
   assert(actual.table[i].degree==orig.table[i].degree);
   for(int j=0;j<orig.table[i].degree;++j)
     assert(actual.table[i].cells[j]==orig.table[i].cells[j]);
  }
  ++comparisons;
 };
 for(int t=0;t<2500;++t){
  Mask prev=w;
  if(t%13==0)for(int p=0;p<V;++p)w[p]=rng()%3==0;
  else for(int z=0;z<t%9;++z)w.flip(rng()%V);
  check(w);check(w);check(prev);check(w);
  // Original and unchanged raw sampler output/RNG should be stable on
  // a cache hit, even after a read against a dissimilar predecessor.
  if(t%5==0){
   Pcg a(rng()),b=a;
   Pet p{int(rng()%V),1,-1},q=p;
   RetentionNeighbors fresh;fresh.prepare(w);
   const auto& reused=memo.get(w);
   for(int it=0;it<300;++it){fresh.random(p,a);reused.random(q,b);assert(p.pos==q.pos);}
   assert(a.s==b.s);
  }
 }
 std::printf("%d exact adjacency epochs and 500 untouched RNG traces\n",comparisons);
}
