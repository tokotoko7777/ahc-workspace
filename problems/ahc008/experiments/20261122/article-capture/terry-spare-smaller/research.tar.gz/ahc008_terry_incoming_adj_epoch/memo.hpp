// Retention and incoming handlers share identical projected-wall adjacency.
// Comparisons are exact, including rollback into any virtual game state.
struct RetentionAdjacencyMemo {
 Mask key;
 bool valid=false;
 RetentionNeighbors adjacency;
 const RetentionNeighbors& get(const Mask& w){
  if(!valid||w!=key){
   key=w;valid=true;adjacency.prepare(w);
  }
  return adjacency;
 }
};
