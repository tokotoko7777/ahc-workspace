# Reuse the single exactly ordered projected-wall adjacency epoch
Current accepted forecasts prepare identical neighbor tables in the
same turn for retention and entrant branches. Store one ordered
table keyed by the whole projected wall mask in Normal, share it
without mixing judge motion or probabilities. Explicit invalidation
through actual changes and virtual rollback; position/species, labels
and RNG are NOT cached. Pure exact checks across 10,000 transitions/
cache reads and 500 old/new sample streams. Same GNU C++23 build.

Fixed-work (existing accepted practice100 and prior independent incoming
held100, use actual recorded caps only diagnostically):
all official full commands and scores match exactly, and per-panel
total solver CPU ≥2% lower, local guard <2.95s. If first fails stop
without independent. Fixed-work results are not default-clock scores.
If both pass then independently at standard 2670ms on real practice
and fresh unfiltered100, preserve raw/useful and sum score, all tapes,
tester guards, no per-case cap in actual runtime. Only after all can
it be considered a faster reference, no scoring/rank claim from fixed.
