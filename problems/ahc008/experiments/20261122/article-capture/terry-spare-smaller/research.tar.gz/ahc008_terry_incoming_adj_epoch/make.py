"""Pinned adopted incoming, same adjacency shared across a projected wall epoch."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def put(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
a='using Retention=std::vector<std::array<int,30>>;'
put(a,(d/'memo.hpp').read_text()+'\n'+a)
a='const std::vector<int>& alive,Pcg& rng, std::vector<ShortTap>* tap=nullptr)'
put(a,'const std::vector<int>& alive,Pcg& rng, RetentionAdjacencyMemo& adjmemo, std::vector<ShortTap>* tap=nullptr)')
put(' RetentionNeighbors adjacency;bool ready=false;\n',' const RetentionNeighbors* preparedNeighborTable=nullptr;\n')
put('  if(!ready){adjacency.prepare(next);ready=true;}','  if(!preparedNeighborTable)preparedNeighborTable=&adjmemo.get(next);\n  const auto& adjacency=*preparedNeighborTable;')
a=' TopologyMemo topology;'
put(a,a+'\n RetentionAdjacencyMemo sharedAdjacency;')
put('geometry.count(),alive,rng,&tap);','geometry.count(),alive,rng,sharedAdjacency,&tap);')
put('      RetentionNeighbors adj;adj.prepare(builds);','      const auto& adj=sharedAdjacency.get(builds);')
(d/'solve.private.cpp').write_text(s)
