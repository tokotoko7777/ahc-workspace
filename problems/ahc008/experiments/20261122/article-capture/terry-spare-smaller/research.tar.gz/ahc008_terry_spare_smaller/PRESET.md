# Spare guards, smaller-room migration (detached)
Input: frozen accepted incoming held100, no practice or alternate scorer. Observe exact original normal prefix without modifying its decisions. Keep all selected jobs and construction guards. Proposal ranks exact passive h1–3 endpoint mass from one current labelled unserved pet (types 1–3, type 5 speed-2 surrogate; no type 4) to a different smaller currently unserved original room by mass / area / (ETA+1), deterministic first tie. Destination uses original gate/aisle geometry, guard stances and short gate-clearance veto. At most one proposal per start turn (no persistent commitment/live decisions); first preparation must actually change the stock command. No new wall before closure.

Validate exact frozen stock input/action/trace digests and all replayed Normal actions. Replay proposal only against recorded facts, and only until t+ETA<275. At every turn all actors used by a proposal must be objectively unassigned by stock (neither construction nor original chosen job); never modify others, both on prep and closure. Both factual and proposal commands must be legal. Keep exact same immediately isolated IDs and worker reachable-set supersets through preparation; at the closure keep every stock isolated ID and require the prospect itself newly isolated in the exact unchanged physical dormant room, whose label count is strictly lower than the source label count. Count distinct board/closure turn/pet/gate opportunities; no counterfactual score or animal path assertion (directional paths in particular may depend on human commands). Stop unless ≥20 actual causal prep changes across ≥10 boards and ≥5 distinct factual newly feasible catches across ≥3 boards and zero observed immediate loss of stock IDs during proposed paths. No threshold changes or live integration.

Replay from this directory after exclusive CPU authorization:

```sh
python make.py
g++ -std=gnu++23 observer.private.cpp -o observer
python materialize.py > materialize.log
python evaluate.py
```

Keep generated assembled private source and binaries out of archives. Observation uses `--pairs=0` only to drive factual Normal prefixes; terminal choices and commands are not modeled or benchmarked.
