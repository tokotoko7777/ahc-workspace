import collections,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import case_history,command_effect,step,snapshot,B,ALL,mask,cells,flood
TAPES=R/'ahc008_terry_hunt_wall_audit'
def assess(people,w,p):
    return snapshot(w,people,p)
def reports(rec,stats):
    k,hist,cmds=case_history(rec)
    p=(D/'logs'/rec['case']).with_suffix('.jobs')
    masks={}; proposals=[]; witnesses=set(); changes=set()
    for line in p.read_text().splitlines():
        if line.startswith('P '):
            t,i,h,l,r,a,b,size,*room=map(int,line.split()[1:])
            assert t in masks and 1<=h<=3 and k[i]!=4
            proposals.append((t,i,h,l,r,a,b,size,room))
        else:
            t,m=map(int,line.split()); assert t not in masks; masks[t]=m
    for t,i,h,l,r,a,b,size,room in proposals:
        if t+h>=275:continue
        gates={q:actor for q,actor in [(l,a),(r,b)] if q>=0}
        body=mask(room)&~mask(gates)
        if not body or len(room)>=size:continue
        assert not body&B[hist[t][0][i]]
        actors={actor:(g,step(g,'L' if g==l else 'R'))for g,actor in gates.items()}
        assert len(actors)==len(gates) and all(q is not None for _,q in actors.values())
        hum=hist[t][1].copy()
        viable=False
        for u in range(t,t+h+1):
            pts,h0,w=hist[u]
            if any(not (masks.get(u,0)>>actor&1) for actor in actors):
                stats['protected_conflict']+=1;break
            cmd=list(cmds[u])
            old=command_effect(h0,w,pts,cmd)
            assert old
            oldids,oldreach,_=assess(old[1],old[0],pts)
            for j,(g,q) in actors.items():
                assert not cmd[j].islower()
                if u<t+h:
                    cmd[j]='U' if hum[j]//30>q//30 else 'D' if hum[j]//30<q//30 else '.'
                else:
                    if hum[j]!=q:break
                    cmd[j]='r' if g==l else 'l'
            else:
                alt=command_effect(hum,w,pts,cmd)
                if not alt:stats['illegal']+=1;break
                aw,ah=alt
                if u<t+h and aw!=old[0]:raise AssertionError('changed stock wall')
                ai,ar,_=assess(ah,aw,pts)
                if oldids&~ai:stats['lost_id']+=1;break
                if u<t+h:
                    if ai!=oldids or any(x&~y for x,y in zip(oldreach,ar)):
                        stats['displaced_reach']+=1;break
                    if u==t:
                        viable=True
                        if ''.join(cmd)!=cmds[u]:changes.add(t)
                    hum=ah
                    continue
                if not viable:raise AssertionError('closure without preparation')
                actual_body=flood(B[next(cells(body))],ALL^aw)
                if actual_body!=body or aw&body or any(body&B[q] for q in ah):
                    stats['physical_room_changed']+=1;break
                if not body&B[pts[i]]:
                    stats['no_arrival']+=1;break
                if oldids&B[i] or not ai&B[i]:
                    stats['not_newly_isolated']+=1;break
                if t in changes:
                    witnesses.add((u,i,tuple(sorted(gates))))
                    stats['closure_new_isolates']+=(ai&~oldids).bit_count()
                break
            stats['missing_stance']+=1;break
    stats['proposals']+=len(proposals)
    return sorted(changes),sorted(witnesses)
recs=json.loads((TAPES/'recordings.json').read_text()); assert len(recs)==100
stats=collections.Counter(); results={}
for record in recs:
    changes,witnesses=reports(record,stats)
    if changes or witnesses:results[record['case']]=dict(changes=changes,witnesses=witnesses)
summary=dict(changes=sum(len(x['changes'])for x in results.values()),
    change_boards=sum(bool(x['changes'])for x in results.values()),
    closures=sum(len(x['witnesses'])for x in results.values()),
    closure_boards=sum(bool(x['witnesses'])for x in results.values()),stats=dict(stats))
summary['pass']=summary['changes']>=20 and summary['change_boards']>=10 and summary['closures']>=5 and summary['closure_boards']>=3 and not stats['lost_id']
(D/'report.json').write_text(json.dumps(dict(summary=summary,cases=results),indent=2)+'\n')
print(json.dumps(summary))
