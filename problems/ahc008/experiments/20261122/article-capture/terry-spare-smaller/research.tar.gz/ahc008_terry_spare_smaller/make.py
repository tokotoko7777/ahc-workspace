from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int spare_log_turn=-1;\ninline std::vector<std::string> spare_rows;\n'+s[i:]
a='    hunt::emit(s.people,jobs,legal,booked);'
put(a,a+'''
    if(spare_log_turn>=0){
     unsigned spare=0;
     for(int i=0;i<m;++i)if(!booked[i])spare|=1u<<i;
     std::string row=std::to_string(spare_log_turn)+" "+std::to_string(spare);
     spare_rows.push_back(row);
     if(spare){
      std::vector<bool> served(rooms.size());
      for(auto j:jobs)served[j.room]=true;
      Mask veto;
      for(int k=0;k<geometry.count();++k)for(int g:{rooms[k].left,rooms[k].right})if(g>=0){
       if(geometry.ids[g]==k)veto.set(g);
       for(int p:nb[g])if(p>=0&&geometry.ids[p]==k)veto.set(p);
      }
      auto label=[&](int p){int k=geometry.ids[p];return k>=0&&k<geometry.count()?k:-1;};
      RetentionNeighbors adj;adj.prepare(builds);
      struct Pick{uint64_t mass=0;int pet=-1,h=0,k=-1,a=-1,b=-1;} best;
      for(int i:alive){
       const auto p=s.pets[i];const int from=label(p.pos);
       if(p.type==4||from<0||served[from])continue;
       auto accepts=[&](int q,int k){
        return k!=from&&!served[k]&&rooms[k].area>0&&rooms[k].area<geometry.rooms[from].size&&!veto[q];
       };
       for(auto x:terry_incoming_room::terminal_histogram(adj.table,p.pos,p.type==5?2:p.type,label,accepts)){
        const auto& r=rooms[x.room];
        if(r.left<0&&r.right<0)continue;
        for(int a=0;a<m;++a)if(spare>>a&1u)
        for(int b=0;b<m;++b)if(spare>>b&1u){
         if((a==b)!=(r.left<0||r.right<0))continue;
         if(r.left>=0&&s.people[a]%30!=r.left%30-1)continue;
         if(r.right>=0&&s.people[b]%30!=r.right%30+1)continue;
         int h=(r.left>=0&&!(actual&~builds&~moves)[r.left])||(r.right>=0&&!(actual&~builds&~moves)[r.right]);
         if(r.left>=0)h=std::max(h,std::abs(s.people[a]/30-r.left/30));
         if(r.right>=0)h=std::max(h,std::abs(s.people[b]/30-r.right/30));
         if(h==0||h>3||!x.mass[h-1])continue;
         // Rank by exact mass/(destination area * (h+1)); keep first tie.
         if(best.pet<0||x.mass[h-1]*rooms[best.k].area*(best.h+1)>best.mass*r.area*(h+1))
          best={x.mass[h-1],i,h,x.room,a,b};
        }
       }
      }
      if(best.pet>=0){
       const auto r=rooms[best.k];
       std::string x="P "+std::to_string(spare_log_turn)+" "+std::to_string(best.pet)+" "+std::to_string(best.h)+" "+
           std::to_string(r.left)+" "+std::to_string(r.right)+" "+std::to_string(best.a)+" "+std::to_string(best.b)+" "+
           std::to_string(geometry.rooms[label(s.pets[best.pet].pos)].size);
       for(int p=0;p<V;++p)if(geometry.ids[p]==best.k)x+=" "+std::to_string(p);
       spare_rows.push_back(std::move(x));
      }
     }
    }
''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn<275&&std::getenv("AHC008_SPARE_SMALLER_LOG"))spare_log_turn=turn;
'''+a+'''
  spare_log_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* p=std::getenv("AHC008_SPARE_SMALLER_LOG")){
   std::ofstream f(p);
   for(const auto& row:spare_rows)f<<row<<'\\n';
 }
'''+a)
(d/'observer.private.cpp').write_text(s)
