"""Static planned-layout certificate; reads no cases, solvers or tapes."""
import re,itertools,json,collections
from pathlib import Path
from fractions import Fraction
D=Path(__file__).resolve().parent.parent
raw=(D/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
def nb(p):
    r,c=divmod(p,30)
    return [i*30+j for i,j in [(r-1,c),(r,c+1),(r+1,c),(r,c-1)]if 0<=i<30 and 0<=j<30]
def md(a,b):
    r,c=divmod(a,30);s,d=divmod(b,30)
    return abs(r-s)+abs(c-d)
def comp(start,open_):
    seen={start};todo=[start]
    for p in todo:
        for q in nb(p):
            if q in open_ and q not in seen:seen.add(q);todo.append(q)
    return seen
layouts=[]
for index,src in enumerate(re.split(r'// map \d\s*\n',raw)[:-1]):
    lanes=set(map(int,re.search(r'\{\s*\{([0-9,\s]+)\}',src)[1].split(',')))
    classes=[[int(z[:-1],16)for z in row.split(',')]
        for row in re.findall(r'\{((?:0x[0-9a-f]+u,){4}0x[0-9a-f]+u)\}',src)]
    occupied=set();doors=set()
    for row in range(30):
        pattern=classes[0 if row==0 else 1 if row%2==0 else 3 if row%4==3 else 4 if index==4 and row%8==5 else 2]
        for c in range(30):
            p=30*row+c
            if pattern[0]>>c&1:occupied.add(p)
            if c not in lanes and any(pat>>c&1 for pat in pattern[1:]):doors.add(p)
    sep=min(md(p,q)for p,q in itertools.combinations(sorted(doors),2))
    assert sep>=2
    surface=set(range(900))-occupied
    allowed=surface-doors
    adj={p:[q for q in nb(p) if q in surface]for p in surface}
    aisle={30*r+c for r in range(30) for c in lanes}
    todo=allowed.copy();rooms=[];unsupported=[]
    while todo:
        body=comp(min(todo),allowed);todo-=body
        if body&aisle:continue
        mouths={q for p in body for q in nb(p) if q in doors and q in surface}
        if not mouths:continue
        if len({p//30 for p in body})!=1 or len(mouths)>2:
            unsupported.append([sorted(body),sorted(mouths)]);continue
        safe=body-{p for p in body if set(nb(p))&mouths}
        rooms.append((body,mouths,safe))
    den=12**6
    ambiguous=total=pair_count=pair_with_mass=shared_mouths=max_alts=max_mass=0
    argmax=None;cache={}
    for A,B in itertools.permutations(rooms,2):
        early,g0,starts=A;late,g1,ends=B
        if g0&g1:shared_mouths+=1;continue
        pair_count+=1
        if not starts or not ends or min(md(p,q)for p in g0 for q in g1)>2:continue
        pair_positive=False
        for p in starts:
            if p not in cache:
                mass={p:den}
                for _ in range(6):
                    nxt=collections.defaultdict(int)
                    for q,num in mass.items():
                        if not adj[q]:nxt[q]+=num;continue
                        assert num%len(adj[q])==0
                        for z in adj[q]:nxt[z]+=num//len(adj[q])
                    mass=nxt
                assert sum(mass.values())==den
                cache[p]=mass
            score=sum(cache[p].get(q,0)for q in ends)
            if not score:continue
            pair_positive=True
            if score>max_mass:
                max_mass=score;argmax=[p,sorted(g0),sorted(g1),sorted(ends)]
            routes={}
            def walk(path,d):
                if len(path)==7:
                    if path[-1] in ends:
                        routes[path[1]]=routes.get(path[1],0)+1
                        assert den%d==0
                        masses.append(den//d)
                    return
                for n in adj[path[-1]]:
                    if n not in path:
                        walk(path+[n],d*len(adj[path[-1]]))
            masses=[];walk([p],1)
            assert sum(masses)==score
            total+=sum(routes.values())
            max_alts=max(max_alts,max(routes.values(),default=0))
            ambiguous+=any(n>1 for n in routes.values())
        pair_with_mass+=pair_positive
    layouts.append(dict(map=index,named_gates=len(doors),minimal_gate_manhattan=sep,
        horizontal_rooms=len(rooms),nonempty_safe_rooms=sum(bool(s)for _,_,s in rooms),
        unsupported=unsupported,distinct_gate_ordered_pairs=pair_count,shared_gate_ordered_pairs=shared_mouths,
        pair_positive_mass=pair_with_mass,shortest_cross_paths=total,multiple_routes_per_first_step=ambiguous,
        max_routes_per_first_step=max_alts,max_exact_conditional_mass=str(Fraction(max_mass,den)),argmax=argmax))
assert len(layouts)==5
print(json.dumps(layouts,indent=2))
