# Fixed 30×8 isolated strip with a real three-row crossing band

One static equality certificate only, not optimization or reuse of the
strict one-permanent-row scope. Physical height 30, width eight counting
aisles x0 and x7. Compare official stock Map2 terrain's c4..11 physical
subset, with pinned semantic masks (58 X: fourteen four-X separator
rows plus two X on r0). Stock row1 has two actual top notches, so do
not silently compare to 15 exact four-cell physical stock bodies.

Candidate ordinary paired rows: 0,2,4,6,21,23,25,27,29. Two-row opposite
three-cell solo packets at 8–9, 11–12 vertically mirrored, and 18–19.
Three consecutive permanent and fully physical crossing rows 14–16.
No missing exterior connection outside the strip. Meet exact 57 X,
15 nominal rooms (9 paired 1×4 plus 6 solos), 12 total crossings,
max 4 vertical steps from either aisle row to an actual open crossing.
Compare counts, not real animal throughput. Border stands in for a
brace only at coordinates outside 0–29. No other placements.

Independent check of stored stock terrain geometry versus explicit
candidate cut shell. Require two safe endpoint parities, direct guard
stances and exact named physical isolation, all-open/each room/each
pair/all-lock subsets, and no phantom/worker trap. All actual gate
contacts to named bodies are checked (a gate may touch only its own).
All-lock verifies exact named bodies and exterior. Any subset reopening
therefore adds gates incident only to the corresponding body and open
exterior, maintaining each other locked body: guarantees intermediate
subsets by component union. Mixed exterior remains connected through
the counted band. Stock final all-locked cross-aisle split is an
expected physical comparator, not hidden by virtual connector.
Report local chamber/traffic trade-offs only, no full-board socket
placement, construction, scorer, solver, or animal simulation.

After explicit review, run exactly once with no shape/placement tweaks:

    timeout -k 1s 10s python3 check.py > result.json
