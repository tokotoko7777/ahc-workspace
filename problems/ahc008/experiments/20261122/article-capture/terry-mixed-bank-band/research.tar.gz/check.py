"""Fixed pure static 30-row bank comparison. Never loads game or trace data."""
import itertools as it
from collections import deque
from pathlib import Path
from hashlib import sha256
import re,json

D=Path(__file__).resolve().parent
DIMS=(30,8)
ALL=set(it.product(range(30),range(8)))
AISLES={(r,c) for r,c in ALL if c in (0,7)}
D4=((-1,0),(1,0),(0,-1),(0,1))
P=(0,2,4,6,21,23,25,27,29)
BAND=(14,15,16)
SPEC=((8,False),(11,True),(18,False))

def adjacency(p):
    return {(p[0]+u,p[1]+v) for u,v in D4}&ALL
def components(floor):
    left=set(floor); cs=[]
    while left:
        r=min(left);left.remove(r);s={r};q=deque([r])
        while q:
            a=adjacency(q.popleft())&left
            left-=a;s|=a;q.extend(a)
        cs.append(s)
    return cs
def pair(r,top_notches=False):
    b={(r,c) for c in range(2,6)}
    if top_notches:b|={(0,3),(0,4)}
    return (b,{(r,1),(r,6)},{(r,0),(r,7)})
def elbow_pair(r,reflected):
    def n(points):
        return {(r+(1-y if reflected else y),x) for y,x in points}
    return [(n(((0,2),(0,3),(1,2))),n(((1,1),)),n(((1,0),))),
            (n(((0,5),(1,5),(1,4))),n(((0,6),)),n(((0,7),)))]
def exact_stock():
    file=D.parent/'ahc008_terry_exact_maps/terrain_data.inc'
    raw=file.read_bytes()
    assert sha256(raw).hexdigest()=='8d1f703d67b9d16fb0ba6d3b20cd2bb4a2cf20aea33e4a7351d45fd129e256cf'
    groups=re.split(r'// map \d\s*\n',raw.decode())
    fields=re.findall(r'\{((?:0x[0-9a-f]+u,){4}0x[0-9a-f]+u)\}',groups[2])
    assert len(fields)==5
    rows=[[int(s[:-1],16) for s in f.split(',')] for f in fields]
    def row(r): return rows[0 if r==0 else 1 if not r%2 else 3 if r%4==3 else 2]
    wall={(r,c) for r,c in ALL if row(r)[0]>>(c+4)&1}
    gotdoors={(r,c) for r,c in ALL if any(x>>(c+4)&1 for x in row(r)[1:])}
    rooms=[pair(r,r==1) for r in range(1,30,2)]
    assert gotdoors==set().union(*(g for b,g,s in rooms))
    assert wall==({(0,2),(0,5)}|{(r,c) for r in range(2,30,2) for c in range(2,6)})
    return rooms,wall
def fixed_mixed():
    rs=[pair(r) for r in P]
    for r,ref in SPEC:rs+=elbow_pair(r,ref)
    # Union the physical boundary requirements of fixed named bodies.
    walls=set()
    for b,g,s in rs:
        walls|=set().union(*(adjacency(p) for p in b))-b-g
    expected=({(r,c) for r in (1,3,5,7,20,22,24,26,28) for c in (2,3,4,5)}|
              {(10,c) for c in (2,4,5)}|
              {(r,c) for r in (13,17) for c in (2,3,5)}|
              {(8,1),(8,4),(9,3),(9,6),
               (11,3),(11,6),(12,1),(12,4),
               (18,1),(18,4),(19,3),(19,6)})
    assert walls==expected
    return rs,walls
def verification(rooms,walls,mixed):
    bodies=set()
    gates=set(); stances=set()
    for b,g,s in rooms:
        assert not (b|g)&(bodies|gates|stances|walls) and not s&(b|g|bodies|gates|walls)
        bodies|=b;gates|=g;stances|=s
    exterior=ALL-walls-bodies-gates
    assert AISLES<=exterior and stances<=exterior
    ordinary=[]
    for b,g,s in rooms:
        assert len(g)==len(s) and len(g) in (1,2)
        assert components(b)==[b]
        assert set().union(*(adjacency(p) for p in b))-b==g|((set().union(*(adjacency(p) for p in b))-b)&walls)
        assert {sum(p)%2 for p in b-set().union(*(adjacency(p) for p in g))}=={0,1}
        for r,c in g:
            assert c in (1,6)
            assert (r,0 if c==1 else 7) in s and (r,2 if c==1 else 5) in b
            assert len(adjacency((r,c))&b)==len(adjacency((r,c))&s)==1
            # A gate touches no other named body. This plus exact closed
            # body and exterior assertions proves arbitrary subset reopening.
            assert not adjacency((r,c))&(bodies-b)
        if len(g)==2:
            r=min(g)[0]
            assert {(r,c) for c in range(8)}==({(r,c) for c in range(8)}&(b|g|s))
            assert not mixed or len(b)==4
            ordinary.append(r)
        elif mixed:
            assert len(b)==3
    permanent=[r for r in range(30) if {(r,c) for c in range(8)}<=exterior]
    assert permanent==list(BAND if mixed else ())
    assert ordinary==list(P if mixed else range(1,30,2))
    closed_ext=components(exterior)
    assert len(closed_ext)==(1 if mixed else 2)
    assert all(x&AISLES for x in closed_ext)
    masks=[()]+[(j,) for j in range(len(rooms))]
    masks+=list(it.combinations(range(len(rooms)),2))
    masks.append(tuple(range(len(rooms))))
    for ids in masks:
        closed=set(ids)
        floor=ALL-walls-set().union(*(rooms[i][1] for i in closed))
        actual=components(floor)
        for i in closed:assert rooms[i][0] in actual
        free=[s for s in actual if s&AISLES]
        expect=1 if mixed or len(ids)<len(rooms) else 2
        assert len(free)==expect and len(actual)==expect+len(ids)
        for i,(b,g,s) in enumerate(rooms):
            assert s<=set().union(*free)
            if i not in closed:assert any(b|g<=a for a in free)
    reach=[min(abs(y-x) for x in ordinary+permanent) for y in range(30)]
    grid=[['.']*8 for _ in range(30)]
    for r,c in walls:grid[r][c]='X'
    for r,c in bodies:grid[r][c]='b'
    for r,c in gates:grid[r][c]='g'
    for r,c in stances:grid[r][c]='s'
    return dict(walls=len(walls),rooms=len(rooms),ordinary=ordinary,
        permanent=permanent,through_total=len(ordinary)+len(permanent),max_nearest=max(reach),
        exact_masks_sampled=len(masks),closed_exterior_components=len(closed_ext),
        mouth_count=len(gates),body_tiles=len(bodies),grid=[''.join(row) for row in grid])
def main():
    a=verification(*exact_stock(),False)
    b=verification(*fixed_mixed(),True)
    assert a['walls']==58 and a['rooms']==15 and a['through_total']==15
    assert b['walls']==57 and b['rooms']==15 and b['through_total']==12 and b['max_nearest']==4
    print(json.dumps(dict(stock=a,mixed=b),indent=2))
if __name__=='__main__':main()
