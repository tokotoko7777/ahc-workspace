"""Audits genuine captured-room one-cell shortenings, not a live policy."""
import csv,hashlib,itertools,json,re,sys
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'ahc008_terry_factual_late'),str(ROOT/'ahc008_terry_scaffold_audit')]
from audit import B,ALL,bitmask,area,observed,replay,wave,flood
# Avoid path-local screen.py name collision.
def near(p,d):
    r,c=divmod(p,30)
    dr,dc={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}[d]
    r+=dr;c+=dc
    return r*30+c if 0<=r<30 and 0<=c<30 else None
def flat(q):return q[0]*30+q[1]
def cells(mask):
    while mask:
        low=mask&-mask;mask^=low;yield low.bit_length()-1
def markers():
    raw=(ROOT/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
    out=[]
    for i,g in enumerate(re.split(r'// map \d\s*\n',raw)[:-1]):
        rows=[tuple(int(q,16) for q in re.findall(r'0x([0-9a-f]+)u',sub)) for sub in re.findall(r'\{[^{}]*0x[^{}]*\}',g)]
        assert len(rows)==5 and all(len(row)==5 for row in rows)
        walls=0; doors={}
        for r in range(30):
            c=0 if r==0 else 1 if not r%2 else 3 if r%4==3 else 4 if i==4 and r%8==5 else 2
            w,l1,r1,l2,r2=rows[c];walls|=w<<(30*r)
            for d,m in [('R',l1|l2),('L',r1|r2)]:
                doors.update({30*r+x:d for x in cells(m)})
        out.append((walls,doors))
    assert [len(x[1]) for x in out]==[60,90,120,135,96]
    return out

def calc(ow,orig_h,trialw,trial_h,room,pet,idset,removed, added):
    # This is strictly a shortening of this component, no topological redesign:
    # all originally exterior parts stay exterior from corresponding people;
    # its surviving room is exactly its prior cells minus the new gate walls.
    aq=room&~added
    if not aq or aq!=flood(aq&-aq,ALL^trialw):return None
    if tuple(i for i,p in enumerate(pet) if B[p]&aq)!=idset:return None
    if any(B[p]&(trialw|aq) for p in trial_h):return None
    score=0
    for x,y in zip(orig_h,trial_h,strict=True):
        orig=flood(B[x],ALL^ow); after=flood(B[y],ALL^trialw)
        if orig&~after or after&~(orig|removed):return None
        if any(B[p]&after and not B[p]&orig for p in pet):return None
        score+=after.bit_count()-orig.bit_count()
    return score/len(orig_h)

def audit(row,obj,base,raw,tape):
    walls, doors=obj; c=Counter(); classes=defaultdict(Counter); entries=[]
    a=(tape/base).with_suffix('.actions').read_bytes()
    trace=(tape/base).with_suffix('.trace').read_text().splitlines()
    assert hashlib.sha256(a).hexdigest()==row['commands_sha']
    assert hashlib.sha256(raw).hexdigest()==row['input_sha']
    assert replay(raw.decode(),trace,a.decode().splitlines(),detailed=True)[0]==int(row['score'])
    _,hist,_=observed(raw,trace)
    chase=bool(int(row['telemetry'].split()[13]))
    commands=a.decode().splitlines()
    for t,cmd in enumerate(commands):
        if chase and t>=275:break
        pets,h,ow=hist[t]; pnext,hn,wactual=hist[t+1]
        h=list(map(flat,h));hn=list(map(flat,hn));p=list(map(flat,pets));po=list(map(flat,pnext))
        g=[]
        for i,d in enumerate(cmd):
            if d in 'urdl':
                q=near(h[i],d.upper())
                if q in doors and doors[q]==d.upper():g.append((i,q,near(q,d.upper())))
        if not g:continue
        pre=bitmask(map(flat,ow));post=bitmask(map(flat,wactual));assert pre&post==pre
        oldopen=ALL^pre;newopen=ALL^post
        hpre=flood(bitmask(h),oldopen);hpost=flood(bitmask(hn),newopen)
        caught=[i for i,v in enumerate(p) if B[v]&hpre and not B[v]&hpost]
        while caught:
            room=flood(B[p[caught[0]]],newopen)
            ids=tuple(i for i,v in enumerate(p) if B[v]&room)
            caught=[i for i in caught if i not in ids]
            # All geometric shifted closures must replace actual gate commands
            # attached to this actual component. Earlier walls not touched.
            opts=[(i,q,v) for i,q,v in g if v is not None and B[v]&room]
            if not opts:continue
            size=room.bit_count();cl='small<=4' if size<=4 else 'large>=5';s=classes[cl]
            c['capture_rooms']+=1;s['capture_rooms']+=1
            c['captured_ids']+=len(ids);s['captured_ids']+=len(ids)
            # Independent absolute ceiling across measured factual events: each
            # released old gate can add at most one cell per person.
            c['all_factual_mouth_ceiling']+=len(opts);s['all_factual_mouth_ceiling']+=len(opts)
            best=bestwait=0;found=[];pa=bitmask(p);pb=bitmask(po)
            for k in (1,2):
                for combo in itertools.combinations(opts,k):
                    removed=bitmask(q for i,q,v in combo); added=bitmask(v for i,q,v in combo)
                    if removed.bit_count()!=k or added.bit_count()!=k:continue
                    # Actors can walk from the aisle onto their own old gate,
                    # then build the new wall; original other commands are kept.
                    alt=hn.copy()
                    if any(B[q]&bitmask(hn) for i,q,v in combo):continue
                    for i,q,v in combo:alt[i]=q
                    # Simultaneous adjacent-pet prohibition at new walls,
                    # including all other animals and post-original actor poses.
                    if added&(pa|wave(pa)|bitmask(alt)|post):continue
                    trial=(post^removed)|added
                    gain=calc(post,hn,trial,alt,room,p,ids,removed,added)
                    if gain is None:continue
                    c['valid_options']+=1;s['valid_options']+=1;best=max(best,gain)
                    # Stronger factual endpoint compatibility only: keep the
                    # old gates synthetically OPEN at t+1, since those wall
                    # builds were replaced by one-step moves. Keep all other
                    # actual t walls and all non-shifted actor endpoints,
                    # do not apply factual t+1 commands (different decision).
                    delayed=None
                    if t<299 and not (added&(pb|wave(pb))):
                        delayed=calc(post,hn,trial,alt,room,po,ids,removed,added)
                    if delayed is not None:
                        c['valid_synthetic_next_options']+=1;s['valid_synthetic_next_options']+=1;bestwait=max(bestwait,delayed)
                    found.append(dict(mouths=k,gain=gain,synthetic_next=delayed,cells=[q for i,q,v in combo]))
            if best:
                c['rooms_positive']+=1;s['rooms_positive']+=1;c['instant_sum']+=best;s['instant_sum']+=best
            if bestwait:
                c['rooms_synthetic_next_positive']+=1;s['rooms_synthetic_next_positive']+=1;c['synthetic_next_sum']+=bestwait;s['synthetic_next_sum']+=bestwait
            if found:entries.append(dict(turn=t,size=size,pet_ids=ids,options=found))
    return dict(case=row['case'],map=int(row['telemetry'].split()[0]),counts=dict(c),size_counts={k:dict(v) for k,v in classes.items()},entries=entries)
def main():
    paths=markers(); logs=[]
    for row in csv.DictReader((ROOT/'ahc008_terry_exact_root/practice100.csv').open()):
        if row['arm']!='terry_independent':continue
        f=row['case']; raw=(ROOT/'ahc008_focus_assets/tools/in'/f).read_bytes()
        logs.append(audit(row,paths[int(row['telemetry'].split()[0])],f,raw,ROOT/'ahc008_terry_scaffold_audit/tapes'))
    assert len(logs)==100
    totals=Counter(); maps=defaultdict(Counter); sizes=defaultdict(Counter)
    for x in logs:
        totals.update(x['counts']);maps[x['map']].update(x['counts'])
        for k,v in x['size_counts'].items():sizes[k].update(v)
    print(json.dumps(dict(totals=totals,maps=maps,sizes=sizes,
        instant_case_count=sum(x['counts'].get('instant_sum',0)>0 for x in logs),
        synthetic_next_case_count=sum(x['counts'].get('synthetic_next_sum',0)>0 for x in logs),cases=logs),indent=2))
if __name__=='__main__':main()
