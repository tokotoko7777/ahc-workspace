// Insert at top of the existing per-column loop. Leave empty and
// multi-worker graph construction untouched for the isolated ablation.
if(const int i=sole[col];i>=0){
 int best=31,jbest=-1;
 for(int j=n-1;j>=0;--j){
  const int d=dist[i][s.pets[j].pos];
  if(d<best){best=d;jbest=j;}
 }
 if(jbest>=0)to[i]=s.pets[jbest].pos/30;
 continue;
}
