from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
ss=[(R/f).read_text() for f in ['ahc008_terry_virtual_chase_absorb/candidate.private.cpp','ahc008_terry_split_bound/solve.private.cpp']]
sig='inline void idle_phase(const State& s,const std::vector<int>& columns,std::vector<char>& action){'
def phase(s):return sig+s.split(sig,1)[1].split('\n}\n}',1)[0]+'\n}'
s=ss[0]; a=phase(s)
assert a==phase(ss[1])
def after(text,unique,value):
    assert text.count(unique)==1
    return text.replace(unique,unique+value)
a=a.replace(sig,'template<bool Track=false> '+sig.replace('action){','action,std::vector<int>* ids=nullptr){'))
a=after(a,' std::vector<int> to(m,-1);','\n if constexpr(Track)ids->assign(m,-1);')
a=a.replace('for(Link l:pairs)if(flow.get_edge(l.e).flow)to[l.i]=s.pets[l.j].pos/30;',
'''for(Link l:pairs)if(flow.get_edge(l.e).flow){
   to[l.i]=s.pets[l.j].pos/30;
   if constexpr(Track)(*ids)[l.i]=l.j;
  }''')
loop=' for(int i=0;i<m;++i)if(!action[i])bfs(w,s.people[i],dist[i]);'
assert a.count(loop)==1
b=a.replace('idle_phase(','idle_single(').replace(loop,(D/'single.inc').read_text())
branch=(D/'branch.inc').read_text().replace(' if(jbest>=0)to[i]=s.pets[jbest].pos/30;',''' if(jbest>=0){
  to[i]=s.pets[jbest].pos/30;
  if constexpr(Track)(*ids)[i]=jbest;
 }''')
b=after(b,' for(int col:columns){','\n'+branch)
declaration='''inline void (*observation)(const State&, const std::vector<int>&, const std::vector<char>&)=nullptr;'''
s=s.replace(phase(s),a+'\n'+b+'\n'+declaration)
name='   idle_phase(s,terrain->aisleColumns,action);'
assert s.count(name)==1
s=s.replace(name,'   if(observation)observation(s,terrain->aisleColumns,action);\n'+name)
(D/'stock.instrumented.inc').write_text(s)
