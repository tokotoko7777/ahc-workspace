# Detached one-worker per-aisle idle assignment

Prep only. No compilation, execution, official run, or production
integration without separate approval. The body of idle_phase matches
between selected a237f798 and f83fd834. Prior idle_cap2 was an assignment
coverage change; idle_entry audited movement opportunities. This is
neither. Only single-worker columns change representation; zero and
multi-worker columns keep the exact original network. Same BFS, planned
wall projection, assigned waits, proposals, distance limit, center-hold
fallback, movement and sanitizer. Both independent snippets are written
locally and contain no weights/reference. Use stock/candidate callables
in a detached probe.

Why exact: With only one unassigned aisle worker, the initially
available positive-capacity paths are source to worker to pet to sink.
Source-only inactive workers cannot supply pet paths. Among shortest
distance d<=30, largest pet vertex settles first; then the zero-cost
sink (larger than every pet) outranks its ties immediately, preserving
the first predecessor. One unit consumes the only reachable source-worker
arc that could reach any pet, so stock has nothing further to augment
or reroute. Thus scan pet IDs descending with strict improvement in d.
Distance 0 is included and duplicate coordinates still distinct pet IDs.
When no edge qualifies both leave the target unset. Ascending-order
scanning with <= is not required; our exact branch uses descending/<.

## Frozen cohorts and tests

- Historical factual accepted incoming held100 signed in
  ahc008_terry_hunt_wall_audit/recordings.json, same t0..274 from
  existing action/trace and original inputs. Use recorded layout, not
  present unlocked map selection. Check each input/action/trace SHA
  and entire accepted action prefix before using ANY row from that
  board. Replay exact Normal locally using the signed turn observations
  and annotate at real phase entry with pre-idle action vector including
  NUL vs reserved '.', wall proposals and claimed moves; no inferred
  assignments. Do not invoke official tester or solve using observed
  future moves until after each real stock action is computed and
  checked. If neither a237 nor f83 Normal with recorded map reproduces
  all required prefixes, stop rather than subselect favorable boards.
  Include every actual idle invocation in verified t0..274 on all100.
- Independent 5000 synthetics from MT19937 seed 0xd5c47a31: alternate
  dense/sparse walls, open planes, isolated pocket masks, several
  parallel aisles, duplicated pet positions and crew placements, mixed
  all-zero, reserved '.'/move/build action vectors; fixed legal physical
  state, proposed builds may close paths; reserve before scanning.
  Additional explicit assertions for equal distances across up/down
  pet rows and ID swap; d=0, d=30, d=31, no pets/no reachable edge,
  booked wait and move, coincident pets, singleton at multiple aisles,
  zero-workers and multi-worker fallback. Include ties whose chosen
  row changes the action, and verify selected target IDs during parity
  to catch same-row ties.
- Freeze candidate, source pins, synthetic/factual records before
  measuring. Require every whole idle action vector and sanitized
  command equal; untouched earlier assigned commands stay unchanged.
  Count phase invocations, original zero/single/multiple column
  frequencies, distinct boards/triggers, singleton with and without
  legal edge, and equal-best-distance ties. Real nonzero singleton
  triggers and explicit edge classes are required.
- Report serial paired process CPU, eight full batches alternating
  order, whole idle phase only (wall projection, BFS, assignment, and
  output mutations incl copying identical pre-action inputs); exclude
  replay/materialization and validation instrumentation; compare digest.
  Real includes all invocations, not a trigger-only subset. Synthetic
  reports all 5000. Exact parity and >=5% whole-phase CPU reduction on
  each cohort required. No tune/rerun if failed. No claim about full
  solver CPU or native score from this detached component result.
