// Replacement for the stock spare-worker BFS loop, immediately before
// the stock per-column loop. Caller already established valid 30x30 cells.
std::array<int,30> sole;
sole.fill(-1);
for(int i=0;i<m;++i)if(!action[i]){
 bfs(w,s.people[i],dist[i]);
 int& worker=sole[s.people[i]%30];
 worker=worker==-1?i:-2;
}
