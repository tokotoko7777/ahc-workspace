from pathlib import Path
from hashlib import sha256
import csv,json
D=Path(__file__).resolve().parent;R=D.parent
A=R/'ahc008_terry_hunt_wall_audit'; I=R/'ahc008_terry_incoming_shadow/held100'
def sh(b):return sha256(b).hexdigest()
rows=json.loads((A/'recordings.json').read_text())
ledger={r['case']:r for r in csv.DictReader((I/'confirm.csv').open())if r['arm']=='terry_independent'}
assert len(rows)==len(ledger)==100
with (D/'signed_prefix.txt').open('w') as out:
 for i,r in enumerate(rows):
    name=r['case']; q=ledger[name]
    assert name==f'{i:04d}.txt'
    init=(I/'in'/name).read_bytes()
    a=(A/'tapes'/Path(name).with_suffix('.actions')).read_bytes()
    t=(A/'tapes'/Path(name).with_suffix('.trace')).read_bytes()
    assert sh(init)==r['input_sha']==q['input_sha']
    assert sh(a)==r['commands_sha']==q['commands_sha'] and sh(t)==r['trace_sha']
    assert r['map']==int(q['telemetry'].split()[0])
    lines=t.decode().splitlines()
    assert lines[::2]==a.decode().splitlines() and len(lines)==600
    inp=init.decode().splitlines(); n=int(inp[0]); m=int(inp[n+1])
    out.write(f'{i} {r["map"]}\n'+'\n'.join(inp[:n+2+m]+lines[:550])+'\n')
