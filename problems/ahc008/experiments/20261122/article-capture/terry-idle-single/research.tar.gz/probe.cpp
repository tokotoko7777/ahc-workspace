#include <bits/stdc++.h>
#define main stock_unused_main
#include "stock.instrumented.inc"
#undef main
using namespace terry_exact_root;
using namespace terry_exact_motion;
struct Test{int board=-1,turn=-1;State s;std::vector<int> cols;std::vector<char> actions;};
std::vector<Test> factual;
int board=-1,turn=-1;
void record(const State& s,const std::vector<int>& cols,const std::vector<char>& a){
 factual.push_back({board,turn,s,cols,a});
}
void replay(){
 std::ifstream in("signed_prefix.txt");assert(in);
 observation=record;
 for(int i=0;i<100;++i){
  int map,n,m;in>>board>>map>>n;assert(in&&board==i);
  State s;
  for(int j=0;j<n;++j){int r,c,k;in>>r>>c>>k;s.pets.push_back({(r-1)*30+c-1,k,-1});}
  in>>m;
  for(int j=0;j<m;++j){int r,c;in>>r>>c;s.people.push_back((r-1)*30+c-1);}
  Normal normal(terrain_lib::terrain(map),s);
  for(turn=0;turn<275;++turn){
   std::string accepted;in>>accepted;assert(in);
   auto proposed=normal.step(s,turn);
   if(proposed!=accepted){
    std::cerr<<"PREFIX MISMATCH board="<<board<<" turn="<<turn<<" stock="<<proposed<<" signed="<<accepted<<std::endl;
    std::abort();
   }
   people_step(s,proposed);
   for(auto& p:s.pets){
    std::string t;in>>t;assert(in);
    for(char a:t){int d=move_dir(a);if(d>=0&&nb[p.pos][d]>=0)p.pos=nb[p.pos][d];}
   }
  }
 }
 observation=nullptr;
 assert(!factual.empty());
}
std::vector<Test> random_tests(){
 std::mt19937 gen(0xd5c47a31u);
 auto choose=[&](unsigned a){return gen()%a;};
 std::vector<Test> out;
 for(int i=0;i<5000;++i){
  Test f;std::array<bool,30> used{};
  const int aisles=1+i%7;
  for(int j=0;j<aisles;++j){int c;do{c=choose(30);}while(used[c]);used[c]=true;f.cols.push_back(c);}
  for(int j=0;j<V;++j){
   int c=j%30,r=j/30,k=i%5;
   f.s.walls[j]=k==0?false:k==1?choose(100)<7:k==2?choose(100)<45:k==3?(c%4==0&&r%5!=0):(r%3==1&&c%5!=1);
  }
  std::vector<int> floor,aisleFloor;
  for(int j=0;j<V;++j)if(!f.s.walls[j]){floor.push_back(j);if(used[j%30])aisleFloor.push_back(j);}
  assert(!aisleFloor.empty());
  int m=5+i%6,n=i%31;
  for(int j=0;j<m;++j){
   int p=i%7==0&&j>0?f.s.people[0]:aisleFloor[choose(aisleFloor.size())];
   f.s.people.push_back(p);
   f.actions.push_back(i%8==0?0:std::array<char,6>{0,0,0,'.','U','r'}[choose(6)]);
  }
  for(int j=0;j<n;++j){
   int p=i%4==0&&j>0?f.s.pets[0].pos:floor[choose(floor.size())];
   f.s.pets.push_back({p,1,-1});
  }
  Mask legal=can_place(f.s);
  for(int j=0;j<m;++j)if(f.actions[j]=='r'&&(nb[f.s.people[j]][1]<0||!legal[nb[f.s.people[j]][1]]))f.actions[j]='.';
  out.push_back(std::move(f));
 }
 return out;
}
void write(std::ostream& out,const std::vector<Test>& in){
 out<<in.size()<<'\n';
 for(const auto& f:in){
  out<<f.board<<' '<<f.turn<<' '<<f.s.walls<<' '<<f.s.people.size()<<' '<<f.s.pets.size()<<' '<<f.cols.size();
  for(int i:f.s.people)out<<' '<<i;
  for(auto p:f.s.pets)out<<' '<<p.pos;
  for(int c:f.cols)out<<' '<<c;
  for(char c:f.actions)out<<' '<<int(c);
  out<<'\n';
 }
}
auto load(const char* path){
 std::ifstream in(path);std::size_t n;in>>n;assert(in&&n<=27500&&n>0);
 std::vector<Test> out(n);
 for(auto& f:out){
  int m,k,c;
  in>>f.board>>f.turn>>f.s.walls>>m>>k>>c;assert(in&&m>=1&&m<=10&&k>=0&&k<=30&&c>=1&&c<=30);
  f.s.people.resize(m);f.actions.resize(m);f.cols.resize(c);
  for(int& p:f.s.people)in>>p;
  for(int j=0;j<k;++j){int p;in>>p;f.s.pets.push_back({p,1,-1});}
  for(int& x:f.cols)in>>x;
  for(char& x:f.actions){int t;in>>t;x=char(t);}
  assert(in);
 }
 return out;
}
struct Stats {
 uint64_t zero=0,single=0,multi=0,edge=0,tie=0,empty=0;
 std::set<int> boards;
 void add(const Test& f,const std::vector<int>& ids){
  Mask w=f.s.walls;
  for(int i=0;i<int(f.actions.size());++i){int d=build_dir(f.actions[i]);if(d>=0){int p=nb[f.s.people[i]][d];if(p>=0)w[p]=1;}}
  for(int c:f.cols){
   int count=0,worker=-1;
   for(int i=0;i<int(f.actions.size());++i)if(!f.actions[i]&&f.s.people[i]%30==c){++count;worker=i;}
   if(count==0){++zero;continue;}
   if(count>=2){++multi;continue;}
   ++single;boards.insert(f.board);
   if(ids[worker]<0){++empty;continue;}
   ++edge;
   Dist d;bfs(w,f.s.people[worker],d);
   int best=d[f.s.pets[ids[worker]].pos],nt=0;
   for(const auto& p:f.s.pets)nt+=d[p.pos]==best;
   tie+=nt>1;
  }
 }
};
auto parity(const Test& f,Stats* stats=nullptr){
 auto x=f.actions,y=x;std::vector<int>a,b;
 idle_phase<true>(f.s,f.cols,x,&a);idle_single<true>(f.s,f.cols,y,&b);
 assert(x==y&&a==b&&sanitize(f.s,x)==sanitize(f.s,y));
 for(int i=0;i<int(f.actions.size());++i)if(f.actions[i])assert(x[i]==f.actions[i]);
 if(stats)stats->add(f,a);
 return std::pair{x,a};
}
void verify(const std::vector<Test>& a,const char* label){
 Stats s;for(auto& f:a)parity(f,&s);
 assert(s.single);
 std::cout<<"parity "<<label<<" calls="<<a.size()<<" no-worker="<<s.zero<<" single="<<s.single
  <<" multi="<<s.multi<<" single_edge="<<s.edge<<" single_noedge="<<s.empty
  <<" single_best_tie="<<s.tie<<" distinct_trigger_boards="<<s.boards.size()<<std::endl;
}
void boundary(){
 Test f;f.s.people={15*30+8};f.actions={0};f.cols={8,9};
 auto pets=[&](std::initializer_list<int>a){f.s.pets.clear();for(int p:a)f.s.pets.push_back({p,1,-1});};
 const int h=f.s.people[0];
 pets({h-30,h+30});auto [a,b]=parity(f);assert(a[0]=='D'&&b[0]==1);
 pets({h+30,h-30});std::tie(a,b)=parity(f);assert(a[0]=='U'&&b[0]==1);
 pets({h,h});std::tie(a,b)=parity(f);assert(!a[0]&&b[0]==1);
 pets({0,1});std::tie(a,b)=parity(f);assert(b[0]==1);
 pets({0});std::tie(a,b)=parity(f);assert(b[0]==0);
 f.s.people={0};f.cols={0};pets({59});std::tie(a,b)=parity(f);assert(b[0]==0);
 pets({89});std::tie(a,b)=parity(f);assert(b[0]<0);
 pets({});std::tie(a,b)=parity(f);assert(b[0]<0);
 f.s.people={0,30,1};f.cols={0,1};f.actions={'.','U',0};pets({2,3});
 std::tie(a,b)=parity(f);assert(a[0]=='.'&&a[1]=='U'&&b[0]<0&&b[1]<0&&b[2]==0);
 f.actions={0,0,0};parity(f);
 f.s.walls.set();f.s.walls.reset(0);f.s.walls.reset(30);f.s.walls.reset(1);f.s.walls.reset(3);
 f.actions={'.','U',0};pets({3});std::tie(a,b)=parity(f);assert(b[2]<0);
 std::cout<<"boundary exact ok"<<std::endl;
}
double cpu(){timespec t{};assert(clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t)==0);return t.tv_sec+t.tv_nsec*1e-9;}
template<bool New> auto pass(const std::vector<Test>& a){
 uint64_t h=0;auto t=cpu();
 for(auto& f:a){
  auto x=f.actions;
  if constexpr(New)idle_single(f.s,f.cols,x);else idle_phase(f.s,f.cols,x);
  for(unsigned char c:x)h=h*131+c;
 }
 return std::pair{cpu()-t,h};
}
double measure(const std::vector<Test>& a,const char* label){
 double old=0,next=0;
 for(int j=0;j<8;++j){
  std::pair<double,uint64_t>x,y;
  if(j%2){y=pass<true>(a);x=pass<false>(a);}
  else{x=pass<false>(a);y=pass<true>(a);}
  assert(x.second==y.second);old+=x.first;next+=y.first;
  std::cout<<std::fixed<<std::setprecision(7)<<"pair "<<label<<' '<<j<<' '<<x.first<<' '<<y.first<<' '<<x.second<<'\n';
 }
 std::cout<<"total "<<label<<' '<<old<<' '<<next<<' '<<next/old<<std::endl;
 return next/old;
}
int main(int argc,char** argv){
 if(argc==2&&std::string_view(argv[1])=="--freeze"){
  replay();
  std::ofstream x("factual.txt"),y("synthetic.txt");assert(x&&y);
  write(x,factual);write(y,random_tests());
  std::cout<<"Exact signed prefixes: 27,500/27,500. Idle snapshots "<<factual.size()<<std::endl;
  return 0;
 }
 assert(argc==1);
 boundary();
 auto real=load("factual.txt"),random=load("synthetic.txt");
 assert(random.size()==5000);
 verify(real,"real");verify(random,"synthetic");
 double a=measure(real,"real"),b=measure(random,"synthetic");
 bool pass=a<=.95&&b<=.95;
 std::cout<<"gate "<<(pass?"PASS":"REJECT")<<std::endl;
 return pass?0:1;
}
