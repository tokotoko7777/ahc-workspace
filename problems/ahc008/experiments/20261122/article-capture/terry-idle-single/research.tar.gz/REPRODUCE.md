# Detached reproduction

Requires the existing anchor source and signed input/action/trace
artifacts, which are not included. Run from the workspace root:
    sha256sum -c ahc008_terry_idle_single/PREP.sha256
    cd ahc008_terry_idle_single
    sha256sum -c PROBE.sha256
    python3 make.py
    python3 factual.py
    g++ -std=c++23 -O3 probe.cpp -o probe
    timeout 240 ./probe --freeze
    sha256sum -c FIXTURES.sha256
    timeout 240 ./probe
The measured build's binary digest is recorded but may vary by compiler.
Never distribute the generated private source, binary, signed tape or
materialized fixture payloads. Only hashes of those files are attached.
