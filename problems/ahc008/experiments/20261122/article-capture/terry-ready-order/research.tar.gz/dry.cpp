#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <ctime>
#include <map>
#include <set>
using namespace exact_build;
static constexpr int Cap=150;
struct Room{int id;std::vector<int> body,gates,stands,need;};
std::vector<Room> rooms[5];
void read(const char* path){
 std::ifstream f(path);std::string line;
 while(std::getline(f,line)){
  std::istringstream s(line);int m,r,a,b,p;s>>m>>r>>a>>b;
  Room z;z.id=r;
  if(a>=0){z.gates.push_back(a);z.stands.push_back(a-1);}
  if(b>=0){z.gates.push_back(b);z.stands.push_back(b+1);}
  std::array<bool,V> in{};
  while(s>>p)z.body.push_back(p),in[p]=true;
  if(z.body.empty())continue;
  std::set<int> need;
  for(int x:z.body)for(int q:nb(x))
    if(q>=0&&!in[q]&&std::find(z.gates.begin(),z.gates.end(),q)==z.gates.end())need.insert(q);
  z.need.assign(need.begin(),need.end());rooms[m].push_back(std::move(z));
 }
}
uint64_t step(uint64_t& s){
 uint64_t z=(s+=0x9e3779b97f4a7c15ULL);
 z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;
 z=(z^(z>>27))*0x94d049bb133111ebULL;
 return z^(z>>31);
}
std::vector<int> spawn(int map,int m){
 uint64_t seed=0x13af85b291246c09ULL^(map*37+m);
 std::vector<int> out;while((int)out.size()<m){
  int p=step(seed)%V;
  if(std::find(out.begin(),out.end(),p)==out.end())out.push_back(p);
 }
 return out;
}
using WallTimes=std::array<int,V>;
Board required(const Crew& c){
 Board b{};
 for(auto& q:c.q)for(auto a:q){
  auto adj=nb(a.at);for(int d=0;d<4;++d)if(a.mask>>d&1)b[adj[d]]=1;
 }
 return b;
}
struct Nominal{int end=0,total=0;};
Nominal nominal(const Crew& c,const std::vector<int>& h,const std::vector<Room>& rooms){
 WallTimes seen;seen.fill(Cap+1);
 int end=0;
 for(int i=0;i<(int)h.size();++i){
  int p=h[i],t=0;
  for(auto a:c.q[i])if(a.mask){
   t+=md(p,a.at);p=a.at;auto adj=nb(p);
   for(int d=0;d<4;++d)if(a.mask>>d&1){++t;seen[adj[d]]=std::min(seen[adj[d]],t);}
  }
  end=std::max(end,t);
 }
 int sum=0;
 for(auto& room:rooms){
  int t=0;for(int x:room.need)t=std::max(t,seen[x]);sum+=t;
 }
 return {end,sum};
}
struct Trial{
 int last=-1;bool conflict=false,stranded=false;
 WallTimes owner{};
 std::vector<int> ready;
 Trial(){owner.fill(-1);}
};
Trial real(Crew c,std::vector<int> h,const std::vector<Room>& rooms,const Board& req){
 Trial r;r.ready.assign(rooms.size(),Cap+1);
 Board w{};
 int left=0;for(auto x:req)left+=x;
 for(int t=1;t<=Cap;++t){
  auto a=c.act_literal(w,h,{}).action;
  Board moving{},busy{};auto next=h;
  for(int i=0;i<(int)h.size();++i)if(a[i]>='A'&&a[i]<='Z'){
   int d=std::find(Move,Move+4,a[i])-Move;int p=nb(h[i])[d];
   if(p<0||w[p]){r.conflict=true;return r;}
   next[i]=p;moving[p]=1;
  }
  for(int p:h)busy[p]=1;
  bool any=false;
  for(int i=0;i<(int)h.size();++i)if(a[i]>='a'&&a[i]<='z'){
   int d=std::find(Put,Put+4,a[i])-Put;int p=nb(h[i])[d];
   if(p<0||w[p]||moving[p]||busy[p]){r.conflict=true;continue;}
   if(!req[p]){r.conflict=true;return r;}
   w[p]=1;r.owner[p]=i;--left;any=true;
  }
  h=std::move(next);
  BFS b;b.run(h[0],w);
  for(int p:h)if(b.d[p]>=INF)r.stranded=true;
  if(any)for(int i=0;i<(int)c.q.size();++i)for(auto a0:c.q[i])if(a0.mask){
   bool need=false;auto adj=nb(a0.at);
   for(int d=0;d<4;++d)if((a0.mask>>d&1)&&!w[adj[d]])need=true;
   if(need&&(w[a0.at]||b.d[a0.at]>=INF))r.stranded=true;
  }
  Board who{};for(int p:h)who[p]=1;
  for(int k=0;k<(int)rooms.size();++k)if(r.ready[k]>Cap){
   auto& z=rooms[k];
   if(std::any_of(z.body.begin(),z.body.end(),[&](int p){return w[p]||who[p];}))continue;
   if(std::any_of(z.gates.begin(),z.gates.end(),[&](int p){return w[p]||who[p];}))continue;
   if(std::any_of(z.stands.begin(),z.stands.end(),[&](int p){return p<0||p>=V||b.d[p]>=INF;}))continue;
   if(std::any_of(z.need.begin(),z.need.end(),[&](int p){return !w[p];}))continue;
   // The catalog body is connected; every orthogonal boundary not in
   // its gate mask is now an actual wall, exactly certifying shape.
   r.ready[k]=t;
  }
  if(!left&&r.last<0)r.last=t;
  if(r.last>=0&&std::all_of(r.ready.begin(),r.ready.end(),[](int u){return u<=Cap;}))return r;
 }
 return r;
}
struct Swap{int i,a,b,c,gain,end;};
void apply(Crew& c,const Swap& s){
 auto& q=c.q[s.i];std::rotate(q.begin()+s.a,q.begin()+s.b,q.begin()+s.c);
}
int main(int argc,char** argv){
 if(argc!=2)return 2;
 read(argv[1]);int boards=0,baseBad=0,finalists=0,wins=0,improvements=0;
 const auto tick=clock();
 std::cout<<"type,map,workers,actor,left,middle,right,proxy_gain,orig_t,cand_t,improved4,delta_ready,reason,cpu_sec\n";
 for(int map=0;map<5;++map)for(int m=5;m<=10;++m){
  Layout l;const auto& a=terry_exact_maps::terrain(map);
  l.aisleRows=a.aisleRows;l.aisleCols=a.aisleColumns;
  for(int p=0;p<V;++p)l.ascii[p]=char(a.cells[p]);
  auto h=spawn(map,m);Crew orig;if(!orig.init(l,h))return 3;
  auto req=required(orig);
  auto base=real(orig,h,rooms[map],req);
  const auto n=nominal(orig,h,rooms[map]);
  if(base.last<0){++baseBad;std::cout<<"board,"<<map<<','<<m<<",,,,,,-1,-1,0,0,base_unfinished,0\n";continue;}
  std::vector<Swap> options;
  for(int i=0;i<m;++i){
   int L=orig.q[i].size();
   for(int a=0;a<L;++a)for(int l1=1;l1<=3&&a+l1<L;++l1)
    for(int l2=1;l2<=3&&a+l1+l2<=L;++l2){
     Swap s{i,a,a+l1,a+l1+l2,0,0};
     auto c=orig;apply(c,s);auto v=nominal(c,h,rooms[map]);
     if(v.end<=n.end&&v.total<n.total){s.gain=n.total-v.total;s.end=v.end;options.push_back(s);}
    }
  }
  std::sort(options.begin(),options.end(),[](auto a,auto b){
   return std::tuple{-a.gain,a.end,a.i,a.a,a.b,a.c}<std::tuple{-b.gain,b.end,b.i,b.a,b.b,b.c};
  });
  bool good=false,improve=false;
  for(int k=0;k<std::min(8,int(options.size()));++k){
   const auto& s=options[k];auto c=orig;apply(c,s);++finalists;
   const auto t0=clock();auto now=real(c,h,rooms[map],req);
   std::string why="ok";
   int faster=0, v=0;
   if(now.conflict)why="illegal";
   else if(now.stranded)why="stranded";
   else if(now.last<0||now.last>base.last)why="makespan";
   else if(now.owner!=base.owner)why="owner";
   else {
    for(int j=0;j<(int)base.ready.size();++j)if(base.ready[j]<=Cap){
     if(now.ready[j]>Cap)why="lost_room";
     faster+=now.ready[j]+4<=base.ready[j];
     v+=base.ready[j]-now.ready[j];
    }
    for(int goal:{(base.last+2)/3,(base.last*2+2)/3,base.last}){
     auto f=[&](const auto& arr){return std::count_if(arr.begin(),arr.end(),[&](int x){return x<=goal;});};
     if(f(now.ready)<f(base.ready))why="checkpoint";
    }
    if(why=="ok"&&v<=0)why="no_gain";
   }
   improve|=why=="ok";good|=why=="ok"&&faster>=2;
   std::cout<<"trial,"<<map<<','<<m<<','<<s.i<<','<<s.a<<','<<s.b<<','<<s.c<<','<<s.gain<<','
      <<base.last<<','<<now.last<<','<<faster<<','<<v<<','<<why<<','<<double(clock()-t0)/CLOCKS_PER_SEC<<'\n';
  }
  ++boards;wins+=good;improvements+=improve;
  std::cout<<"board,"<<map<<','<<m<<",,,,,,"<<base.last<<",0,0,0,"<<(good?"win":improve?"small":"none")<<",0\n";
 }
 std::cerr<<"boards "<<boards<<" base_bad "<<baseBad<<" finalists "<<finalists
   <<" improvements "<<improvements<<" wins "<<wins<<" cpu "<<double(clock()-tick)/CLOCKS_PER_SEC
   <<" go "<<(boards==30&&wins>=8)<<'\n';
}
