# No-pet original crew order dry gate (frozen before execution)

Panel: all 5 independent canonical maps crossed with M=5–10 (30 boards).
Distinct synthetic start cells come from fixed local SplitMix64 streams keyed by
(map,M); no official inputs, contest seeds, pets, forecasts or capture policy.
Use literal exact Crew::act_literal and final move-first wall validator.
Simulation cap 150 turns for original and candidates. All nominal assigned
X must be observed installed; every exact original writer must stay the
same, no newly disconnected crew or unfinished reachable queue stance, and
actual last required X no later. Physical room masks and both mouth stances
are from the frozen configured catalog. A usable room is physically trappable,
unentered, and carries reachable exterior stances. Track first usable state
time (after observed current wall placement), not a claim of real capture.

Candidates: deterministic adjacent swaps of neighboring same-owner stance
blocks with lengths 1–3 each, all jobs/stance tuples unchanged. Generate all such
swaps; proxy scans nominal Manhattan + build-bit times for every owner and
ranks decrease in sum of each configured room's last required wall, subject
to no proxy makespan regression. Up to 8 finalists per board, one swap each.
Exact result requires all originally usable rooms to appear, usable-count
by original dry makespan thirds no worse, and lower sum of first usable
times. A winning board further requires at least two rooms each ≥4 turns
earlier. GO needs at least 8 winning boards among all 30. No relaxations,
adaptation or live patch in this dry preflight.

Keep machine-readable every finalist, its actual quality or rejection,
full board summary, and CPU-time trace. Retain negative observations.
