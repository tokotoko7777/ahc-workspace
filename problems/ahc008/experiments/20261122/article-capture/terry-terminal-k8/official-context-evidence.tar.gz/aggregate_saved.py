"""Read-only repair of final summary indexing; no solver or timing run."""
from pathlib import Path
import json,csv
P=Path(__file__).resolve().parent/'dev'
out=json.loads((P/'native-context.json').read_text()); r=json.loads((P/'report.json').read_text())
p={x['case']:x for x in r['cases']}
forced={}
for x in csv.DictReader((P/'official.csv').open()):forced.setdefault(x['case'],{})[int(x['arm']=='terry_independent')]=x
assert len(out)==len(forced)==len(p)==100
assert len({x['case'] for x in out})==100 and all(set(x)=={0,1} for x in forced.values())
def calc(fn):
    rows=[arms[int(fn(k))] for k,arms in forced.items()]
    return dict(score=sum(int(x['score'])for x in rows),full=sum(int(x['full'])for x in rows),useful=sum(int(x['useful300'])for x in rows),chase=sum(fn(k)for k in forced))
result=dict(n=100,native=dict(score=sum(x['score']for x in out),full=sum(x['full']for x in out),useful=sum(x['useful']for x in out),
        chase=sum(x['mode']for x in out),maxwall=max(x['wall']for x in out),pairs=sum(x['pairs']for x in out)),
    all_normal=calc(lambda k:False),all_chase=calc(lambda k:True),k8_mean_oracle_mix=calc(lambda k:p[k]['mean']),
    k8_confidence_oracle_mix=calc(lambda k:p[k]['confident']),
    mode_diff_vs_k8_mean=sum(x['mode']!=p[x['case']]['mean']for x in out),
    mode_diff_vs_k8_confidence=sum(x['mode']!=p[x['case']]['confident']for x in out),
    mismatching_own_mode=[x['case']for x in out if x['mode'] not in x['matched_modes']],
    mismatching_both=[x['case']for x in out if not x['matched_modes']])
assert result==json.loads((P/'native-context-summary.json').read_text())
print(json.dumps(result,indent=2))
