# Unmodified native default contextual arm only
No new policy, thresholds, or seed selection. All 100 same frozen t275-live conditional inputs. Exact official tester/playback + independent replay/score and signed 275-action prefix. Record current native output signed hash, mode, raw and useful full, score, wall and work. Outside historical leaderboard inference. Compare only against arithmetic K8 mixtures previously fixed; those mixtures are not selected policy in this run. Preserve/report any mismatch with own forced hash or both forced hashes rather than dropping cases or changing mode.

    sha256sum -c NATIVE_FROZEN.sha256
    sha256sum -c SHA256SUMS
    python native_context.py > native-context.log
