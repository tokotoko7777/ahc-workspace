"""Context-only exact current native default on the frozen t275-eligible panel."""
import collections,csv,hashlib,json,re,sys,tempfile
from pathlib import Path
from scout import D,R,X,run,sha,short_prefix
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood
tools=R/'ahc008_focus_assets/tools/target/release'
solver=R/'ahc008_terry_split_bound/solve'
manifest=(X/'manifest.json').read_bytes()
assert sha(manifest)=='5c2877a6733e3bb454096d3f2da17f830899a1bfd047c485b2707a3c6480399d'
selected=json.loads(manifest)['selected']; assert len(selected)==100
forced=collections.defaultdict(dict)
for v in csv.DictReader((X/'official.csv').open()):
    forced[v['case']][int(v['arm']=='terry_independent')]=v
probe={v['case']:v for v in json.loads((X/'report.json').read_text())['cases']}
out=[]
for r in selected:
    name=r['case'];raw=(X/'selected'/name).read_bytes(); assert sha(raw)==r['sha256']
    f=forced[name]; assert all(f[i]['input_sha']==r['sha256'] and f[i]['prefix_sha']==r['prefix_sha'] for i in (0,1))
    with tempfile.TemporaryDirectory() as q:
        q=Path(q); tel=q/'native';act=q/'actions';tape=q/'tape'
        a,e,c,wall=run([str(tools/'tester'),'env','AHC008_TERRY_EXACT_LOG='+str(tel),str(solver)],raw,5.0)
        m=re.fullmatch(rb'Score = (\d+)\s*',e); assert c==0 and m,(name,c,e)
        acts=a.splitlines(); assert len(acts)==300 and short_prefix(b'\n'.join(acts[:275])+b'\n')==r['prefix_sha']
        mode_fields=list(map(int,tel.read_text().split()));assert len(mode_fields)==15
        mode=mode_fields[13];assert mode in (0,1)
        act.write_bytes(a)
        ao,eo,co,_=run([str(tools/'tester'),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(act),str(tape)],raw,12)
        assert (ao,eo,co)==(a,e,c)
        trace=tape.read_text().splitlines()
        independent=replay(raw.decode(),trace,a.decode().splitlines(),detailed=True)[0]
        assert independent==int(m[1])==mode_fields[14]
        _,hist,_=observed(raw,trace); ps,hs,ws=hist[300]
        op=ALL^sum(B[idx(q)]for q in ws); reach=flood(sum({B[idx(q)]for q in hs}),op)
        full=all(not (reach&B[idx(q)])for q in ps)
        sum_area=sum(flood(B[idx(q)],op).bit_count()for q in hs)
        useful=full and sum_area>=300*len(hs)
        both=[i for i in (0,1) if f[i]['commands_sha']==sha(a)]
        if mode in both:
            assert independent==int(f[mode]['score']) and full==bool(int(f[mode]['full'])) and useful==bool(int(f[mode]['useful300']))
        out.append(dict(case=name,sha=r['sha256'],prefix=r['prefix_sha'],command_sha=sha(a),matched_modes=both,mode=mode,
            score=independent,full=int(full),useful=int(useful),wall=wall,pairs=mode_fields[10],area=sum_area/len(hs)))
        (X/'native-context.json').write_text(json.dumps(out,indent=2)+'\n')
        print(name,mode,independent,'match',both,flush=True)
def aggregate(label):
    rs=[f[case][int(label(case))]for case,f in forced.items()]
    return dict(score=sum(int(r['score'])for r in rs),full=sum(int(r['full'])for r in rs),
        useful=sum(int(r['useful300'])for r in rs),chase=sum(bool(label(case))for case in forced))
assert len(out)==len(selected)==len(forced)==len(probe)==100
result=dict(n=100,native=dict(score=sum(r['score']for r in out),full=sum(r['full']for r in out),useful=sum(r['useful']for r in out),
        chase=sum(r['mode']for r in out),maxwall=max(r['wall']for r in out),pairs=sum(r['pairs']for r in out)),
    all_normal=aggregate(lambda k:False),all_chase=aggregate(lambda k:True),k8_mean_oracle_mix=aggregate(lambda k:probe[k]['mean']),
    k8_confidence_oracle_mix=aggregate(lambda k:probe[k]['confident']),
    mode_diff_vs_k8_mean=sum(r['mode']!=probe[r['case']]['mean']for r in out),
    mode_diff_vs_k8_confidence=sum(r['mode']!=probe[r['case']]['confident']for r in out),
    mismatching_own_mode=[r['case']for r in out if r['mode'] not in r['matched_modes']],
    mismatching_both=[r['case']for r in out if not r['matched_modes']])
(X/'native-context-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
