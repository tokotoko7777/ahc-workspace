import argparse,csv,hashlib,json,re,sys,tempfile
from pathlib import Path
p=argparse.ArgumentParser()
for k in ('harness','tester','baseline','candidate','inputs','output'):p.add_argument(k,type=Path)
p.add_argument('--n',type=int,default=30)
p.add_argument('--baseline-arg',action='append',default=[])
p.add_argument('--candidate-arg',action='append',default=[])
a=p.parse_args()
sys.path[:0]=[str(a.harness.resolve()),str(a.harness.resolve()/'experiments/20261122')]
from benchmark_cases import run
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood
p2=a.harness.resolve()/'benchmark_cases.py'
paths=sorted(a.inputs.glob('*.txt'))[:a.n]
assert len(paths)==a.n
res=[]
for f in paths:
 raw=f.read_bytes()
 for arm,cmd,extra in [('v25',a.baseline,a.baseline_arg),('terry_independent',a.candidate,a.candidate_arg)]:
  with tempfile.TemporaryDirectory() as d:
   d=Path(d); acts=d/'actions'; tape=d/'tape'; log=d/'terry';
   out,err,rc,wall=run([str(a.tester.resolve()),'env','AHC008_TERRY_EXACT_LOG='+str(log),str(cmd.resolve()),*extra],raw,4.5)
   m=re.fullmatch(rb'Score = (\d+)\s*',err)
   assert rc==0 and m,(f,arm,rc,err)
   acts.write_bytes(out)
   rr,re_,rx,_=run([str(a.tester.resolve()),sys.executable,str(p2),'--playback',str(acts),str(tape)],raw,12.0)
   assert (rr,re_,rx)==(out,err,rc)
   t=tape.read_text().splitlines(); action=out.decode().splitlines()
   score=replay(raw.decode(),t,action,detailed=True)[0]
   assert score==int(m[1])
   kinds,history,_=observed(raw,t)
   caught={};areas=[];residue={}
   for i,(ps,hs,ws) in enumerate(history):
    op=ALL^sum(B[idx(p)]for p in ws)
    group=flood(sum({B[idx(p)]for p in hs}),op)
    for j,x in enumerate(ps):
     if j not in caught and not group&B[idx(x)]:
      caught[j]=(i,j,kinds[j],flood(B[idx(x)],op).bit_count())
    if i in (75,100,160,225,275,300):
     residue[i]=len(ps)-len(caught)
    if i==300:areas=[flood(B[idx(p)],op).bit_count() for p in hs]
   last=residue[300]; farea=sum(areas)/len(areas)
   original_style=log.read_text().strip() if log.exists() else ''
   if original_style:assert int(original_style.split()[-1])==score,(f,arm,original_style,score)
   r=dict(case=f.name,arm=arm,input_sha=hashlib.sha256(raw).hexdigest(),commands_sha=hashlib.sha256(out).hexdigest(),
      prefix_sha=hashlib.sha256(("::".join(action[:275])).encode()).hexdigest(),
      score=score,wall=wall,humans=len(areas),full=int(last==0),useful300=int(last==0 and farea>=300),
      mean_human_area=farea,final_residual=last,
      exact4_100=sum(e[0]<=100 and e[3]==4 for e in caught.values()),
      exact4_160=sum(e[0]<=160 and e[3]==4 for e in caught.values()),
      exact4_final=sum(e[3]==4 for e in caught.values()),
      residue=json.dumps(residue,separators=(',',':')),captures=';'.join(':'.join(map(str,e)) for e in sorted(caught.values())),
      telemetry=original_style)
   res.append(r)
 with a.output.open('w') as dest:
  wr=csv.DictWriter(dest,r.keys());wr.writeheader();wr.writerows(res)
 print(f.name,flush=True)
for arm in ('v25','terry_independent'):
 x=[z for z in res if z['arm']==arm]
 print(arm, {k:sum(z[k] for z in x) for k in ('score','full','useful300','final_residual','exact4_100','exact4_160','exact4_final')},
    'max',max(z['wall'] for z in x))
