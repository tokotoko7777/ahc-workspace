"""Shadow exact 8 paired trajectories plus independent ordinary-clock feasibility."""
import json,tempfile,sys,re
from pathlib import Path
from scout import X,R,prefix,sha,short_prefix,run
TESTER=R/'ahc008_focus_assets/tools/target/release/tester'
STOCK=R/'ahc008_terry_split_bound/solve'
rec=json.loads((X/'manifest.json').read_text());assert rec['eligible_complete']
result=[]
with tempfile.TemporaryDirectory() as q:
    q=Path(q)
    for row in rec['selected']:
        raw=(X/'selected'/row['case']).read_bytes();assert sha(raw)==row['sha256']
        h,n,pairs,t=prefix('shadow',raw,q)
        assert n==row['target_count'] and h==row['prefix_sha'] and len(pairs)==8
        assert all(len(a)==2 and all(0<=x<=100000000 for x in a)for a in pairs)
        tel=q/'native.log'
        out,err,code,w=run([str(TESTER),'env','AHC008_TERRY_EXACT_LOG='+str(tel),str(STOCK),'--pairs=8'],raw,5.0)
        assert code==0 and re.fullmatch(rb'Score = \d+\s*',err)
        assert len(out.splitlines())==300
        prefix_native=short_prefix(b'\n'.join(out.splitlines()[:275])+b'\n');assert prefix_native==h
        fields=list(map(int,tel.read_text().split())); assert len(fields)==15 and 0<=fields[10]<=8
        ng=fields[10]
        assert [sum(z[j]for z in pairs[:ng])for j in (0,1)]==fields[11:13]
        result.append(dict(case=row['case'],pairs=pairs,native_pairs=ng,native_time=w,shadow_time=t))
        (X/'shadow.json').write_text(json.dumps(result,indent=2)+'\n')
assert len(result)==100
