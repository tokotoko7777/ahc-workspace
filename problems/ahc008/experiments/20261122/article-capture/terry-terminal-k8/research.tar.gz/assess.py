import collections,csv,json
from pathlib import Path
D=Path(__file__).resolve().parent;X=D/'dev'
r=json.loads((X/'manifest.json').read_text())['selected']
s={x['case']:x for x in json.loads((X/'shadow.json').read_text())}
lab=collections.defaultdict(dict)
for x in csv.DictReader((X/'official.csv').open()):
    assert x['arm'] not in lab[x['case']]
    lab[x['case']][x['arm']]=x
out=[]
for a in r:
    case=a['case'];p=s[case];v=lab[case]
    n,c=v['v25'],v['terry_independent']
    assert a['sha256']==n['input_sha']==c['input_sha'] and a['prefix_sha']==n['prefix_sha']==c['prefix_sha']
    nt,ct=(list(map(int,k['telemetry'].split()))for k in (n,c))
    assert len(nt)==len(ct)==15 and nt[0]==ct[0] and nt[10]==ct[10]==0 and nt[13]==0 and ct[13]==1
    diffs=[y-x for x,y in p['pairs']]; total=sum(diffs); pos=sum(d>0 for d in diffs)
    rawloss=int(c['full'])<int(n['full'])
    useful_loss=int(c['useful300'])<int(n['useful300'])
    delta=int(c['score'])-int(n['score'])
    out.append(dict(case=case,mean=total>0,confident=total>0 and pos>=7,raw_loss=rawloss,useful_loss=useful_loss,
        delta=delta,native_pairs=p['native_pairs'],model_sum=total,strict_model_wins=pos))
assert len(out)==len(r)==len(s)==len(lab)==100
M=[x for x in out if x['mean']]
rej=[x for x in M if not x['confident']]
harm=[x for x in M if x['raw_loss'] or x['useful_loss']]
nonharm_gain=[x for x in M if not x['raw_loss'] and not x['useful_loss'] and x['delta']>0]
avoided=sum(not x['confident']for x in harm);keep=sum(x['confident']for x in nonharm_gain)
native=sum(x['native_pairs']==8 for x in out)
stats=dict(selected=100,mean_chase=len(M),confidence_rejections=len(rej),
    actual_harm=len(harm),harm_vetoed=avoided,actual_safe_positive=len(nonharm_gain),safe_positive_retained=keep,
    native_8_completed=native,normal_raw_useful_totals=[sum(int(lab[x['case']]['v25'][k])for x in out)for k in ('full','useful300')],
    chase_raw_useful_totals=[sum(int(lab[x['case']]['terry_independent'][k])for x in out)for k in ('full','useful300')])
for group,xs in (('mean',M),('confidence',[x for x in out if x['confident']]),('rejected',rej)):
    stats[group+'_observed_losses']={k:sum(x[k]for x in xs)for k in ('raw_loss','useful_loss')}
    stats[group+'_observed_losses']['score_loss_cases']=sum(x['delta']<0 for x in xs)
    stats[group+'_observed_losses']['score_loss_sum']=sum(min(0,x['delta'])for x in xs)
    stats[group+'_observed_losses']['score_delta']=sum(x['delta']for x in xs)
stats['calibration_pass']=bool(len(M)>=12 and len(rej)>=5 and len(harm)>=3 and 3*avoided>=2*len(harm)
    and nonharm_gain and 2*keep>=len(nonharm_gain))
stats['native_budget_pass']=native>=95
(X/'report.json').write_text(json.dumps(dict(summary=stats,cases=out),indent=2)+'\n')
print(json.dumps(stats))
