from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
P=D.parent/'ahc008_terry_split_bound/solve.private.cpp'
s=P.read_text();assert hashlib.sha256(s.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
def put(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
put('struct Decision{int pairs=0;', 'inline std::vector<std::pair<int,int>> phase_audit_pairs;\ninline bool phase_keep_pairs=false;\nstruct Decision{int pairs=0;')
put('  ++answer.pairs;answer.normal+=score(s);answer.chase_sum+=score(t);','''  ++answer.pairs;
  const int x=score(s), y=score(t);
  answer.normal+=x; answer.chase_sum+=y;
  if(phase_keep_pairs)phase_audit_pairs.emplace_back(x,y);''')
put(' int map=-1,cap=100000,limit_ms=2670;', ' int map=-1,cap=100000,limit_ms=2670;\n std::string phase;')
put('  else if(s.starts_with("--ms="))limit_ms=std::stoi(s.substr(5));','''  else if(s.starts_with("--ms="))limit_ms=std::stoi(s.substr(5));
  else if(s.starts_with("--terminal="))phase=s.substr(11);''')
put('  if(turn==275)d=decide(s,policy,cap,stop);','''  if(turn==275){
   if(phase=="scout"||phase=="shadow"){
    if(cap!=0)return 2;
    const char* path=std::getenv("AHC008_TERMINAL_K8");
    if(!path)return 2;
    std::ofstream o(path);
    auto target=terry_partition::majorityPets(s.walls,s.people,pet_cells(s));
    o<<target.size()<<'\\n';
    if(phase=="shadow"){
     if(target.empty())return 2;
     phase_keep_pairs=true;
     d=decide(s,policy,8,Clock::time_point::max());
     if(d.pairs!=8||phase_audit_pairs.size()!=8)return 2;
     for(auto [x,y]:phase_audit_pairs)o<<x<<' '<<y<<'\\n';
    }
    return 0; // Official probe intentionally stops after 275 valid commands.
   }
   if(phase=="normal"||phase=="chase"){
    if(cap!=0)return 2;
    d.chose=phase=="chase";
   }else if(phase.empty())d=decide(s,policy,cap,stop);
   else return 2;
  }''')
(D/'observer.private.cpp').write_text(s)
