"""Detached, causal single-choice late reserve probe on signed held100."""
import collections,hashlib,itertools,json,math,re,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import case_history,command_effect,step,snapshot,mask,cells,B,ALL,flood,wave
P=R/'ahc008_terry_hunt_wall_audit'
ADJ=tuple(wave(b) for b in B)
DEN=12**6
DIR='URDL'
def maps():
    q=R/'ahc008_terry_exact_maps/terrain_data.inc'
    out=[]
    for k,g in enumerate(re.split(r'// map \d\s*\n',q.read_text())[:-1]):
        rows=re.findall(r'\{((?:0x[0-9a-f]+u,){4}0x[0-9a-f]+u)\}',g)
        vals=[[int(v[:-1],16) for v in row.split(',')]for row in rows]
        left=right=alls=0
        for r in range(30):
            _,a,b,c,d=vals[0 if r==0 else 1 if r%2==0 else 3 if r%4==3 else 4 if k==4 and r%8==5 else 2]
            left|=c<<(r*30);right|=d<<(r*30);alls|=(a|b|c|d)<<(r*30)
        out.append((left,right,alls))
    assert len(out)==5
    return out

def route(at,target,h,w,current):
    # One deterministic shortest path, padding with wait after arrival.
    if at==target:return '.'*h
    for a in DIR:
        q=step(at,a)
        if q is None or w&B[q] or current&B[q]:continue
        if q==target:return a+'.'*(h-1)
    if h==1:return None
    for a in DIR:
        q=step(at,a)
        if q is None or (w|current)&B[q]:continue
        for b in DIR:
            if step(q,b)==target:return a+b
    return None

def room_candidates(w,workers,left,right,allgates):
    allowed=ALL^(w|allgates)
    near=workers
    for _ in range(2):near=(near|wave(near))&~w
    for l in cells(left&~w):
        ls=step(l,'L');seed=step(l,'R')
        if ls is None or seed is None or not near&B[ls] or not allowed&B[seed]:continue
        body=flood(B[seed],allowed)
        if body&workers:continue
        front=wave(body)&~(body|w)
        if not front&B[l] or front.bit_count()!=2:continue
        rr=front&right
        if not rr or rr.bit_count()!=1:continue
        r=next(cells(rr));rs=step(r,'R');inside=step(r,'L')
        if rs is None or inside is None or not body&B[inside] or not near&B[rs]:continue
        if (front&workers) or body&(B[ls]|B[rs]):continue
        V=front|wave(front); T=body&~V
        if T:yield l,r,ls,rs,body,V,T

def distribution(p,n,w):
    data={p:DEN}
    for _ in range(n):
        nxt=collections.defaultdict(int)
        for q,m in data.items():
            opts=ADJ[q]&~w;d=opts.bit_count()
            if not d:nxt[q]+=m;continue
            assert m%d==0
            for z in cells(opts):nxt[z]+=m//d
        data=nxt
    assert sum(data.values())==DEN
    return data

def pick(current,cmd,typ,geo,stats):
    # Deliberately no turn+1 observations in scope.
    p,actors,base=current
    original=command_effect(actors,base,p,cmd);assert original
    walls,oldpose=original
    preids,prereach,_=snapshot(walls,oldpose,p)
    free=[i for i,c in enumerate(cmd) if not c.islower()]
    if len(free)<2:return None
    who=mask(actors[i]for i in free)
    directed={}
    dist={}
    best=None
    # Current old action may reveal walls, but no future walls or pets.
    for l,r,ls,rs,body,V,T in room_candidates(walls,mask(oldpose)|who,*geo):
        if not who:break
        for h in (1,2):
            looks=[[(i,path)for i in free if (path:=route(actors[i],g,h,walls,0)) is not None]for g in (ls,rs)]
            if not all(looks):continue
            if any(oldpose[i]==ls and oldpose[j]==rs for i in free for j in free if i!=j):
                stats['stock_already_at_stances']+=1;continue
            if h not in directed:
                z=mask(p[i]for i,k in enumerate(typ) if k>=4)
                for _ in range(2*h):z=(z|wave(z))&~walls
                directed[h]=z
            if directed[h]&(V|T):
                stats['directed_proximity_excluded']+=1;continue
            if h not in dist:
                dist[h]=[distribution(q,k*h,walls)for q,k in zip(p,typ)if k<=3]
            masses=[(sum(m for q,m in d.items() if V&B[q]),
                     sum(m for q,m in d.items() if T&B[q]))for d in dist[h]]
            numerator=math.prod(DEN-v for v,t in masses)-math.prod(DEN-v-t for v,t in masses)
            if numerator<=0:continue
            probability=Fraction(numerator,DEN**len(masses))
            for (a,pa),(b,pb) in itertools.product(*looks):
                if a==b:continue
                c=list(cmd);c[a]=pa[0];c[b]=pb[0]
                differences=sum(x!=y for x,y in zip(c,cmd))
                if not differences:continue
                res=command_effect(actors,base,p,c)
                if not res or res[0]!=walls:continue
                ids,reaches,_=snapshot(res[0],res[1],p)
                if ids!=preids or any(q&~z for q,z in zip(prereach,reaches)):continue
                rank=(probability,-h,-differences,-l,-r,-a,-b)
                if best is None or rank>best[0]:
                    best=(rank,h,l,r,ls,rs,body,a,b,pa,pb,res[1])
    return best

def closure(p,w,poses,cmd,roles,gates,body,oldids,oldreach):
    c=list(cmd)
    for i,d in roles:c[i]=d
    trial=command_effect(poses,w,p,c)
    if not trial:return 0,'illegal'
    nw,nh=trial
    if nw&body or flood(B[next(cells(body))],ALL^nw)!=body:return 0,'changed_geometry'
    ids,reaches,_=snapshot(nw,nh,p)
    if oldids&~ids:return 0,'lost_ids'
    if any(oldreach[i]==oldreach[j] and reaches[i]!=reaches[j] for i in range(len(nh))for j in range(i)):
        return 0,'worker_split'
    return ids&~oldids,'ok'

def label(t,proposal,hist,cmds,typ,stats):
    rank,h,l,r,ls,rs,body,a,b,pa,pb,pose=proposal
    if h==2:
        p,h0,w=hist[t+1]; cmd=cmds[t+1]; ow,oh=command_effect(h0,w,p,cmd)
        if cmd[a].islower() or cmd[b].islower():return 'protected_future_wall',0
        c=list(cmd);c[a]=pa[1];c[b]=pb[1]
        alt=command_effect(pose,w,p,c)
        if not alt or alt[0]!=ow:return 'illegal_future_prep',0
        old,reaches,_=snapshot(ow,oh,p); new,nreach,_=snapshot(alt[0],alt[1],p)
        if old&~new:return 'lost_ids',0
        if old!=new or any(q&~z for q,z in zip(reaches,nreach)):return 'changed_prep_reach',0
        pose=alt[1]
    p,h0,w=hist[t+h];cmd=cmds[t+h]
    assert pose[a]==ls and pose[b]==rs
    if cmd[a].islower() or cmd[b].islower():return 'protected_closure_wall',0
    ow,oh=command_effect(h0,w,p,cmd);old,reach,_=snapshot(ow,oh,p)
    gates=mask((l,r))
    hits=sum(B[i]for i,(q,k) in enumerate(zip(p,typ))if k<=3 and body&B[q])&~old
    if not hits:return 'no_new_passive_arrival',0
    new,why=closure(p,w,pose,cmd,[(a,'r'),(b,'l')],gates,body,old,reach)
    if not hits&new:return why if why!='ok' else 'no_exact_new_passive',0
    for i,j in itertools.product(range(len(h0)),repeat=2):
        if i==j or h0[i]!=ls or h0[j]!=rs or cmd[i].islower() or cmd[j].islower():continue
        same,_=closure(p,w,h0,cmd,[(i,'r'),(j,'l')],gates,body,old,reach)
        new&=~same
    gained=new&hits
    return ('witness',gained) if gained else ('stock_already_possible',0)

def main():
    signed=P/'recordings.json'
    assert hashlib.sha256(signed.read_bytes()).hexdigest()=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
    cases=json.loads(signed.read_text());assert len(cases)==100
    stats=collections.Counter();records={};geos=maps(); strata=collections.defaultdict(collections.Counter)
    import csv
    ledger=R/'ahc008_terry_incoming_shadow/held100/confirm.csv'
    assert hashlib.sha256(ledger.read_bytes()).hexdigest()=='9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2'
    rows=list(csv.DictReader(ledger.open()))
    chase={x['case']:int(x['telemetry'].split()[13])for x in rows if x['arm']=='terry_independent'}
    assert len(chase)==100
    for z in cases:
        kinds,hist,cmds=case_history(z); proposals=[];distinct=set()
        for t in range(230,298):
            mode='Chase' if chase[z['case']] and t>=275 else 'Normal'
            stats['examined']+=1;strata[mode]['examined']+=1
            pr=pick(hist[t],cmds[t],kinds,geos[z['map']],stats)
            if pr is None:continue
            rank,h,l,r,ls,rs,b,a,c,ra,rc,_=pr
            why,ids=label(t,pr,hist,cmds,kinds,stats)
            stats[why]+=1
            strata[mode]['proposals']+=1;strata[mode][why]+=1
            strata['h'+str(h)]['proposals']+=1;strata['h'+str(h)][why]+=1
            if ids:distinct.add((t+h,l,r,b))
            proposals.append(dict(t=t,eta=h,prob=str(rank[0]),left=l,right=r,actors=[a,c],
                   routes=[ra,rc],body=list(cells(b)),new_ids=list(cells(ids)),label=why,mode=mode))
        if proposals:records[z['case']]=dict(changes=proposals,witnesses=len(distinct))
    total=sum(len(z['changes'])for z in records.values());witnesses=sum(z['witnesses']for z in records.values())
    wb=sum(bool(z['witnesses'])for z in records.values())
    result=dict(changes=total,boards=len(records),witnesses=witnesses,witness_boards=wb,stats=dict(stats),
        strata={k:dict(v)for k,v in strata.items()},
        gate=total>=12 and len(records)>=8 and witnesses>=6 and wb>=4 and not stats['lost_ids'])
    (D/'report.json').write_text(json.dumps(dict(summary=result,boards=records),indent=2)+'\n')
    print(json.dumps(result))
if __name__=='__main__':main()
