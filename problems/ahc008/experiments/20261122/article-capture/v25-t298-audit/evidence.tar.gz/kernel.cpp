#pragma GCC optimize("O3")
#include <bits/stdc++.h>
using namespace std;
// Reuse the exact v25-fast2 terminal subset evaluator and bit-grid flood.
#define main original_entry
#include "../ahc008_v25_terminal_sets/solve.cpp"
#undef main
namespace stance_audit {
using terminal_sets::Rows;
using terminal_sets::Board;
using Adj=array<array<int,4>,900>;
constexpr int NC=900;
int at(const Adj& nb,const vector<int>& h,int i,char code){
 if(code=='.')return h[i];
 size_t d=string_view("UDLR").find(toupper(code));
 return d<4?nb[h[i]][d]:-1;
}
struct Top {int floorSum=0,rem=0,components=0;unsigned ids=0;};
Top topology(Rows r,const vector<int>& h,const vector<int>& p){
 Rows comp{};int a;Top t;
 while(terminal_sets::B::pop_first(r,comp,a)){
  int hc=0;
  for(int q:h)hc+=terminal_sets::has(comp,q);
  if(!hc)continue;
  ++t.components;t.floorSum+=a*hc;
  for(int i=0;i<int(p.size());i++)if(terminal_sets::has(comp,p[i])){++t.rem;t.ids|=1U<<i;}
 }
 return t;
}
void run(){
 int count;
 cin>>count;
 Adj nb;
 for(int p=0;p<NC;p++)nb[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 while(count--){
  string id,a298,a299;int N;
  cin>>id>>N>>a298>>a299;
  vector<int> h(5),p(N),q(N),ty(N);
  for(int& x:h)cin>>x;
  for(int i=0;i<N;i++)cin>>p[i]>>q[i]>>ty[i];
  Board base;for(auto& x:base){int b;cin>>b;x=b;}
  auto rows=terminal_sets::open(base);
  auto no=terminal_sets::forbidden({},h,p,nb);
  auto ref298=terminal_sets::validate(a298,rows,no,h,nb);
  assert(ref298);
  Board wall299;
  for(int i=0;i<NC;i++)wall299[i]=!terminal_sets::has(ref298->walkable,i);
  const auto h299=ref298->after;
  const auto cert299=terminal_sets::validate(a299,ref298->walkable,
        terminal_sets::forbidden({},h299,q,nb),h299,nb);
  assert(cert299);
  const auto scoreBase=terminal_sets::objective(cert299->walkable,cert299->after,q);
  const auto topBase=topology(cert299->walkable,cert299->after,q);
  const auto stockExact=terminal_sets::optimize(a299,wall299,h299,q,nb,[]{return false;});
  assert(stockExact.completed);
  // This cohort must reproduce the terminal audit's proven no-op exactly.
  assert(stockExact.act==a299);
  for(int worker=0;worker<5;worker++)if(!islower(a298[worker])){
   bool relevantDog=false;
   // Membership in the unchanged post-wall departure component.
   array<bool,NC> seen{};
   vector<int> visit{h[worker]};seen[h[worker]]=1;
   for(size_t j=0;j<visit.size();j++)for(int u:nb[visit[j]])if(u>=0&&!wall299[u]&&!seen[u]){
    seen[u]=true;visit.push_back(u);
   }
   for(int i=0;i<N;i++)if(ty[i]==4&&seen[p[i]])relevantDog=true;
   for(char alt:string_view("UDLR"))if(alt!=a298[worker]){
    string cmd=a298;cmd[worker]=alt;
    auto transfer=terminal_sets::validate(cmd,rows,no,h,nb);
    if(!transfer)continue;
    assert(transfer->walkable==ref298->walkable);
    const auto adjusted=transfer->after;
    // Choose best new terminal wall set without assuming stock command
    // remains executable at the altered pose.
    string fallback(5,'.');
    const auto legalStock=terminal_sets::validate(a299,ref298->walkable,
                               terminal_sets::forbidden({},adjusted,q,nb),adjusted,nb);
    if(legalStock)fallback=a299;
    const auto b=terminal_sets::optimize(fallback,wall299,adjusted,q,nb,[]{return false;});
    assert(b.completed);
    const auto cert=terminal_sets::validate(b.act,ref298->walkable,
                               terminal_sets::forbidden({},adjusted,q,nb),adjusted,nb);
    assert(cert);
    const auto score=terminal_sets::objective(cert->walkable,cert->after,q);
    const auto top=topology(cert->walkable,cert->after,q);
    const auto preserve=topology(ref298->walkable,adjusted,q);
    cout<<id<<','<<worker<<','<<alt<<','<<at(nb,h,worker,alt)<<','<<relevantDog<<','
        <<scoreBase<<','<<score<<','<<topBase.rem<<','<<top.rem<<','<<topBase.floorSum<<','<<top.floorSum
        <<','<<top.components<<','<<preserve.rem-top.rem<<','<<(preserve.ids&~top.ids)<<','<<b.evaluations<<','<<a298<<','<<a299<<','<<b.act<<'\n';
   }
  }
 }
}
}
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);stance_audit::run();}
