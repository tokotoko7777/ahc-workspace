"""Consume existing exact tapes only. Neither solver nor official tester is executed."""
import argparse,csv,hashlib,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark import replay
from guarded_entry_trace import observed

COLUMNS='case worker dir dest dog stock_objective new_objective stock_remaining new_remaining stock_floor_sum new_floor_sum human_components new_detached_heads new_detached_mask evaluated_sets actual298 actual299 adjusted299'.split()
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('ledger',type=Path)
    p.add_argument('inputs',type=Path)
    p.add_argument('tapes',type=Path)
    p.add_argument('kernel',type=Path)
    p.add_argument('--model',default='baseline')
    a=p.parse_args()
    rows=[x for x in csv.DictReader(a.ledger.open()) if x['model']==a.model]
    assert len(rows)==30 and all(int(row['humans'])==5 for row in rows)
    blob=[str(len(rows))]
    idx=lambda q:30*q[0]+q[1]
    for row in rows:
        n=row['case']
        source=(a.inputs/n).read_bytes()
        assert hashlib.sha256(source).hexdigest()==row['input_sha256']
        act=(a.tapes/n).with_suffix('.actions').read_bytes()
        assert hashlib.sha256(act).hexdigest()==row['actions_sha256']
        cmd=act.decode().splitlines()
        assert hashlib.sha256(('\n'.join(cmd[:299])+'\n').encode()).hexdigest()==row['prefix299']
        tape=(a.tapes/n).with_suffix('.trace').read_text().splitlines()
        score,*_=replay(source.decode(),tape,cmd,detailed=True)
        assert score==int(row['score'])
        types,hist,_=observed(source,tape)
        assert len(hist)==301
        p298,h298,w298=hist[298]
        p299,_,_=hist[299]
        blob += [f'{n} {len(types)} {cmd[298]} {cmd[299]}',' '.join(map(str,map(idx,h298)))]
        blob += [f'{idx(u)} {idx(v)} {typ}' for u,v,typ in zip(p298,p299,types,strict=True)]
        cells=set(map(idx,w298))
        blob += [' '.join(str(int(i in cells)) for i in range(900))]
    r=subprocess.run([str(a.kernel.resolve())],input='\n'.join(blob)+'\n',capture_output=True,text=True,check=True)
    result=[]
    for z in csv.DictReader(r.stdout.splitlines(),fieldnames=COLUMNS):
        for k in COLUMNS:
            if k not in ('case','dir','actual298','actual299','adjusted299'):z[k]=int(z[k])
        z['strict_gain']=z['new_objective']>z['stock_objective']
        z['new_full']=z['stock_remaining']>0 and z['new_remaining']==0
        z['new_useful_full']=not z['new_remaining'] and z['new_floor_sum']>=1500 and (
            z['stock_remaining']>0 or z['stock_floor_sum']<1500)
        z['new_detached_ids']=[i for i in range(20) if z['new_detached_mask']>>i&1]
        result.append(z)
    def stats(rows):
        return {k:dict(options=len(matches),cases=len({r['case'] for r in matches}))
                for k in ['all','strict_gain','new_full','new_useful_full']
                for matches in [[r for r in rows if k=='all' or r[k]]]}
    print(json.dumps(dict(input_cases=len(blob) and len(rows),general=stats(result),
        no_dog_departure_component=stats([x for x in result if not x['dog']]),options=result),indent=2))

if __name__=='__main__':
    main()
