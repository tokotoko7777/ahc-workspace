import csv,hashlib,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent; W=D.parent; H=W/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark_cases import run
T=W/'ahc008_focus_assets/tools/target/release/tester'
solver=W/'ahc008_v25_fast_static/solve'
inputs=W/'ahc008_v24_five_retention/m5-dev30/in'; logs=D/'tapes';logs.mkdir(exist_ok=True)
r=[q for q in csv.DictReader((W/'ahc008_v25_terminal_sets/dev30.csv').open()) if q['model']=='baseline']
assert len(r)==30
for q in r:
 f=inputs/q['case']; data=f.read_bytes()
 assert hashlib.sha256(data).hexdigest()==q['input_sha256']
 cmd=logs/(f.stem+'.actions');trace=logs/(f.stem+'.trace')
 with tempfile.TemporaryDirectory() as tm:
  tm=Path(tm)
  labels='ARTICLE RESCUE BRIDGE TERMINAL_SETS TERRY BANK'.split()
  a,e,rc,_=run([str(T),'env',*(f'AHC008_{x}_LOG={tm/x}' for x in labels),str(solver)],data,4.5)
 assert rc==0 and hashlib.sha256(a).hexdigest()==q['actions_sha256'],f.name
 assert e.decode().strip()==f"Score = {q['score']}"
 cmd.write_bytes(a)
 b,er,rc,_=run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',cmd,trace],data,12.)
 assert (b,er,rc)==(a,e,0)
 print(f.name,flush=True)
