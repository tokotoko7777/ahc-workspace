"""Detached paired calibration on recorded accepted incoming held100 only."""
import collections,hashlib,json,math,random,sys
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
J=R/'ahc008_terry_inward_online'
sys.path.insert(0,str(J))
from observer import case_history,jobs_by_turn,command_effect,step,B,ALL,mask,cells,flood,wave,support
P=R/'ahc008_terry_hunt_wall_audit'
ADJ=tuple(wave(b) for b in B)
DEN=12**3

def kernel(p,kind,w):
    m={p:DEN}
    for _ in range(kind):
        n=collections.defaultdict(int)
        for q,num in m.items():
            edges=ADJ[q]&~w;deg=edges.bit_count()
            if not deg:n[q]+=num;continue
            assert num%deg==0
            for z in cells(edges):n[z]+=num//deg
        m=n
    assert sum(m.values())==DEN
    return m

def predict(p,w,kinds,V,T):
    rows=[]
    for i,k in enumerate(kinds):
        if k>=4:
            if support(p[i],w,k)&(V|T):return None
            continue
        m=kernel(p[i],k,w)
        v=sum(n for q,n in m.items() if V&B[q])
        t=sum(n for q,n in m.items() if T&B[q])
        assert v+t<=DEN
        rows.append((i,m,v,t))
    norm=DEN**len(rows)
    pv=math.prod(DEN-v for _,_,v,t in rows)
    pnone=math.prod(DEN-v-t for _,_,v,t in rows)
    pi=norm-math.prod(DEN-t for _,_,v,t in rows)
    assert 0<=pv-pnone<=pi<=norm
    return rows,(pv-pnone)/norm,pi/norm,pv/norm,sum(t for _,_,v,t in rows)/DEN

def board(rec,pin,stats):
    kinds,h,commands=case_history(rec)
    jpath=(J/'logs'/rec['case']).with_suffix('.jobs')
    assert hashlib.sha256(jpath.read_bytes()).hexdigest()==pin[rec['case']]
    jobs=jobs_by_turn(jpath,len(h[0][1]))
    report=[]
    for t,js in sorted(jobs.items()):
        pts,people,oldwall=h[t]; after,hum,w=h[t+1]
        assert (w,hum)==command_effect(people,oldwall,pts,commands[t])
        occupied=mask(hum)
        candidates=[]
        stats['eta1_job_rows']+=len(js)
        for eta,l,r,a,b,named in js:
            if eta!=1 or min(l,r)<0 or l==r or a==b:continue
            if hum[a]!=step(l,'L') or hum[b]!=step(r,'R'):continue
            stats['same_stance_next']+=1
            gates=B[l]|B[r]
            if gates&(w|occupied):continue
            body=mask(named)&~gates
            if not body or body&(w|occupied):continue
            seed=B[next(cells(body))]
            if flood(seed,ALL^(w|gates))!=body:continue
            if flood(seed,ALL^(w|B[l]))==body or flood(seed,ALL^(w|B[r]))==body:continue
            V=gates|wave(gates);T=body&~V
            if not T:continue
            candidates.append((l,r,a,b,body,V,T))
        for j,(l,r,a,b,body,V,T) in enumerate(candidates):
            # Never duplicate or reuse a physical body or mouth in this turn.
            if any((body&z[4]) or l in z[:2] or r in z[:2]
                   for i,z in enumerate(candidates) if i!=j):
                stats['shared_geometry_excluded']+=1;continue
            forecast=predict(pts,w,kinds,V,T)
            if forecast is None:
                stats['directed_unknown_excluded']+=1;continue
            rows,pj,pi,pavail,ex=forecast
            assert all(after[i] in dist for i,dist,_,_ in rows)
            assert all(not (V|T)&B[after[i]] for i,k in enumerate(kinds) if k>=4)
            veto=any(V&B[q] for q in after)
            any_inside=any(T&B[q] for q in after)
            y=int(any_inside and not veto)
            check=['.']*len(people);check[a]='r';check[b]='l'
            z=command_effect(hum,w,after,check)
            if y:assert z==(w|B[l]|B[r],hum)
            assert bool(z)==(not veto)
            mix=[kinds.count(k) for k in range(1,6)]
            report.append(dict(t=t,l=l,r=r,y=y,pj=pj,pi=pi,available=pavail,
                observed_available=int(not veto),inside=int(any_inside),expected_targets=ex,mix=mix,
                veto_animals=sum(bool(V&B[q]) for q in after),
                veto_mouths=sum(any((B[g]|ADJ[g])&B[q] for q in after) for g in (l,r)),
                body=body.bit_count()))
    return report

def aggregate(rows):
    n=len(rows)
    if not n:return dict(n=0)
    mean=lambda a:sum(a)/n
    return dict(n=n,actual=mean(r['y'] for r in rows),p_joint=mean(r['pj'] for r in rows),
        p_ind=mean(r['pi'] for r in rows),brier_joint=mean((r['pj']-r['y'])**2 for r in rows),
        brier_ind=mean((r['pi']-r['y'])**2 for r in rows),
        availability=mean(r['available'] for r in rows),actual_availability=mean(r['observed_available'] for r in rows))

def main():
    records=json.loads((P/'recordings.json').read_text())
    pin=dict(x.split() for x in (J/'materialize.log').read_text().splitlines())
    assert len(records)==len(pin)==100
    stats=collections.Counter()
    by={z['case']:board(z,pin,stats) for z in records}
    rows=[r for rr in by.values() for r in rr]
    groups=[(sum((r['pi']-r['y'])**2-(r['pj']-r['y'])**2 for r in rr),len(rr)) for rr in by.values()]
    rng=random.Random(882182735)
    boot=[]
    for _ in range(4000):
        ss=[groups[rng.randrange(len(groups))] for _ in groups]
        dn=sum(n for _,n in ss)
        if dn:boot.append(sum(x for x,_ in ss)/dn)
    boot.sort();interval=[boot[int((len(boot)-1)*x)] for x in (.025,.975)] if boot else None
    overall=aggregate(rows); nboards=sum(bool(x) for x in by.values()); positives=sum(r['y'] for r in rows)
    diff=overall['brier_ind']-overall['brier_joint'] if rows else None
    s=dict(overall=overall,boards=nboards,positives=positives,brier_improvement=diff,paired_board_bootstrap95=interval,
        gate=bool(len(rows)>=100 and nboards>=20 and positives>=10 and diff>=.01 and interval[0]>0),stats=dict(stats),
        mix={str(x):aggregate([r for r in rows if bool(sum(r['mix'][3:]))==x]) for x in (False,True)},
        factual_veto_mouths={str(x):aggregate([r for r in rows if r['veto_mouths']==x]) for x in range(3)},
        calibration={key:[aggregate([r for r in rows if min(9,int(10*r[key]))==i]) for i in range(10)] for key in ('pi','pj')})
    (D/'report.json').write_text(json.dumps(dict(summary=s,snapshots=by),indent=2)+'\n')
    print(json.dumps({k:v for k,v in s.items() if k!='calibration'}))
if __name__=='__main__':main()
