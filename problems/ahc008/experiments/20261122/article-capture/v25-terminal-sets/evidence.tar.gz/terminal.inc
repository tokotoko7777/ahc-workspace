namespace terminal_sets {
 constexpr int V=900,S=30,M=5;
 using B=BitGridComponents<S,S>;
 using Rows=B::Rows;
 using Board=array<uint8_t,V>;
 using WorkerMasks=uint32_t;
 inline bool has(const Rows& a,int p){return (a[p/S]>>(p%S))&1U;}
 inline void add(Rows& a,int p){a[p/S]|=1U<<(p%S);}
 inline void erase(Rows& a,int p){a[p/S]&=~(1U<<(p%S));}
 inline bool valid(int p){return p>=0&&p<V;}
 inline Rows open(const Board& board){
  Rows a{};for(int p=0;p<V;p++)if(!board[p])add(a,p);return a;
 }
 inline Rows forbidden(const Rows& a,const vector<int>& h,const vector<int>& pets,
                       const array<array<int,4>,V>& nb){
  Rows no=a; // requested with empty rows; leave the grid input untouched.
  for(int p:h)add(no,p);
  for(int p:pets){add(no,p);for(int q:nb[p])if(valid(q))add(no,q);}
  return no;
 }
 struct Evaluated{
  Rows walkable{};
  vector<int> after;
 };
 inline optional<Evaluated> validate(string_view act,const Rows& orig,const Rows& no,
                     const vector<int>& h,const array<array<int,4>,V>& nb){
  if(act.size()!=h.size())return nullopt;
  Evaluated x{orig,h};
  for(size_t i=0;i<h.size();i++){
   if(act[i]=='.')continue;
   const auto w=string_view("udlr").find(act[i]);
   const auto m=string_view("UDLR").find(act[i]);
   if(w==string_view::npos&&m==string_view::npos)return nullopt;
   int p=nb[h[i]][w==string_view::npos?m:w];
   if(!valid(p)||!has(orig,p))return nullopt;
   if(w!=string_view::npos){
    if(has(no,p))return nullopt;
    erase(x.walkable,p); // overlapping legal builds make one wall
   }else x.after[i]=p;
  }
  for(int p:x.after)if(!has(x.walkable,p))return nullopt;
  return x;
 }
 inline long long objective(Rows r,const vector<int>& h,const vector<int>& pets){
  Rows comp{};long long total=0;
  int area;
  while(B::pop_first(r,comp,area)){
   int people=0,heads=0;
   for(int q:h)people+=has(comp,q);
   if(!people)continue;
   for(int q:pets)heads+=has(comp,q);
   total+=(1LL*area*people)<<(pets.size()-heads);
  }
  return total;
 }
 inline WorkerMasks extend(WorkerMasks possible, unsigned allowed){
  WorkerMasks reached=0;
  while(possible){
   const int subset=countr_zero(possible);
   possible&=possible-1;
   for(unsigned free=allowed&~unsigned(subset);free;free&=free-1){
    unsigned bit=free&-free;
    reached|=1U<<(subset|bit);
   }
  }
  return reached;
 }
 struct Choice{int p;unsigned workers;int priority;};
 inline int assign(const vector<Choice>& searched, int at, unsigned used, array<int,M>& plan){
  if(at==int(searched.size()))return 1;
  for(unsigned free=searched[at].workers&~used;free;free&=free-1){
   unsigned one=free&-free;int i=countr_zero(one);
   plan[i]=searched[at].p;
   if(assign(searched,at+1,used|one,plan))return 1;
   plan[i]=-1;
  }
  return 0;
 }
 struct Result {string act;int evaluations=0;bool completed=true;};
 template<class Stop>
 Result optimize(string base,const Board& walls,const vector<int>& h,const vector<int>& pets,
                 const array<array<int,4>,V>& nb,Stop stop){
  Result result{base};
  if(h.size()!=M||stop()){result.completed=false;return result;}
  Rows rows=open(walls),no=forbidden({},h,pets,nb);
  auto old=validate(base,rows,no,h,nb);
  if(!old){result.completed=false;return result;} // existing protocol guards own an invalid old result
  long long best=objective(old->walkable,old->after,pets);
  // Old legal moves can be removed: their endpoints were adjacent open
  // cells in exactly old->walkable, hence had the same component label.
  vector<Choice> cand,stack,chosen;
  bool improved=false;
  auto noWalls=objective(rows,h,pets);
  if(noWalls>best){best=noWalls;improved=true;}
  array<unsigned,V> slots{};
  for(int i=0;i<M;i++)for(int p:nb[h[i]])if(valid(p)&&has(rows,p)&&!has(no,p))slots[p]|=1U<<i;
  for(int p=0;p<V;p++)if(slots[p]){
   int score=0;
   for(int dx=-2;dx<=2;dx++)for(int dy=-2;dy<=2;dy++){
    int x=p/S+dx,y=p%S+dy;
    if(x<0||x>=S||y<0||y>=S||walls[x*S+y])score+=(abs(dx)<=1&&abs(dy)<=1)?3:1;
   }
   cand.push_back({p,slots[p],score});
  }
  stable_sort(cand.begin(),cand.end(),[](auto a,auto b){return a.priority>b.priority;});
  // Max 20 distinct cells: sum(C(20,k), k=1..5) = 21,699.
  // Clock checks every 32 actual evaluations; no calls beyond t299.
  constexpr int MAX_SETS=21699;
  auto search=[&](auto&& self,int from,WorkerMasks matches)->void{
   for(int j=from;j<int(cand.size());j++){
    const auto x=cand[j];const auto next=extend(matches,x.workers);
    if(!next)continue;
    if(result.evaluations>=MAX_SETS||
       ((result.evaluations&31)==0&&stop())){
     result.completed=false;return;
    }
    stack.push_back(x);erase(rows,x.p);
    long long v=objective(rows,h,pets);++result.evaluations;
    if(v>best){best=v;chosen=stack;improved=true;}
    if(stack.size()<M)self(self,j+1,next);
    add(rows,x.p);stack.pop_back();
    if(!result.completed)return;
   }
  };
  search(search,0,1U); // only the empty worker set is initially reachable
  if(improved){
   array<int,M> allocation;allocation.fill(-1);
   if(!assign(chosen,0,0U,allocation))return result;
   string proposal(M,'.');
   for(int i=0;i<M;i++)if(allocation[i]>=0){
    auto it=find(nb[h[i]].begin(),nb[h[i]].end(),allocation[i]);
    if(it==nb[h[i]].end())return result;
    proposal[i]="udlr"[it-nb[h[i]].begin()];
   }
   auto verified=validate(proposal,rows,no,h,nb);
   if(verified&&objective(verified->walkable,verified->after,pets)==best)result.act=move(proposal);
  }
  return result;
 }
}
