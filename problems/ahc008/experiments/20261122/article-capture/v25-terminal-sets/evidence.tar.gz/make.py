from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);data=p.read_bytes()
assert hashlib.sha256(data).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=data.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep('struct Game {',Path(__file__).with_name('terminal.inc').read_text()+'struct Game {')
rep(' string terminal(string baseline){',''' int exactTerminalSets=0;
 bool exactTerminalCompleted=false,exactTerminalChanged=false;
 string exactTerminalSet(const string& old){
  if(turn!=299||humans.size()!=5||!endSearch)return old;
  vector<int> positions;for(auto p:pets)positions.push_back(p.p);
  auto result=terminal_sets::optimize(old,wall,humans,positions,nb,[&]{
   return clock()-started>2.05*CLOCKS_PER_SEC;
  });
  exactTerminalSets=result.evaluations;
  exactTerminalCompleted=result.completed;
  exactTerminalChanged=result.act!=old;
  return result.act;
 }
 string terminal(string baseline){''')
rep('    g.act=std::move(proposal);','''    if(g.turn==299&&g.humans.size()==5)proposal=g.exactTerminalSet(proposal);
    g.act=std::move(proposal);''')
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* p=getenv("AHC008_TERMINAL_SETS_LOG")){
  ofstream f(p);f<<g.exactTerminalSets<<' '<<g.exactTerminalCompleted<<' '<<g.exactTerminalChanged<<'\\n';
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
