#define main original_entry
#include "solve.cpp"
#undef main
namespace term_test {
using namespace terminal_sets;
using Adj=std::array<std::array<int,4>,900>;
Adj adj(){
 Adj a;
 for(int p=0;p<900;p++)
  a[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 return a;
}
long long oracle(Board board,const vector<int>& h,const vector<int>& pets,const Adj& n,string ac){
 vector<int> pos=h;
 for(int i=0;i<5;i++)if(ac[i]!='.'){
  int d=int(string_view("UDLR").find(toupper(ac[i])));
  if(d<0||d>=4)return -1;
  int q=n[h[i]][d];
  if(q<0||board[q])return -1;
 }
 for(int i=0;i<5;i++)if(islower(ac[i])){
  int q=n[h[i]][string_view("udlr").find(ac[i])];
  if(count(h.begin(),h.end(),q))return -1;
  for(int p:pets)if(p==q||count(n[p].begin(),n[p].end(),q))return -1;
  board[q]=1;
 }
 for(int i=0;i<5;i++)if(isupper(ac[i])){
  pos[i]=n[h[i]][string_view("UDLR").find(ac[i])];
  if(board[pos[i]])return -1;
 }
 long long ans=0;
 for(int p:pos){
  vector<int> q{p};
  array<bool,900> see{};
  see[p]=true;
  for(size_t j=0;j<q.size();j++)for(int a:n[q[j]])if(a>=0&&!board[a]&&!see[a]){
   see[a]=true;q.push_back(a);
  }
  int count=0;for(int a:pets)count+=see[a];
  ans+=1LL*q.size()<<(pets.size()-count);
 }
 return ans;
}
void check(){
 std::mt19937 rng(0xeab170);
 auto n=adj();
 for(int z=0;z<2000;z++){
  vector<unsigned> a(rng()%7);
  for(auto& v:a)v=rng()%32;
  auto enumerate=[&](auto&& self,int at,int used)->uint32_t{
   if(at==int(a.size()))return 1U<<used;
   uint32_t out=0;
   for(int i=0;i<5;i++)if((a[at]>>i&1)&&!(used>>i&1))out|=self(self,at+1,used|1<<i);
   return out;
  };
  uint32_t dp=1;
  for(auto v:a)dp=extend(dp,v);
  assert(dp==enumerate(enumerate,0,0));
 }
 for(int z=0;z<120;z++){
  Board w;w.fill(1);
  vector<int> avail;
  for(int x=10;x<16;x++)for(int y=10;y<16;y++)if(rng()%4){
   int q=x*30+y;w[q]=0;avail.push_back(q);
  }
  vector<int> h(5),pets(rng()%6);
  for(int& p:h)p=avail[rng()%avail.size()];
  for(int& p:pets)p=avail[rng()%avail.size()];
  const auto r=open(w), stat=forbidden({},h,pets,n);
  string a(5,'.'),base=a;
  long long best=oracle(w,h,pets,n,base);
  // Exhaustive legal build/wait commands, independently including duplicate walls.
  auto visit=[&](auto&& self,int i){
   if(i==5){
    best=max(best,oracle(w,h,pets,n,a));
    return;
   }
   for(char c:std::string_view(".udlr")){a[i]=c;self(self,i+1);}
  };
  visit(visit,0);
  for(int k=0;k<80;k++){
   for(char& c:a)c=".udlrUDLR"[rng()%9];
   auto ans=oracle(w,h,pets,n,a);
   auto parsed=validate(a,r,stat,h,n);
   assert((ans>=0)==bool(parsed));
   if(parsed){
    assert(ans==objective(parsed->walkable,parsed->after,pets));
    // Every legal step stays in its original post-wall component.
    assert(ans==objective(parsed->walkable,h,pets));
    base=a;
   }
  }
  const auto exact=optimize(base,w,h,pets,n,[]{return false;});
  assert(exact.completed&&oracle(w,h,pets,n,exact.act)==best);
  if(oracle(w,h,pets,n,base)==best)assert(exact.act==base);
  int quota=10;
  const auto partial=optimize(base,w,h,pets,n,[&]{return --quota<1;});
  assert(oracle(w,h,pets,n,partial.act)>=oracle(w,h,pets,n,base));
 }
}
}
int main(){term_test::check();}
