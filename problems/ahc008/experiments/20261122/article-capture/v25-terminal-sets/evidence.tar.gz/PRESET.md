Only M5 final action t299. Advance to a completely new M5-only official
generator100 only if development has at least one exact-prefix case with
strictly improved official score, no exact-prefix score declines, no
decrease in useful or total full clears, and no runtime close to 3s.
Report if any score proof uses only clocks and not the same prefix.
For a future holdout take first 100 header-M5 from seeds SHA-256
ahc008-m5-terminal-sets-confirm-20261122-v1: + index 0..1199 (first
eight bytes unsigned big-endian). Same no-decline with useful/full
and at least one real score improvement; check both pinned general
100 sets and independent replay if adopting as deterministic final
search, no different prior strategy or historical score.
