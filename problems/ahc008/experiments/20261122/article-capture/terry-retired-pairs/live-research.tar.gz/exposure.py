"""Factual capture exposure of the fixed atlas. Never runs a solver/tester."""
import collections as C
import hashlib
import json
from pathlib import Path
import sys

D=Path(__file__).resolve().parent
R=D.parent
T=R/'ahc008_terry_hunt_wall_audit'
I=R/'ahc008_terry_incoming_shadow/held100'
H=R/'ahc008_focus_solver/problems/ahc008/experiments/20261122'
sys.path.insert(0,str(H))
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,wave,flood,cells

PLACEMENTS={
    2:((6,6),(10,13),(18,6),(22,20)),
    3:((6,8),(10,21),(18,8),(22,21)),
}

def bits(points):
    return sum(B[p] for p in set(points))

def sha(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()

def fixed_atlas():
    named={}
    for line in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        m,r,g0,g1,*floor=map(int,line.split())
        k=m,bits(floor),g0,g1
        assert k not in named
        named[k]=r
    across={}
    for m,bays in PLACEMENTS.items():
        exact={};total=0
        for k,(s,c) in enumerate(bays):
            floor_union=bits(s*30+x for x in range(c,c+4))
            for r in (s-1,s+1):
                floor=bits(r*30+x for x in range(c,c+4))
                g0=r*30+c-1;g1=r*30+c+4
                rid=named[m,floor,g0,g1]
                assert floor not in exact
                exact[floor]=(k,rid,r,(g0,g1))
                floor_union|=floor|B[g0]|B[g1]
            for r in (s-3,s+3):
                floor=bits(r*30+x for x in range(c,c+4))
                assert (m,floor,r*30+c-1,r*30+c+4) in named
            assert not ((wave(total)|total)&floor_union)
            total|=floor_union
        assert len(exact)==8
        across[m]=(exact,total)
    return across

def board(case_index,kind,history,exact,bay):
    out=[];seen=set();old_wall=0
    for time,(animals,staff,walls) in enumerate(history):
        flags=bits(map(idx,walls))
        reachable=flood(bits(map(idx,staff)),ALL^flags)
        newly={}
        for j,pet in enumerate(animals):
            if j not in seen and not (reachable&B[idx(pet)]):
                room=flood(B[idx(pet)],ALL^flags)
                newly.setdefault(room,[]).append(j)
        for body,ids in newly.items():
            assert time and flags!=old_wall
            seen.update(ids)
            room=exact.get(body)
            if room:
                exposure='exact_retired_body'
            elif body&bay:
                exposure='other_isolation_intersects_bay'
            else:
                exposure='disjoint'
            event=dict(case=case_index,action=time-1,animal_ids=ids,
                       species=[kind[j] for j in ids],floor=body.bit_count(),
                       actual_new_boundary=list(cells(wave(body)&(flags&~old_wall))),
                       exposure=exposure)
            assert event['actual_new_boundary']
            if room:
                k,rid,r,g=room
                event.update(bay=k,stock_room=rid,room_row=r,
                             stock_mouths=list(g),mouths_newly_built=[
                                 v for v in g if B[v]&(flags&~old_wall)])
            out.append(event)
        old_wall=flags
    return out,len(seen)

def summary(events):
    counts=C.Counter();head=C.Counter()
    for x in events:
        for k in x['species']:counts[k]+=1
        t=x['action']
        name='0..132' if t<133 else '133..159' if t<160 else '160..274' if t<275 else '275..299'
        head[name]+=len(x['animal_ids'])
    return dict(events=len(events),heads=sum(counts.values()),boards=len({x['case'] for x in events}),
                species=dict(counts),head_timing=dict(head))

def main():
    atlas=fixed_atlas()
    ledger=json.loads((T/'recordings.json').read_text())
    assert len(ledger)==100 and len({x['case'] for x in ledger})==100
    rows=[]; events=[]
    for rec in ledger:
        nm=rec['case']; m=rec['map']
        if m not in atlas:continue
        case=I/'in'/nm
        actions=(T/'tapes'/nm).with_suffix('.actions')
        trace=actions.with_suffix('.trace')
        assert [sha(v) for v in (case,actions,trace)]==[
            rec[k] for k in ('input_sha','commands_sha','trace_sha')]
        reply=trace.read_text().splitlines()
        assert len(reply)==600 and actions.read_text().splitlines()==reply[::2]
        kinds,hist,_=observed(case.read_bytes(),reply)
        ev,done=board(nm,kinds,hist,*atlas[m])
        assert (done==len(kinds))==bool(rec['actual_full'])
        events.extend(dict(map=m,**x) for x in ev)
        sx=[x for x in ev if x['exposure']=='exact_retired_body']
        rows.append(dict(case=nm,map=m,animals=len(kinds),first_isolations=done,
                         exposed_events=len(sx),exposed_heads=sum(len(x['animal_ids']) for x in sx)))
    by_map={}
    for m in atlas:
        ev=[x for x in events if x['map']==m]
        rr=[x for x in rows if x['map']==m]
        by_map[m]=dict(cases=len(rr),initial_heads=sum(x['animals'] for x in rr),all=summary(ev),
            exact=summary([x for x in ev if x['exposure']=='exact_retired_body']),
            overlap_nonexact=summary([x for x in ev if x['exposure']=='other_isolation_intersects_bay']),
            exposed_events_per_board=dict(C.Counter(x['exposed_events'] for x in rr)))
    print(json.dumps(dict(total_ledger_cases=100,selected=len(rows),by_map=by_map,
                          rows=rows,events=events),indent=2))

if __name__=='__main__':
    main()
