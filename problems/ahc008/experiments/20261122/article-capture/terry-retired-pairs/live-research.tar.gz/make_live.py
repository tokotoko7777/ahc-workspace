"""Accepted selected split solver to frozen static retired-pair atlas, single change."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
p=s.index('namespace terry_exact_root {')
h=(d/'atlas.hpp').read_text()
h='\n'.join(line for line in h.splitlines() if line!='#pragma once' and not line.startswith('#include'))
h+='''
namespace retired_pairs {
inline const Terrain& for_solver(int map) {
 if(map==2){ static const auto x=atlas(2).initial; return x; }
 if(map==3){ static const auto x=atlas(3).initial; return x; }
 return terrain(map);
}
}
'''
old=' const auto& cfg=terrain_lib::terrain(map);'
assert s.count(old)==1
s='#include <stdexcept>\n'+s[:p]+h+'\n'+s[p:]
s=s.replace(old,' const auto& cfg=retired_pairs::for_solver(map);')
(d/'solve.private.cpp').write_text(s)
