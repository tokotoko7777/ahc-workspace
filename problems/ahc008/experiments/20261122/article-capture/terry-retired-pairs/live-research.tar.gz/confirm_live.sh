#!/usr/bin/env bash
set -euo pipefail
D=ahc008_terry_retired_pairs
P=ahc008_focus_solver/problems/ahc008
B=ahc008_terry_split_bound/solve
T=ahc008_focus_assets/tools/target/release/tester
export PYTHONPATH="$PWD/ahc008_integrated_v11:$PWD/$P/experiments/20261122:$PWD/$P:$PWD/ahc008_bridge_audit"
passed(){ python -c 'import json,sys; assert json.load(open(sys.argv[1]))["gate"]' "$1"; }
passed "$D/dev100/summary.json"
python "$D/prepare_live.py" held100
python ahc008_terry_exact_root/bench.py "$P" "$T" "$B" "$D/solve" "$D/held100/in" "$D/held100/confirm.csv" --n 100 >"$D/held100/confirm.log" 2>&1
python "$D/analyze_live.py" "$D/held100/confirm.csv" >"$D/held100/summary.json"
passed "$D/held100/summary.json"
python ahc008_terry_exact_root/bench.py "$P" "$T" "$B" "$D/solve" ahc008_focus_assets/tools/in "$D/practice.csv" --n 100 >"$D/practice.log" 2>&1
python "$D/analyze_live.py" "$D/practice.csv" >"$D/practice.json"
passed "$D/practice.json"
