#pragma once
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <array>
#include <stdexcept>
#include <utility>

namespace retired_pairs {
using namespace terry_exact_maps;
struct Placement{int row,left;}; // shared separator row, leftmost body column.
struct Bay {
 Placement pos;
 std::array<int,2> retired;
 std::array<int,2> intact; // same-bank intact room one away to either side
 Board removedWalls,removedDoors,body;
 Board footprint()const{return removedWalls|removedDoors|body;}
};
struct Named {
 Board body,doors,stands;
 int l=-1,r=-1;
 bool any()const{return doors.any();}
};
struct Layout {
 Terrain original, initial;
 std::array<Bay,4> bay;
 std::vector<Named> originalNames;
 Board removedWalls, removedDoors;
};
inline std::array<Placement,4> placements(int map){
 if(map==2)return {{{6,6},{10,13},{18,6},{22,20}}};
 if(map==3)return {{{6,8},{10,21},{18,8},{22,21}}};
 throw std::invalid_argument("only unchanged map 2/3 are eligible");
}
inline std::vector<Named> named(const Terrain& t,const Board& wall){
 auto r=classify(t,wall,{}, {cell(0,t.aisleColumns.front())});
 std::vector<Named> out(r.count());
 for(int i=0;i<r.count();i++){
  auto v=r.rooms[i];out[i].l=v.left;out[i].r=v.right;
  if(v.left>=0){
   out[i].doors.set(v.left);out[i].stands.set(v.left-1);
  }
  if(v.right>=0){
   out[i].doors.set(v.right);out[i].stands.set(v.right+1);
  }
 }
 for(int p=0;p<V;p++)if(r.ids[p]>=0&&r.ids[p]<r.count()&&!t.doorCells[p])
  out[r.ids[p]].body.set(p);
 return out;
}
inline int exact(const std::vector<Named>& table,int row,int first){
 Board b;
 for(int q=first;q<first+4;q++)b.set(cell(row,q));
 int l=cell(row,first-1),r=cell(row,first+4);
 for(int i=0;i<int(table.size());i++)if(table[i].l==l&&table[i].r==r&&table[i].body==b)return i;
 throw std::runtime_error("frozen room/twin not exact in stock catalog");
}
inline Layout atlas(int map) {
 Layout a;
 a.original=terrain(map);
 a.initial=a.original;
 a.originalNames=named(a.original,a.original.plannedWalls);
 const auto z=placements(map);
 for(int i=0;i<4;i++){
  auto p=z[i];
  Bay b{p,{exact(a.originalNames,p.row-1,p.left),exact(a.originalNames,p.row+1,p.left)},
        {exact(a.originalNames,p.row-3,p.left),exact(a.originalNames,p.row+3,p.left)},{},{},{}};
  for(int col=p.left;col<p.left+4;col++) {
   int q=cell(p.row,col);
   if(!a.original.planned(q))throw std::runtime_error("not the frozen shared stock X");
   b.removedWalls.set(q);
  }
  for(int j:b.retired){
   b.body|=a.originalNames[j].body;
   b.removedDoors|=a.originalNames[j].doors;
  }
  a.removedWalls|=b.removedWalls;
  a.removedDoors|=b.removedDoors;
  a.bay[i]=std::move(b);
 }
 a.initial.plannedWalls&=~a.removedWalls;
 a.initial.doorCells&=~a.removedDoors;
 for(int q=0;q<V;q++)if(a.removedDoors[q]||a.removedWalls[q]){
  int row=q/W;
  a.initial.cells[q]=a.original.constructionRow(row)?Marker::Sweep:
                    (row%2?Marker::Room:Marker::Open);
 }
 return a;
}
}
