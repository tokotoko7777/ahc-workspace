# Four scattered retired-pair bays, static-only fixture

Predetermined six-coordinate placements are not fitted to a case:
* map 2: (separator row, first body column) (6,6), (10,13), (18,6), (22,20).
* map 3: (6,8), (10,21), (18,8), (22,21).

For each nominal bay require two exact original two-mouth width-four stock
rooms rows separator±1 and retained intact twins separator±3. Retire only
the former two room labels and their four named door markers, and omit
the four X between them. Keep both outside bracing rows, every old stance
and all other roles. Every removed wall must abut exactly both and no
other named body. Disallow any overlap or cardinal contact of whole
abandoned footprints, counting removed doors and walls. The atlas
does not consult case IDs, motion, outcomes, or selector features.

Audit both actual semantic classifier and independent full-close room
components. All retained named IDs must biject up to renumbering, with
exact physical body and left/right role. Test all old aisle/stance
reach relations with the full-open board, every single old lock, and every
old two-mouth same-room lock (retired doors intentionally stay open).
Report how many aisle components exist after every surviving gate is
closed. Every bay stays connected to an old aisle in this view; no
retained room may rejoin the exterior. Require 0/1 safe checkerboard
endpoint distances ≤10 from every abandoned cell on the full-open board.

No compilation/execution in this preparation assignment. After root
timing clearance, the intended standalone command is:
```sh
g++ -std=c++23 -Wall -Wextra -pedantic ahc008_terry_retired_pairs/verify.cpp -o /tmp/terry-pairs-static
/tmp/terry-pairs-static
```
No headroom claim until this fixture itself passes, no live policy, replay,
or altered official score here.
