#pragma GCC optimize("O3")
#include "atlas.hpp"
#include <cassert>
#include <iostream>
#include <set>

using namespace retired_pairs;
std::vector<int> points(const Board& a){
 std::vector<int> r;
 for(int q=0;q<V;++q)if(a[q])r.push_back(q);
 return r;
}
Board neighbors(const Board& a){
 Board b;
 for(int p:points(a))for(int q:adjacent(p))if(q>=0)b.set(q);
 return b;
}
Board component(const Components& c,int p){
 Board b;
 if(c.labels[p]<0)return b;
 for(int q=0;q<V;q++)if(c.labels[q]==c.labels[p])b.set(q);
 return b;
}
int md(int p,int q){return std::abs(p/W-q/W)+std::abs(p%W-q%W);}
std::array<int,V> from(const Board& origins,const Board& walls){
 std::array<int,V> d,q;d.fill(-1);
 int n=0;
 for(int p:points(origins)){
  assert(!walls[p]);
  d[p]=0;q[n++]=p;
 }
 for(int k=0;k<n;k++)for(int p:adjacent(q[k]))if(p>=0&&!walls[p]&&d[p]<0)
  d[p]=d[q[k]]+1,q[n++]=p;
 return d;
}
void verifyMap(int map){
 const Layout a=atlas(map);
 const auto& old=a.original;const auto& n=a.initial;
 assert(a.removedWalls.count()==16&&a.removedDoors.count()==16);
 assert(n.plannedWalls.count()+16==old.plannedWalls.count());
 assert(old.aisleCells==n.aisleCells);
 for(int r=0;r<W;r++)assert(old.constructionRow(r)==n.constructionRow(r));
 assert((a.removedWalls&a.removedDoors).none());
 std::set<int> retired;
 Board used;
 for(const auto& bay:a.bay){
  auto footprint=bay.footprint();
  assert(((neighbors(used)|used)&footprint).none());
  used|=footprint;
  for(int j:bay.retired)assert(retired.insert(j).second);
  for(int p:points(bay.removedWalls)){
   int incidence=0;
   for(int j=0;j<int(a.originalNames.size());j++)
    if(a.originalNames[j].any()&&(neighbors(a.originalNames[j].body)&Board{}.set(p)).any()){
     assert(j==bay.retired[0]||j==bay.retired[1]);++incidence;
    }
   assert(incidence==2);
  }
 }
 for(const auto& bay:a.bay)for(int j:bay.intact)assert(!retired.count(j));
 auto oldClosed=labels(old.plannedWalls|old.doorCells);
 auto newClosed=labels(n.plannedWalls|n.doorCells);
 auto updated=named(n,n.plannedWalls);
 std::array<Board,2> safe;
 Board endpoint=old.aisleCells;
 int count=0;
 std::set<int> mapped;
 for(int j=0;j<int(a.originalNames.size());j++){
  const auto& r=a.originalNames[j];if(!r.any())continue;
  endpoint|=r.stands;
  if(retired.count(j))continue;
  assert(r.body.any());
  assert(component(oldClosed,points(r.body)[0])==r.body);
  assert(component(newClosed,points(r.body)[0])==r.body);
  int match=-1;
  for(int i=0;i<int(updated.size());i++)
   if(updated[i].body==r.body&&updated[i].l==r.l&&updated[i].r==r.r&&updated[i].stands==r.stands)match=i;
  assert(match>=0&&mapped.insert(match).second);
  for(int p:points(r.doors))assert(old.cells[p]==n.cells[p]);
  for(int p:points(r.body)) {
   bool okay=true;
   for(int q:points(r.doors))if(md(p,q)<2)okay=false;
   if(okay)safe[(p/W+p%W)&1].set(p);
  }
  ++count;
 }
 for(int i=0;i<int(updated.size());i++)if(updated[i].any())assert(mapped.count(i));
 assert((endpoint&old.plannedWalls).none()&&(endpoint&n.plannedWalls).none());
 // All old geometry's service relations survive. Retired mouths are now
 // passages even when the test action would previously have closed them.
 auto service=[&](Board add){
  const auto p=labels(old.plannedWalls|add);
  const auto q=labels(n.plannedWalls|(add&~a.removedDoors));
  for(int x:points(endpoint)){
   assert(p.labels[x]>=0&&q.labels[x]>=0);
   for(int y:points(endpoint))if(p.labels[x]==p.labels[y])assert(q.labels[x]==q.labels[y]);
  }
 };
 service({});
 for(int g:points(old.doorCells))service(Board{}.set(g));
 for(const auto& r:a.originalNames)if(r.doors.count()==2)service(r.doors);
 const auto distance0=from(safe[0],n.plannedWalls);
 const auto distance1=from(safe[1],n.plannedWalls);
 int max0=0,max1=0;
 for(const auto& bay:a.bay){
  auto footprint=bay.footprint();
  // With every surviving mouth closed, each abandoned bay is still a
  // proper exterior passage, not an isolated phantom or retained body.
  for(int q:points(footprint)){
   assert((component(newClosed,q)&old.aisleCells).any());
   int d0=distance0[q],d1=distance1[q];
   assert(d0>=0&&d1>=0&&d0<=10&&d1<=10);
   max0=std::max(max0,d0);max1=std::max(max1,d1);
  }
 }
 std::set<int> oldRoads,newRoads;
 for(int p:points(old.aisleCells)){
  oldRoads.insert(oldClosed.labels[p]);newRoads.insert(newClosed.labels[p]);
 }
 assert(newRoads.size()<=oldRoads.size());
 std::cout<<"map="<<map<<" savedX="<<a.removedWalls.count()<<" retired="<<retired.size()
          <<" retained="<<count<<" max_d0="<<max0<<" max_d1="<<max1
          <<" fully_closed_aisle_components="<<oldRoads.size()<<"->"<<newRoads.size()<<'\n';
}
int main(){verifyMap(2);verifyMap(3);}
