# Conditional measurement plan: scattered stock pen-pair retirement
Do not build this before frozen static atlas passes both maps unchanged.
C++ predecessor is the verified exact split-bound selected solver. Only
change: if the original selector nominates map2 or map3, use the
atlas's physical and semantic edited stock map; do not retrain or
alter the selector or change another capture/room/rollout rule. Same
published 2670ms and no fixed rollout cap. Other map outputs must
be identical unless clock noise changes final mode; report this.
Exactly 16 nominal scaffold cells saved in every eligible map. The
goal is to trade excess room density for more retained floor without
losing all-head captures. No artificial case-ID, seeds, or suffix-driven
selection. A static proof does not imply causal capture unchanged.

Run one frozen freshly generated unfiltered 100 (new distinct seed
namespace, use official gen) vs accepted comparator, serially, official
tester and official playback + independent legality/score. Do not
preselect cases or adjust geometry after outcomes. Gate: all legal and
max tester wall <2.95 s, no decrease in full/useful counts, material
aggregate score gain ≥0.2%, and common fully captured eligible cases
gain ≥6 per-worker floor cells on average. Also compare exact planned
walls, first-catch timing/type, wall counts and captivity floor
components by selected map. If pilot fails, no held or official
practice run; diagnose when/which species lose captures, do not claim
success from geometry. If passes, preregister independent fresh100
and official distributed100 A/B under the same criteria.
