# Actual dev100 midgame throughput decomposition, frozen plan

Only the already completed independent dev100 two-arm pilot and the 80
pre-existing map2/map3 case IDs. Never use the original distributed practice
or separate incoming held / reserve held. Both solver sources and the whole
pilot CSV are hashed; every generated input name/hash, full action SHA,
official score and full 15-field per-arm telemetry must match. Set each arm
to its own original completed rollout cap (telemetry field 10, zero-based),
changing only the wall-clock stop of the replay-only copy. Use official
playback for replies and verify independent legality/score and tape digest.
Stop at the first discrepancy and do not report an aggregate or substitute
score-only / final-shape agreement. Incomplete normal rollout side effects
in a native run could defeat action equivalence even at equal cap.

For reference, time t means pre-human state after t previous actions;
window includes actions t=100 through t=159 inclusive. Compare only the
SAME retained exact stock body masks and the original named gate/stance
cells in both arms (omit old removed-room observations from this primary
funnel, but count their actual first captures separately for context).
For each originally identified pet, each arm independently records:

1. At t=100, currently reachable, not ever-lost counts. Snapshot occupancy,
   first decision-boundary entry, and observed first microstep arrivals in
   any retained one-/two-mouth room during the window by pet ID. Present at
   t100 is left-censored occupancy, not falsely tagged an arrival.
2. First occurrence in a specific retained TWO-mouth body while both
   original gates open, exact structural support present and closing both
   would isolate that exact body with no worker inside. Verify gate legality
   against CURRENT all-animal occupancy/adjacency and starting humans;
   separately check same-turn other-worker move/build compatibility at
   actual guard assignments. Keep incomplete supports, partial/closed
   mouths, wrong local flood, animal-blocked and person-blocked as separate
   diagnostic counters. An unfinished unrelated room does not suppress a
   candidate.
3. Guard bottleneck ETA by exact BFS to fixed exterior stances avoiding
   this body's fields and both gates (distances ≤2 only); require two
   distinct workers. Distinguish ETA0 (both currently aligned), ETA≤2,
   and truly aligned stock-action-compatible issue-without-displacing-other
   moves/builds. No claim a speculative move would preserve observed pets.
4. Actual first newly disconnected humans-versus-pet event, and the subset
   using one exact retained room / retained pair / retired original room.
   Score not recomputed from these proxy windows. Report exact t160
   reachable ID lists and paired gains/losses (same case IDs only).

Pooled ID funnel on all 80 affected fixed cases, and separately baseline
t100 survivor, candidate t100 survivor, both t100 survivors, and paired
t160 descriptive strata (both, candidate-only, baseline-only).
Post-treatment strata are descriptive and are not causal evidence.
Counts are unique pet identities per case, not raw repeated window counts;
repeated windows are diagnostic only. Never report full across only
successfully reproduced subset.

From workspace root, only after exclusive timing clearance:

```sh
python ahc008_terry_retired_pairs/pipeline/materialize.py \
  ahc008_focus_assets/tools/target/release/tester --execute
python ahc008_terry_retired_pairs/pipeline/analyze.py \
  > ahc008_terry_retired_pairs/pipeline/funnel.json
```

The first command writes individual materializations and, only after all
160 match, a single authorization manifest for the funnel. After any
discordance, it writes `first_mismatch.json`, exits without a manifest,
and leaves partial tapes explicitly unusable by the analyzer. No use of
native causal prefixes without a subsequent separately approved and
independently hash-verified plan. Nothing in these tools changes the
scored source files, pilot ledger, or either original held cohort.
