"""Capture funnel from the exact pinned 160 pilot trajectories, not rollouts."""
import collections as C
import json
from pathlib import Path
import sys

from materialize import A,D,R,sha,chosen
from guarded_entry_trace import observed,STEPS
from stochastic_lock_audit import ALL,B,ADJ,idx,wave,flood
sys.path.insert(0,str(A))
from exposure import fixed_atlas,bits

START,END=100,160
STAGES=(
    'present100','body_window','entry_snapshot','entry_microstep','two_body',
    'structurally_ready','legal','eta2','eta0','aligned_compatible',
    'first_catch','retained_catch','retained_two_catch','retired_catch',
)

def shift(p,c):
    a,b=STEPS[c.upper()]
    return p+a*30+b

def retained_stock(mapid):
    catalog={}; bodies={}; at={}
    retired,_=fixed_atlas()[mapid]
    for line in (R/'ahc008_terry_small_rooms/catalog.tsv').read_text().splitlines():
        m,i,l,r,*pos=map(int,line.split())
        if m!=mapid:continue
        b=bits(pos)
        if b in retired:continue
        named=[g for g in (l,r) if g>=0]
        stands=[p for p in (l-1 if l>=0 else -1,r+1 if r>=0 else -1) if p>=0]
        assert b and i not in catalog and b not in bodies
        gates=bits(named);rim=wave(b)&~(b|gates)
        catalog[i]=dict(body=b,gates=gates,mouths=named,stands=stands,support=rim)
        for p in pos:
            assert p not in at
            at[p]=i
        bodies[b]=i
    return catalog,at,bodies,retired

def near_stance(stance,allowed):
    start=B[stance]
    if not start&allowed:return 0
    close=start
    for _ in range(2):close|=wave(close)&allowed
    return close

def board(row,trace,initial):
    mapid=row['map']
    catalog,at,bodies,retired=retained_stock(mapid)
    kinds,raw,_=observed(initial,trace)
    states=[]
    for ps,hs,ws in raw:
        p,h=list(map(idx,ps)),list(map(idx,hs))
        w=bits(map(idx,ws))
        states.append((p,h,w,flood(bits(h),ALL^w)))
    assert len(states)==301
    ans={k:set() for k in STAGES}; frames=C.Counter()
    first={}
    previous=states[START-1][0]
    def record(k,ids,t):
        ans[k].update(ids)
        for i in ids:first.setdefault((k,i),t)
    for t in range(START,END):
        ps,hs,w,reached=states[t]
        p1,h1,w1,reached1=states[t+1]
        action=trace[2*t]
        pm=bits(ps); hm=bits(hs)
        animal_veto=pm|wave(pm)
        occupied=C.defaultdict(list)
        for i,p in enumerate(ps):
            rid=at.get(p)
            if rid is None or not reached&B[p]:continue
            occupied[rid].append(i)
            record('body_window',[i],t)
            if t==START:record('present100',[i],t)
            elif at.get(previous[i])!=rid:record('entry_snapshot',[i],t)
        for rid,heads in occupied.items():
            d=catalog[rid]; b=d['body'];g=d['gates']
            if len(d['mouths'])!=2:continue
            record('two_body',heads,t)
            frames['two_body']+=1
            if w&g:
                frames['partial_or_closed_mouth']+=1;continue
            if w&d['support']!=d['support']:
                frames['own_shell_incomplete']+=1;continue
            physical=ALL&~(w|g)
            if flood(b&-b,physical)!=b:
                frames['wrong_local_flood']+=1;continue
            if hm&b:
                frames['worker_inside']+=1;continue
            record('structurally_ready',heads,t)
            blocked1=bool(animal_veto&g);blocked2=bool(hm&g)
            frames['animal_blocked']+=blocked1
            frames['person_blocked']+=blocked2
            if blocked1 or blocked2:continue
            record('legal',heads,t)
            s0,s1=d['stands']
            exterior=ALL&~(w|g|b)
            n0=near_stance(s0,exterior);n1=near_stance(s1,exterior)
            if any(i!=j and n0&B[h] and n1&B[q]
                   for i,h in enumerate(hs) for j,q in enumerate(hs)):
                record('eta2',heads,t)
            aligned=[(i,j) for i,h in enumerate(hs) for j,q in enumerate(hs)
                     if i!=j and h==s0 and q==s1]
            if aligned:record('eta0',heads,t)
            for i,j in aligned:
                g0,g1=d['mouths']
                if all(action[k]=='.' or (action[k].islower() and shift(hs[k],action[k])==gate)
                       for k,gate in ((i,g0),(j,g1))) and not any(
                       c.isupper() and B[shift(hs[k],c)]&g
                       for k,c in enumerate(action) if k not in (i,j)):
                    record('aligned_compatible',heads,t);break
        for i,motion in enumerate(trace[2*t+1].split()):
            p=ps[i]
            for c in motion:
                if c=='.':continue
                q=shift(p,c)
                if at.get(q) is not None and at.get(p)!=at[q] and reached1&B[q]:
                    record('entry_microstep',[i],t)
                p=q
            assert p==p1[i]
        for i,p in enumerate(p1):
            if not reached&B[ps[i]] or reached1&B[p]:continue
            assert w1!=w
            b=flood(B[p],ALL^w1)
            record('first_catch',[i],t)
            if b in bodies:
                record('retained_catch',[i],t)
                if len(catalog[bodies[b]]['mouths'])==2:record('retained_two_catch',[i],t)
            if b in retired:record('retired_catch',[i],t)
        previous=ps
    active={k:sorted(i for i,p in enumerate(states[k][0]) if states[k][3]&B[p])
            for k in (START,END)}
    return dict(map=mapid,case=row['case'],arm=row['arm'],kinds=kinds,
                active100=active[START],active160=active[END],frames=dict(frames),
                stages={k:sorted(v) for k,v in ans.items()},
                first=[dict(stage=k,pet=i,turn=t) for (k,i),t in sorted(first.items())])

def totals(rows):
    out=C.defaultdict(lambda:C.defaultdict(C.Counter))
    for rr in rows.values():
        left=rr['v25'];right=rr['terry_independent'];assert left['kinds']==right['kinds']
        allids=set(range(len(left['kinds'])))
        l0=set(left['active100']);r0=set(right['active100'])
        l1=set(left['active160']);r1=set(right['active160'])
        groups={'all':allids,'stock_survivors100':l0,'candidate_survivors100':r0,
                 'both_survive100':l0&r0,'both_survive160':l1&r1,
                 'stock_only160':l1-r1,'candidate_only160':r1-l1}
        for r in (left,right):
            for g,ids in groups.items():
                bucket=out[g][r['arm']];bucket['head_denominator']+=len(ids)
                bucket.update(active100=len(ids&set(r['active100'])),active160=len(ids&set(r['active160'])))
                for stage in STAGES:bucket[stage]+=len(ids&set(r['stages'][stage]))
    return out

def main():
    exact=chosen()
    manifest=json.loads((D/'materialized/manifest.json').read_text())
    assert len(manifest)==160
    expected={(r['case'],r['arm']):r for r in exact}
    rows=C.defaultdict(dict)
    for r in manifest:
        signed=expected.pop((r['case'],r['arm']))
        name=r['case'];arm=r['arm'];tag=f'{Path(name).stem}.{arm}'
        a=D/'materialized'/(tag+'.actions');t=D/'materialized'/(tag+'.trace');i=A/'dev100/in'/name
        assert sha(i.read_bytes())==r['input_sha']==signed['input_sha']
        assert sha(a.read_bytes())==r['actions_sha']==signed['commands_sha']
        assert sha(t.read_bytes())==r['trace_sha']
        assert r['score']==int(signed['score']) and r['telemetry']==list(map(int,signed['telemetry'].split()))
        s=t.read_text().splitlines()
        assert a.read_text().splitlines()==s[::2] and len(s)==600
        outcome=board(r,s,i.read_bytes())
        for k in (100,160):assert len(outcome[f'active{k}'])==json.loads(signed['residue'])[str(k)]
        rows[name][arm]=outcome
    assert not expected and len(rows)==80 and all(len(x)==2 for x in rows.values())
    print(json.dumps(dict(by_map={m:totals({k:v for k,v in rows.items() if v['v25']['map']==m}) for m in (2,3)},
                          paired=totals(rows),rows=rows),indent=2))

if __name__=='__main__':main()
