"""Only verified submitted tapes. Never opens a solver or tester."""
import collections,hashlib,itertools,json,re,sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008'
I=R/'ahc008_terry_incoming_shadow/held100'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mask(i):
    return sum({B[p] for p in i})
def cells(x):
    while x:
        bit=x&-x
        yield bit.bit_length()-1
        x^=bit
def terrain():
    t=(R/'ahc008_terry_exact_maps/terrain_data.inc').read_text()
    out=[]
    for i,g in enumerate(re.split(r'// map \d\s*\n',t)[:-1]):
        rows=re.findall(r'\{((?:0x[0-9a-f]+u,){4}0x[0-9a-f]+u)\}',g)
        assert len(rows)==5
        values=[[int(z[:-1],16) for z in r.split(',')] for r in rows]
        planned=doors=0
        for r in range(30):
            z=0 if r==0 else 1 if r%2==0 else 3 if r%4==3 else 4 if i==4 and r%8==5 else 2
            w,a,b,c,d=values[z]
            planned|=w<<(r*30)
            doors|=(a|b|c|d)<<(r*30)
        out.append((planned,doors))
    assert [a.bit_count()for a,b in out]==[335,290,260,233,284]
    assert [b.bit_count()for a,b in out]==[60,90,120,135,96]
    return out
def snapshot(wall,people,pets):
    open_=ALL^wall
    known=[]; union=0
    for h in people:
        reach=next((v for v in known if v&B[h]),0)
        if not reach:
            reach=flood(B[h],open_);union|=reach
        known.append(reach)
    inaccessible=sum(1<<i for i,p in enumerate(pets)if not union&B[p])
    return inaccessible,known,union
def analyze_board(record,ts):
    name=record['case']; case=I/'in'/name
    a=D/'tapes'/Path(name).with_suffix('.actions'); tape=a.with_suffix('.trace')
    assert sha(case)==record['input_sha'] and sha(a)==record['commands_sha'] and sha(tape)==record['trace_sha']
    commands=a.read_text().splitlines();trace=tape.read_text().splitlines()
    assert len(commands)==300 and commands==trace[::2]
    kinds,history,_=observed(case.read_bytes(),trace)
    hist=[([idx(p) for p in ps],[idx(h) for h in hs],mask(map(idx,w)))for ps,hs,w in history]
    x,gates=ts[record['map']]
    counts=collections.Counter(); option=[]; local=set()
    for t in range(275):
        p,h,w=hist[t]; _,h1,w1=hist[t+1]
        eligible=(w1&~w)&~x
        if not eligible:continue
        assert not eligible&~gates,(name,t,list(cells(eligible&~gates)))
        counts.update(turns=1,all_eligible_placed=eligible.bit_count())
        old_id,_,_=snapshot(w,h,p)
        new_id,stock_exterior,_=snapshot(w1,h1,p)
        gain=new_id&~old_id
        criterion='co_wall' if gain else 'no_new_id'
        counts[f'{criterion}_turns']+=1
        pool=list(cells(eligible))
        valid=[]
        for k in range(len(pool),0,-1):
            for c in itertools.combinations(pool,k):
                m=mask(c)
                alt_id,exterior,_=snapshot(w1^m,h1,p)
                if alt_id!=new_id:continue
                if any(old&~new for old,new in zip(stock_exterior,exterior)):continue
                valid.append((m,c))
        if valid:
            distinct={q for _,c in valid for q in c}
            counts[f'{criterion}_local_turns']+=1
            counts[f'{criterion}_local_tiles']+=len(distinct)
            local.update(distinct)
            option.append((t,criterion,gain,valid))
    p,h,w=hist[300]
    base,parts,union=snapshot(w,h,p)
    actual_full=base==(1<<len(p))-1
    assert actual_full==bool(record['actual_full'])
    result=dict(record,counts=dict(counts),local_candidate_tiles=sorted(local),
                local_options=[dict(turn=t,kind=k,newly_isolated_bits=g,subsets=[c for _,c in v])for t,k,g,v in option])
    if not actual_full:return result
    n=len(h); base_area=sum(v.bit_count()for v in parts)
    pet_floor=flood(mask(p),ALL^w)
    no_one=((ALL^w)&~(union|pet_floor)).bit_count()
    split=n*union.bit_count()-base_area
    budget=dict(planned_x=(w&x).bit_count(),extra_walls=(w&~x).bit_count(),pet_only=pet_floor.bit_count(),
                empty_unscored=no_one,human_split=float(Fraction(split,n)),mean_human_area=float(Fraction(base_area,n)))
    assert n*(900-budget['planned_x']-budget['extra_walls']-budget['pet_only']-no_one)==base_area+split
    freed=0; chosen=[]
    for t,k,g,subsets in option:
        for m,c in subsets:
            assert m&w==m and not m&freed
            alt,_,_=snapshot(w^(freed|m),h,p)
            if alt==base:
                chosen.append(dict(turn=t,kind=k,tiles=c));freed|=m
                break
    final,hr,_=snapshot(w^freed,h,p)
    gain=sum(v.bit_count()for v in hr)-base_area
    assert final==base and gain>=0
    result.update(area_budget=budget,jointly_safe=chosen,joint_tile_count=freed.bit_count(),
                  terminal_gain=float(Fraction(gain,n)),terminal_gain_exact=str(Fraction(gain,n)))
    return result
def main():
    ts=terrain()
    records=json.loads((D/'recordings.json').read_text())
    assert len(records)==100 and sum(r['actual_full']for r in records)==99
    rows=[analyze_board(r,ts)for r in records]
    counts=collections.Counter()
    for row in rows:counts.update(row['counts'])
    full=[r for r in rows if r['actual_full']]
    positive=[r for r in full if r['terminal_gain']>0]
    gate_tiles=sum(r['joint_tile_count']for r in positive)
    gain=sum((Fraction(r['terminal_gain_exact']) for r in positive),Fraction())
    budget={k:sum(r['area_budget'][k]for r in full)/99 for k in full[0]['area_budget']}
    q=dict(cases=100,full=99,local_boards=sum(bool(r['local_candidate_tiles'])for r in rows),
          local_tiles=sum(len(r['local_candidate_tiles'])for r in rows),counts=dict(counts),
          positive_gain_boards=len(positive),joint_count_on_positive_boards=gate_tiles,
          terminal_area_gain_total=float(gain),terminal_area_gain_exact=str(gain),
          gate=gate_tiles>=25 and len(positive)>=12,mean_factual_area_budget=budget,rows=rows)
    (D/'report.json').write_text(json.dumps(q,indent=2)+'\n')
    print(json.dumps({k:v for k,v in q.items() if k!='rows'},indent=2))
if __name__=='__main__':main()
