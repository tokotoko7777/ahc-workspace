"""Only insert local exact-work clock bypass into the pinned replay solver."""
import hashlib,os,sys
from pathlib import Path
BASE='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
out=Path(__file__).resolve().parent/'observer.private.cpp'
raw=Path(sys.argv[1]).read_bytes()
assert hashlib.sha256(raw).hexdigest()==BASE
src=raw.decode()
old=' const auto stop=started+std::chrono::milliseconds(limit_ms);'
new=''' const bool fixed_replay=std::getenv("AHC008_HUNT_FIXED_REPLAY")!=nullptr;
 if(fixed_replay && (cap<0 || cap>1000))return 2;
 const auto stop=fixed_replay?Clock::time_point::max():started+std::chrono::milliseconds(limit_ms);'''
assert src.count(old)==1
fd=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
with os.fdopen(fd,'w') as f:f.write(src.replace(old,new))
