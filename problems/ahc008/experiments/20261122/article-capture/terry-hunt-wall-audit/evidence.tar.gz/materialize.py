import csv,hashlib,json,re,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008'
I=R/'ahc008_terry_incoming_shadow/held100'
sys.path.insert(0,str(H))
from benchmark_cases import run
from benchmark import replay
def sha(x):return hashlib.sha256(x).hexdigest()
def main():
    tester,binary=(Path(x).resolve()for x in sys.argv[1:])
    p=I/'confirm.csv'
    assert sha(p.read_bytes())=='9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2'
    rows=[r for r in csv.DictReader(p.open())if r['arm']=='terry_independent']
    assert len(rows)==100 and len({x['case']for x in rows})==100
    target=D/'tapes';target.mkdir(exist_ok=False)
    summary=[]
    with tempfile.TemporaryDirectory() as q:
        q=Path(q)
        for row in rows:
            name=row['case']; raw=(I/'in'/name).read_bytes()
            assert sha(raw)==row['input_sha']
            mark=list(map(int,row['telemetry'].split())); assert len(mark)==15
            a=target/Path(name).with_suffix('.actions'); t=a.with_suffix('.trace')
            tel=q/'tel'
            out,err,code,wall=run([str(tester),'env','AHC008_HUNT_FIXED_REPLAY=1',
                                   'AHC008_TERRY_EXACT_LOG='+str(tel),str(binary),f'--pairs={mark[10]}'],raw,5.5)
            score=re.fullmatch(rb'Score = (\d+)\s*',err)
            assert code==0 and score and int(score[1])==int(row['score']),(name,code,err)
            assert sha(out)==row['commands_sha'],(name,'digest mismatch')
            assert list(map(int,tel.read_text().split()))==mark,(name,'telemetry mismatch')
            tel.unlink(); a.write_bytes(out)
            oo,ee,cc,_=run([str(tester),sys.executable,str(H/'benchmark_cases.py'),
                              '--playback',str(a),str(t)],raw,12)
            assert (oo,ee,cc)==(out,err,code)
            assert replay(raw.decode(),t.read_text().splitlines(),out.decode().splitlines(),detailed=True)[0]==int(row['score'])
            summary.append(dict(case=name,map=mark[0],input_sha=row['input_sha'],actual_full=int(row['full']),
                  score=int(row['score']),pairs=mark[10],commands_sha=row['commands_sha'],trace_sha=sha(t.read_bytes()),elapsed=wall))
            print(name,flush=True)
    (D/'recordings.json').write_text(json.dumps(summary,indent=2)+'\n')
if __name__=='__main__':main()
