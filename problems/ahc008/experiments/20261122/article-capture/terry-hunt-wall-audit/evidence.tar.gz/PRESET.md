# Submitted normal hunt co-wall omission census

Population is exactly the accepted incoming held100 ledger recorded
before this audit; this is an inherited held cohort, not a fresh holdout
for any potential omission policy. Every score/complete action/input
digest and exact original paired terminal count and scores must match.
Only audit invocation uses the clock bypass, at each already-recorded
pair count. All work remains bounded by process timeout; use original
default map, seeds, and actions. No test alternative may be executed.

For actual t<275 post-human state, planned-X actions and movements all
remain the same; every distinct installed wall from a lowercase
nonplanned-X command is a possible omission. Check these are nominal
hunt mouths. Compare all nonempty subsets of that turn's eligible
walls. Use *the same* observed current animal coordinates, before
their pet turn, and actual post-command human coordinates. Raw
success requires exact same all isolated pet-ID bits as actual
post-human plus every worker's new reachable set a superset. Initial
pre-command stock snapshot gives old isolated IDs; distinguish actual
no-new-capture turns from co-walls in a stock turn isolating new IDs.
Distinct tile IDs are counted within board; no addition of overlapping
subset sizes or attribution of causality to earlier wall omission.

Separately, on the 99 original full boards use physically fictional
final wall deletion to test whether locally removable wall tiles can
be jointly opened without connecting any pet to any human. Enforce
compatible locally valid subsets on the same turn. Deterministic
constructive lower bound: chronological turns, accept the largest
feasible local subset with current final jointly-open set, ties
by row-major tile tuples. No retry/order change. Calculate weighted
per-human component-area gain and require positive gain. Advance only
if at least 25 unique tiles in this joint certificate on at least 12
different positive-gain boards. No gate changes after inspection.
This is not a legal game action, no pet positions projected onto new
paths, no guarantee earlier skip would preserve actual capture or score.

Compute and publish missing-area budget per actual full terminal state:
planned X / extra walls / pet-only floor / no-human/no-pet floor /
human split (union minus per-person mean) / scored per-human mean.
