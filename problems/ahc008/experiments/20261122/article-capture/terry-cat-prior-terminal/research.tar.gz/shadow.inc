// detached harness, generated after the accepted source; never interactive
namespace terminal_shadow {
using namespace terry_exact_root;
using Post=std::array<double,latent_public::N+1>;
constexpr int sentinel=-1;
struct Draw{int raw=sentinel;double retry=0.;};
uint64_t mix(uint64_t v){
 v=(v^(v>>30))*0xbf58476d1ce4e5b9ULL;
 v=(v^(v>>27))*0x94d049bb133111ebULL;
 return v^(v>>31);
}
double rnd(uint64_t seed,int i,uint64_t salt){
 return double(mix(seed^mix(uint64_t(i)+0x9e3779b97f4a7c15ULL)^salt)>>11)*0x1p-53;
}
std::vector<Draw> initializer(char model,uint64_t seed,const std::vector<int>& active,
                              const std::vector<Post>& probs){
 std::vector<Draw> out;
 for(int i:active){
  Draw a;
  a.retry=rnd(seed,i,0x85d2ab6f3e5ac112ULL);
  if(model=='P'){
   double q=rnd(seed,i,0x639d87df97086637ULL);
   for(int j=0;j<V;++j){
    q-=probs[i][j];
    if(q<0){a.raw=j;break;}
   }
  }
  out.push_back(a);
 }
 return out;
}
struct ResetStats {int sentinel=0,invalid=0,keep=0;};
void assign(State& s,const std::vector<int>& active,const std::vector<Draw>& draw,ResetStats& count){
 for(int j=0;j<(int)draw.size();++j){
  auto& p=s.pets[active[j]];
  int x=draw[j].raw;
  Dist d;bfs(s.walls,p.pos,d);
  if(x>=0&&d[x]>0&&d[x]<INF){p.target=x;++count.keep;continue;}
  if(x<0)++count.sentinel;else ++count.invalid;
  int cells[V],n=0;
  for(int q=0;q<V;++q)if(d[q]>0&&d[q]<INF)cells[n++]=q;
  p.target=n?cells[std::min(n-1,int(draw[j].retry*n))]:-1;
 }
}
struct Score{int value;bool full,useful;};
Score result(const State& s){
 auto c=terrain_lib::labels(s.walls);
 std::vector<bool> used(c.count);std::vector<int> sizes(c.count);
 for(int p=0;p<V;++p)if(c.labels[p]>=0)++sizes[c.labels[p]];
 int area=0;for(int q:s.people){used[c.labels[q]]=true;area+=sizes[c.labels[q]];}
 bool full=true;for(auto p:s.pets)if(used[c.labels[p.pos]]){full=false;break;}
 return {score(s),full,full&&area>=300*(int)s.people.size()};
}
struct Replay{
 State s;std::vector<std::string> cmd;std::vector<std::vector<std::string>> pet;
 std::vector<int> active;
 std::vector<Post> probs;
};
Replay replay_public(State initial,std::istream& stream,Normal& normal){
 Replay r;
 r.s=initial;
 int n=initial.pets.size();
 for(int t=0;t<275;++t){
  std::string a,b;
  assert(std::getline(stream,a)&&std::getline(stream,b));
  assert(normal.step(r.s,t)==a);
  people_step(r.s,a);
  std::istringstream ss(b);std::vector<std::string> words(n);
  for(int i=0;i<n;++i){
   ss>>words[i];assert(ss);
   for(char x:words[i]){
    int d=move_dir(x);assert(d>=0);
    int p=nb[r.s.pets[i].pos][d];assert(p>=0&&!r.s.walls[p]);r.s.pets[i].pos=p;
   }
  }
  r.cmd.push_back(a);r.pet.push_back(words);
 }
 auto map=terrain_lib::labels(r.s.walls);
 int major=terrain_lib::majority_group(map,r.s.people);
 r.probs.resize(n);
 for(int i=0;i<n;++i)if(r.s.pets[i].type==5&&map.labels[r.s.pets[i].pos]==major){
  r.active.push_back(i);r.probs[i][V]=1;
 }
 if(r.active.empty())return r;
 State z=std::move(initial);
 for(int t=0;t<275;++t){
  people_step(z,r.cmd[t]);latent_public::State light;
  for(int i=0;i<V;++i)light.walls[i]=z.walls[i];
  for(int i:r.active){
   auto x=latent_public::decode(z.pets[i].pos,light.walls,r.pet[t][i]);
   latent_public::cat(light,z.pets[i].pos,x,r.probs[i],true);
   z.pets[i].pos=x.end;
  }
 }
 return r;
}
int evaluate(std::string mode,const char* in,const char* tape){
 std::ifstream x(in),y(tape);
 int n,m;x>>n;
 State s;std::array<int,5> counts{};
 for(int i=0;i<n;++i){int r,c,k;x>>r>>c>>k;s.pets.push_back({(r-1)*30+c-1,k,-1});++counts[k-1];}
 x>>m;
 for(int i=0;i<m;++i){int r,c;x>>r>>c;s.people.push_back((r-1)*30+c-1);}
 assert(x&&y);
 const auto& land=terrain_lib::terrain(terry_exact_selector::choose(m,counts));
 Normal initial(land,s);
 const auto r=replay_public(s,y,initial);
 std::cout<<"active";
 for(int i:r.active)std::cout<<','<<i;
 std::cout<<'\n';
 if(mode=="H8"||mode=="H8native"){
  if(mode=="H8native"){
   auto d=decide(r.s,initial,8,Clock::time_point::max());
   assert(d.pairs==8);
   std::cout<<"stock,"<<d.normal<<','<<d.chase_sum<<'\n';
   return 0;
  }
 } else if(r.active.empty())return 0; // all mechanisms exactly H: no active initializer
 const auto first=chase(r.s,land,275);
 const bool check=mode=="H8";
 assert(check||mode=="model");
 for(char model:std::string(check?"H":"HUP")){
  for(int block=0;block<(check?1:2);++block){
   auto ordinary=initial;
   for(int trial=0;trial<(check?8:32);++trial){
    // H8 block derived from stock iteration; shadow blocks domain separated.
    const uint64_t seed=check?998244353ULL*(trial+1):
     mix((block?0x084a76d91e23dcd1ULL:0xe25caf53780713cbULL)+trial);
    auto left=r.s,right=r.s;
    const auto draw=model=='H'?std::vector<Draw>{}:initializer(model,seed,r.active,r.probs);
    ResetStats nl,cl;
    auto ordinary_rng=ordinary.rng;
    ordinary.rng=Pcg(42);
    ChaCha a(seed),b(seed);
    for(int t=275;t<300;++t){
     people_step(left,ordinary.step(left,t));
     if(t==275&&model!='H')assign(left,r.active,draw,nl);
     actual_motion(left,a);
    }
    ordinary.rng=ordinary_rng; // preserve stock crew/topology progression within block
    for(int t=275;t<300;++t){
     people_step(right,t==275?first:chase(right,land,275));
     if(t==275&&model!='H')assign(right,r.active,draw,cl);
     actual_motion(right,b);
    }
    auto A=result(left),B=result(right);
    std::cout<<model<<','<<block<<','<<trial<<','<<A.value<<','<<B.value<<','
     <<A.full<<','<<A.useful<<','<<B.full<<','<<B.useful<<','
     <<nl.sentinel<<','<<nl.invalid<<','<<nl.keep<<','
     <<cl.sentinel<<','<<cl.invalid<<','<<cl.keep<<'\n';
   }
  }
 }
 return 0;
}
}
int main(int argc,char** argv){
 if(argc!=4)return 2;
 std::ios::sync_with_stdio(false);
 return terminal_shadow::evaluate(argv[1],argv[2],argv[3]);
}
