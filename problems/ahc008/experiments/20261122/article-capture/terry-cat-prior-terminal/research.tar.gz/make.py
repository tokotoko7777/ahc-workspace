"""Generate a detached local executable from pinned exact sources; no run."""
from pathlib import Path
from hashlib import sha256
D=Path(__file__).resolve().parent
W=D.parent
def read(path,sha):
    b=(W/path).read_bytes()
    assert sha256(b).hexdigest()==sha,path
    return b.decode()
csr=read('ahc008_terry_chase_csr_integrate/solve.private.cpp',
    '9ba280d498e2fde5e33004d3d5102a930576a385b372ae35d5d829194a683509')
stock=read('ahc008_terry_split_bound/solve.private.cpp',
    'f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088')
latent=read('ahc008_terry_target_active275/observer.cpp',
    'd83710cadeeb3f4e88bf5f74f922da3d64a8f2ca0b2322e0a9bba910dac2ebf3')
inc,code=latent.split('constexpr int N=900,M=10;',1)
latent=inc+'\nnamespace latent_public {\nconstexpr int N=900,M=10;'+code.split('\nint main(',1)[0]+'\n}\n'
def stem(src):
    assert src.count('\nint main(')==1
    return src.split('\nint main(',1)[0]
for label,base in [('csr',csr),('stock',stock)]:
    (D/f'{label}.private.cpp').write_text(stem(base)+'\n'+latent+'\n'+(D/'shadow.inc').read_text())
