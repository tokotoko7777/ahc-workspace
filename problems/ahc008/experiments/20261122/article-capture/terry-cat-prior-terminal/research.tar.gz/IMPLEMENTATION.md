# Detached implementation, not run

Run only after approval for exclusive CPU time. The bundled C++ program never
invokes an official judge. The runner checks two archived independently
validated forced outcome ledgers (Normal is arm v25 solely by naming, Chase
terry_independent), forced-Chase tape bytes and exact shared action prefix.
The observer validates every reconstructed Normal command before t275 to
reconstruct crew/topology/RNG, not just board. It consumes no t275 tape
commands, moves, factual outcomes, mode assignments, or judge seed suffix.

```sh
D=ahc008_terry_cat_prior_terminal
(cd "$D" && sha256sum -c FROZEN.sha256)
python "$D/make.py"
g++ -std=c++23 -O3 "$D/csr.private.cpp" -o "$D/csr"
python "$D/run.py" "$D/csr" model > "$D/result.json"
```

The preceding command validates **all 800 historical stock H8 Normal/Chase
score pairs point-for-point** before any model work. Use the same runner's
`verify` mode to run only that fatal correctness check if needed. Optional
diagnostic generation includes the original f83 without CSR; it is subject
to the same replay and H8 verification. Treat any source, tape, shared prefix,
pre-action active set, replayed order or H8 disagreement as fatal, with no
partial model result. CSR is a previously verified diagnostic-only fixed-work
optimization. There is no internal native timer; the external 25s per-case
guard fails the entire test rather than stop after a reduced trial count.

The two locked blocks have 32 complete pairs per model, which is 8,640
model pairs across 45 eligible boards plus 800 reference pairs (9,440
total). The 55 no-active-cat boards are modeled only for H8 verification.
For main blocks, no initializer calls would execute and all three variants
would be byte-identical within each case and seed: the same copied ordinary
state, first Chase action, seeds, call order and stock ordinary queue
progression. Their all100 treatment deltas are therefore exactly zero;
absolute totals are reported for active45 only, with no invented
all100 absolute or unobserved sign-agreement totals. Approximate total CPU
expected one to three minutes; long-tail flow and Normal forecasting could
make four minutes a conservative upper budget.

The initializer's one-step independent salt streams are fixed. Untargeted
pets keep all stock target selection code; random-stream alignment can
diverge causally after an active cat's modified RNG draw count. H vs U
quantifies plumbing rather than attributing it to the inferred prior.
