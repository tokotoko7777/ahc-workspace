# Detached cat-only t275 prior: dual forced outcome QA (design only)

## Inputs and null
Use the selected K8 conditional 100, exact accepted f83 0–274 prefix and
identical public t275 snapshot in both branches. Before computing predictions,
freeze exact source, selected input and prefix manifests, tape hashes, verified
complete actual forced-Normal and forced-Chase scores and full/useful flags,
fixed recorded policy/config semantics and the seed blocks. Forced pair labels
must start at the same pre-action state and use actual unchanged judge
randomness; verify every pair. If a complete genuine forced-Normal outcome is
missing (e.g. a proposed command trace or “Normal preview” is not a continuation),
do not substitute a preview or use native selected outcomes. Stop. Mask labels,
native mode, source seed suffix and case identifier from the evaluator. Identifier
can be attached externally only for join/reporting. Experimental population is
all100 and the predeclared active-cat subgroup: at least one cat in the
largest-human component at t275 before either hypothetical action. No panels,
cuts, policy thresholds or model parameters chosen by outcomes.

Freeze two independent blocks of 32 complete paired trials, identical indexed
seeds for every board, separate from initializer salts. No time-varying stopping,
appeal to baseline retained pair counts, or comparison of incomplete pairs.
Historical comparator H uses the existing uniform cat reselect using its normal
judge stream. Control U explicitly initializes cat targets with separate common
draw plumbing and uses the same code path as posterior P. P filters from t0 to
t274 solely on observed human commands, walls/positions and pet strings; use
only t275 pre-human snapshot and posterior as input. Use no observed t275 action
from either forced tape. Can validate historical H via frozen fixed-work
reference branch sums and/or exact deterministic fixtures before comparing,
and fully report H–U differences; primary is P vs U only. Do not treat
H–U as predictor lift. Record all blocked/coincident/reset decisions per arm.

## Sampling and law
For each existing eligible cat ID and trial, draw one common quantile from
the fixed initializer stream and sample a *raw* posterior category (a valid
persistent target cell or reset sentinel) before any policy step. P keeps any
valid concrete sample common to Normal and Chase; U starts at sentinel. For
each branch, after its own first simulated human action, test that category:
blocked, disconnected or coincident is invalid and reselects exactly like
reset. Use the same second independent initializer quantile for both branches
and U/P to choose among that branch's row-major reachable non-current cells.
Thus a reset/invalid branch may select a different cell due to different
geometry; forcibly sharing one geometrically valid coordinate would bias the
joint law. All later directed ties, uniform second substeps and hit resets
follow official cat motion, with no initializer steering; noneligible cats
and all dogs are identical to controls. The judge's wall/people action order
is preserved. Keep subsequent judge seed, policies, their own RNG seeds,
timing-argument quirks, and original construction-queue semantics frozen
within each mode/model. Reinitialize each model/seed *block* from the
unmodified t275 snapshot including construction queue and ordinary RNG. If
the baseline intentionally carries queue mutations across trials within a
block, preserve it and report divergence as downstream; never carry a queue
between models/blocks. No factual construction queue reconstructed from
t275+ tape. Common random streams need not stay identical after branches
consume different amounts of RNG; track paired covariance, not independence.

## Outputs and prospective gate
For each case/model/block publish pairs, Normal/Chase normalized-score sample
sums, means, per-pair covariance, standard error of within-pair score
difference, full/useful estimates, and sign of Chase minus Normal (ties use
Normal). Report both separate blocks and pooled sign; covariance across
initializer models should also be logged by pairing identical block+trial
indices. Check no-case/no-mode inputs into the policy and P/U byte-equivalent
predictions for no-active-cat cases before target labels are joined.

On the real paired forced labels, report on all100 and active-cat subset:
sign agreement on non-ties, count of corrected vs spoiled choices relative to
U, realized selected score sum, exact full/useful counts, and regret against
the per-case max of the two factual forced scores. Single factual paired judge
trajectory is noisy relative to model expectation; no causal benefit beyond
this frozen panel and no oracle/national-rank claim.

A meaningful diagnostic pass requires all verified paired labels and all
model work complete; at least 12 eligible active-cat cases with non-tied
factual forced outcomes and at least four repeat forecast sign flips (P vs U)
in the same direction in both blocks, with posterior absolute mean margin
≥1m in each block. Among these repeat flips, ≥3 corrected and ≤1 spoiled.
Additionally pooled selection must gain ≥20m actual forced score over U across
all100, with no drop in exact full/useful counts; report native mode only
if separately needed for provenance, never for the metrics here. Require
the gain not be driven solely by plumbing: posterior must also have positive
observed score delta versus H (secondary, no threshold optimization).

If all pass, freeze the identical comparator/thresholds again and apply once
to a genuinely independent K8-like active sample from new official-generator
inputs; freeze unbiased case acceptance based only on public t275 activity,
before scoring any outcome, no reuse of this 100. Require the same gates and
report attrition/matched prefixes. This conditional confirmation is not an
unconditional score estimate: before changing a solver, would need separately
authorized, broader native-timing held verification confirming legal outputs,
runtime reserve and repeat score/useful gains. Never promote a candidate merely
for first-step calibration. If any gate fails, archive and stop.
