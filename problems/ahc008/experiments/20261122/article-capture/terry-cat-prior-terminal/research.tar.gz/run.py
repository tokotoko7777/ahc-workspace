"""Fixed work verifier and detached prediction runner, no official process."""
import csv, hashlib, json, math, statistics, subprocess, sys
from pathlib import Path

D=Path(__file__).resolve().parent
W=D.parent
K=W/'ahc008_terry_terminal_k8'/'dev'
F=W/'ahc008_terry_clean_normal_preview'
A=W/'ahc008_terry_target_active275'
pins={
 K/'manifest.json':'5c2877a6733e3bb454096d3f2da17f830899a1bfd047c485b2707a3c6480399d',
 K/'official.csv':'54ec41b7e157b8586841a019b4d71ba51ea7f2a289af5e2d3b31904f845bd218',
 K/'shadow.json':'76a5038e61615d25c9dcecf1c21f9e6669c2b02b2f92a649f63b5459d3ff5f75',
 F/'recordings.json':'4d45b441e35e56287ddaad4986c78bed0deba07057fa29a52bc40b2bbff42f2c',
 A/'events.local.json':'97dc7ad310baff731f0d67caf8a8dba335ba124e64b2ade351bfc1ab80f1f2c6',
}
def sha(x):return hashlib.sha256(x).hexdigest()
def sub(exe,mode,inp,tape):
    out=subprocess.check_output([exe,mode,inp,tape],text=True,timeout=25)
    a,*rows=list(csv.reader(out.splitlines()));assert a[0]=='active'
    return list(map(int,a[1:])),rows
def validate(path):
    for p,h in pins.items():assert sha(p.read_bytes())==h,p
    selected={r['case']:r for r in json.loads((K/'manifest.json').read_bytes())['selected']}
    forced=json.loads((F/'recordings.json').read_bytes())
    expected={r['case']:r['pairs'] for r in json.loads((K/'shadow.json').read_bytes())}
    active={}
    for c,row in json.loads((A/'events.local.json').read_bytes())['5']:
        active.setdefault(c,[]).append(int(row[1]))
    assert len(selected)==len(forced)==len(expected)==100 and len(active)==45
    official={}
    for row in csv.DictReader((K/'official.csv').open()):
        c=row['case'];m=row['arm'];assert m in ('v25','terry_independent')
        k='N' if m=='v25' else 'C'
        lost=official.setdefault(c,{})
        assert k not in lost
        lost[k]=row
    pending={}
    for r in forced:
        c=r['case']; rec=selected[c]
        inp=K/'selected'/c
        action=(F/'tapes'/c).with_suffix('.actions');trace=action.with_suffix('.trace')
        ia,aa,ta=[p.read_bytes() for p in (inp,action,trace)]
        al=aa.splitlines();tl=ta.splitlines()
        assert len(al)==300 and len(tl)==600 and al==tl[::2]
        sx=sha(b'::'.join(al[:275])); assert sx==rec['prefix_sha']
        assert sha(ia)==r['input_sha']==rec['sha256']
        assert sha(aa)==r['actions_sha'] and sha(ta)==r['trace_sha']
        for k,z in official[c].items():
            assert z['prefix_sha']==sx and z['input_sha']==r['input_sha']
            if k=='C':assert z['commands_sha']==r['actions_sha']
        pending[c]=(inp,trace)
    assert set(pending)==set(selected)==set(official)==set(expected)
    # First validate all historical pair vectors, with no P/U runs in this phase.
    verified={}
    for c,(inp,trace) in pending.items():
        ids,rows=sub(path,'H8',inp,trace)
        assert ids==sorted(active.get(c,[])),(c,'active identity')
        got=[[int(z[3]),int(z[4])]for z in rows]
        assert got==expected[c],(c,'H8 history differs')
        assert all(z[:2]==['H','0'] and int(z[2])==i for i,z in enumerate(rows))
        verified[c]=got
    return pending,active,verified,official

def covariance(x,y):
    return statistics.covariance(x,y)
def mark(rows):
    m=[[int(r[i]) for r in rows] for i in range(3,13)]
    x,y=m[:2]; ds=[b-a for a,b in zip(x,y)]
    return dict(n=len(rows),n_sum=sum(x),c_sum=sum(y),delta=statistics.mean(ds),
        n_mean=statistics.mean(x),c_mean=statistics.mean(y),
        covariance=covariance(x,y),stderr=statistics.stdev(ds)/math.sqrt(len(ds)),
        n_full=sum(m[2]),n_useful=sum(m[3]),c_full=sum(m[4]),c_useful=sum(m[5]))
def signs(s):return int(s['delta']>0)
def stats(rows):
    out={m:{} for m in 'HUP'}
    for model in out:
        own=[r for r in rows if r[0]==model]
        for b in ('0','1'):
            b_rows=[r for r in own if r[1]==b]
            assert len(b_rows)==32 and [int(r[2])for r in b_rows]==list(range(32))
            out[model][b]=mark(b_rows)
        out[model]['pooled']=mark(own)
        out[model]['init_counts']=[sum(int(r[i])for r in own)for i in range(9,15)]
    for b in ('0','1'):
        for model in 'HP':
            u=[int(r[4])-int(r[3]) for r in rows if r[:2]==['U',b]]
            c=[int(r[4])-int(r[3]) for r in rows if r[:2]==[model,b]]
            out[model][b]['covariance_delta_with_U']=covariance(u,c)
    return out

def judge(out,locked):
    choices={m:{} for m in 'HUP'};repeat=[]
    for c,s in out.items():
        for m in choices:choices[m][c]='C' if signs(s[m]['pooled']) else 'N'
        dx=[signs(s['P'][b])-signs(s['U'][b]) for b in ('0','1')]
        if dx[0] and dx[0]==dx[1] and min(abs(s['P'][b]['delta']) for b in ('0','1'))>=1e6:
            real=int(locked[c]['C']['score'])-int(locked[c]['N']['score'])
            repeat.append((c,dx[0],real))
    def tally(picks):
        q=[locked[c][k]for c,k in picks.items()]
        ret={n:sum(int(z[n])for z in q) for n in ('score','full','useful300')}
        ret['regret']=sum(max(int(x['score'])for x in locked[c].values())-int(locked[c][k]['score'])
                          for c,k in picks.items())
        ret['non_tie_correct']=sum(int(locked[c][k]['score'])>int(locked[c]['N' if k=='C' else 'C']['score'])
                                   for c,k in picks.items())
        return ret
    counts={m:tally(p)for m,p in choices.items()}
    delta={m:{k:counts['P'][k]-counts[m][k] for k in counts['P']}for m in 'HU'}
    better=sum(real*sgn>0 for _,sgn,real in repeat)
    worse=sum(real*sgn<0 for _,sgn,real in repeat)
    n_unequal=sum(z['N']['score']!=z['C']['score'] for c,z in locked.items() if c in out)
    gate=n_unequal>=12 and len(repeat)>=4 and better>=3 and worse<=1 and delta['U']['score']>=20000000 and delta['U']['full']>=0 and delta['U']['useful300']>=0 and delta['H']['score']>0
    return dict(pass_gate=gate,non_tied_active=n_unequal,repeat=repeat,repeated_corrected=better,
                repeated_spoiled=worse,active_absolute=counts,active_and_all100_deltas=delta,
                absolute_all100_omitted='55 identical noneligible cases structurally bypassed',
                picks=choices)

def main():
    exe=Path(sys.argv[1]).resolve()
    p,active,verified,labels=validate(exe)
    if len(sys.argv)==3 and sys.argv[2]=='verify':
        print(json.dumps(dict(verified=len(verified),expected_pair_vectors=verified),indent=2))
        return
    assert len(sys.argv)==3 and sys.argv[2]=='model'
    outputs={}; raw={}
    for c in active:
        ids,rows=sub(exe,'model',*p[c])
        assert ids==sorted(active[c]) and len(rows)==192
        raw[c]=rows; outputs[c]=stats(rows)
    print(json.dumps(dict(verified_h8=len(verified),summary=judge(outputs,labels),
                          case_stats=outputs,raw_rows=raw),indent=2))
if __name__=='__main__':main()
