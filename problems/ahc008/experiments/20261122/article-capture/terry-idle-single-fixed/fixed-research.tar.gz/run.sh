#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=ahc008_terry_idle_single_fixed
H=ahc008_terry_virtual_chase_absorb
A=ahc008_focus_assets/tools/in
F=ahc008_terry_first_chase_reuse/default-fresh100/in
sha256sum -c "$D/SOURCE.sha256"
case "${1:-}" in
 compile)
  test ! -e "$D/baseline_fixed" && test ! -e "$D/candidate_fixed"
  for x in baseline candidate; do
    g++ -std=gnu++23 "$D/${x}_fixed.private.cpp" -o "$D/${x}_fixed"
  done
  sha256sum "$D/"{baseline_fixed,candidate_fixed} > "$D/BIN.sha256"
  ;;
 measure)
  sha256sum -c "$D/BIN.sha256"
  test ! -e "$D/practice.csv" && test ! -e "$D/fresh.csv"
  python3 "$D/bench.py" "$A" "$H/practice.native.csv" "$D/practice.csv" | tee "$D/practice.log"
  python3 "$D/bench.py" "$F" "$H/fresh.native.csv" "$D/fresh.csv" | tee "$D/fresh.log"
  ;;
 *) exit 2;;
esac
