from pathlib import Path
from hashlib import sha256
D=Path(__file__).resolve().parent;R=D.parent
Q=R/'ahc008_terry_idle_single'
a=(R/'ahc008_terry_virtual_chase_absorb/candidate.private.cpp').read_bytes()
assert sha256(a).hexdigest()=='a237f7986e03ba94e98cfb6f1d2059f50d87305f6c8a82b1fa6d4ccd5f013f22'
a=a.decode()
def patch(s,x,y):
    assert s.count(x)==1
    return s.replace(x,y)
stop=' const auto stop=started+std::chrono::milliseconds(limit_ms);'
a=patch(a,stop,''' const bool fixed_audit=std::getenv("AHC008_IDLE_SINGLE_FIXED")!=nullptr;
 if(fixed_audit&&cap>10000)return 2;
 const auto stop=fixed_audit?Clock::time_point::max():started+std::chrono::milliseconds(limit_ms);''')
sig='inline void idle_phase(const State& s,const std::vector<int>& columns,std::vector<char>& action){'
phase=sig+a.split(sig,1)[1].split('\n}\n}',1)[0]+'\n}'
b=patch(phase,' for(int i=0;i<m;++i)if(!action[i])bfs(w,s.people[i],dist[i]);',(Q/'single.inc').read_text())
b=patch(b,' for(int col:columns){',' for(int col:columns){\n'+(Q/'branch.inc').read_text())
for tag,s in [('baseline',a),('candidate',patch(a,phase,b))]:
    (D/f'{tag}_fixed.private.cpp').write_text(s)
b=(R/'ahc008_terry_virtual_chase_absorb/bench_amended.py').read_text()
b=patch(b,'AHC008_VIRTUAL_ABSORB_FIXED=1','AHC008_IDLE_SINGLE_FIXED=1')
b=patch(b,"('positive_rollout',lambda r:r['draws']>0)","('positive_rollout',lambda r:r['draws']>0),('no_rollout',lambda r:r['draws']==0)")
b=patch(b,"z['positive_rollout']['reduction']>0","z['no_rollout']['candidate_us']<=z['no_rollout']['baseline_us']")
(D/'bench.py').write_text(b)
