"""Serial alternating fixed-work exact speed + shared independent replay."""
import csv,sys,re,tempfile,json,hashlib,shutil
from pathlib import Path
from statistics import median
D=Path(__file__).resolve().parent;R=D.parent
H=R/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark_cases import run
from benchmark import replay
T=R/'ahc008_focus_assets/tools/target/release/tester'; TIME=R/'ahc008_terry_speed/time'
A=D/'baseline_fixed';B=D/'candidate_fixed'
src,ledger,dst=(Path(p)for p in sys.argv[1:]);rows=[r for r in csv.DictReader(ledger.open())if r['arm']=='terry_independent'];assert len(rows)==100
out=[]
for i,r in enumerate(rows):
 name=r['case']; raw=(src/name).read_bytes(); assert hashlib.sha256(raw).hexdigest()==r['input_sha']
 mark=list(map(int,r['telemetry'].split())); assert len(mark)==15
 with tempfile.TemporaryDirectory()as q:
  q=Path(q); cpu=q/'cpu'; tel=q/'tel'; act=q/'act'; tape=q/'trace'; arms=[('baseline',A),('candidate',B)]
  for tag,binary in (arms if i%2==0 else arms[::-1]):
   args=[str(T),str(TIME),str(cpu),shutil.which('env'),'AHC008_TERRY_EXACT_LOG='+str(tel),'AHC008_IDLE_SINGLE_FIXED=1',str(binary),f'--pairs={mark[10]}']
   a,e,rc,w=run(args,raw,4.5)
   assert rc==0 and (got:=re.fullmatch(rb'Score = (\d+)\s*',e)),(name,tag,rc,e)
   assert w<2.95,(name,tag,'external_wall_gate',w)
   digest=hashlib.sha256(a).hexdigest(); now=list(map(int,tel.read_text().split())); sc=int(got[1])
   assert len(now)==15 and now[-1]==sc and now[10]==mark[10],(name,tag,now,mark)
   observed=(digest,now)
   if tag==arms[i%2][0]: prior=observed
   else: assert observed==prior,(name,tag,observed,prior)
   out.append(dict(case=name,arm=tag,score=sc,draws=now[10],
       normal_sum=now[11],chase_sum=now[12],mode=now[13],commands_sha=digest,cpu_us=int(cpu.read_text()),wall=w,
       history_command_match=int(digest==r['commands_sha']),history_score_match=int(sc==int(r['score'])),
       history_telemetry_match=int(now==mark),historical_fields_changed=' '.join(str(i) for i,(old,new)in enumerate(zip(mark,now)) if old!=new)))
  act.write_bytes(a)
  assert run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',str(act),str(tape)],raw,12)[:3]==(a,e,rc)
  assert replay(raw.decode(),tape.read_text().splitlines(),a.decode().splitlines(),detailed=True)[0]==sc
 with dst.open('w')as f:
  wr=csv.DictWriter(f,out[0].keys());wr.writeheader();wr.writerows(out)
 print(name,flush=True)
z={}
for label, eligible in [('all',lambda r:True),('positive_rollout',lambda r:r['draws']>0),('no_rollout',lambda r:r['draws']==0)]:
 a,b=([r for r in out if r['arm']==k and eligible(r)]for k in ('baseline','candidate'))
 u,v=(sum(r['cpu_us']for r in arm)for arm in (a,b))
 z[label]=dict(n=len(a),baseline_us=u,candidate_us=v,reduction=1-v/u,max_wall=max(r['wall']for r in a+b))
z['historical_diagnostics']={k:sum(not r[k] for r in out if r['arm']=='baseline') for k in ('history_command_match','history_score_match','history_telemetry_match')}
z['pass']=z['all']['reduction']>=.02 and z['no_rollout']['candidate_us']<=z['no_rollout']['baseline_us'] and z['all']['max_wall']<2.95
dst.with_suffix('.json').write_text(json.dumps(z,indent=2)+'\n')
print(json.dumps(z))
if not z['pass']:raise SystemExit(3)
