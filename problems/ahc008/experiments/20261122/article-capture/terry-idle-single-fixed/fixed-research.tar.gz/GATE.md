# Selected a237 exact fixed-work admission: one-worker aisle shortcut

Local benchmark preparation only. Candidate and baseline both start from
selected a237f7986e03ba94e98cfb6f1d2059f50d87305f6c8a82b1fa6d4ccd5f013f22.
Only independent tested single-worker snippet differs between arms. Both
include the same audit-only inactive deadline option from the preceding
absorption fixed-work comparison, retaining the internal checks and
numeric work cap. Never use this option in a default solver.

Distributed100 first, then existing independent100 only if distributed
passes. Use recorded accepted a237 native candidate arm from paired
absorption for each historical work cap, retaining original inputs,
order and RNG. Require both arms to complete that exact cap. Alternate
baseline-first/candidate-first by input in serial paired process CPU.
Always require tester exit legality and strictly <2.95s external tester
wall on each measured arm run; guard process timeout 4.5s. Equal complete
actions and all 15 telemetry values including terminal Normal/Chase
sums and mode; equal official score, plus official playback and
independent score on the common identical action stream. Historical
ledger action/score/full telemetry differences are separately reported,
not considered matched-arm errors. Stop on any failure, no retry.

Each panel requires at least 2% measured whole-process CPU aggregate
reduction and non-increasing no-rollout CPU aggregate (no tolerance).
Report positive-rollout separately without making it an extra gate.
No native score comparison or deployment in this task.

Commands after clearance from workspace:
    bash ahc008_terry_idle_single_fixed/run.sh compile
    bash ahc008_terry_idle_single_fixed/run.sh measure
Only publish independently written adapter/scaffold and ledgers/pins;
no generated private source, inputs, or compiled binaries.
