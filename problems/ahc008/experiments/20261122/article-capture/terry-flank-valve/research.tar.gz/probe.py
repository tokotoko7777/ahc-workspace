"""Snapshot certificates only; no solver, tester, score, or stochastic motion."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter
import json,sys
R=Path(__file__).resolve().parent.parent
E=R/'ahc008_focus_solver/problems/ahc008/experiments/20261122'
sys.path.insert(0,str(E))
from guarded_entry_trace import observed,STEPS
from stochastic_lock_audit import B,ALL,flood,wave,idx
T=R/'ahc008_terry_hunt_wall_audit'
I=R/'ahc008_terry_incoming_shadow/held100/in'
C1=R/'ahc008_terry_brace_valves/catalog.txt'
C2=R/'ahc008_terry_small_rooms/catalog.tsv'
PINS={T/'recordings.json':'dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5',
 C1:'37d2e7dd993018a902ead1053f4e92e036c8280b7a1b4a0a9a8f773396f64b41',
 C2:'2d697e1b2cbf0cd9d754d38a18059e2fbcd484b7440868da8016f8310132ba06'}
def digest(b):return sha256(b).hexdigest()
def mask(xs):return sum(B[x] for x in set(xs))
def step(p,s):
    x,y=STEPS[s.upper()]
    r,c=divmod(p,30)
    assert 0<=r+x<30 and 0<=c+y<30
    return p+30*x+y
def room_data():
    data={}
    rooms={}
    for line in C2.read_text().splitlines():
        m,i,a,b,*q=map(int,line.split())
        rooms[m,i]=(a,b,mask(q))
    for line in C1.read_text().splitlines():
        z=line.split()
        if z[0]!='valve':continue
        k,v,s,a,i,j,g0,g1,h0,h1=map(int,z[1:])
        assert v-1==s and s-1==a
        for rid,near,far in ((i,g0,g1),(j,h0,h1)):
            c=near+1
            b=rooms[k,rid][2]
            assert (near,far)==rooms[k,rid][:2] and B[c]&b and abs(v-c)==30
            data.setdefault(k,{})[b]=(v,s,near,far,c)
    return data

def snap(p,h,w):
    comps=[]
    for x in h:
        assert not B[x]&w
        comps.append(next((c for c in comps if c&B[x]),0) or flood(B[x],ALL^w))
    hu=0
    for c in comps:hu|=c
    unseen=sum(1<<i for i,x in enumerate(p) if not B[x]&hu)
    return comps,hu,unseen

def exact_room(w,cap,body):
    tail=body^B[cap]
    return flood(tail&-tail,ALL^w)==tail

def head_mask(p,b):return sum(1<<i for i,x in enumerate(p) if B[x]&b)

def read(rec):
    name=rec['case']; base=(T/'tapes'/name).with_suffix('')
    inp,act,trace=[p.read_bytes() for p in (I/name,base.with_suffix('.actions'),base.with_suffix('.trace'))]
    assert [digest(p) for p in (inp,act,trace)]==[rec[k] for k in ('input_sha','commands_sha','trace_sha')]
    cmd=act.decode().splitlines(); z=trace.decode().splitlines()
    assert len(cmd)==300 and len(z)==600 and z[::2]==cmd
    _,hist,_=observed(inp,z)
    return cmd,[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w))) for p,h,w in hist]

def board(rec,catalog):
    actions,hist=read(rec)
    p,h,w=hist[-1]
    assert bool(snap(p,h,w)[2]==(1<<len(p))-1)==bool(rec['actual_full'])
    seen=set(); rows=[]; tracked=catalog.get(rec['map'],{})
    if not tracked:return rows
    for t,a in enumerate(actions[:275]):
        p,h,w=hist[t]; _,nxt,w1=hist[t+1]
        if w==w1:continue
        jobs={i:step(h[i],ch) for i,ch in enumerate(a) if ch.islower()}
        assert w|mask(jobs.values())==w1
        old,_,was=snap(p,h,w)
        post,hu,now=snap(p,nxt,w1)
        gained=now&~was
        if not gained:continue
        block=mask(p)|wave(mask(p))
        for body,(v,s,near,far,cap) in tracked.items():
            if body in seen or not head_mask(p,body)&gained:continue
            if flood(body&-body,ALL^w1)!=body:continue
            seen.add(body)
            row={'turn':t,'before160':t<160,'baseline_room_heads':head_mask(p,body).bit_count(),
                 'zero_lag':False,'reserve':False}
            rows.append(row)
            own=[i for i,x in jobs.items() if x==near]
            oth=[i for i,x in jobs.items() if x==far]
            if len(own)!=1 or len(oth)!=1 or not w&B[v]:
                row['reject']='not_unique_installed_two_door';continue
            i=own[0];j=oth[0]
            assert i!=j and h[i]==near-1 and h[j]==far+1
            assert not mask(h)&B[v]  # hence no actual zero-lag stance
            if block&B[cap]:
                row['reject']='illegal_cap_pet';continue
            walt=(w1&~mask((v,near)))|B[cap]
            assert walt.bit_count()==w1.bit_count()-1
            if not exact_room(walt,cap,body):
                row['reject']='tail_not_exact';continue
            # Reserve must have a factual wait now, preserve all its
            # unrelated wall work (none), and hold the adjacent exterior
            # service cell in the observed t start. Preposition is a
            # hypothetical earlier step, NOT a legal same-turn move+build.
            reserves=[k for k,x in enumerate(h) if (k==i or a[k]=='.') and k!=j and x==s]
            if not reserves:
                row['reject']='no_one_step_reserve';continue
            protected=[]
            for k in reserves:
                pre=h[:]; pre[k]=v
                ends=nxt[:]; ends[k]=v
                if mask(pre)&B[cap] or mask(ends)&walt:continue
                # Pre-closure valve pose must be in same open exterior
                # component as its old reserve stance. Post-lock remains
                # connected to factual reserve cell from the real flank.
                if not flood(B[s],ALL^(w^B[v]))&B[v]:continue
                anew,un,iso=snap(p,ends,walt)
                if now&~iso:continue
                if not anew[k]&B[s]:continue
                if any(post[a]&B[nxt[b]] and not anew[a]&B[ends[b]]
                       for a in range(len(h)) for b in range(a)):continue
                if not (un&B[v] and un&B[near]):continue
                floor=Fraction(sum(c.bit_count() for c in anew)-sum(c.bit_count() for c in post),len(h))
                if floor<=0:continue
                protected.append((floor,iso&~now))
            if not protected:
                row['reject']='global_topology_or_no_net_floor';continue
            floor,extra=max(protected)
            row.update(reserve=True,net_local_mean_floor=str(floor),extra_heads=extra.bit_count())
    return rows

def main():
    for p,h in PINS.items():assert digest(p.read_bytes())==h
    catalog=room_data(); records=json.loads((T/'recordings.json').read_text())
    assert len(records)==len({r['case'] for r in records})==100
    ans=[dict(case=r['case'],map=r['map'],events=board(r,catalog)) for r in records]
    hits=[(r,e) for r in ans for e in r['events'] if e['reserve']]
    zeros=sum(e['zero_lag'] for r in ans for e in r['events'])
    boards=len({r['case'] for r,e in hits})
    print(json.dumps(dict(signed=len(ans),total=sum(len(r['events']) for r in ans),
        zero_lag=zeros,one_step_events=len(hits),one_step_boards=boards,
        first_band_hits=sum(e['before160'] for r,e in hits),
        summed_local_gain=str(sum(Fraction(e['net_local_mean_floor']) for r,e in hits)),
        reject=dict(Counter(e['reject'] for r in ans for e in r['events'] if 'reject' in e)),
        consideration_gate=zeros>=5 or (len(hits)>=30 and boards>=15),rows=ans),indent=2))
if __name__=='__main__':main()
