# Flank-as-guard planned X deferral: snapshot-only support screen

Older accepted exact Incoming signed held100 (not current f83 or new
holdout); verify all complete input/actions/trace hashes and final full
flags. No tester, score, mutable policy, or later pet motion. Pinned static
disjoint maps2–4 valve and room catalogues, no map1 extrapolation. For each
first actual newly isolated occupied attached stock tube in t0..274, only
test when both original mouth actions are unique and original valve is
already installed. Hypothesis: never built valve serves as orthogonal
exterior stance, close near first body tile rather than original near
gate, still close far gate and leave other actions unchanged. Recompute
exact physical three/fewer tail according to original length minus one,
current pet/human legality and worker/pet reach sets. Do not force opposite
pig parity; consider only current observed positions and legally placeable
walls. Original near gate and skipped valve must both end human-side.

Distinguish actual zero-lag (already installed valve in all considered
baseline snapshots makes factual standing there structurally unavailable)
from optimistic one-step reserve. For latter, reserve holds adjacent
service cell at observed t start and has factual wait, or is the original
near guard; preposition that actor hypothetically on skipped valve
*before* the counterfactual t action. This is not move and build in one
action. No premise is made that the previous stock turn or pet path
could be preserved. It is a staffing/topology upper diagnostic only.
Every non-target worker keeps its exact observed t movement/work; original
near worker waits when displaced, all other stock walls retained including
the far partner. Check no existing or newly stock-isolated pet ID becomes
reachable and no originally connected worker pair splits, revised worker
has exterior path back, and exact mean unpenalized human floor strictly
rises. Net floor recalculates all components; no adding hypothetical
cavity and wall savings twice. Repeated turn opportunities cannot be
summed as possible global floor improvement; local summed floor is only
descriptive. Report t<160 separately, no threshold changes.

Support gate: ≥5 actual zero-lag events, or ≥30 independently certified
one-step frozen first events on ≥15 different boards. The latter only
motivates investigating causal early role coverage; does not validate
deployment, actual motion or score. If killed do not change threshold.
Map1: center notches at c9/c19 are not exterior once either original
edge cap shifts inward one; its proximal side brace removal would touch
adjacent one-mouth geometry outside the frozen paired valve catalog.
No code or experiment on map1. One sanctioned read-only invocation:
`python3 -u ahc008_terry_flank_valve/probe.py > ahc008_terry_flank_valve/result.json`.
