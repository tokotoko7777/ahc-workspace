"""Separation ID/timing audit after a complete paired live panel."""
from collections import Counter
from pathlib import Path
import csv
import json
import sys

ledger=Path(sys.argv[1])
inputs=Path(sys.argv[2])
base={}
for row in csv.DictReader(ledger.open()):
    base.setdefault(row['case'],{})[row['arm']]=row
assert len(base)==100 and all(len(x)==2 for x in base.values())
ts=Counter()
flips=[]
for f,d in sorted(base.items()):
    a,b=d['v25'],d['terry_independent']
    assert a['input_sha']==b['input_sha']
    sa,sb=map(int,(a['score'],b['score']))
    ts['wins' if sb>sa else 'losses' if sb<sa else 'ties']+=1
    ts['different_actions']+=a['commands_sha']!=b['commands_sha']
    aa,bb=a['telemetry'].split(),b['telemetry'].split()
    assert aa[0]==bb[0] and aa[-1]==str(sa) and bb[-1]==str(sb)
    ts['mode_flips']+=aa[13]!=bb[13]
    ts['old_pairs']+=int(aa[10]);ts['new_pairs']+=int(bb[10])
    if a['full']==b['full']:
        continue
    ntext=(inputs/f).read_text().splitlines()
    kinds=[int(row.split()[2]) for row in ntext[1:1+int(ntext[0])]]
    def parse(c):
        return {x[1]:x[0] for x in (tuple(map(int,s.split(':')))for s in c['captures'].split(';') if s)}
    ca,cb=map(parse,(a,b))
    flips.append(dict(case=f,score=[sa,sb],final_full=[int(a['full']),int(b['full'])],
        original_map=int(aa[0]),actual_m=int(a['humans']),
        terminal_chase=[int(aa[13]),int(bb[13])],
        remaining_times=[json.loads(a['residue']),json.loads(b['residue'])],
        different_isolated_ids=[(j,kinds[j],ca.get(j),cb.get(j))for j in range(len(kinds))
          if (j in ca)!=(j in cb)]))
print(json.dumps(dict(**ts,full_flips=flips),indent=2))
