# Frozen separated arrival experiment; detached first

Normal h123 currently forecasts only animals already in an identified
room. Keep all of their forecasts, actions, RNG and the h0/h>=4
bins literal. Add only h1–3 exact short *endpoint* mass from animals
in the factual majority region that start outside every valid label.
Dogs are excluded; cow/pig/rabbit exact equal-neighbor model unchanged
and cats use the existing two-step symmetric surrogate. At endpoint
count only an actual original room label outside either gate's
closed neighbor set. Non-target pets/worker motion and future altered
walls are not predicted. This is an arrival from outside, not waiting
while inside or grouping. Actual transitions, geometry, staffing,
wall commands and realized motion are unchanged in the detached audit.

Proceed only after all same 275-submitted-command prefix SHA and full
official-known evidence match across the independent inherited60.
Require zero stock immediately isolated individual losses from the
detached proposal, ≥20 changed sanitized first actions across ≥10
boards, and ≥5 unique physical evidence states across ≥3 different
boards: alternative offers a *different* ETA1–3 job and one start
outside pet reaches safe body at modeled ETA in factual replay.
From the actual command at start, require those actors could reach
stakes and close actual legal gate(s) at the modeled ETA despite the
factual full blocker set without rejecting any existing wall command
or changing another actor's protected commands or earlier walls.
At close, pet not already isolated by factual action at same turn.
Keep fixed factual trajectories; this is only geometric evidence and
not a proof of score. If fails, do not relax due to case numbers.
If passes new untouched generated dev100 then held100 then official
practice100, earlier ≥0.1% / nondeclining full+useful / <2.95s / exact
official-playback and independent validation gates, same clock.
