"""Production C++23 of exactly the observed additive arrivals model."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_split_dp/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='170382b80e4ca1b0d3a5c4f0948527edabfbb43c0549fa8512fbe9dccc59e223'
h=(d.parent/'ahc008_terry_incoming_room/histogram.hpp').read_text().replace('#pragma once\n','')
a='#pragma GCC optimize("O3")'
assert s.count(a)==1
s=s.replace(a,a+'\n'+h)
# Read the single shared detached arithmetic block; production does not
# allocate old and alternate room arrays or evaluate two job selectors.
e=(d/'make.py').read_text()
front=e.index('     std::vector<int> outside;')
back=e.index('      if(any){',front)
kernel=e[front:back]
kernel=kernel.replace('      auto mod=rooms; bool any=false;\n','')
kernel=kernel.replace('       any=true;const double old=','       const double old=')
kernel=kernel.replace('       mod[k].override_short[h-1]', '       rooms[k].override_short[h-1]')
kernel+='     }\n'
a='    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));'
assert s.count(a)==1
s=s.replace(a,kernel+a)
(d/'live.private.cpp').write_text(s)
