"""Detached same-path entrant-mass audit; keep accepted stdout only."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_split_dp/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='170382b80e4ca1b0d3a5c4f0948527edabfbb43c0549fa8512fbe9dccc59e223'
def put(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
def ap(a,b):
    put(a,a+b)
a='#pragma GCC optimize("O3")'
ap(a,'\n'+(d.parent/'ahc008_terry_incoming_room/histogram.hpp').read_text().replace('#pragma once\n',''))
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int incoming_turn=-1;\ninline std::vector<std::string> incoming_rows;\n'+s[i:]
a='    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));'
ap(a,'''
    if(incoming_turn>=0){
     std::vector<int> outside;
     for(int i:alive){
      const auto& p=s.pets[i];const int k=geometry.ids[p.pos];
      if(p.type!=4&&(k<0||k>=geometry.count()))outside.push_back(i);
     }
     if(!outside.empty()){
      Mask veto;
      for(int k=0;k<geometry.count();++k){
       const auto& q=geometry.rooms[k];
       for(int g:{q.left,q.right})if(g>=0){
        if(geometry.ids[g]==k)veto.set(g);
        for(int p:nb[g])if(p>=0&&geometry.ids[p]==k)veto.set(p);
       }
      }
      auto label=[&](int p){const int k=geometry.ids[p];return k>=0&&k<geometry.count()?k:-1;};
      auto gateOK=[&](int p,int k){return rooms[k].area>0&&!veto[p];};
      RetentionNeighbors adj;adj.prepare(builds);
      std::vector<std::array<uint64_t,3>> additions(geometry.count());
      for(int i:outside){
       const Pet& p=s.pets[i];
       const int speed=p.type==5?2:p.type;
       for(auto x:terry_incoming_room::terminal_histogram(adj.table,p.pos,speed,label,gateOK)){
        for(int q=0;q<3;++q)additions[x.room][q]+=x.mass[q];
       }
      }
      constexpr double den=terry_incoming_room::denominator;
      auto mod=rooms; bool any=false;
      for(int k=0;k<(int)rooms.size();++k) for(int h=1;h<=3;++h) if(additions[k][h-1]){
       any=true;const double old=rooms[k].override_short[h-1]>=0?rooms[k].override_short[h-1]:rooms[k].retention[h];
       mod[k].override_short[h-1]=old+100.0*double(additions[k][h-1])/den;
      }
      if(any){
       const auto open=bits_to_array(actual & ~builds & ~moves);
       const auto newJ=hunt::choose(s.people,booked,mod,open);
       auto issue=[&](const auto& js){
        auto q=booked;auto a=action;
        hunt::emit(s.people,js,legal,q);
        for(int i=0;i<m;++i)if(q[i])a[i]=*q[i];
        idle_phase(s,terrain->aisleColumns,a);return sanitize(s,a);
       };
       auto a=issue(jobs),b=issue(newJ);
       if(a!=b){
        incoming_rows.push_back("C "+std::to_string(incoming_turn)+" "+a+" "+b);
        for(const auto& j:newJ){
         if(std::any_of(jobs.begin(),jobs.end(),[&](const auto& v){
          return std::tie(j.room,j.a,j.b)==std::tie(v.room,v.a,v.b);
         }))continue;
         int eta=(j.left>=0&&!open[j.left])||(j.right>=0&&!open[j.right]);
         if(j.left>=0)eta=std::max(eta,std::abs(s.people[j.a]/30-j.left/30));
         if(j.right>=0)eta=std::max(eta,std::abs(s.people[j.b]/30-j.right/30));
         if(eta<1||eta>3||!additions[j.room][eta-1])continue;
         std::string line="J "+std::to_string(incoming_turn)+" "+std::to_string(eta)+
          " "+std::to_string(j.left)+" "+std::to_string(j.right)+" "+std::to_string(j.a)+" "+std::to_string(j.b)+" "+std::to_string(outside.size());
         for(int id:outside)line+=" "+std::to_string(id);
         for(int p=0;p<V;++p)if(geometry.ids[p]==j.room)line+=" "+std::to_string(p);
         incoming_rows.push_back(std::move(line));
        }
       }
      }
     }
    }
''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn<275&&std::getenv("AHC008_TERRY_INCOMING_AUDIT"))incoming_turn=turn;
'''+a+'''
  incoming_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* path=std::getenv("AHC008_TERRY_INCOMING_AUDIT")){
   std::ofstream f(path);for(const auto& row:incoming_rows)f<<row<<'\\n';
 }
'''+a)
(d/'audit.private.cpp').write_text(s)
