# Fixed for live tests after the observation-only gate
60 exact stock prefixes and original input/action/trace hashes and full
scores verify. Detached alternate: 2,515 different first commands across
all60, zero immediate isolated animals lost, 38 factual observed
compatible legal new ETA opportunities across27, all cases protected
old other work; this is not a new score.

Production changes only additive predicted h1–3 gate-safe endpoint
mass from originally unlabelled cow, pig, rabbit and cat (old two-step
cat surrogate), in both actual and virtual Normal. Same existing
tracked-room values, output set, clock, geometry, ties, no new RNG.
Single C++23 before any live results. Compare unfiltered fresh dev100
at original 2670ms on both arms, then only on pass separately locked
generated held100, then only on both passes official distributed100.
Each needs all exact official tester, playback and independent score,
max local <2.95s, total score ≥0.1% more, raw and useful full not lower.
If failed reject without watching untested held/practice or adjusting
candidate based on measured seed/time. No historical ranking inference.
