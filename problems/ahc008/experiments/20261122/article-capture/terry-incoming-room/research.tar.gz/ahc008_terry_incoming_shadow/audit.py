"""Frozen incoming-room detached evidence. No new actions or real scores."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

D=Path(__file__).resolve().parent; R=D.parent; P=R/'ahc008_terry_chase_cut_ties'
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,flat,flood,near,observed,replay,wave

def project(p,h,w,command):
    ban=bitmask(h+p)|wave(bitmask(p))|w
    nxt=[];new=0
    for x,c in zip(h,command,strict=True):
        q=x if c=='.' else near(x,c.upper())
        if q is None:
            return None
        if c.islower():
            if B[q]&(ban|new):
                return None
            new|=B[q];nxt.append(x)
        else:
            nxt.append(q)
    if bitmask(nxt)&(w|new):
        return None
    return nxt,w|new

def capids(p,h,w,c):
    old=flood(bitmask(h),ALL^w)
    result=project(p,h,w,c)
    assert result is not None
    now=flood(bitmask(result[0]),ALL^result[1])
    return {i for i,x in enumerate(p) if B[x]&old and not B[x]&now}

def vertical(p,stance):
    if p%30!=stance%30:
        return None
    return 'U' if p//30>stance//30 else 'D' if p//30<stance//30 else '.'


def witness(history,kinds,actions,t,eta,gates,roles,region,incoming,proposed):
    gate_mask=bitmask(gates)
    danger=gate_mask|wave(gate_mask)
    body=bitmask(region)&~gate_mask
    p,h,w=history[t]
    target=t+eta
    if not body or target>=275:
        return []
    pp,actualh,actualwalls=history[target]
    old_after=project(pp,actualh,actualwalls,actions[target])
    assert old_after is not None
    old_reachable=flood(bitmask(old_after[0]),ALL^old_after[1])
    chosen=set()
    for i in incoming:
        assert int(kinds[i])!=4 and not B[p[i]]&(body|gate_mask)
        if B[pp[i]]&body&~danger&old_reachable:
            chosen.add(i)
    if not chosen:
        return []
    where={actor:g-1 if c=='r' else g+1 for g,actor,c in roles}
    closes={actor:c for g,actor,c in roles}
    hh=h[:];ww=w
    for step in range(t,target+1):
        pets,_,frozen_walls=history[step]
        if ww!=frozen_walls:
            return []
        action=list(actions[step])
        for actor,stance in where.items():
            if action[actor].islower():
                return []
            c=vertical(hh[actor],stance)
            if c is None or (step==target and c!='.') or (step==t and c!=proposed[actor]):
                return []
            action[actor]=closes[actor] if step==target else c
        out=project(pets,hh,ww,''.join(action))
        if out is None:
            return []
        if step==target:
            prior=flood(bitmask(hh),ALL^ww)
            after=flood(bitmask(out[0]),ALL^out[1])
            candidates=[]
            for i in sorted(chosen):
                spot=B[pets[i]]
                if spot&prior and not spot&after:
                    pocket=flood(spot,ALL^out[1])
                    if not pocket&~body:
                        candidates.append(dict(pet=i,species=int(kinds[i]),eta=eta,
                                mouths=gates,actors=sorted(where),final_action=''.join(action),
                                size=pocket.bit_count()))
            return candidates
        hh,ww=out
    raise AssertionError('missing final turn')

def sha(data):return hashlib.sha256(data).hexdigest()

meta=json.loads((P/'manifest.json').read_text())
ledger={ '%04d.txt'%z['board']:z for z in json.loads((P/'report.json').read_text())['tapes']}
records=[]
for f,hsh in sorted(meta['input'].items()):
    raw=(P/'in'/f).read_bytes()
    a=(P/'tapes'/f).with_suffix('.actions').read_bytes()
    tape=(P/'tapes'/f).with_suffix('.trace').read_bytes()
    ref=ledger[f]
    assert sha(raw)==hsh==ref['input_sha'] and sha(a)==ref['commands_sha'] and sha(tape)==ref['trace_sha']
    actions=a.decode().splitlines(); trace=tape.decode().splitlines()
    assert replay(raw.decode(),trace,actions,detailed=True)[0]==ref['score']
    parts=raw.decode().splitlines(); n=int(parts[0]);m=int(parts[n+1])
    with tempfile.TemporaryDirectory() as tmp:
        out=Path(tmp)/'out'
        z=subprocess.run([str(D/'audit'),'--pairs=0'],
            input='\n'.join(parts[:n+2+m]+trace[1::2])+'\n',text=True,capture_output=True,
            check=True,timeout=10,env=dict(os.environ,AHC008_TERRY_INCOMING_AUDIT=str(out)))
        assert z.stdout.splitlines()[:275]==actions[:275],f
        lines=out.read_text().splitlines()
    kinds,observed_states,_=observed(raw,trace)
    history=[(list(map(flat,p)),list(map(flat,h)),bitmask(map(flat,w))) for p,h,w in observed_states]

    counts=collections.Counter()
    changes={}; events={}
    for line in lines:
        k,*fields=line.split()
        if k=='C':
            t,old,alt=fields;t=int(t)
            assert old==actions[t] and old!=alt
            pp,hh,ww=history[t]
            before=capids(pp,hh,ww,old);after=capids(pp,hh,ww,alt)
            counts.update(changed=1,lost=len(before-after),gained=len(after-before))
            changes[t]=alt
        else:
            assert k=='J'
            t,eta,left,right,a,b,n,*payload=map(int,fields)
            start_outside=payload[:n]; region=payload[n:]
            roles=[]
            if left>=0:roles.append((left,a,'r'))
            if right>=0:roles.append((right,b,'l'))
            mouths=tuple(q for q,_,_ in roles)
            counts.update(alternate_arrival_job=1)
            result=witness(history,kinds,actions,t,eta,mouths,roles,region,start_outside,changes[t])
            for x in result:
                key=(t,mouths,x['pet'])
                if key not in events:
                    events[key]=dict(turn=t,**x)
    counts.update(physical_events=len(events),physical_turns=len({z['turn'] for z in events.values()}))
    records.append(dict(case=f,counts=counts,events=sorted(events.values(),key=lambda z:(z['turn'],z['pet']))))
    print(f,dict(counts),file=sys.stderr,flush=True)
assert len(records)==60
total=collections.Counter()
for z in records:total.update(z['counts'])
boards={x:sum(z['counts'][x]>0 for z in records)for x in total}
gate=total['changed']>=20 and boards['changed']>=10 and total['lost']==0 and total['physical_turns']>=5 and boards['physical_events']>=3
print(json.dumps(dict(n=len(records),total=total,boards=boards,gate=gate,records=records),indent=2))
