# Exact passive arrival histogram, endpoint horizons 1–3

One sparse physical-board diffusion per animal, no solver/policy or
RNG integration. Supply actual orthogonal physical adjacency
(degree at most 4 and cells), start, speed 1–3 (2 also represents
stock uniform-cat surrogate), and two callbacks: label_of(cell) gives
a nonnegative named room or negative unlabelled; feasible(cell,room)
can veto a named horizon endpoint. The caller screens initial state
and eventual whole-gate legality; no room or worker behavior is built in.
Labels and feasibility never block or absorb transitions.

Returns sorted/deduplicated Entry{room,mass[3]}, no all-zero records.
Index h−1 is endpoint mass at h. Exact D=12^9=5,159,780,352,
including degree-zero stasis. At most nine expansions with support
within a 181-cell Manhattan diamond; two 900-slot weights arrays and
a sort/merge only for the up to three sets of endpoint records.
Raw layer mass ≤12^k and no uint64 overflow.

Validation: 360 independent exhaustive path trees on fixed random small
boards, plus deterministic stagnation, parity, veto, and merged-room
cases. No integration or official benchmark.

    g++ -std=c++23 -O2 -Wall -Wextra unit.cpp -o /tmp/terry-incoming-unit
    /tmp/terry-incoming-unit
