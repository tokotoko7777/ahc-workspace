#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <random>
#include <vector>
#include "histogram.hpp"

using terry_incoming_room::Entry;
constexpr uint64_t D=terry_incoming_room::denominator;
struct Neighbor {
    std::array<int,4> cells{};
    unsigned degree=0;
};
using Graph=std::array<Neighbor,900>;
void edge(Graph& g,int a,int b) {
    assert(std::abs(a/30-b/30)+std::abs(a%30-b%30)==1);
    g[a].cells[g[a].degree++]=b;
    g[b].cells[g[b].degree++]=a;
}
template<class Label,class Feasible>
std::vector<Entry> exhaustive(const Graph& g,int from,int speed,const Label& label,const Feasible& ok) {
    std::map<int,std::array<uint64_t,3>> tally;
    for(int h=1;h<=3;++h) {
        auto visit=[&](auto&& self,int p,int left,uint64_t den)->void{
            if(left==0) {
                int id=label(p);
                if(id<0||!ok(p,id))return;
                assert(D%den==0);
                tally[id][h-1]+=D/den;
                return;
            }
            unsigned n=g[p].degree;
            if(n==0)self(self,p,left-1,den);
            else for(unsigned i=0;i<n;++i)self(self,g[p].cells[i],left-1,den*n);
        };
        visit(visit,from,h*speed,1);
    }
    std::vector<Entry> ans;
    for(auto& [id,mass]:tally)ans.push_back({id,mass});
    return ans;
}
template<class Label,class Feasible>
std::vector<Entry> check(const Graph& g,int start,int speed,const Label& label,const Feasible& ok) {
    const auto a=terry_incoming_room::terminal_histogram(g,start,speed,label,ok);
    assert(a==exhaustive(g,start,speed,label,ok));
    std::array<uint64_t,3> sum{};
    int prev=-1;
    for(const auto& row:a) {
        assert(row.room>prev&&(row.mass[0]||row.mass[1]||row.mass[2]));
        prev=row.room;
        for(int h=0;h<3;++h)sum[h]+=row.mass[h];
    }
    for(uint64_t mass:sum)assert(mass<=D);
    return a;
}
int main() {
    const auto yes=[](int,int){return true;};
    const auto no=[](int,int){return false;};
    Graph g{};
    const auto l=[](int p){return p==1?7:-1;};
    for(int speed=1;speed<=3;++speed) {
        assert(check(g,0,speed,l,yes).empty());
        assert((check(g,1,speed,l,yes)==std::vector<Entry>{{7,{D,D,D}}}));
        assert(check(g,1,speed,l,no).empty());
    }
    edge(g,0,1);
    assert((check(g,0,1,l,yes)==std::vector<Entry>{{7,{D,0,D}}}));
    assert(check(g,0,2,l,yes).empty()); // crosses the room, never ends there
    assert((check(g,0,3,l,yes)==std::vector<Entry>{{7,{D,0,D}}}));

    Graph d{};
    for(int p=10;p<13;++p)edge(d,p,p+1);
    const auto two=[](int p){return p==10?40000000:p==13?0:-1;};
    const auto accept=[](int p,int id){assert(id==0||id==40000000);return !(id==0&&p==13);};
    const auto x=check(d,11,1,two,yes);
    assert(x.size()==2&&x[0].room==0&&x[1].room==40000000);
    const auto y=check(d,11,1,two,accept);
    assert(y.size()==1&&y.front()==x.back());
    const auto merged=[](int p){return p==10||p==12?42:-1;};
    assert((check(d,11,1,merged,yes)==std::vector<Entry>{{42,{D,0,D}}}));

    std::mt19937 rng(282615);
    for(int i=0;i<360;++i) {
        Graph small{};
        int s=1+i%3;
        std::array<int,900> labels;
        std::array<bool,900> can{};
        labels.fill(-1);
        std::vector<int> ps;
        for(int r=10;r<14;++r)for(int c=10;c<14;++c) {
            int p=30*r+c;labels[p]=int(rng()%8)-2;can[p]=rng()%3;
            ps.push_back(p);
        }
        for(int p:ps)for(int q:{p+1,p+30}) {
            if(q/30>13||q%30>13||rng()%3==0)continue;
            if(s==3&&(small[p].degree>=3||small[q].degree>=3))continue;
            edge(small,p,q);
        }
        const auto label=[&](int p){return labels[p];};
        const auto ok=[&](int p,int id){assert(id==labels[p]);return can[p];};
        check(small,ps[rng()%ps.size()],s,label,ok);
    }
    std::cout<<"360 randomized exhaustive comparisons and deterministic endpoint fixtures passed\n";
}
