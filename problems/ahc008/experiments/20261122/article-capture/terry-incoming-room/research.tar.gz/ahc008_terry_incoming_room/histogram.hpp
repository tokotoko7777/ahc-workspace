#pragma once
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <utility>
#include <vector>

namespace terry_incoming_room {
inline constexpr int V=900,substeps=9;
inline constexpr std::array<uint64_t,substeps+1> pow12=[]{
    std::array<uint64_t,substeps+1> a{};
    a[0]=1;
    for(int i=1;i<=substeps;++i)a[i]=12*a[i-1];
    return a;
}();
inline constexpr uint64_t denominator=pow12[substeps];
static_assert(denominator==5159780352ULL);

struct Entry {
    int room;
    std::array<uint64_t,3> mass{};
    bool operator==(const Entry&) const = default;
};

// Physical orthogonal grid adjacency. Consult callbacks at full-turn
// endpoints only. Negative label is unnamed. Caller screens outside starts.
template<class Table,class Label,class Feasible>
std::vector<Entry> terminal_histogram(const Table& adj,int start,int speed,
                                      const Label& label_of,const Feasible& feasible) {
    assert(0<=start&&start<V&&1<=speed&&speed<=3);
    struct Layer {
        std::array<uint64_t,V> weight{};
        std::array<uint16_t,181> active{};
        int n=0;
        void accumulate(int p,uint64_t x) {
            assert(0<=p&&p<V&&x>0);
            if(!weight[p]) {
                assert(n<int(active.size()));
                active[n++]=static_cast<uint16_t>(p);
            }
            weight[p]+=x;
        }
    } layer[2];
    auto *cur=&layer[0], *next=&layer[1];
    cur->accumulate(start,1);
    std::vector<Entry> out;
    for(int step=1;step<=3*speed;++step) {
        for(int j=0;j<cur->n;++j) {
            int p=cur->active[j];
            uint64_t x=cur->weight[p];
            const auto& a=adj[p];
            const auto n=static_cast<unsigned>(a.degree);
            assert(n<=4);
            cur->weight[p]=0;
            if(n==0)next->accumulate(p,12*x);
            else {
                x*=12/n;
                for(unsigned d=0;d<n;++d)next->accumulate(a.cells[d],x);
            }
        }
        cur->n=0;std::swap(cur,next);
        if(step%speed==0)
            for(int j=0;j<cur->n;++j) {
                const int p=cur->active[j],r=label_of(p);
                if(r<0||!feasible(p,r))continue;
                Entry row{r};
                row.mass[step/speed-1]=cur->weight[p]*pow12[substeps-step];
                out.push_back(row);
            }
    }
    std::sort(out.begin(),out.end(),[](const Entry& a,const Entry& b){return a.room<b.room;});
    std::size_t j=0;
    for(const Entry& row:out) {
        if(j==0||out[j-1].room!=row.room){out[j++]=row;continue;}
        for(int h=0;h<3;++h)out[j-1].mass[h]+=row.mass[h];
    }
    out.resize(j);
    return out;
}
}
