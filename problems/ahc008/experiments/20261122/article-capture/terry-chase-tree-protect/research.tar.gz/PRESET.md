# Chase connector-tree protected minimum cut (detached only)

Use accepted incoming held100 inherited tapes only, instrumented stock
decision from the exact verified ledger. All actual Chase t275..299
snapshots on the current solver are included, not just eventual splits,
and no protected policy is evaluated by the tester. Require current
crew fully connected and original provisional stock shape by itself
to split that same crew in today's projected post-wall geometry.

Choose exactly one deterministic connector tree: shortest paths from
worker0 to every current worker in an ordered U,R,D,L BFS of the
current open graph. Union of first-discovery predecessor chains is a
tree. Set only its traversable vertices' split capacities to stock
prohibitive 100,000,000. Leave source arcs/order, target positions,
capacity prize, meeting radius and all other cells unchanged. Reuse
stock max-flow shape implementation. Tie behavior outside the altered
admissible vertex set stays stock. No secondary weighting or cut
cost-equality requirement; unlike equal-flow tie analysis this asks
about a constrained alternative, and unlike cut reuse it is current.

Compare nonempty masks on actual recorded current worker and animal
positions, before the factual action. Both masks must be physically
legal now (no current humans/animals or animal orthogonal adjacency);
the constrained mask must keep the crew connected and preserve all
exact isolated pet IDs of the stock projected cut, including a same
nonempty newly isolated subset. Every corresponding worker's stock
reachable set must be a subset, and strictly higher mean floor.
On each mask all new walls must be covered by distinct real workers
with an adjacent stance reachable through its projected final graph.
Exact bottleneck assignment maximum approach time plus 1 must fit
remaining actions, and alternative duration no greater than stock.

Advance only with >=5 distinct qualifying (stock and protected masks,
newly separated IDs) states on >=3 boards and >=50 summed mean area
tiles from the best per-board witness. This is a noncausal current
stage-feasibility screen, not a promise that animals stay or that
cut recurrence and existing future moves remain. No change or
widening if it fails. No policy execution, official scoring or rank.
