#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main equal_flow_unused_main
#include "../ahc008_terry_chase_cut_ties/kernel.cpp"
#undef main
#pragma GCC diagnostic pop
namespace mp=terry_exact_maps;
using Vec=std::vector<int>;

struct ProtectedNet:MaxFlow<int> {
    using MaxFlow<int>::MaxFlow;
    static inline Board tree;
    int add_edge(int from,int to,int capacity) {
        if(from<2*p::padded&&from%2==0&&to==from+1) {
            const int q=from/2,r=q/p::P-1,c=q%p::P-1;
            if(0<=r&&r<30&&0<=c&&c<30&&tree[r*30+c])capacity=100000000;
        }
        return MaxFlow<int>::add_edge(from,to,capacity);
    }
};
Board connector(const Board& walls,const Vec& crew) {
    std::array<int,p::size> parent,q;
    parent.fill(-1);
    int len=1;
    q[0]=crew[0];parent[crew[0]]=crew[0];
    for(int j=0;j<len;++j) for(int v:p::neighbors(q[j]))
        if(v>=0&&!walls[v]&&parent[v]<0){parent[v]=q[j];q[len++]=v;}
    Board res;
    for(int h:crew) {
        if(parent[h]<0)return {};
        for(int u=h;!res[u];u=parent[u])res.set(u);
    }
    assert(res[crew[0]]);
    return res;
}
bool connected(const Actual& a) {
    for(const auto& s:a.visible)if(s!=a.visible.front())return false;
    return true;
}
int main() {
    int board,turn,map;
    while(std::cin>>board>>turn>>map) {
        const auto people=read_vec(),pets=read_vec(),closed=read_vec();
        Board w,blocked;
        for(int a:closed)w.set(a);
        blocked=w;
        for(int a:people)blocked.set(a);
        for(int a:pets) {
            blocked.set(a);
            for(int z:p::neighbors(a))if(z>=0)blocked.set(z);
        }
        std::cout<<board<<' '<<turn;
        const auto end=[&](std::string_view code) {std::cout<<' '<<code<<'\n';};
        auto tree=connector(w,people);
        if(tree.none()){end("crew_already_split");continue;}
        const auto& roads=mp::terrain(map).aisleCells;
        const Vec targets=p::majorityPets(w,people,pets);
        if(targets.empty()){end("no_target");continue;}
        const auto stock=p::shape<MaxFlow<int>>(w,roads,people,targets,turn);
        if(stock.walls.empty()){end("empty_stock");continue;}
        if(std::any_of(stock.walls.begin(),stock.walls.end(),[&](int z){return blocked[z];})){
            // We still identify whether this provisionally separates
            // people (without assuming pets have left their actual positions).
            Board shadow=w;
            for(int z:stock.walls)shadow.set(z);
            if(std::any_of(people.begin(),people.end(),[&](int z){return shadow[z];})){
                end("stock_drops_worker_tile");continue;
            }
            const auto branch=get_component(shadow,people.front());
            if(std::any_of(people.begin(),people.end(),[&](int z){return !branch[z];}))
                end("stock_split_but_blocked");
            else end("stock_no_split_blocked");
            continue;
        }
        Board a=w;
        for(int z:stock.walls)a.set(z);
        const auto u=evaluate(a,people,pets);
        if(connected(u)){end("stock_no_split");continue;}
        ProtectedNet::tree=tree;
        const auto other=p::shape<ProtectedNet>(w,roads,people,targets,turn);
        if(other.walls.empty()){end("empty_protected");continue;}
        Board b=w;
        bool bad=false;
        for(int z:other.walls){bad|=blocked[z]||tree[z];b.set(z);}
        if(bad){end("bad_protected_wall");continue;}
        const auto v=evaluate(b,people,pets);
        if(!connected(v)){end("still_split");continue;}
        if(u.ids!=v.ids){end("different_ids");continue;}
        const unsigned newly=u.ids&~evaluate(w,people,pets).ids;
        if(!newly){end("no_new_ids");continue;}
        bool includes=true;
        for(std::size_t i=0;i<people.size();++i)includes&=(u.visible[i]&~v.visible[i]).none();
        if(!includes||v.sum<=u.sum){end("non_dominant");continue;}
        const int d0=eta(a,people,stock.walls),d1=eta(b,people,other.walls);
        if(d0+1>300-turn||d1>d0){end("staff_or_eta");continue;}
        std::cout<<" witness "<<v.sum-u.sum<<' '<<people.size()<<' '<<d0<<' '<<d1<<' '<<newly<<' '<<stock.walls.size();
        for(int z:stock.walls)std::cout<<' '<<z;
        std::cout<<' '<<other.walls.size();
        for(int z:other.walls)std::cout<<' '<<z;
        std::cout<<'\n';
    }
}
