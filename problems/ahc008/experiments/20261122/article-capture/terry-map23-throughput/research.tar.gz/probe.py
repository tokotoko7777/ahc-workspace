import hashlib,json,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent;X=D/'dev'
p=json.loads((X/'manifest.json').read_text());s=p['model_seeds'];assert len(p['rows'])==100
data=[]
for row in p['rows']:
    raw=(X/'selected'/row['case']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['sha256']
    n=int(raw.splitlines()[0]);m=int(raw.splitlines()[n+1])
    x=subprocess.run([str(D/'probe'),*map(str,s)],input=b'\n'.join(raw.splitlines()[:n+m+2])+b'\n',
        capture_output=True,check=True,timeout=1.5)
    k,us,*v=x.stdout.decode().split()
    assert k in ('ok','incomplete')
    t=list(map(int,v))
    assert (len(t)==8 and int(us)<650000) if k=='ok' else not t
    data.append(dict(case=row['case'],wall_us=int(us),status=k,r100=t[:4],r160=t[4:]))
    (X/'probe.json').write_text(json.dumps(data,indent=2)+'\n')
