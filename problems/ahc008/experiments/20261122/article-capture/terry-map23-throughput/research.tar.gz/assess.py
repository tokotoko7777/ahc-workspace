"""Frozen held labels, no model/threshold fit."""
import collections,csv,json,random
from pathlib import Path
D=Path(__file__).resolve().parent;X=D/'dev'
p=json.loads((X/'manifest.json').read_text())
data=json.loads((X/'probe.json').read_text());assert len(data)==100
sim={r['case']:r for r in data}
lab=collections.defaultdict(dict)
for r in csv.DictReader((X/'official.csv').open()):
    assert r['arm'] not in lab[r['case']]
    a={'v25':2,'terry_independent':3}[r['arm']]
    telemetry=list(map(int,r['telemetry'].split()))
    assert len(telemetry)==15 and telemetry[0]==a and telemetry[-1]==int(r['score'])
    lab[r['case']][a]=r
rows=[]
for z in p['rows']:
    c=z['case']; s=sim[c]
    a,b=lab[c][2],lab[c][3]
    assert z['sha256']==a['input_sha']==b['input_sha']
    d=lambda r,key:int(json.loads(r['residue'])[str(key)])
    f=lambda r,k:int(r[k])
    dp=lambda v:(v[1]+v[3]-v[0]-v[2]) if v else None
    actual100=d(b,100)-d(a,100); actual160=d(b,160)-d(a,160)
    model100=dp(s['r100']); model160=dp(s['r160'])
    down=f(b,'full')<f(a,'full') or f(b,'useful300')<f(a,'useful300')
    area_gain=f(a,'full') and f(b,'full') and float(b['mean_human_area'])>float(a['mean_human_area'])
    rows.append(dict(case=c,actual100=actual100,actual160=actual160,model100=model100,model160=model160,
        down=down,positive_full_area=bool(area_gain),under_budget=s['status']=='ok',model_us=s['wall_us']))
assert len(rows)==len(lab)==len(sim)==100
sign=[(r['actual160']*r['model160']>0)for r in rows if r['actual160'] and r['model160']]
boots=[]
if sign:
    # Conditions on paired nonzero support; exactly one row per distinct board.
    gen=random.Random(440791603)
    boots=sorted(sum(sign[gen.randrange(len(sign))]for _ in sign)/len(sign)for _ in range(4000))
lower=boots[int(.05*(len(boots)-1))] if boots else None
nonzero=sum(bool(r['actual160'])for r in rows)
down=[r for r in rows if r['down']]
area=[r for r in rows if r['positive_full_area']]
veto=sum(r['model160'] is not None and r['model160']>0 for r in down)
retain=sum(r['model160'] is not None and r['model160']<=0 for r in area)
completed=sum(r['under_budget']for r in rows)
summary=dict(eligible=100,completed=completed,actual_160_nonzero=nonzero,paired_nonzero_support=len(sign),
    sign_correct=sum(sign),one_sided_95_lower_concordance=lower,downside_cases=len(down),vetoed_downside=veto,
    jointly_full_area_improved=len(area),retained_area_cases=retain,max_probe_us=max(r['model_us']for r in rows),
    t100_actual_nonzero=sum(bool(r['actual100'])for r in rows),
    t100_model_nonzero=sum(bool(r['model100'])for r in rows))
summary['pass']=bool(completed>=80 and nonzero>=12 and len(sign)>=12 and 10*sum(sign)>=7*len(sign)
    and lower is not None and lower>.5 and len(down)>=5 and 5*veto>=4*len(down)
    and area and 3*retain>=len(area))
(X/'report.json').write_text(json.dumps(dict(summary=summary,rows=rows),indent=2)+'\n')
print(json.dumps(summary))
