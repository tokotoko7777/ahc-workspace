"""Prelude eligibility only. Dev100 generation requires explicit clearance."""
import argparse,hashlib,json,re,shutil,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_exact_selector'))
from verify import eval_reference
NS='ahc008-map23-capture-throughput-v1'
def seed(s):
    return int.from_bytes(hashlib.sha256(s.encode()).digest()[:8],'little')
def hashbytes(b):return hashlib.sha256(b).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('gen',type=Path);a=p.parse_args()
    out=D/'dev';out.mkdir()
    seeds=[seed(f'{NS}:dev:{i}')for i in range(4096)];assert len(set(seeds))==len(seeds)
    (out/'seeds.txt').write_text(''.join(f'{x}\n'for x in seeds))
    subprocess.run([str(a.gen.resolve()),str(out/'seeds.txt')],cwd=out,check=True,timeout=90)
    w=[float.fromhex(x)for x in re.findall(r'-?0x[0-9a-f]+\.[0-9a-f]+p[+-][0-9]+',
        (R/'ahc008_terry_exact_selector/weights.private.inc').read_text())]
    assert len(w)==3589
    rows=[]; hashes=set(); (out/'selected').mkdir()
    for i in range(len(seeds)):
        path=out/'in'/f'{i:04d}.txt'; raw=path.read_bytes()
        h=hashbytes(raw);assert h not in hashes;hashes.add(h)
        lines=raw.splitlines(); n=int(lines[0]);m=int(lines[n+1])
        counts=[0]*5
        for l in lines[1:n+1]:
            k=int(l.split()[-1]);counts[k-1]+=1
        if m<8 or eval_reference(w,(m,*counts))[0]!=2:continue
        case=f'{len(rows):04d}.txt'
        shutil.copyfile(path,out/'selected'/case)
        rows.append(dict(case=case,idx=i,seed=seeds[i],sha256=h,people=m,counts=counts))
        if len(rows)==100:break
    assert len(rows)==100
    (out/'manifest.json').write_text(json.dumps(dict(namespace=NS,stream_limit=len(seeds),rows=rows,
        seedlist_sha=hashbytes((out/'seeds.txt').read_bytes()),
        model_seeds=[seed(f'{NS}:model-motion:{i}')for i in range(2)],
        confirm_namespace=f'{NS}:fresh-confirm'),indent=2)+'\n')
if __name__=='__main__':main()
