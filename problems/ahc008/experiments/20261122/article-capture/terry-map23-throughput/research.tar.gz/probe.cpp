#define main phase_unused_original_main
#include "../ahc008_terry_split_bound/solve.private.cpp"
#undef main

int main(int argc,char**argv){
 using namespace terry_exact_root;
 std::ios::sync_with_stdio(false); std::cin.tie(nullptr);
 const auto start=Clock::now();
 const auto stop=start+std::chrono::milliseconds(650);
 if(argc!=3)return 2;
 const std::array<uint64_t,2> seeds={std::stoull(argv[1]),std::stoull(argv[2])};
 int n,m;if(!(std::cin>>n))return 2;
 State live; std::array<int,5> kinds{};
 for(int i=0;i<n;++i){
  int r,c,k;std::cin>>r>>c>>k;live.pets.push_back({(r-1)*30+c-1,k,-1});++kinds[k-1];
 }
 std::cin>>m;
 for(int i=0;i<m;++i){int r,c;std::cin>>r>>c;live.people.push_back((r-1)*30+c-1);}
 if(m<8||terry_exact_selector::choose(m,kinds)!=2)return 3;
 const auto residual=[](const State&s){
  Mask reach;
  for(int p:s.people)if(!reach[p]){
   Dist d;bfs(s.walls,p,d);
   for(int q=0;q<V;++q)if(d[q]<INF)reach.set(q);
  }
  return int(std::count_if(s.pets.begin(),s.pets.end(),[&](const auto& p){return !reach[p.pos];}));
 };
 std::array<std::array<int,2>,2> r100{},r160{};
 const auto emit_time=[&] { return std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-start).count(); };
 for(int j=0;j<2;++j)for(int k=0;k<2;++k){
  const int map=2+k;
  Normal policy(terrain_lib::terrain(map),live);
  State s=live; ChaCha rng(seeds[j]);
  for(int t=0;t<160;++t){
   if(Clock::now()>=stop){std::cout<<"incomplete "<<emit_time()<<'\n';return 0;}
   people_step(s,policy.step(s,t));actual_motion(s,rng);
   if(t==99)r100[j][k]=n-residual(s);
  }
  r160[j][k]=n-residual(s);
  if(Clock::now()>=stop){std::cout<<"incomplete "<<emit_time()<<'\n';return 0;}
 }
 const auto used=emit_time();
 if(used>=650000){std::cout<<"incomplete "<<used<<'\n';return 0;}
 std::cout<<"ok "<<used;
 for(auto v:r100)for(int x:v)std::cout<<' '<<x;
 for(auto v:r160)for(int x:v)std::cout<<' '<<x;
 std::cout<<'\n';
}
