from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);d=p.read_bytes()
assert hashlib.sha256(d).hexdigest()=='46f210cc5dd50b8a6088724861ae5c2b044d08edb109a891ee217352730fcb84'
s=d.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep('struct Options{\n int trials=50,steps=-1;',Path(__file__).with_name('windows.inc').read_text()+'struct Options{\n int trials=50,steps=-1;')
rep(' string integratedBankPlan(){',''' terry_mc::WindowMasks captureMasks;
 bool captureMasksTried=false,captureMasksFit=false;
 string integratedBankPlan(){''')
rep('''    for(int k=0;k<n;k++)if(!pairInfo[k].empty()){
     bitset<Horizon+1> wants;''','''    if(!captureMasksTried){
     captureMasksFit=captureMasks.initialize(terrySim,banks);
     captureMasksTried=true;
    }
    if(captureMasksFit){
     array<uint64_t,Horizon+1> desired{};
     for(int k=0;k<n;k++)for(auto pair:pairInfo[k])desired[pair.d]|=uint64_t(1)<<k;
     for(int h=1;h<=maxEta;h++)captureMasks.reduce(pathsMC,h,desired[h],[&](int k,const auto& p){
      mean[k][h]=p.expected;chance[k][h]=p.any;
     });
    }else for(int k=0;k<n;k++)if(!pairInfo[k].empty()){
     bitset<Horizon+1> wants;''')
o.write_text(s)
