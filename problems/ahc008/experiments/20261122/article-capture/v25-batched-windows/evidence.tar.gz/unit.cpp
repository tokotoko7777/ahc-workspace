#define main original_entry
#include "solve.cpp"
#undef main
namespace wm_test {
using namespace terry_mc;
struct Tube{int g,k;std::array<int,4> inner;};
void check(const Simulator& sim,const Paths& paths,const std::vector<Tube>& tubes,
           int eta,uint64_t wants){
 WindowMasks u;
 assert(u.initialize(sim,tubes));
 uint64_t visited=0;
 u.reduce<true>(paths,eta,wants,[&](int k,const Window& got){
  auto& x=tubes[k];
  auto ref=capture_window(paths,sim,x.g,x.k,x.inner,eta);
  assert(std::bit_cast<uint64_t>(got.expected)==std::bit_cast<uint64_t>(ref.expected));
  assert(std::bit_cast<uint64_t>(got.any)==std::bit_cast<uint64_t>(ref.any));
  for(int j=0;j<MP;j++)assert(std::bit_cast<uint64_t>(got.pet[j])==std::bit_cast<uint64_t>(ref.pet[j]));
  visited|=uint64_t(1)<<k;
 });
 assert(visited==wants);
 uint64_t aggregate=0;
 u.reduce(paths,eta,wants,[&](int k,const Window& got){
  auto& x=tubes[k];
  auto ref=capture_window(paths,sim,x.g,x.k,x.inner,eta);
  assert(std::bit_cast<uint64_t>(got.expected)==std::bit_cast<uint64_t>(ref.expected));
  assert(std::bit_cast<uint64_t>(got.any)==std::bit_cast<uint64_t>(ref.any));
  aggregate|=uint64_t(1)<<k;
 });
 assert(aggregate==wants);
}
void fixed(){
 Simulator sim;
 std::vector<Tube> q={{31,36,{32,33,34,35}}, {31,31,{33,33,60,-1}},
                      {32,37,{33,34,35,36}}, {-1,42,{31,64,64,terry_mc::V}}};
 Paths p;p.trials=1;p.n=3;p.horizon=1;p.pos.resize(2);
 const std::array<int,8> cells={0,30,31,32,33,34,36,89};
 for(int a:cells)for(int b:cells)for(int c:cells){
  p.pos[0]={short(a),short(b),short(c)};
  p.pos[1]={short(c),short(a),short(b)};
  for(uint64_t m=0;m<16;m++)for(int h:{-1,0,1,2})check(sim,p,q,h,m);
 }
 q.resize(64,q.front());
 p.pos[0]={33,33,34};
 check(sim,p,q,0,1ULL<<63);
 check(sim,p,q,0,~0ULL);
 WindowMasks wm;
 q.push_back(q.front());
 assert(!wm.initialize(sim,q)&&wm.valid==0);
}
void random(){
 Simulator sim;
 std::mt19937 rng(0xb30df);
 for(int i=0;i<900;i++){
  int n=1+rng()%64;
  std::vector<Tube> q(n);
  for(auto& a:q){
   a.g=rng()%terry_mc::V;a.k=(rng()%2)?a.g:rng()%terry_mc::V;
   for(int j=0;j<4;j++)a.inner[j]=(rng()%2)?a.g+(int(rng()%9)-4):rng()%terry_mc::V;
  }
  Paths p;p.trials=rng()%129;p.n=rng()%(MP+1);p.horizon=rng()%26;
  p.pos.resize(p.trials*(p.horizon+1));
  for(auto& a:p.pos)for(int j=0;j<p.n;j++)a[j]=rng()%terry_mc::V;
  uint64_t mask=rng();mask|=uint64_t(rng())<<32;
  if(n<64)mask&=(1ULL<<n)-1;
  for(int h:{0,int(rng()%(p.horizon+1)),p.horizon})check(sim,p,q,h,mask);
 }
}
}
int main(){wm_test::fixed();wm_test::random();}
