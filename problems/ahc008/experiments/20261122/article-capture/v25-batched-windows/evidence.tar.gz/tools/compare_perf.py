"""Summarize exact pairing and process-only CPU data."""
import csv, collections, json, sys, statistics
def compare(name):
 rows=collections.defaultdict(dict)
 for r in csv.DictReader(open(name)):
  k=r['case'],r['rep']; assert r['model'] not in rows[k]; rows[k][r['model']]=r
 assert rows and all(len(r)==2 for r in rows.values())
 t=dict(pairs=len(rows),exact=sum(x['old']['action_hash']==x['new']['action_hash']for x in rows.values()))
 if 'prefix275_sha256' in next(iter(rows.values()))['old']:
  t['prefix275_exact']=sum(x['old']['prefix275_sha256']==x['new']['prefix275_sha256']for x in rows.values())
 for x in rows.values(): assert x['old']['input_hash']==x['new']['input_hash']
 for col,scale in [('solver_cpu_us',1e6),('wall_seconds',1)]:
  vals=[[float(q[m][col])/scale for q in rows.values()]for m in ('old','new')]
  a,b=vals
  t[col]=dict(sums=[sum(a),sum(b)],median=[statistics.median(a),statistics.median(b)],max=[max(a),max(b)],
              ratio=sum(b)/sum(a),median_paired_reduction=statistics.median(1-n/o for o,n in zip(a,b)))
 t['scores']=[sum(int(x[m]['score'])for x in rows.values())for m in ('old','new')]
 t['differences']=[dict(case=k[0],rep=k[1],old=v['old']['score'],new=v['new']['score'])
   for k,v in rows.items() if v['old']['action_hash']!=v['new']['action_hash']]
 return t
if __name__=='__main__':print(json.dumps({p:compare(p)for p in sys.argv[1:]},indent=2))
