#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/resource.h>
static long long us(struct timeval x){return x.tv_sec*1000000LL+x.tv_usec;}
int main(int n,char **v){
 if(n!=3)return 2;
 pid_t p=fork(); if(p<0)return 3;
 if(p==0){execl(v[1],v[1],(char*)0);_exit(127);}
 int status; struct rusage u; pid_t q;
 do q=wait4(p,&status,0,&u);while(q<0&&errno==EINTR);
 if(q!=p)return 4;
 FILE *f=fopen(v[2],"w");if(!f)return 5;
 fprintf(f,"%lld %lld\n",us(u.ru_utime),us(u.ru_stime));
 if(fclose(f))return 6;
 return WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status);
}
