"""Sequential same-input timing: wait4 solver-only CPU + exact official output."""
import argparse,csv,hashlib,json,sys,tempfile,statistics
from pathlib import Path
P=Path(__file__).resolve().parent; W=P.parent; H=W/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H));from benchmark_cases import run
from benchmark import replay
T=W/'ahc008_focus_assets/tools/target/release/tester'
p=argparse.ArgumentParser()
for k in ('old','new','cases','output'):p.add_argument(k,type=Path)
p.add_argument('--reps',type=int,default=3);p.add_argument('--replay',action='store_true');a=p.parse_args()
rows=[]
for i,case in enumerate(sorted(a.cases.glob('*.txt'))):
 raw=case.read_bytes(); pair=[('old',a.old),('new',a.new)]
 for k in range(a.reps):
  for model,solver in (pair if (i+k)%2==0 else pair[::-1]):
   with tempfile.TemporaryDirectory() as tmp:
    result=Path(tmp)/'rusage'
    out,err,rc,wall=run([str(T),str(P/'wait4_time'),str(solver.resolve()),str(result)],raw,4.5)
    assert rc==0 and err.startswith(b'Score = '),(case,model,rc,err)
    u,s=map(int,result.read_text().split())
    if a.replay:
     tape=Path(tmp)/'tape'; trace=Path(tmp)/'trace'
     tape.write_bytes(out)
     uu,ee,cc,_=run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',tape,trace],raw,12.)
     assert (uu,ee,cc)==(out,err,0)
     score,*_=replay(raw.decode(),trace.read_text().splitlines(),out.decode().splitlines(),detailed=True)
     assert score==int(err.split()[-1])
    pre=b'\n'.join(out.splitlines()[:275])+b'\n'
    rows.append(dict(case=case.name,rep=k,model=model,score=int(err.split()[-1]),
      action_hash=hashlib.sha256(out).hexdigest(),prefix275_sha256=hashlib.sha256(pre).hexdigest(),input_hash=hashlib.sha256(raw).hexdigest(),
      solver_cpu_us=u+s,wall_seconds=wall))
 with a.output.open('w') as f:
  w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
 print(case.name,flush=True)
