After exact dev 30×3: confirm on both pinned official practice100 and
separate general100 with untouched v25 and this exact batched source.
Measure uninstrumented solver-only CPU via wait4 and independent replay,
alternating arm order, serial. Adopt as a speed-only baseline if both
panels have ≥3% aggregate CPU reduction, all actions before t275 exact,
all official legal, and any latter mismatch is specifically explained
under existing clock-driven limits (never claim all actions identical
if not). No policy or historical ranking upgrade. Do not use extra CPU
for more computation until this exact replacement is independently checked.
