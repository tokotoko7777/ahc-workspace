# v25 opt-in CPU profile
Pinned exact v25 generator input SHA256 46f210cc5dd50b8a6088724861ae5c2b044d08edb109a891ee217352730fcb84.
From workspace:
    python ahc008_v25_profile/make.py ahc008_v24_standby_early_seam/record/solve-v25.cpp ahc008_v25_profile/solve.cpp
    g++ -std=c++23 ahc008_v25_profile/solve.cpp -o ahc008_v25_profile/solve

Run via the existing exact official/replay harness with a unique AHC008_CPU_PROFILE=/path/CASE.csv per invocation. Compare historical action and score hashes; mark diverged trajectories separately. The CSV records inclusive process CPU clock ticks and calls, plus clocks_per_second, total ticks since Game's existing budget start, existing seam cache queries/hits/capacity, and how many existing overBudget checks returned true (first/last turn). No new clock checks were added inside the overBudget implementation. File output occurs after the game; stdout and normal stderr are untouched.

Default opt-in profile has two clock reads/sample for each coarse section. Times nest: integrated_total includes rescue (after handoff), builder, relay, candidate MC and final planner; guard_forecast_block includes guard_sample_paths; rescue_pocket can include rescue_select, which includes select_flow; lane_handoff_relay includes lane_relay. Never sum overlapping buckets. late_plan includes the entire seam path and uses the existing cheap cache counters instead of per-query clocks. advance_io_motion includes processed CPU but not elapsed judge wait. Call counts record entries and include early returns unless the name denotes an already-entered conditional block. An independent measured official elapsed time is distinct from these process CPU ticks.

Do not set AHC008_CPU_PROFILE_DETAIL for the main measurement. That optional switch adds clock sampling per cutPocket candidate, intended only to localize time inside select_flow after a coarse profile. Reads plus counter updates and branch/layout perturbations can bias wall/CPU and shift solver budget-limited trajectories; off mode adds no profiling clock reads, but even that is not a guarantee of byte identity. The instrumented binary is not a proposed replacement. For speed claims run separate sequential uninstrumented controls; no profile run was executed here.

## Recorded v25 M5 construction / rescue profile

All 30 complete historical v25 action hashes and scores match this
instrumented run; original official testing and independent replay.
Total instrumented process CPU 14.173 s across 30. Inclusive times, not
disjoint:

- Guard forecast block 3.034 s (21.4%), of which sample paths 1.734 s.
- Late paired rollout 2.369 s (16.7%).
- Late seam planning 2.118 s (14.9%), 1,624,840 seam cache queries,
  1,104,408 hits.
- No existing global over-budget checks returned true in this panel.

This suggests an exact batch reduction for guard forecasts: process
shared sample positions once for multiple still-eligible tubes rather
than scan pets afresh for every horizon and tube. No speed claim from
profile or install. Go/no-go requires actual uninstrumented timing and
no action/output changes (distinguish clock-based Monte Carlo noise).
Raw evidence, generator and exact-run scripts in `evidence.tar.gz`.
