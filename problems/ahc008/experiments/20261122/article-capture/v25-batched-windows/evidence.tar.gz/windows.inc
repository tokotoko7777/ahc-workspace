// Exact capture_window reductions, bit i is tube i. The standalone evaluator
// remains the authority when representation cannot fit.
struct WindowMasks{
 using Mask=uint64_t;
 std::array<Mask,V> bad{},body{};
 Mask valid=0;
 template<class Tubes> bool initialize(const Simulator& sim,const Tubes& tubes){
  bad.fill(0);body.fill(0);valid=0;
  if(tubes.size()>64)return false;
  for(size_t i=0;i<tubes.size();i++){
   const auto& x=tubes[i];
   if(x.g<0||x.g>=V||x.k<0||x.k>=V)continue;
   const Mask bit=Mask(1)<<i;
   valid|=bit;
   for(int p:{x.g,x.k}){
    bad[p]|=bit;
    for(int q:sim.nb[p])if(q>=0)bad[q]|=bit;
   }
   for(int p:x.inner)if(p>=0&&p<V)body[p]|=bit;
  }
  return true;
 }
 template<bool WantPet=false,class Store>
 void reduce(const Paths& path,int eta,Mask desired,Store&& store)const{
  if(!desired)return;
  std::array<unsigned,64> any{},expected{};
  std::conditional_t<WantPet,std::array<std::array<unsigned,MP>,64>,std::array<unsigned,0>> per{};
  if(eta>=0&&eta<=path.horizon&&path.trials>0){
   for(int i=0;i<path.trials;i++){
    const auto& pos=path.at(i,eta);
    Mask overlap=0,blocked=0;
    for(int j=0;j<path.n;j++){
     blocked|=bad[pos[j]];
     overlap|=body[pos[j]];
    }
    const Mask available=desired&valid&~blocked;
    Mask hits=overlap&available;
    if(!hits)continue;
    while(hits){
     ++any[std::countr_zero(hits)];
     hits&=hits-1;
    }
    for(int j=0;j<path.n;j++){
     Mask pets=body[pos[j]]&available;
     while(pets){
      int k=std::countr_zero(pets);
      ++expected[k];
      if constexpr(WantPet)++per[k][j];
      pets&=pets-1;
     }
    }
   }
  }
  while(desired){
   const int k=std::countr_zero(desired);
   desired&=desired-1;
   Window out;
   if(path.trials>0){
    out.expected=double(expected[k])/path.trials;
    out.any=double(any[k])/path.trials;
    if constexpr(WantPet)for(int j=0;j<MP;j++)out.pet[j]=double(per[k][j])/path.trials;
   }
   store(k,out);
  }
 }
};
