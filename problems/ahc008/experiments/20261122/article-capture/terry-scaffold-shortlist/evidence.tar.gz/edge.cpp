#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace terry_exact_maps;
int main(){
 for(int g=0;g<5;g++){
  const auto& t=terrain(g);auto old=classify(t,t.plannedWalls,{}, {t.aisleColumns[0]});
  std::vector<bool> skip(old.count());
  for(int p:{0,W-1,V-W,V-1}){
   int k=old.ids[p];if(k<0||k>=old.count())continue;
   auto q=old.rooms[k];
   if((q.left>=0)!=(q.right>=0))skip[k]=true;
  }
  Board lostRoom,keptRoom,doors,freed;
  for(int i=0;i<V;i++)if(old.ids[i]>=0&&old.ids[i]<old.count()){
   if(skip[old.ids[i]])lostRoom[i]=true;
   else keptRoom[i]=true;
  }
  doors=lostRoom&t.doorCells;
  for(int p=0;p<V;p++)if(t.planned(p)){
   bool touches=false,protected_=false;
   for(int q:adjacent(p))if(q>=0){
    touches|=lostRoom[q];
    protected_|=keptRoom[q]||(t.doorCells[q]&&!doors[q]);
   }
   if(touches&&!protected_)freed[p]=true;
  }
  Terrain alter=t;alter.plannedWalls&=~freed;alter.doorCells&=~doors;
  for(int p=0;p<V;p++)if(freed[p]||doors[p])alter.cells[p]=Marker::Open;
  const auto now=classify(alter,alter.plannedWalls,{}, {alter.aisleColumns[0]});
  auto newShut=labels(alter.plannedWalls|alter.doorCells);
  auto oldShut=labels(t.plannedWalls|t.doorCells);
  std::vector<bool> aisles(newShut.count);
  for(int p=0;p<V;p++)if(alter.aisle(p))aisles[newShut.labels[p]]=true;
  int dropped=std::count(skip.begin(),skip.end(),true);
  bool same=now.count()==old.count()-dropped&&(old.participates&~now.participates).none();
  std::vector<int> renumber(old.count(),-1),newUsed(now.count(),-1);
  for(int p=0;p<V;p++)if(keptRoom[p]){
   const int a=old.ids[p],b=now.ids[p];
   if(b<0||b>=now.count()){same=false;continue;}
   if((renumber[a]>=0&&renumber[a]!=b)||(newUsed[b]>=0&&newUsed[b]!=a))same=false;
   renumber[a]=b;newUsed[b]=a;
  }
  for(int k=0;k<old.count();k++)if(renumber[k]>=0){
   auto x=old.rooms[k],y=now.rooms[renumber[k]];
   if(x.left!=y.left||x.right!=y.right||x.size!=y.size)same=false;
  }
  std::vector<int> identities(oldShut.count,-1),inverse(newShut.count,-1);
  for(int p=0;p<V;p++){
   if((lostRoom[p]||freed[p])&&
      (now.ids[p]>=0||newShut.labels[p]<0||!aisles[newShut.labels[p]]))same=false;
   if(!lostRoom[p]&&oldShut.labels[p]>=0){
    int a=oldShut.labels[p],b=newShut.labels[p];
    if(b<0){same=false;continue;}
    if((identities[a]>=0&&identities[a]!=b)||(inverse[b]>=0&&inverse[b]!=a))same=false;
    identities[a]=b;inverse[b]=a;
   }
  }
  std::cout<<g<<' '<<dropped<<' '<<freed.count()<<' '<<doors.count()<<' '<<same;
  for(int p=0;p<V;p++)if(freed[p])std::cout<<' '<<p;
  std::cout<<" |";
  for(int p=0;p<V;p++)if(doors[p])std::cout<<' '<<p;
  std::cout<<'\n';
 }
}
