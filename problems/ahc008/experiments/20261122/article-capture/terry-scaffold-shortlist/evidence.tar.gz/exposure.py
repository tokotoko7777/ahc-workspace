"""Exact frozen final graph exposure of the fixed edge-room retirement family."""
import argparse,collections,csv,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ahc008_terry_scaffold_audit'))
from audit import area,observed,replay,idx,bitmask

p=argparse.ArgumentParser(description=__doc__)
for k in ('geometry','ledger','inputs','tapes'):p.add_argument(k,type=Path)
a=p.parse_args()
choices={}
for row in a.geometry.read_text().splitlines():
    cuts,doors=row.split('|')
    g,rooms,planN,doorN,valid,*plan=map(int,cuts.split())
    dg=list(map(int,doors.split()))
    assert valid and len(plan)==planN and len(dg)==doorN
    choices[g]=(plan,dg,rooms)
res=[]
rows=[x for x in csv.DictReader(a.ledger.open()) if x['arm']=='terry_independent']
assert len(rows)==100
for ref in rows:
    n=ref['case']
    raw=(a.inputs/n).read_bytes()
    cmds=(a.tapes/n).with_suffix('.actions').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==ref['input_sha']
    assert hashlib.sha256(cmds).hexdigest()==ref['commands_sha']
    trace=(a.tapes/n).with_suffix('.trace').read_text().splitlines()
    sc,*_=replay(raw.decode(),trace,cmds.decode().splitlines(),detailed=True)
    assert sc==int(ref['score'])
    _,hist,_=observed(raw,trace)
    p,h,w=hist[-1]
    pets=bitmask(map(idx,p));people=list(map(idx,h));old=bitmask(map(idx,w))
    initial=area(old,people,pets)
    assert initial[0]==(ref['full']=='1')
    g=int(ref['telemetry'].split()[0]);plan,doors,rooms=choices[g]
    x=old&bitmask(plan);gates=old&bitmask(doors)
    trial=area(old&~(x|gates),people,pets)
    no_door=area(old&~x,people,pets)
    res.append(dict(case=n,map=g,full=initial[0],installed_plan=x.bit_count(),closed_retired_gates=gates.bit_count(),
               still_full=trial[0],only_X_still_full=no_door[0],
               raw_frozen_added_floor=(trial[1]-initial[1])/len(people),
               certified_added_floor=(trial[1]-initial[1])/len(people) if trial[0] else None))
full=[r for r in res if r['full']]
safe=[r for r in full if r['still_full']]
print(json.dumps(dict(cases=len(res),actual_full=len(full),by_map_cases=collections.Counter(r['map'] for r in res),
    static_retired_rooms={g:z[2] for g,z in choices.items()},
    at_least_one_removed_wall_case=sum(bool(r['installed_plan'] or r['closed_retired_gates']) for r in full),
    closed_retired_gates=sum(r['closed_retired_gates'] for r in full),
    retained_full=len(safe),tainted_full=len(full)-len(safe),
    would_leak_X_only=sum(not r['only_X_still_full'] for r in full),
    average_frozen_added_area_all_full=sum(r['raw_frozen_added_floor'] for r in full)/len(full),
    average_certified_added_area_safe_cases=sum(r['certified_added_floor'] for r in safe)/len(safe),
    cases_certified_at_least_10_cells=sum(r['certified_added_floor']>=10 for r in safe),
    by_case=res),indent=2))
