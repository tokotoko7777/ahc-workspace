#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <set>
#include <vector>
using namespace terry_exact_maps;
bool preserves(const Board& before,const Board& after){
 const auto a=labels(before),b=labels(after);
 std::vector<int> same(a.count,-1),rev(b.count,-1);
 for(int p=0;p<V;p++)if(!before[p]){
  const int x=a.labels[p],y=b.labels[p];assert(x>=0&&y>=0);
  if((same[x]>=0&&same[x]!=y)||(rev[y]>=0&&rev[y]!=x))return false;
  same[x]=y;rev[y]=x;
 }
 return true;
}
bool certificate(const Terrain& t,const Rooms& old,const Board& freed){
 const Board base=t.plannedWalls;
 const Board altered=base&~freed;
 if(!preserves(base,altered)||!preserves(base|t.doorCells,altered|t.doorCells))return false;
 const auto a=classify(t,altered,{}, {t.aisleColumns.front()});
 if(a.count()!=old.count()||(old.participates&~a.participates).any())return false;
 for(int p=0;p<V;p++){
  if(!base[p]&&a.ids[p]!=old.ids[p])return false;
  if(freed[p]&&(a.ids[p]>=0||!a.participates[p]))return false;
 }
 for(int i=0;i<a.count();i++){
  auto x=a.rooms[i],y=old.rooms[i];
  if(x.left!=y.left||x.right!=y.right||x.size!=y.size)return false;
 }
 const auto seal=labels(altered|t.doorCells);
 std::vector<bool> isAisle(seal.count);
 for(int p=0;p<V;p++)if(t.aisleCells[p]&&seal.labels[p]>=0)isAisle[seal.labels[p]]=true;
 for(int p=0;p<V;p++)if(freed[p]&&(seal.labels[p]<0||!isAisle[seal.labels[p]]))return false;
 return true;
}
int main(){
 // Short segments may only use no-room/no-gate-touch planned cells.
 // Independently verify each candidate and all singles jointly.
 for(int g=0;g<5;g++){
  auto& t=terrain(g);
  const auto room=classify(t,t.plannedWalls,{}, {t.aisleColumns.front()});
  Board target=t.doorCells,loose,single,edge;
  for(int p=0;p<V;p++)if(room.ids[p]>=0&&room.ids[p]<room.count())target[p]=true;
  for(int p=0;p<V;p++)if(t.plannedWalls[p]){
   bool touch=false;
   for(int q:adjacent(p))if(q>=0&&target[q])touch=true;
   if(!touch)loose[p]=true;
   if(p/W==0||p/W==W-1)edge[p]=true;
  }
  for(int p=0;p<V;p++)if(loose[p]){Board one;one[p]=true;if(certificate(t,room,one))single[p]=true;}
  int groups=0;
  for(int p=0;p<V;p++)if(loose[p])for(int d:{1,2}){
   Board m;int x=p;
   for(int len=1;len<=4&&x>=0&&loose[x];len++,x=adjacent(x)[d]){
    m[x]=true;
    if(len>=2&&certificate(t,room,m))++groups;
   }
  }
  Board joint=single;
  if(!certificate(t,room,joint))joint.reset();
  int outer=0;
  for(int p=0;p<V;p++)if(edge[p]){
   Board one;one[p]=true;outer+=certificate(t,room,one);
  }
  std::cout<<g<<' '<<loose.count()<<' '<<single.count()<<' '<<groups<<' '
           <<edge.count()<<' '<<(loose&edge).count()<<' '<<outer<<' '<<joint.count();
  for(int p=0;p<V;p++)if(joint[p])std::cout<<' '<<p;
  std::cout<<'\n';
 }
}
