"""Frozen same-turn occupied stock whole-capture substitution, no solver."""
from collections import defaultdict,Counter
from fractions import Fraction
from pathlib import Path
import hashlib,json,sys
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import case_history, command_effect, step, snapshot, B,ALL,mask,cells,flood,wave
from analyze import terrain
P=R/'ahc008_terry_hunt_wall_audit'
M=R/'ahc008_terry_small_poly_bounded'
ADJ=[wave(b) for b in B]

def bodies(seed,required,opened,eligible,workers):
    seen=set()
    def rec(body):
        if body in seen or body&workers:return
        seen.add(body)
        while True:
            frontier=wave(body)&opened&~body
            if frontier&workers:return
            mandatory=frontier&~eligible
            if not mandatory:break
            body|=mandatory
            if body.bit_count()>5 or body in seen:return
            seen.add(body)
        size=body.bit_count()
        if size>=3 and required&~body==0 and frontier:
            pts=list(cells(body)); xy=[divmod(p,30) for p in pts]
            r,c=zip(*xy)
            if (max(r)-min(r)+1)*(max(c)-min(c)+1)!=size:yield body,frontier
        if size<5:
            for q in cells(frontier):yield from rec(body|B[q])
    return rec(seed)

def bind(front,opts):
    todo=sorted(cells(front),key=lambda q:(len(opts[q]),q))
    def rec(k,used):
        if k==len(todo):return ()
        q=todo[k]
        for i,d in opts[q]:
            if used&B[i]:continue
            tail=rec(k+1,used|B[i])
            if tail is not None:return ((i,d),)+tail
        return None
    return rec(0,0)

def readsha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def audit(rec,doors,pin,stats):
    name=rec['case']; kinds,hist,cmds=case_history(rec)
    fp=M/'masks'/name
    assert readsha(fp)==pin[name]
    spare=dict(tuple(map(int,x.split()))for x in fp.read_text().splitlines())
    witnesses=[]
    for t in range(275):
        stats['examined']+=1
        p,h,w=hist[t]
        _,stockh,stockw=hist[t+1]
        newwalls=stockw&~w
        if not newwalls&doors:continue
        cmd=cmds[t]
        assert command_effect(h,w,p,cmd)==(stockw,stockh)
        oldids=snapshot(w,h,p)[0]
        ids,reaches,_=snapshot(stockw,stockh,p)
        gained=ids&~oldids
        if not gained:continue
        closers=defaultdict(list)
        for i,d in enumerate(cmd):
            if not d.islower():continue
            z=step(h[i],d); assert z is not None
            closers[z].append(i)
        components={flood(B[p[i]],ALL^stockw)for i in cells(gained)}
        best=None
        for actual in sorted(components):
            sz=actual.bit_count()
            if sz<5:continue
            touching=wave(actual)&newwalls
            if touching&~doors or not 1<=touching.bit_count()<=2:continue
            original={i for q in cells(touching)for i in closers[q]}
            if not 1<=len(original)<=2:continue
            stats['eligible_capture_events']+=1
            actors=sorted(original|{i for i in cells(spare.get(t,0)) if cmd[i]=='.'})
            required=mask(p[i]for i in cells(gained) if actual&B[p[i]])
            assert required
            v=stockw^touching
            forbidden=v|mask(h+stockh)|(doors&~touching)
            for q in p:forbidden|=B[q]|ADJ[q]
            opts=defaultdict(list)
            for i in actors:
                for d in 'urdl':
                    q=step(h[i],d)
                    if q is not None and not forbidden&B[q]:opts[q].append((i,d))
            if not opts:continue
            eligible=mask(opts); workers=mask(stockh)
            for body,front in bodies(required&-required,required,ALL^v,eligible,workers):
                stats['irregular_candidates']+=1
                if body.bit_count()>=sz or front.bit_count()>len(actors):continue
                used=bind(front,opts)
                if used is None:continue
                repl=list(cmd)
                for i in original:repl[i]='.'
                for i,d in used:
                    assert repl[i]=='.';repl[i]=d
                expected=v|front
                result=command_effect(h,w,p,repl)
                assert result==(expected,stockh),(name,t)
                newids,after,_=snapshot(expected,stockh,p)
                if ids!=newids:
                    stats['id_mismatch']+=1;continue
                if any(reaches[i]==reaches[j] and after[i]!=after[j] for i in range(len(h))for j in range(i)):
                    stats['worker_split']+=1;continue
                area_delta=sum(y.bit_count()-x.bit_count()for x,y in zip(reaches,after))
                if area_delta<=0:continue
                assert flood(required&-required,ALL^expected)==body
                rank=(area_delta,-body.bit_count(),-front.bit_count(),-body,-front)
                if best is None or rank>best[0]:
                    best=(rank,dict(t=t,gain=str(Fraction(area_delta,len(h))),stock_floor=sz,
                        original_walls=list(cells(touching)),new_walls=list(cells(front)),
                        new_body=list(cells(body)),changed_actual_caught_ids=[i for i in cells(gained)if B[p[i]]&actual],
                        factual=cmd,replacement=''.join(repl),stock_closers=sorted(original),
                        newly_used_idle=sorted(i for i,d in used if i not in original)))
        if best:witnesses.append(best[1])
    return witnesses

def main():
    recfile=P/'recordings.json';assert readsha(recfile)=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
    pin=dict(x.split()for x in (M/'masks_manifest.log').read_text().splitlines())
    recs=json.loads(recfile.read_text());assert len(recs)==len(pin)==100
    stats=Counter();boards={}; geos=terrain()
    for rec in recs:
        z=audit(rec,geos[rec['map']][1],pin,stats)
        if z:boards[rec['case']]=z
    witnesses=sum(len(x)for x in boards.values())
    gain=sum(Fraction(z['gain'])for x in boards.values()for z in x)
    s=dict(events=witnesses,boards=len(boards),exact_mean_floor_gain=str(gain),stats=dict(stats),
        gate=witnesses>=20 and len(boards)>=12 and gain>=100)
    (D/'report.json').write_text(json.dumps(dict(summary=s,boards=boards),indent=2)+'\n')
    print(json.dumps(s))
if __name__=='__main__':main()
