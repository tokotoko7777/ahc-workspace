"""Strict score/action-preserving shadow replay of retained selected Chase cases."""
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
import tempfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
H=ROOT/'ahc008_focus_solver/problems/ahc008'
P=ROOT/'ahc008_terry_passive_exact_short'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark_cases import run
from benchmark import replay

LOCKS=(
    ('inherited_dev',P/'dev100/pilot.csv','f5adb6ce2dad449cc01da55da296850afb8f784cced53600b3546fe2694fb383',13),
    ('inherited_held',P/'held100/confirm.csv','7754984a687f9f36b4e4c9fcc0afcc090ecac9d8a702882f0b4f03382ce63fce',12)
)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def main():
    tester,solver,out=(Path(p).resolve() for p in sys.argv[1:])
    assert not out.exists()
    selected=[]; universes=[]
    for name,path,lock,wanted in LOCKS:
        assert digest(path.read_bytes())==lock
        rows=[r for r in csv.DictReader(path.open()) if r['arm']=='terry_independent']
        assert len(rows)==100 and len({r['case'] for r in rows})==100
        universe=[]
        for r in rows:
            inp=path.parent/'in'/r['case']
            raw=inp.read_bytes()
            assert digest(raw)==r['input_sha']
            expected=list(map(int,r['telemetry'].split()))
            assert len(expected)==15 and expected[-1]==int(r['score'])
            assert expected[13]==int(expected[12]>expected[11])
            universe.append(r['input_sha'])
            if expected[13]:
                assert expected[10]>0
                selected.append((name,r,raw,expected))
        assert sum(k==name for k,*_ in selected)==wanted
        universes.extend(universe)
    assert len(universes)==len(set(universes))==200 and len(selected)==25
    report=[]
    for name,r,raw,stat in selected:
        pairs,normal,chase,old=stat[10:14]
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); log=d/'shadow'; telemetry=d/'telemetry'; a=d/'actions'; tape=d/'tape'
            out_raw,err,code,wall=run([str(tester),'env','AHC008_TERRY_EXACT_LOG='+str(telemetry),
                                      'AHC008_TERMINAL_SHADOW='+str(log),str(solver),f'--pairs={pairs}'],raw,5.5)
            score=re.fullmatch(rb'Score = (\d+)\s*',err)
            assert code==0 and score and int(score[1])==stat[-1],(name,r['case'],code,err)
            assert digest(out_raw)==r['commands_sha'],(name,r['case'],'changed full transcript')
            assert list(map(int,telemetry.read_text().split()))==stat,(name,r['case'],'changed stock telemetry')
            a.write_bytes(out_raw)
            out_again,err_again,code_again,_=run([str(tester),sys.executable,str(H/'benchmark_cases.py'),
                                                  '--playback',str(a),str(tape)],raw,12.)
            assert (out_raw,err,code)==(out_again,err_again,code_again)
            assert replay(raw.decode(),tape.read_text().splitlines(),out_raw.decode().splitlines(),detailed=True)[0]==stat[-1]
            logs=list(map(int,log.read_text().split()))
            assert len(logs)==12 and logs[:4]==stat[10:14]
            a,b=logs[4:8],logs[8:12]
            for n,group in ((pairs//2,a),(pairs-pairs//2,b)):
                assert all(0<=v<=n for v in group) and group[0]>=group[2] and group[1]>=group[3]
            raw_delta,useful_delta=(a[i+1]+b[i+1]-a[i]-b[i] for i in (0,2))
            veto=raw_delta<0 or useful_delta<0
            concord=pairs>=4 and veto and any(x<y and u<v for x,y,u,v in ((a[1],a[0],b[1],b[0]),(a[3],a[2],b[3],b[2])))
            q=dict(cohort=name,case=r['case'],input_sha=r['input_sha'],commands_sha=r['commands_sha'],
                   score=stat[-1],actual_full=int(r['full']),actual_useful=int(r['useful300']),
                   pairs=pairs,normal_score_sum=normal,chase_score_sum=chase,split_first=a,split_second=b,
                   raw_chase_minus_normal=raw_delta,useful_chase_minus_normal=useful_delta,
                   veto=veto,concordant_split=concord,offline_wall=wall)
            report.append(q)
            print(name,r['case'],pairs,raw_delta,useful_delta,bool(veto),bool(concord),flush=True)
    v=sum(r['veto'] for r in report); c=sum(r['concordant_split'] for r in report)
    miss=sum(r['veto'] and (not r['actual_full'] or not r['actual_useful']) for r in report)
    result=dict(cohort_denominator=200,stock_selected_chase=25,exact_reexecuted=25,
                veto_boards=v,concordant_boards=c,factual_miss_veto_boards=miss,
                gate=v>=5 and c>=3 and miss>=1,rows=report)
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()if k!='rows'},indent=2))
if __name__=='__main__': main()
