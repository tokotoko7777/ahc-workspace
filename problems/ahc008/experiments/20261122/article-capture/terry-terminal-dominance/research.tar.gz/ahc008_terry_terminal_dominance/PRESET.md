# Observation only: terminal predicted capture-count dominance
This screen uses both frozen accepted h123 dev100 and held100 result
ledgers (SHA pins in audit.py) as inherited independent development
cohorts, not a new holdout for this comparator. Do not use practice100,
generate data, run a variant policy, or change a rule after observing.
All 200 input rows establish the denominator. Only stock-selected
Chase can be vetoed with the same completed paired work, so rerun just
those 25 rows at their exact recorded fixed pair count. All recorded
pairs must complete in shadow mode, with unchanged terminal seed,
actions, score, stock map, stock Chase selection and exact Normal and
Chase accumulated scores. Do not drop incomplete or mismatched rows.
Only the isolated local diagnostic execution disables the internal
2,670ms cutoff, since the hard pair cap is fixed per ledger. External
time bounds remain. This has no default/production behavior.

Score and full/useful outcomes are extracted from one original final
per-person component traversal on each completed simulated arm. Raw
full means no animal in any human component; useful means raw full and
per-person integer area sum at least 300*M. The normalized
decision would additionally require Chase predicted raw and useful
counts each no lower than Normal. Equal score cannot enter Chase.
The shadow records the rule but always emits original accepted actions.

Split every recorded pair list at floor(N/2), preserving consecutive
seed order. A full-list veto has repeated evidence only if N≥4 and
the *same* strict disadvantage (raw or useful) appears in both
halves; a raw deficit on one half and useful on the other does not
pass. A repeated direction is not an independent real-world validation.
Advance only if there are at least 5 veto boards, at least 3 with a
concordant split, and at least 1 actual stock raw or useful miss among
vetoes. If not, no change and no scope expansion. These are real-state
forecast differences, not proof of a rescue or observed gains. Even if
passed, a real candidate must first be compared on separate fresh
uniform100 and independent locked holdout with ≥0.1% score gain, raw
and useful nonlower, all legal, local max <2.95s.
