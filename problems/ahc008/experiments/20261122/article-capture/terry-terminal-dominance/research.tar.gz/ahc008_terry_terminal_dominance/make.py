"""Make the private source for a shadow-only terminal instrumentation."""
import hashlib
import os
import sys
from pathlib import Path
BASE='08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
def main():
    p=Path(sys.argv[1])
    raw=p.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==BASE
    body=raw.decode()
    def replace(old,new):
        nonlocal body
        assert body.count(old)==1,old
        body=body.replace(old,new,1)
    replace('inline int score(const State& s){',
            'struct EndMetrics {int points; int full; int useful;};\ninline EndMetrics terminal_metrics(const State& s){')
    replace(' for(auto p:s.pets)if(g[p.pos]>=0)++animals[g[p.pos]];',
            ' bool full=true;\n for(auto p:s.pets)if(g[p.pos]>=0){++animals[g[p.pos]];full=false;}')
    replace(' for(int h:s.people){int i=g[h];v+=std::ldexp(double(sizes[i])/900.,-animals[i]);}\n return int(std::round(v*1e8/s.people.size()));\n}',
            ' int sum=0;\n for(int h:s.people){int i=g[h];v+=std::ldexp(double(sizes[i])/900.,-animals[i]);sum+=sizes[i];}\n return {int(std::round(v*1e8/s.people.size())),full,full&&sum>=300*int(s.people.size())};\n}\n'
            'inline int score(const State& s){return terminal_metrics(s).points;}')
    replace('struct Decision{int pairs=0;int64_t normal=0,chase_sum=0;bool chose=false;};',
            'struct Decision{int pairs=0;int64_t normal=0,chase_sum=0;bool chose=false;\n'
            ' std::array<std::array<int,4>,2> shadow{};\n};')
    replace('  ++answer.pairs;answer.normal+=score(s);answer.chase_sum+=score(t);',
            '  const auto ea=terminal_metrics(s),eb=terminal_metrics(t);\n'
            '  ++answer.pairs;answer.normal+=ea.points;answer.chase_sum+=eb.points;\n'
            '  auto& z=answer.shadow[i<=cap/2?0:1];z[0]+=ea.full;z[1]+=eb.full;z[2]+=ea.useful;z[3]+=eb.useful;')
    replace(' const auto stop=started+std::chrono::milliseconds(limit_ms);',
            ' const char* shadow_path=std::getenv("AHC008_TERMINAL_SHADOW");\n'
            ' if(shadow_path&&(cap<1||cap>1000))return 2;\n'
            ' const auto stop=shadow_path?Clock::time_point::max():started+std::chrono::milliseconds(limit_ms);')
    replace(' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){',
            ' if(shadow_path){\n'
            '  std::ofstream f(shadow_path);\n'
            '  f<<d.pairs<<\' \'<<d.normal<<\' \'<<d.chase_sum<<\' \'<<d.chose;\n'
            '  for(const auto& block:d.shadow)for(int x:block)f<<\' \'<<x;\n'
            '  f<<\'\\n\';\n }\n'
            ' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){')
    dst=Path(__file__).resolve().parent/'shadow.private.cpp'
    fd=os.open(dst,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as f:f.write(body)
    dst.chmod(0o600)
    print(hashlib.sha256(dst.read_bytes()).hexdigest())
if __name__=='__main__':main()
