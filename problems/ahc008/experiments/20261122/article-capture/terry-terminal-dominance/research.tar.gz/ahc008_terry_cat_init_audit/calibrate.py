"""Fixed, observed-only t275 first-step calibration, with cheap exposure mode."""
import argparse
import hashlib
import json
import math
from pathlib import Path

D=Path(__file__).resolve().parents[1]/'ahc008_terry_chase_cut_ties'
DIR='UDLR'
adj=[[p-30 if p>=30 else -1,p+30 if p<870 else -1,
      p-1 if p%30 else -1,p+1 if p%30<29 else -1] for p in range(900)]
pop=[i.bit_count() for i in range(16)]

def next_pos(p,c):
    return p if c=='.' else adj[p][DIR.index(c.upper())]

def bfs(p,walls):
    masks=[0]*900
    dist=[-1]*900
    dist[p]=0
    reach=[p]
    for q in reach:
        nd=dist[q]+1
        for k,z in enumerate(adj[q]):
            if z<0 or walls[z]: continue
            if dist[z]<0:
                dist[z]=nd
                reach.append(z)
            if dist[z]==nd:
                masks[z]|=(1<<k) if q==p else masks[q]
    return reach,masks

def forecast(p,walls,posterior):
    prior,_=posterior
    reach,masks=bfs(p,walls)
    if len(reach)==1: return reach,masks,0.,[0.]*4,[0.]*4,0.
    survivors=sum(prior[q] for q in reach[1:])
    renew=min(1.,max(0.,1.-survivors))
    uniform=1./(len(reach)-1)
    spread=renew*uniform
    a=[0.]*4; b=[0.]*4; square=0.
    for q in reach[1:]:
        m=masks[q]
        v=prior[q]+spread
        square+=v*v
        av=v/pop[m]; bv=uniform/pop[m]
        for k in range(4):
            if m&(1<<k): a[k]+=av; b[k]+=bv
    return reach,masks,spread,a,b,1./square if square>0 else 0.

def update(first,mid,end,post,info):
    prior,_=post
    reach,masks,spread,a,_,_=info
    if first<0 or a[first]<=0: return ([0.]*900,1.)
    bit=1<<first
    scale=1./a[first]
    ans=[0.]*900
    for q in reach[1:]:
        m=masks[q]
        if m&bit: ans[q]=(prior[q]+spread)*scale/pop[m]
    reset=ans[mid]+(ans[end] if end!=mid else 0.)
    ans[mid]=ans[end]=0.
    return ans,reset

def majority(people,walls):
    # Ties use the first row-major cell in the component, not human index.
    visited=set()
    best=()
    result=set()
    for p in people:
        if p in visited: continue
        c=set(bfs(p,walls)[0])
        visited.update(c)
        key=(sum(q in c for q in people),-min(c))
        if key>best: best=key; result=c
    return result

def contents(path,key,row):
    b=path.read_bytes()
    assert hashlib.sha256(b).hexdigest()==row[key],(path,key)
    return b.decode().splitlines()

def case(row,exposure):
    name=f'{row["board"]:04d}'
    inp=contents(D/'in'/f'{name}.txt','input_sha',row)
    actions=contents(D/'tapes'/f'{name}.actions','commands_sha',row)
    tape=contents(D/'tapes'/f'{name}.trace','trace_sha',row)
    assert tape[::2]==actions
    n=int(inp[0])
    pos=[(int(r)-1)*30+int(c)-1 for r,c,_ in map(str.split,inp[1:1+n])]
    cats={i for i,line in enumerate(inp[1:1+n]) if line.split()[-1]=='5'}
    people=[(int(r)-1)*30+int(c)-1 for r,c in map(str.split,inp[n+2:n+2+int(inp[n+1])])]
    walls=bytearray(900)
    eligible=set()
    history=[]
    stop=275 if exposure else 276
    for t in range(stop):
        if t>=270 and not exposure:
            comp=majority(people,walls)
            eligible={i for i in cats if pos[i] in comp}
        for j,c in enumerate(actions[t]):
            q=next_pos(people[j],c)
            if c.islower(): walls[q]=1
            else: people[j]=q
        moves=tape[2*t+1].split()
        assert len(moves)==n
        if not exposure:
            history.append((walls[:],{i:(pos[i],moves[i]) for i in cats},eligible.copy() if t>=270 else set()))
        for i,string in enumerate(moves):
            for c in string: pos[i]=next_pos(pos[i],c)
    if exposure:
        comp=majority(people,walls)
        return [name,sum(pos[i] in comp for i in cats),len(cats)]
    # Filter only cats eligible on at least one reported turn, retaining their full prefix.
    qualifying=set().union(*(h[2] for h in history[-6:]))
    post={i:([0.]*900,1.) for i in qualifying}
    rows=[]
    for t,(wall,starts,eligible) in enumerate(history):
        for i in qualifying:
            p,string=starts[i]
            first=DIR.find(string[0]) if string else -1
            mid=next_pos(p,string[0]) if first>=0 else p
            end=mid
            for c in string[1:]: end=next_pos(end,c)
            before=post[i]
            info=forecast(p,wall,before)
            if i in eligible:
                _,_,_,a,b,ess=info
                rows.append(dict(case=name,turn=t,cat=i,direction=first,post=a,uniform=b,reset=before[1],ess=ess))
            post[i]=update(first,mid,end,before,info)
    return rows

def summarize(rows,lo,hi):
    cases={}
    excluded=0
    for r in rows:
        if not lo<=r['turn']<=hi:continue
        k=r['direction']
        if k<0:excluded+=1;continue
        a,b=r['post'],r['uniform']
        dn=math.log(max(a[k],1e-12))-math.log(max(b[k],1e-12))
        db=sum((b[i]-(i==k))**2-(a[i]-(i==k))**2 for i in range(4))
        cases.setdefault(r['case'],[]).append((dn,db))
    n=len(cases)
    dn=[sum(x for x,_ in a)/len(a) for a in cases.values()]
    db=[sum(y for _,y in a)/len(a) for a in cases.values()]
    return dict(cases=n,events=sum(map(len,cases.values())),excluded=excluded,
        nll_gain=sum(dn)/max(n,1),brier_gain=sum(db)/max(n,1),wins=sum(x>0 for x in dn),
        pass_gate=n>=12 and sum(dn)/max(n,1)>=.05 and sum(db)>0 and sum(x>0 for x in dn)>n/2)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--exposure',action='store_true')
    args=ap.parse_args()
    meta=json.loads((D/'report.json').read_text())
    assert meta['n']==len(meta['tapes'])==60
    data=[]; unavailable=[]
    for row in meta['tapes']:
        try:
            v=case(row,args.exposure)
        except (FileNotFoundError,AssertionError) as e:
            unavailable.append([row['board'],str(e)])
            continue
        if args.exposure: data.append(v)
        else: data.extend(v)
    if args.exposure:
        print(json.dumps(dict(verified=len(data),connected_cases=sum(x[1]>0 for x in data),
            connected_cats=sum(x[1] for x in data),total_cats=sum(x[2] for x in data),
            per_case=[x for x in data if x[1]>0],unavailable=unavailable)))
    else:
        print(json.dumps(dict(primary=summarize(data,275,275),support=summarize(data,270,274),
            unavailable=unavailable,rows=data)))

if __name__=='__main__': main()
