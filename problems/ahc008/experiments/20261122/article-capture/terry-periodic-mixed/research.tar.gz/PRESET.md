# Mixed I/O periodic board: one frozen feasibility query

Independent of cases, stock tapes, and solver source. Solve one 10×10 periodic
binary MILP via SciPy HiGHS. Stop after ≤180 seconds with the command below.
Single model, zero objective, no retries, alternate tiers or threshold changes.
Timeout without a witness is not impossibility; a verified MILP infeasibility
is for this exact template and backbone only. A candidate that fails physical
verification remains a failure; the model relaxes nonlocal connectivity.

## Model
Both I and O exact 4-cell chambers; two opposite mouths, aligned in an
I row/column or in one of two same-row O placements. Both pig-safe parities:
at least one floor of each parity not orthogonally close to either gate.
Mouth and outward guard are consecutive; the two stances of each room are
distinct, but different rooms can share an exterior stance.
Require >=9 rooms, <=25 walls, at least one room of each traffic axis; do
not require both shape families represented. Reserve full row 0 and column
0 as exterior streets. Guards can stand there, not walls/gates/body. This
is a tractability restriction, not a necessary condition of general periodic
feasibility. A 4×4 subgrid or arbitrary hybrid port movement is not modeled.
Body/mouth/guard ownership sum plus wall <=1, incidence of brace requests
<=4 times wall and wall implies at least one request. Stance requests ≤4
times unoccupied (not body, gate or wall). Both factors are exact: each
requesting room owns a distinct adjacent body or gate cell, respectively.

## Independent checks
Recompute cell borders, guards, parity and distinct ownership. Flood physical
open board, body under each individual closure, residual connected floor under
each individual closure, exterior on all closures, and each named body after
all closures. Verify an uninterrupted exterior row and column orthogonally
meet. In the periodic lift, following the complete row/column supplies
two continuous paths from their intersection to the corresponding translated
intersections, hence independent winding even with all gates closed. Every
guard reaches this backbone in <=4 exterior-only steps. Evaluate all 100
relative phases of one incumbent for the bounded 30×30 board (eight dihedral
symmetries produce isometric bounded boards, so need no repeated checks)
(no extra solver calls): keep every complete body+gates+guard placement,
convert incomplete room floor to exterior, keep/charge all 225-or-fewer
periodic X, check actual >=75 rooms and repeat physical checks with no wraps.
No implied construction or live usefulness. End-to-end limit enforced as:
```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout -k 1s 179s \
  python3 -u ahc008_terry_periodic_mixed/search.py
```
