#!/usr/bin/env python3
"""One frozen, pure-geometry HiGHS feasibility model."""
import itertools as it
import json
import sys
from collections import deque
from time import monotonic

T = 10
D = ((1,0),(-1,0),(0,1),(0,-1))
def add(a,b): return a[0]+b[0], a[1]+b[1]
def mod(p): return p[0]%T,p[1]%T
def outside(body):
    return {add(p,d) for p in body for d in D} - set(body)
def transform(p,k):
    x,y=p
    if k&4: x,y=y,x
    return ((-x if k&1 else x),(-y if k&2 else y))

def templates():
    """(axis, family, unwrapped anchor-relative body, gates, guards, braces)."""
    for axis in range(2):
        for family in ('I','O'):
            for row in range(1+(family=='O')):
                b = {(0,j) for j in range(4)} if family=='I' else set(it.product(range(2),repeat=2))
                end = 3 if family=='I' else 1
                g = {(row,-1),(row,end+1)}
                s = {(row,-2),(row,end+2)}
                z = outside(b)-g
                assert len({sum(p)%2 for p in b-outside(g)})==2
                yield (axis,family,*(frozenset(transform(p,axis*4) for p in a) for a in (b,g,s,z)))

def placements():
    out=[]
    for r,c in it.product(range(T), repeat=2):
        for a,f,b,g,s,z in templates():
            raw=tuple(frozenset(add(p,(r,c)) for p in q) for q in (b,g,s,z))
            bb,gg,ss,zz=(frozenset(map(mod,q)) for q in raw)
            if any(0 in p for p in bb|gg|zz): continue
            assert len(bb|gg|ss|zz)==sum(map(len,raw))
            out.append((a,f,(bb,gg,ss,zz),raw))
    return out

def solve(start):
    import numpy as np
    from scipy.optimize import milp, Bounds, LinearConstraint
    from scipy.sparse import coo_matrix
    ps=placements()
    cells=list(it.product(range(T),repeat=2))
    nc=len(ps)
    ix={p:nc+i for i,p in enumerate(cells)}
    rows=[]; cols=[]; vals=[]; lo=[]; hi=[]
    def con(terms,l=-np.inf,u=np.inf):
        j=len(lo)
        for k,v in terms:
            rows.append(j);cols.append(k);vals.append(v)
        lo.append(l);hi.append(u)
    con(((i,1) for i in range(nc)),l=9)
    con(((i,1) for i in ix.values()),u=25)
    for a in range(2):
        con(((i,1) for i,q in enumerate(ps) if q[0]==a),l=1)
    for p in cells:
        w=ix[p]
        owned=[]; incident=[]; service=[]
        for i,(_,_,(b,g,s,z),_) in enumerate(ps):
            if p in b or p in g: owned.append(i)
            if p in s: service.append(i)
            if p in z: incident.append(i)
        con([(i,1) for i in owned]+[(w,1)],u=1)
        # Different rooms may share a stance, each via a distinct adjacent gate.
        con([(i,4) for i in owned]+[(i,1) for i in service]+[(w,4)],u=4)
        # Every requiring template owns a distinct body neighbor of p.
        con([(i,1) for i in incident]+[(w,-4)],u=0)
        # No ornamental walls.
        con([(i,-1) for i in incident]+[(w,1)],u=0)
    shape=(len(lo),nc+len(cells))
    a=coo_matrix((vals,(rows,cols)),shape=shape).tocsc()
    print(json.dumps(dict(templates=nc,variables=shape[1],rows=shape[0],nnz=a.nnz)),flush=True)
    seconds=168-(monotonic()-start)
    if seconds<=0: return
    result=milp(np.zeros(shape[1]),integrality=np.ones(shape[1]),
                bounds=Bounds(np.zeros(shape[1]),np.ones(shape[1])),
                constraints=LinearConstraint(a,np.array(lo),np.array(hi)),
                options=dict(time_limit=seconds,presolve=True))
    print(json.dumps(dict(status=int(result.status),msg=result.message,
                          elapsed=monotonic()-start,incumbent=result.x is not None)),flush=True)
    if result.x is not None:
        x=result.x
        if np.max(abs(x-np.rint(x)))>1e-6: raise AssertionError("fractional incumbent")
        chosen=[ps[i] for i in range(nc) if x[i]>0.5]
        walls={p for p,i in ix.items() if x[i]>0.5}
        yield chosen,walls

def flood(start,allowed,step):
    assert start in allowed
    d={start:0}; q=deque([start])
    while q:
        p=q.popleft()
        for n in step(p):
            if n in allowed and n not in d:
                d[n]=d[p]+1;q.append(n)
    return d

def verify(n,rooms,walls,periodic,cap,minimum,axis_required=True):
    """No MILP matrix use. Check physical open/locked floor and actor constraints."""
    def neighbors(p):
        return [((p[0]+d[0])%n,(p[1]+d[1])%n) if periodic else add(p,d) for d in D]
    cell=set(it.product(range(n),repeat=2))
    assert len(walls)<=cap and len(rooms)>=minimum
    assert walls<=cell
    assert not axis_required or {r[0] for r in rooms}=={0,1}
    floors=[]
    guards=set()
    for ax,fam,(b,g,s,z) in rooms:
        assert len(b)==4 and len(g)==len(s)==2 and fam in ('I','O')
        assert set(b|g|s)<=cell and not (b|g|s)&walls 
        assert not b&g and not (b|g)&s
        assert not (b|g)&set().union(*floors) and not (b|g)&guards
        assert not s&set().union(*floors)
        guards|=s
        floors.append(b|g)
        # All boundary cells that exist physically must be the two gates or solid.
        bd={q for p in b for q in neighbors(p) if q in cell}-b
        assert bd==g|z and z<=walls
        safe=b-{q for p in g for q in neighbors(p)}
        assert {sum(p)%2 for p in safe}=={0,1}
        assert all(len(set(neighbors(p))&s)==1 and len(set(neighbors(p))&b)==1 for p in g)
        assert all(len(set(neighbors(p))&g)==1 for p in s)
        for p in g:
            body_neighbor,=set(neighbors(p))&b
            guard,=set(neighbors(p))&s
            assert (body_neighbor[ax^1]+guard[ax^1]-2*p[ax^1]) % n == 0
            assert body_neighbor[ax]==guard[ax]==p[ax]
        assert len(set(flood(min(b),b,neighbors)))==4
        if fam=='O': assert all(len(set(neighbors(p))&b)==2 for p in b)
        else: assert len({p[ax] for p in b})==1
        y=ax
        by=sorted({p[y] for p in g})
        assert len(by)==1  # horizontal pair same row, vertical pair same column
    blank=cell-walls
    ext=blank-set().union(*floors)
    assert guards<=ext
    # At least one physically uninterrupted exterior row and column: their
    # 3×3 periodic lift contains paths to +n in both axes, with locks or without.
    rows=[i for i in range(n) if all((i,j) in ext for j in range(n))]
    cols=[j for j in range(n) if all((i,j) in ext for i in range(n))]
    assert rows and cols
    backbone={p for p in ext if p[0] in rows or p[1] in cols}
    root=rows[0],cols[0]
    assert len(flood(root,blank,neighbors))==len(blank)
    assert set(flood(root,ext,neighbors))==ext
    # Multi-source exterior distance to an axis street, independently checked.
    near=backbone.copy()
    for _ in range(4): near|={q for p in near for q in neighbors(p) if q in ext}
    assert guards<=near
    allg=set().union(*(r[2][1] for r in rooms))
    for ax,f,(b,g,s,z) in rooms:
        assert set(flood(min(b),blank-g,neighbors))==b
        assert len(flood(root,blank-g,neighbors))==len(blank-g)-4
        assert set(flood(min(b),blank-allg,neighbors))==b
    return dict(rooms=len(rooms), walls=len(walls), horizontal=sum(a==0 for a,_,_ in rooms),
                exterior=len(ext), rows=rows, cols=cols, guard_max_distance=4)

def bounded(chosen,wall):
    """Check the one witness's fixed translations/dihedral phases, no second solve."""
    # Other dihedral phases are isometries of these 100 bounded boards.
    for k,rs,cs in it.product((0,),range(T),range(T)):
        def forward(p): return add(transform(p,k),(rs,cs))
        tw=set(mod(forward(q)) for q in wall)
        bw={(r,c) for r,c in it.product(range(30),repeat=2) if mod((r,c)) in tw}
        rooms=[]
        inside=lambda p: min(p)>=0 and max(p)<30
        for axis,f,_,raw in chosen:
            for i,j in it.product(range(-2,4),repeat=2):
                b,g,s,z=tuple(frozenset(add(forward(p),(T*i,T*j)) for p in part) for part in raw)
                if all(map(inside,b|g|s)):
                    rooms.append((axis^bool(k&4),f,(b,g,s,frozenset(filter(inside,z)))))
        if len(rooms)<75: continue
        try:
            proof=verify(30,rooms,bw,False,225,75)
        except AssertionError:
            continue
        return dict(phase=[k,rs,cs],proof=proof,walls=bw,rooms=rooms)
    return None

def display(walls,rooms,n):
    board=[['.']*n for _ in range(n)]
    for r,c in walls: board[r][c]='#'
    for ax,f,(b,g,s,z) in rooms:
        for r,c in b: board[r][c]='H' if ax==0 else 'V'
        for r,c in g: board[r][c]='g'
        for r,c in s: board[r][c]='s'
    return [''.join(row) for row in board]

def main():
    start=monotonic()
    for chosen,walls in solve(start):
        rooms=[(a,f,phys) for a,f,phys,_ in chosen]
        try:
            proof=verify(T,rooms,walls,True,25,9)
        except AssertionError:
            print(json.dumps(dict(torus_verified=False,board=display(walls,rooms,T))))
            raise
        print(json.dumps(dict(torus_verified=True,proof=proof,board=display(walls,rooms,T))),flush=True)
        p=bounded(chosen,walls)
        if p is not None:
            print(json.dumps(dict(bounded_verified=True,phase=p['phase'],proof=p['proof'],
                                  board=display(p['walls'],p['rooms'],30))))
        else:
            print(json.dumps(dict(bounded_verified=False)))
if __name__=='__main__':
    main()
