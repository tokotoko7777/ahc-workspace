"""Prepped only: deterministic phase4 center fallback geometry and signed future labels."""
import collections,hashlib,itertools,json,os,subprocess,sys,tempfile,time
from pathlib import Path
D=Path(__file__).resolve().parent;ROOT=D.parent
sys.path.insert(0,str(ROOT/'ahc008_terry_inward_online'))
from observer import case_history,command_effect,step,B,ALL,mask,cells,flood,wave
LEDGER=ROOT/'ahc008_terry_hunt_wall_audit/recordings.json'
INPUT=ROOT/'ahc008_terry_incoming_shadow/held100/in'
TAPES=LEDGER.parent/'tapes'
CAT=ROOT/'ahc008_terry_small_rooms/catalog.tsv'
LANES=((8,21),(4,14,24),(4,11,18,25),(0,6,13,19,26),(4,11,18,25))
PINS={LEDGER:'dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5',
      CAT:'2d697e1b2cbf0cd9d754d38a18059e2fbcd484b7440868da8016f8310132ba06',
      ROOT/'ahc008_terry_inward_online/observer.py':'0adb6fdafc77a7a778dbd5ff11a812ef95379124a2f8201dcebe527618409d70'}
def comp(h,w):return flood(mask(h),ALL^w)
def tags(path,m):
    flags=collections.defaultdict(set)
    for line in path.read_text().splitlines():
        t,i=map(int,line.split())
        assert 0<=t<275 and 0<=i<m and i not in flags[t]
        flags[t].add(i)
    return flags
def catalog():
    out=collections.defaultdict(list)
    for row in CAT.read_text().splitlines():
        m,r,l,h,*body=map(int,row.split())
        if (l>=0)==(h>=0) or not 1<=len(body)<=4:continue
        gate=l if l>=0 else h
        move='R' if l>=0 else 'L'
        stance=step(gate,'L' if l>=0 else 'R')
        if stance is not None and stance%30 in LANES[m]:
            out[m].append((gate,stance,move,mask(body)))
    return out
def intervals(a,b,w):
    if a%30!=b%30:return None
    lo,hi=sorted((a,b))
    line=mask(range(lo,hi+1,30))
    if line&w:return None
    return (hi-lo)//30
def screen(rec,st,old,flags,ct,stats):
    q=[];mid=rec['map']; anchors=mask(r*30+c for r in range(30) for c in LANES[mid])
    for t in sorted(flags):
        if len(flags[t])<2:continue
        p,h,w=st[t]
        prev=comp(h,w);pm=mask(p)
        if not prev&pm:stats['postclear_flags']+=1;continue
        actual=command_effect(h,w,p,old[t]);assert actual
        pw,ph=actual;after=comp(ph,pw)
        for lane in LANES[mid]:
            f=[i for i in sorted(flags[t]) if h[i]%30==lane]
            if len(f)<2:continue
            i,j=f[:2]
            lane_root=flood(B[h[i]],ALL^w)
            if not (lane_root&B[h[j]] and lane_root&pm):continue
            stats['same_lane_live_pairs']+=1
            # Canonical ready room is actually cut by its currently open
            # legal mouth, body complete, with an exterior stance.
            sites=[]
            forbidden=pm|wave(pm)|mask(h)|mask(ph)|pw
            for g,s,move,b in ct[mid]:
                if s%30!=lane or B[g]&forbidden or b&(pw|mask(ph)):continue
                if flood(b&-b,ALL^(pw|B[g]))!=b:continue
                if not B[s]&after or not b&after:continue
                if not b&~(B[g]|wave(B[g])):continue
                sites.append((g,s,move,b))
            if len({x[1] for x in sites})<2:continue
            def obj(people):
                vals=[]
                for _,s,_,_ in sites:
                    ds=[z for i in f if (z:=intervals(people[i],s,pw)) is not None]
                    if not ds:return None
                    vals.append(min(ds))
                return max(vals),sum(vals)
            ref=obj(ph)
            if ref is None:continue
            best=None
            for a,b in itertools.product('.UD',repeat=2):
                cmd=list(old[t]);cmd[i]=a;cmd[j]=b;cmd=''.join(cmd)
                if cmd==old[t]:continue
                trial=command_effect(h,w,p,cmd)
                if not trial or trial[0]!=pw:continue
                nh=trial[1]
                if any(flood(B[x],ALL^pw)!=flood(B[y],ALL^pw) for x,y in zip(ph,nh,strict=True)):continue
                if (after&anchors)&~comp(nh,pw):continue
                value=obj(nh)
                if value is None or value>=ref:continue
                # At least one worst-case stance step, not a sum-only gain.
                if value[0]>=ref[0]:continue
                k=(value,sum(x!=y for x,y in zip(old[t],cmd,strict=True)),a,b)
                if best is None or k<best[0]:best=(k,nh,cmd)
            if best:
                stat,nh,cmd=best
                q.append(dict(t=t,actors=[i,j],h=list(nh),stock=old[t],shadow=cmd,sites=sites,
                    minimax_gain=ref[0]-stat[0][0],sum_gain=ref[1]-stat[0][1]))
                stats['strict_first_decisions']+=1
                break # a single chosen first aisle, stable configured order
    return q
def label(st,old,flags,options,dl):
    witnesses=[];seen=set()
    for q in options:
        if time.monotonic()>dl:raise TimeoutError('total deadline')
        t=q['t'];shadow=q['h']
        for n in range(t+1,min(t+4,275)):
            p,h,w=st[n]; retained=set(q['actors'])
            delta={i for i in retained if h[i]!=shadow[i]}
            if not delta:break
            # Any genuinely committed build/move/hold touched by the
            # positional offset invalidates the prefix (no reassignment).
            if not delta<=flags.get(n,set()):break
            assert all(h[i]==shadow[i] for i in range(len(h)) if i not in retained)
            old_action=command_effect(h,w,p,old[n]);assert old_action
            ow,of=old_action;before=comp(h,w);orc=comp(of,ow)
            old_captured={i for i,x in enumerate(p)if B[x]&before and not B[x]&orc}
            # Verify shifted origins still have exact actual human reach.
            if any(flood(B[x],ALL^w)!=flood(B[y],ALL^w) for x,y in zip(h,shadow,strict=True)):break
            for i in sorted(delta):
                if old[n][i].islower():continue
                for gate,stance,d,body in q['sites']:
                    if shadow[i]!=stance or h[i]==stance:continue
                    if body&(mask(shadow)|w|ow) or B[gate]&(w|ow):continue
                    if flood(body&-body,ALL^(ow|B[gate]))!=body:continue
                    ca=list(old[n]);ca[i]=d.lower();ca=''.join(ca)
                    result=command_effect(shadow,w,p,ca)
                    if not result or result[0]!=(ow|B[gate]):continue
                    rw,rh=result;root=comp(rh,rw)
                    if root&body or any(B[p[j]]&root for j in old_captured):continue
                    new={j for j,x in enumerate(p)if B[x]&before&body and not B[x]&root}-old_captured
                    fresh=new-seen
                    if fresh:
                        witnesses.append(dict(start=t,close=n,actor=i,gate=gate,ids=sorted(fresh)))
                        seen|=fresh
            moved=command_effect(shadow,w,p,old[n])
            if not moved or moved[0]!=ow or any(B[p[j]]&comp(moved[1],ow) for j in old_captured):break
            shadow=moved[1]
    return witnesses,seen
def main(exe):
    start=time.monotonic();structural=start+120;deadline=start+180
    for f,h in PINS.items():assert hashlib.sha256(f.read_bytes()).hexdigest()==h
    ct=catalog();rec=json.loads(LEDGER.read_text())
    assert len(rec)==len({q['case'] for q in rec})==100
    prepared=[];stats=collections.Counter()
    for q in rec:
        nm=q['case']; kinds,st,old=case_history(q)
        raw=(INPUT/nm).read_text().splitlines();n=int(raw[0]);m=int(raw[n+1]);assert len(st[0][1])==m
        tr=(TAPES/nm).with_suffix('.trace').read_text().splitlines()
        payload='\n'.join(raw[:n+2+m]+tr[1:550:2])+'\n'
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'flags'
            sub=subprocess.run([str(exe.resolve()),'--pairs=0'],input=payload,text=True,capture_output=True,check=True,
                timeout=max(.001,structural-time.monotonic()),env=dict(os.environ,AHC008_IDLE_SPACING_TRACE=str(f)))
            assert sub.stdout.splitlines()==old[:275],nm
            flags=tags(f,m)
        picks=screen(q,st,old,flags,ct,stats)
        if picks:prepared.append((nm,st,old,flags,picks))
        if time.monotonic()>structural:raise TimeoutError('structural deadline')
    summary=dict(verified=100,structural_boards=len(prepared),counters=stats,passes=False)
    if len(prepared)<20:return summary|dict(phase='structural-stop')
    out=[];heads=0
    for nm,st,old,flags,picks in prepared:
        ws,ids=label(st,old,flags,picks,deadline)
        if ids:out.append(dict(case=nm,heads=len(ids),events=ws))
        heads+=len(ids)
    if time.monotonic()>deadline:raise TimeoutError('total deadline')
    return summary|dict(phase='signed-labels',boards=len(out),heads=heads,examples=out,passes=heads>=5 and len(out)>=5)
if __name__=='__main__':
    try:print(json.dumps(main(Path(sys.argv[1])),indent=2))
    except (AssertionError,TimeoutError,subprocess.SubprocessError,OSError) as e:
        raise SystemExit(f'incomplete: {type(e).__name__}: {e}') from e
