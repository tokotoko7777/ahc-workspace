"""Prepare-only local observation derivative, no policy change."""
from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
src=(D.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_bytes()
assert hashlib.sha256(src).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
s=src.decode()
def set_(token,prefix='',suffix=''):
    global s
    assert s.count(token)==1,token
    s=s.replace(token,prefix+token+suffix)
set_('inline void idle_phase(const State& s,const std::vector<int>& columns,std::vector<char>& action){',prefix='''
inline int spacing_turn=-1;
inline std::vector<std::string> spacing_observer_rows;
''')
set_('  int t=to[i];',prefix='''
  if(spacing_turn>=0&&to[i]<0)
    spacing_observer_rows.push_back(std::to_string(spacing_turn)+" "+std::to_string(i));
''')
set_('  if(turn==275)d=decide(s,policy,cap,stop);',prefix='''
  const char* spacing_log=std::getenv("AHC008_IDLE_SPACING_TRACE");
  if(spacing_log&&turn==275){
     std::ofstream f(spacing_log);
     for(const auto& r:spacing_observer_rows)f<<r<<'\\n';
     return f?0:3;
  }
  spacing_turn=spacing_log?turn:-1;
''')
set_('  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);',suffix='\n  spacing_turn=-1;')
(D/'observer.private.cpp').write_text(s)
