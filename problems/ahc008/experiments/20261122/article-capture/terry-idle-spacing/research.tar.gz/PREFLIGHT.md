# True center-fallback aisle spacing, detached preflight (unexecuted)

Only the named accepted incoming held100 signed cohort and original
6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40
source. Existing ledger SHA dde3b218…, exact catalog and historical
observed-state parser pinned in validator. No fresh generation, altered
selection code, simulator execution or official tooling authorized.

The independent make.py generator inserts a C++ observation hook at
the original idle loop after actual min-cost flow and before fallback
row selection. Only the unbooked path (!action) whose to[i] is really
negative is recorded. A stock dot is not interpreted as unbooked. The
hook never edits any command and exits before late switch after t274;
separate approval is required before source generation/build/replay.

Stage 1 validates all100 accepted complete input/command/reply digests,
then every original emitted t0–274 command equals the stock tape.
At that instant choose the first two genuine fallback workers by ID in
a configured aisle whose common actual component has an accessible pet.
At least two distinct actual ready one-mouth 1–4-body exterior stances
must exist in that lane, with exact reconstructed geometry after stock
commands, currently legally buildable mouth, unblocked body, and selected
stanza within the same vertical travel interval where applicable.
All other actors and their absolute actions are kept. Evaluate only
nine vertical/wait pairs, one action for first eligible aisle per turn,
stable order. Compare with the original sanitized post-command poses,
minimizing lexicographically max and sum over ready-stance nearest
currently genuine fallback actors' vertical open distance. Other true
fallback workers on that aisle participate at stock poses, never moved.
Require strictly better max (>=1 fewer steps), then sum/ties. Commit no
walls. Revalidate both batches and require exactly the same constructed
walls, every human's reach set, every existing capture ID, and every
reachable configured service anchor. Counts are offered geometry, not
captures.

Only if >=20 distinct boards have a valid strict first action may the
validator look at recorded t+1..3 labels. Advance from that one
alternative action with all later stock actions as factual replay,
never repeat the new policy. An actor whose position differs from
stock must still be in genuine center fallback at each intervening
turn; if not, reject that future prefix rather than moving their paid
stance. Require all stock wall targets, current human reach sets and
capture effects unaltered through the prefix. A witness replaces only
the genuinely fallback actor at the new exact stance (stock not
aligned), closing a site fixed at t using strictly legal current
geometry and preserving every other actual action and captured ID.
Deduplicate by real animal ID per board. Require >=5 distinct new
heads across >=5 boards, no losses. Hindsight replies label feasibility
only, not causal motion or policy choices; directed pets can move
differently under altered human positions.

The signed cohort is complete or rejected, with no case replacement.
Internal deadlines: 120 sec whole structural / 180 sec total, with
subprocess timeout; approved wrapper should also impose hard max180s.
Files are prep only. No compile, generator execution or replay yet.
