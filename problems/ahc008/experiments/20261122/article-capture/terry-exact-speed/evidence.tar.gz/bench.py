"""Sequential official CPU comparison, never choose a live parameter by this fixture."""
import argparse,csv,hashlib,re,sys,tempfile,statistics
from pathlib import Path
p=argparse.ArgumentParser()
for n in ('tester','inputs','ledger','old','new','output'):p.add_argument(n,type=Path)
a=p.parse_args()
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent/'ahc008_focus_solver/problems/ahc008'))
from benchmark_cases import run
samples=[x for x in csv.DictReader(a.ledger.open()) if x['arm']=='terry_independent']
data=[]
for i,x in enumerate(samples):
 name=x['case'];inp=(a.inputs/name).read_bytes()
 assert hashlib.sha256(inp).hexdigest()==x['input_sha']
 draws=int(x['telemetry'].split()[10])
 pair=[('baseline',a.old),('fast',a.new)]
 for tag,src in (pair if i%2==0 else pair[::-1]):
  with tempfile.TemporaryDirectory() as tmp:
   timefile=Path(tmp)/'cpu'
   args=[str(a.tester.resolve()),str(here/'time'),str(timefile),str(src.resolve()),f'--pairs={draws}']
   out,err,rc,wall=run(args,inp,4.5)
   assert rc==0 and err.strip()==('Score = '+x['score']).encode(),(name,tag,rc,err)
   dig=hashlib.sha256(out).hexdigest()
   assert dig==x['commands_sha'],(name,tag,draws,dig,x['commands_sha'])
   data.append(dict(case=name,arm=tag,draws=draws,action_hash=dig,score=x['score'],
                    cpu_us=int(timefile.read_text()),wall=wall))
 with a.output.open('w') as f:
  w=csv.DictWriter(f,list(data[0]));w.writeheader();w.writerows(data)
 print(name,flush=True)
for tag in ('baseline','fast'):
 jobs=[j for j in data if j['arm']==tag]
 for kind,rows in [('all',jobs),('without_rollout',[j for j in jobs if j['draws']==0])]:
  print(tag,kind,len(rows),sum(j['cpu_us']for j in rows),statistics.median(j['cpu_us']for j in rows),max(j['wall']for j in rows))
