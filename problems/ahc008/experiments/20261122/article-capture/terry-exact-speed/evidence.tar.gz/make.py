"""Independent exact handoff fast path. Private generated input/output: no publishing."""
from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:])
r=p.read_bytes()
assert hashlib.sha256(r).hexdigest()=='54f2b1ecc90820fcc5c99bc4e3cb8ddfe06c5952bf45851bf9d1a21e49341ae9'
s=r.decode()
target='  z.staffing=match(layout,z.walls,h,q);'
assert s.count(target)==1
s=s.replace(target,'''  if(std::all_of(q.begin(),q.end(),[](const Queue& u){return u.empty();})&&!layout.aisleCols.empty()){
   // Exact equivalence: if current column multiset equals desired slots,
   // own rows already achieve a zero-cost perfect matching. The original
   // returns ETA zero and issues no idle crew move. It cannot send a
   // different column with zero distance and empty construction queues.
   auto cols=layout.aisleCols;
   std::stable_sort(cols.begin(),cols.end(),[](int a,int b){return std::abs(a-N/2)<std::abs(b-N/2);});
   std::array<int,N> want{};
   for(int i=0;i<m;++i)++want[cols[i%cols.size()]];
   for(int p:h)--want[p%N];
   if(std::all_of(want.begin(),want.end(),[](int z){return z==0;})){
    z.staffing.eta=0;
    for(int p:h)z.staffing.cols.push_back(p%N);
    return z;
   }
  }
  z.staffing=match(layout,z.walls,h,q);''')
o.write_text(s)
