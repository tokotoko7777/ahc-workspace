#define _GNU_SOURCE
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/resource.h>
static long long micros(struct timeval a){return a.tv_sec*1000000LL+a.tv_usec;}
int main(int argc,char** argv){
 if(argc<3)return 2;
 pid_t pid=fork();
 if(pid<0)return 3;
 if(pid==0){argv[0]=argv[2];execv(argv[0],argv+2);_exit(127);}
 struct rusage u;int state;
 pid_t checked;
 do checked=wait4(pid,&state,0,&u);while(checked<0&&errno==EINTR);
 if(checked!=pid)return 4;
 FILE* f=fopen(argv[1],"w");
 if(!f)return 5;
 fprintf(f,"%lld\n",micros(u.ru_utime)+micros(u.ru_stime));
 if(fclose(f))return 6;
 return WIFEXITED(state)?WEXITSTATUS(state):128+WTERMSIG(state);
}
