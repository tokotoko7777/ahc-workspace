#include <bits/stdc++.h>
#include "../ahc008_focus_solver/library/max-flow.hpp"
#include "../ahc008_terry_exact_partition/partition.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"

namespace p=terry_partition;
using p::Board;

struct ResidualPair:MaxFlow<int> {
    using MaxFlow<int>::MaxFlow;
    static inline std::vector<char> largest;
    static inline std::vector<int> people;
    static int node(int at) { return 2*((at/30+1)*p::P+at%30+1); }

    std::vector<char> min_cut(int source) const {
        const auto small=MaxFlow<int>::min_cut(source);
        const int sink=source+1;
        std::vector<char> must_sink(n,false);
        std::vector<int> pending;
        auto enqueue=[&](int v) {
            assert(!small[v]);
            if(!must_sink[v]) {
                must_sink[v]=true; pending.push_back(v);
            }
        };
        enqueue(sink);
        for(int v=2*p::padded;v<source;++v) if(!small[v]) enqueue(v);
        for(int at:people) for(int v:{node(at),node(at)+1}) if(!small[v]) enqueue(v);
        for(std::size_t i=0;i<pending.size();++i)
            for(const auto& e:graph[pending[i]])
                if(graph[e.to][e.reverse_index].capacity>0) enqueue(e.to);
        largest.resize(n);
        for(int v=0;v<n;++v) largest[v]=!must_sink[v];
        auto cost=[&](const auto& mark) {
            int64_t total=0;
            for(const auto& e:edges()) if(mark[e.from]&&!mark[e.to]) total+=e.capacity;
            return total;
        };
        assert(largest[source]&&!largest[sink]&&cost(largest)==cost(small));
        for(int v=2*p::padded;v<source;++v) assert(small[v]==largest[v]);
        for(int at:people) for(int v:{node(at),node(at)+1}) assert(small[v]==largest[v]);
        return small;
    }
};

struct Actual {
    std::vector<Board> visible;
    unsigned ids=0;
    int sum=0;
};
Board get_component(const Board& walls, int at) {
    const auto d=p::distances(walls,at);
    Board b;
    for(int i=0;i<p::size;++i) if(d[i]>=0) b.set(i);
    return b;
}
Actual evaluate(const Board& wall, const std::vector<int>& crew, const std::vector<int>& pet) {
    Actual a;
    Board union_reach;
    for(int h:crew) {
        assert(!wall[h]); auto v=get_component(wall,h);
        union_reach|=v; a.sum+=v.count(); a.visible.push_back(v);
    }
    for(int i=0;i<int(pet.size());++i) {
        assert(!wall[pet[i]]);
        if(!union_reach[pet[i]]) a.ids|=(1u<<i);
    }
    return a;
}
int eta(const Board& terrain,const std::vector<int>& crew,const std::vector<int>& jobs) {
    constexpr int inf=999;
    if(jobs.empty()||jobs.size()>crew.size()) return inf;
    std::vector<std::array<int,p::size>> ds;
    for(int h:crew) ds.push_back(p::distances(terrain,h));
    const int M=crew.size();
    std::vector<int> dp(1<<M,inf), tmp;
    dp[0]=0;
    for(int w:jobs) {
        tmp.assign(1<<M,inf);
        for(int i=0;i<M;++i) {
            int near=inf;
            for(int v:p::neighbors(w)) if(v>=0&&ds[i][v]>=0) near=std::min(near,ds[i][v]);
            for(int m=0;m<(1<<M);++m) if(!(m>>i&1))
                tmp[m|(1<<i)]=std::min(tmp[m|(1<<i)],std::max(dp[m],near));
        }
        dp.swap(tmp);
    }
    return *std::min_element(dp.begin(),dp.end());
}
std::vector<int> read_vec() {
    int n; std::cin>>n; assert(n>=0&&n<=900);
    std::vector<int> v(n); for(int& x:v) {std::cin>>x;assert(x>=0&&x<900);}
    return v;
}
int main() {
    int board,turn,map;
    while(std::cin>>board>>turn>>map) {
        auto people=read_vec(), pet=read_vec(), closed=read_vec();
        Board wall,blocked;
        for(int v:closed) wall.set(v);
        blocked=wall;
        for(int h:people) blocked.set(h);
        for(int v:pet) {
            blocked.set(v);
            for(int n:p::neighbors(v)) if(n>=0) blocked.set(n);
        }
        std::cout<<board<<' '<<turn;
        auto end=[&](std::string_view code){std::cout<<' '<<code<<'\n';};
        auto tar=p::majorityPets(wall,people,pet);
        if(tar.empty()){end("no_target");continue;}
        ResidualPair::people=people;
        auto shape=p::shape<ResidualPair>(wall,terry_exact_maps::terrain(map).aisleCells,people,tar,turn);
        std::vector<int> alt;
        const auto& big=ResidualPair::largest;
        for(int at=0;at<p::size;++at) if(!wall[at]) {
            int n=ResidualPair::node(at);
            if(big[n]!=big[n+1]) alt.push_back(at);
        }
        if(shape.walls==alt){end("identical_walls");continue;}
        if(alt.empty()||shape.walls.empty()){end("empty_walls");continue;}
        if(std::any_of(shape.walls.begin(),shape.walls.end(),[&](int w){return blocked[w];})||
           std::any_of(alt.begin(),alt.end(),[&](int w){return blocked[w];})){end("blocked_wall");continue;}
        Board sw=wall,aw=wall;
        for(int w:shape.walls) sw.set(w);
        for(int w:alt) aw.set(w);
        const auto a=evaluate(sw,people,pet), b=evaluate(aw,people,pet);
        if(a.ids!=b.ids){end("different_ids");continue;}
        const auto pre=evaluate(wall,people,pet);
        if(a.ids==pre.ids){end("no_new_capture");continue;}
        const auto dominates=[&]() {
            for(std::size_t i=0;i<a.visible.size();++i)
                if((a.visible[i]&~b.visible[i]).any()) return false;
            return true;
        };
        if(b.sum<=a.sum||!dominates()){end("non_dominant");continue;}
        const int t0=eta(sw,people,shape.walls), t1=eta(aw,people,alt);
        if(t0>=999||t1>t0||t1+1>300-turn){end("staff_or_eta");continue;}
        std::cout<<" witness "<< (b.sum-a.sum)<<' '<< people.size()<<' '<<t0<<' '<<t1<<' '<<a.ids<<' '<<shape.walls.size();
        for(int w:shape.walls) std::cout<<' '<<w;
        std::cout<<' '<<alt.size();
        for(int w:alt) std::cout<<' '<<w;
        std::cout<<'\n';
    }
}
