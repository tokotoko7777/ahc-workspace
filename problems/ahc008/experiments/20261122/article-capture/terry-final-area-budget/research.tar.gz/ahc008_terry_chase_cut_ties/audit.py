"""Baseline-only verified tapes, then a read-only whole-state flow-cut audit."""
import collections
import json
import re
import subprocess
import sys
from fractions import Fraction
from pathlib import Path
from prepare import D, LIVE, NS, N, sh

ROOT=D.parent
H=ROOT/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(H),str(H/'experiments/20261122')]
from benchmark_cases import run
from benchmark import replay
from guarded_entry_trace import observed

def vec(seq):
    points=[30*r+c for r,c in seq]
    return str(len(points))+' '+' '.join(map(str,points))

def main():
    _,tester,solver,kernel=sys.argv
    tester,solver,kernel=(Path(p).resolve() for p in (tester,solver,kernel))
    m=json.loads((D/'manifest.json').read_text())
    assert sh(D/'manifest.json')=='4f92bb7fa8a6ef0b3ce68f028084974d11d34463bf9a21db985d36b4d544b17b'
    assert m['namespace']==NS and m['sample']==N and sh(solver)==LIVE==m['solver_sha']
    assert sh(D/'seeds.txt')==m['seedlist_sha']
    tapes=D/'tapes'
    tapes.mkdir(exist_ok=False)
    log=tapes/'current.telemetry'
    snapshots=[]; board_runs=[]; chosen=0
    for i,(name,hsh) in enumerate(m['input'].items()):
        f=D/'in'/name
        assert sh(f)==hsh
        raw=f.read_bytes()
        out,err,rc,wall=run([str(tester),'env','AHC008_TERRY_EXACT_LOG='+str(log),str(solver)],raw,4.5)
        p=re.fullmatch(rb'Score = (\d+)\s*',err)
        assert rc==0 and p,(name,rc,err)
        marks=list(map(int,log.read_text().split()))
        assert len(marks)==15 and marks[-1]==int(p[1]); log.unlink()
        a=tapes/f'{i:04}.actions'
        t=tapes/f'{i:04}.trace'
        a.write_bytes(out)
        q,e,c,_=run([str(tester),sys.executable,str(H/'benchmark_cases.py'),
                     '--playback',str(a),str(t)],raw,12)
        assert (q,e,c)==(out,err,rc)
        trace=t.read_text().splitlines()
        commands=out.decode().splitlines()
        assert len(commands)==300 and replay(raw.decode(),trace,commands,detailed=True)[0]==int(p[1])
        board_runs.append(dict(board=i,input_sha=hsh,commands_sha=sh(a),trace_sha=sh(t),
                              score=int(p[1]),rollouts=marks[10],chase=marks[13],wall=wall))
        if marks[13]:
            chosen+=1
            _,history,_=observed(raw,trace)
            for turn in range(275,300):
                pets,humans,walls=history[turn]
                snapshots.append(f'{i} {turn} {marks[0]} {vec(humans)} {vec(pets)} {vec(sorted(walls))}')
        print(name, 'chase' if marks[13] else 'normal',flush=True)
    (D/'snapshots.txt').write_text('\n'.join(snapshots)+'\n')
    process=subprocess.run([str(kernel)],input='\n'.join(snapshots)+'\n',
                           check=True,text=True,capture_output=True,timeout=30)
    lines=process.stdout.splitlines()
    (D/'screen.txt').write_text(process.stdout)
    assert len(lines)==len(snapshots)==chosen*25
    reasons=collections.Counter(); best={}; episodes=set(); witness=[]
    for line in lines:
        board,t,why,*value=line.split()
        reasons[why]+=1
        if why=='witness':
            n,m,t0,t1,iso,l,*masks=map(int,value)
            assert m>0 and n>0
            episodes.add((board,iso,tuple(masks)))
            best[board]=max(Fraction(),best.get(board,Fraction()),Fraction(n,m))
            witness.append([int(board),int(t),n,m,t0,t1,iso,l,masks])
    total=sum(best.values(),Fraction())
    clean=dict(n=N,chosen_chase=chosen,total_snapshots=len(snapshots),reasons=dict(reasons),
               unique_witness_episodes=len(episodes),boards_with_witness=len(best),
               dedup_mean_gain=float(total),exact_gain=str(total),
               gate=(len(episodes)>=5 and len(best)>=3 and total>=50),witness=witness,
               tapes=board_runs)
    (D/'report.json').write_text(json.dumps(clean,indent=2)+'\n')
    print(json.dumps({k:v for k,v in clean.items() if k not in ('witness','tapes')},indent=2))
if __name__=='__main__':main()
