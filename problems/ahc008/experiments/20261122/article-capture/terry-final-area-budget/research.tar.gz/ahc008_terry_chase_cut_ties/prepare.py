import hashlib,json,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent
NS='ahc008/20261123/terry-chase-cut-ties-v1/dev'
LIVE='f4ee50670fd4a93a99dbe908bdf1c2ab02d3f75061c812c77e3b218fe2113ec7'
N=60
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    g=Path(sys.argv[1]).resolve()
    s=[int.from_bytes(hashlib.sha256(f'{NS}/{i}'.encode()).digest()[:8],'little')for i in range(N)]
    assert len(set(s))==N
    f=D/'seeds.txt';value=''.join(f'{x}\n' for x in s)
    if f.exists():assert f.read_text()==value
    else:f.write_text(value)
    subprocess.run([str(g),str(f)],cwd=D,check=True)
    files=sorted((D/'in').glob('*.txt'))
    assert len(files)==N
    a={p.name:sh(p) for p in files}
    assert [*a]==[f'{i:04}.txt' for i in range(N)] and len(set(a.values()))==N
    m=dict(namespace=NS,sample=N,seedlist_sha=sh(f),generator_sha=sh(g),solver_sha=LIVE,input=a)
    j=D/'manifest.json';text=json.dumps(m,indent=2)+'\n'
    if j.exists():assert j.read_text()==text
    else:j.write_text(text)
    print('dev60 manifest',sh(j))
if __name__=='__main__':main()
