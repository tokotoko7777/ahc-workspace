# Same-prize equal-flow terminal cut diagnostic

On every factual live chase turn 275–299 in a new locked dev60, the stock
shape's residual source-reachable cut is the inclusion-minimal optimal
source side. For one counterpart only, freeze each targeted pet prize
node and each current human front/back node on its currently selected
side. Starting with sink and all stock sink-side fixed vertices, search
residual arcs in reverse. The complement is the inclusion-maximal
eligible source side: it contains all stock source-reachable vertices,
excludes all required sink-side vertices, and has no positive residual
outgoing arc. Both cuts have exactly the stock primary capacity. No
tuned weights or new flow solve. An existing min-cost-flow worker tie
backend is unrelated (this tests *physical wall shapes* using max-flow
cut equivalence). Prior factual-late checks examined only immediate
one/two-wall moves on historical failed endings, not equal-flow cuts.

Require a different nonempty physical wall mask, no current pet or
human occupancy or pet-neighbor conflict on any wall of either mask,
and at least one originally human-reachable animal inside the stock
separated set. Keep exactly the same IDs separated from all humans
between the old and candidate hypothetical post-cut boards. Every
current worker's eventual reachable floor must contain the entire floor
that worker would have on the stock cut; mean area must strictly grow.
All proposed wall jobs require distinct workers. Compute the optimal
landing time by bottleneck DP: BFS from each actual human, forbidding
their candidate final cut cells in advance for safe egress, gives all
honest adjacent stance distances. Candidate exact minimax ETA no longer
than stock, finite within remaining turns, and distinct staffing covers
every build action. This is a conservative current-state geometry
certificate, not evidence that the animal will stay put until closing.
Only exact baseline chase turns with consistent observed input/score
and legality qualify. No alternate action ever executed here.

Fixed dev sample is 60 uniform seeds generated from first SHA256 eight
bytes, little endian, of UTF-8
`ahc008/20261123/terry-chase-cut-ties-v1/dev/i` for i=0…59, no
resampling by outcomes. Do not use official practice100 in any phase.
Target minimum: ≥5 unique qualifying (wall mask pair, occupied pet-ID
state) episodes on ≥3 boards and ≥50 summed mean-human reachable cells
using only best strict witness on each board. Fail if any qualifier
below these conditions. No broadening on this panel. Snapshot gain is
not deployable score; live comparison would be a different experiment,
on fresh locked cases and only after this gate, with ≥0.1% paired gain,
no raw/useful regression, full legality and local <2.95s.
