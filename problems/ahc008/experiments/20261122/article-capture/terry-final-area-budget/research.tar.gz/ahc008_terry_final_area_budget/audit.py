"""Decompose factual scoring area from already verified fresh60 tapes only."""
import collections
from fractions import Fraction
import hashlib
import json
import re
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'ahc008_terry_chase_cut_ties'
H=ROOT/'ahc008_focus_solver/problems/ahc008'
A=ROOT/'ahc008_terry_scaffold_audit'
S=ROOT/'ahc008_terry_exact_selector'
sys.path[:0]=[str(A),str(S),str(H),str(H/'experiments/20261122')]
# Explicit file module to avoid a local audit.py name collision.
import importlib.util
spec=importlib.util.spec_from_file_location('scaffold_helpers',A/'audit.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
from verify import eval_reference
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,flood,idx,wave

NEI=[[q for q in (p-30,p-1,p+1,p+30) if 0<=q<900 and abs(q//30-p//30)+abs(q%30-p%30)==1] for p in range(900)]

def mask(p):
    return sum({B[i] for i in p})
def digest(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()

def shortest_reopen(wall,used,pets,room):
    # Exclude every wall adjacent to any pet-only component: opening any such
    # wall along a path connected to humans reconnects a pet immediately.
    forbidden=pets|(wall&wave(pets))
    d=[999]*900
    prev=[None]*900
    q=collections.deque(helper.cells(used))
    for p in q:d[p]=0
    while q:
        p=q.popleft()
        if room&B[p]:
            path=[]
            while prev[p] is not None:path.append(p);p=prev[p]
            answer=[z for z in path if wall&B[z]]
            op=(ALL^wall)|mask(answer)
            reachable=flood(used,op)
            assert reachable&room==room and not reachable&pets
            return answer
        for z in NEI[p]:
            if forbidden&B[z]:continue
            cost=bool(wall&B[z]); nd=d[p]+cost
            if nd<d[z]:
                d[z]=nd;prev[z]=p
                (q.append if cost else q.appendleft)(z)
    return None

def choose(raw,weights):
    lines=raw.splitlines()
    n=int(lines[0]); k=[0]*5
    for row in lines[1:1+n]:k[int(row.split()[2])-1]+=1
    m=int(lines[n+1])
    return eval_reference(weights,(m,*k))[0]

def main():
    meta=json.loads((D/'report.json').read_text())
    assert meta['n']==60 and len(meta['tapes'])==60
    planned=helper.planned_masks(ROOT/'ahc008_terry_exact_maps/terrain_data.inc')
    data=(S/'weights.private.inc').read_text()
    weights=list(map(float.fromhex,re.findall(r'-?0x[0-9a-f]+\.[0-9a-f]+p[+-][0-9]+',data)))
    assert len(weights)==3589
    rows=[]; skipped=[]
    for row in meta['tapes']:
        name=f'{row["board"]:04d}'; inp=D/'in'/f'{name}.txt'
        a=D/'tapes'/f'{name}.actions'; tr=D/'tapes'/f'{name}.trace'
        assert digest(inp)==row['input_sha'] and digest(a)==row['commands_sha'] and digest(tr)==row['trace_sha']
        raw=inp.read_bytes(); trace=tr.read_text().splitlines(); actions=a.read_text().splitlines()
        score=replay(raw.decode(),trace,actions,detailed=True)[0]
        assert score==row['score']
        _,hist,_=observed(raw,trace)
        pets,people,walls=hist[-1]
        pets,people=([idx(v) for v in g] for g in (pets,people))
        end=mask(map(idx,walls)); opens=ALL^end
        human_reach=flood(mask(people),opens)
        if human_reach&mask(pets):
            skipped.append(dict(case=name,score=score))
            continue
        labels,parts=helper.labels(opens)
        groups=collections.Counter(labels[p] for p in people)
        crit={labels[p] for p in pets}
        x=end&planned[choose(raw,weights)]
        use=mask(q for g in groups for q in helper.cells(parts[g]))
        assert use==human_reach
        pc=mask(q for g in crit for q in helper.cells(parts[g]))
        avg=Fraction(sum(parts[g].bit_count()*n for g,n in groups.items()),len(people))
        split=Fraction(use.bit_count())-avg
        empties=[]
        if (empty:=opens&~(use|pc)):
            when={}
            snapshots=[]
            for t,(pa,hu,wa) in enumerate(hist):
                w=mask(map(idx,wa))
                if snapshots:
                    for q in helper.cells(w&~snapshots[-1][0]):when[q]=t-1
                snapshots.append((w,mask(map(idx,hu))))
            for g,rm in enumerate(parts):
                if not rm&empty:continue
                assert rm&empty==rm
                rim=wave(rm)&end
                close=max((when[p] for p in helper.cells(rim)),default=-1)
                assert close>=0
                last=-1
                for t,(w,h) in enumerate(snapshots):
                    if flood(h,ALL^w)&rm:last=t
                path=shortest_reopen(end,use,pc,rm)
                empties.append(dict(size=rm.bit_count(),boundary_width=rim.bit_count(),
                    boundary_X=(rim&x).bit_count(),last_human_reachable_state=last,
                    terminal_boundary_completed_action=close, safe_fixed_reopen_width=len(path) if path is not None else None,
                    fixed_reopen_walls=[{'cell':z,'placed_action':when[z],'planned_X':bool(x&B[z])}for z in path] if path is not None else None))
        rowout=dict(case=name,humans=len(people),score=score,map=choose(raw,weights),
              planned_x=x.bit_count(),extra_walls=(end&~x).bit_count(),
              pet_only=pc.bit_count(),empty_unscored=sum(g['size'] for g in empties),
              human_union=use.bit_count(),human_split=float(split),per_human_area=float(avg),
              components_with_humans=len(groups),empty_components=empties)
        assert 900-avg==rowout['planned_x']+rowout['extra_walls']+rowout['pet_only']+rowout['empty_unscored']+split
        rows.append(rowout)
    fields=['planned_x','extra_walls','pet_only','empty_unscored','human_union','human_split','per_human_area']
    sums={f:sum(r[f] for r in rows) for f in fields}
    groups=[r for x in rows for r in x['empty_components']]
    q=dict(full=len(rows),nonfull=skipped,split_boards=sum(r['components_with_humans']>1 for r in rows),
       sums=sums,means={k:v/len(rows) for k,v in sums.items()},
       empty_case_count=sum(bool(r['empty_unscored']) for r in rows),empty_max=max(r['empty_unscored']for r in rows),
       empty_components=len(groups),empty_cells_by_min_reopen_width=dict(collections.Counter(
         width for r in groups for width in [str(r['safe_fixed_reopen_width'])]*r['size'])),
       empty_cells_with_boundary_closed_pre_t275=sum(r['size']for r in groups if r['terminal_boundary_completed_action']<275),
       rows=rows)
    return q

if __name__=='__main__':
    print(json.dumps(main(),indent=2))
