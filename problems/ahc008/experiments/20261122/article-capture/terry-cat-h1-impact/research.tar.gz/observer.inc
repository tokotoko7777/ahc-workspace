#include <sstream>
#include <set>
namespace early_impact {
using namespace terry_exact_root;
using Post=std::array<double,V+1>;
struct Event{int pet,room,left,right; Mask safe,body,projected;std::array<double,3> pred;};
struct Arm {
 std::string cmd; std::vector<hunt::Candidate> jobs;
 std::vector<Event> events; std::vector<int> samples;
};
struct Hook{int arm;Arm* result;const std::vector<Post>* posterior;};
inline Hook* hook=nullptr;
int gait(int p,int gate,int side,const Mask& w){
 if(gate<0)return 0;
 const int q=nb[gate][side<0?3:1];
 if(q<0||w[q]||p%30!=q%30)return 99;
 return std::abs(p/30-q/30);
}
bool physical_eta1(const State& s,const Mask& w,const std::vector<std::optional<char>>& booked,
                   const hunt::Room& room){
 int best=99;
 for(int a=0;a<(int)booked.size();++a)if(!booked[a])
 for(int b=0;b<(int)booked.size();++b)if(!booked[b]){
  if((a==b)!=(room.left<0||room.right<0))continue;
  best=std::min(best,std::max(gait(s.people[a],room.left,-1,w),gait(s.people[b],room.right,1,w)));
 }
 return best==1;
}
void before(const State& s,const Mask& w,const Mask& move,const terrain_lib::Rooms& g,
 const std::vector<std::optional<char>>& booked,std::vector<hunt::Room>& rooms){
 latent_public::State light;
 for(int z=0;z<V;++z)light.walls[z]=w[z];
 for(int k=0;k<(int)rooms.size();++k){
  auto& room=rooms[k];
  if(room.area<=0||(room.left<0&&room.right<0))continue;
  const double original=room.override_short[0]>=0?room.override_short[0]:room.retention[1];
  if(original<=0||!physical_eta1(s,w,booked,room))continue;
  bool good=true;Mask veto;
  for(int gate:{room.left,room.right})if(gate>=0){
   good&=g.ids[gate]==k&&!w[gate]&&!move[gate];
   veto.set(gate);for(int z:nb[gate])if(z>=0)veto.set(z);
  }
  if(!good)continue;
  Mask safe,body;
  for(int z=0;z<V;++z)if(!w[z]&&g.ids[z]==k){
   if(z!=room.left&&z!=room.right)body.set(z);
   if(!veto[z])safe.set(z);
  }
  if(safe.none())continue;
  double remove=0,add=0;
  for(int i=0;i<(int)s.pets.size();++i){
   const auto pet=s.pets[i];
   if(pet.type!=5||g.ids[pet.pos]!=k||!g.participates[pet.pos])continue;
   std::array<double,4> e{};int degree=0;double sum=0.;
   for(int d=0;d<4;++d){
    int x=latent_public::nb[pet.pos][d];if(x<0||w[x])continue;
    int n=0,h=0;for(int z:latent_public::nb[x])if(z>=0&&!w[z]){++n;h+=safe[z];}
    assert(n); e[d]=double(h)/n; sum+=e[d];++degree;
   }
   if(!(sum>0&&sum<degree-1e-12))continue;
   auto prior=(*hook->posterior)[i];
   latent_public::Steps dummy;dummy.len=2;
   auto px=latent_public::cat(light,pet.pos,dummy,prior,false);
   std::array<double,3> a{sum/degree,0,0};
   for(int d=0;d<4;++d){a[1]+=px.legacy[d]*e[d];a[2]+=px.post[d]*e[d];}
   hook->result->events.push_back({i,k,room.left,room.right,safe,body,w,a});
   if(hook->arm>=0){remove+=hook->result->samples[i];add+=100*a[hook->arm];}
  }
  if(hook->arm>=0&&(remove||add))
   room.override_short[0]=std::max(0.,original-remove+add);
 }
}
void after(const std::vector<hunt::Candidate>& jobs){hook->result->jobs=jobs;}
Arm run_arm(Normal& policy,const State& s,int t,const std::vector<Post>& p,int kind){
 Arm out;out.samples.resize(s.pets.size());
 Hook context{kind,&out,&p};hook=&context;
 impact_h1_samples=&out.samples;impact_before=before;impact_after=after;
 out.cmd=policy.step(s,t);
 impact_h1_samples=nullptr;impact_before=nullptr;impact_after=nullptr;hook=nullptr;
 return out;
}
bool dogs_invariant(const State& a,const State& b){
 if(a.people==b.people)return true;
 auto graph=terrain_lib::labels(a.walls);
 for(const auto& p:a.pets)if(p.type==4)
  for(int i=0;i<(int)a.people.size();++i)if(a.people[i]!=b.people[i]){
   int x=graph.labels[p.pos];
   if(graph.labels[a.people[i]]==x||graph.labels[b.people[i]]==x)return false;
  }
 return true;
}
std::vector<int> isolated(const State& s){
 auto g=terrain_lib::labels(s.walls);std::vector<bool> human(g.count);
 for(int p:s.people)human[g.labels[p]]=true;
 std::vector<int> out;
 for(int i=0;i<(int)s.pets.size();++i)if(!human[g.labels[s.pets[i].pos]])out.push_back(i);
 return out;
}
bool split(const State& stock,const State& other){
 auto a=terrain_lib::labels(stock.walls),b=terrain_lib::labels(other.walls);
 for(int i=0;i<(int)stock.people.size();++i)for(int j=0;j<i;++j)
  if(a.labels[stock.people[i]]==a.labels[stock.people[j]]&&
     b.labels[other.people[i]]!=b.labels[other.people[j]])return true;
 return false;
}
bool loss(const std::vector<int>& base,const std::vector<int>& alt){
 return !std::includes(alt.begin(),alt.end(),base.begin(),base.end());
}
std::string ids(const std::set<int>& a){
 std::string out;for(int x:a){if(!out.empty())out+=';';out+=std::to_string(x);}return out;
}
bool selected(const Arm& a,const Event& e){
 return std::any_of(a.jobs.begin(),a.jobs.end(),[&](auto& j){return j.room==e.room;});
}
bool closed_selected(const Arm& a,const Event& e,const State& before,const State& after){
 if(!selected(a,e)||(e.body&after.walls).any()||!e.safe[before.pets[e.pet].pos])return false;
 for(int p:{e.left,e.right})if(p>=0&&(before.walls[p]||!after.walls[p]))return false;
 return true;
}
int run(const char* input,const char* tracePath){
 std::ifstream f(input),tr(tracePath);State s;std::array<int,5> counts{};
 int n,m;f>>n;s.pets.resize(n);
 for(int i=0;i<n;++i){int r,c,k;f>>r>>c>>k;s.pets[i]={(r-1)*30+c-1,k,-1};++counts[k-1];}
 f>>m;for(int i=0;i<m;++i){int r,c;f>>r>>c;s.people.push_back((r-1)*30+c-1);}
 assert(f&&tr);
 auto& land=terrain_lib::terrain(terry_exact_selector::choose(m,counts));
 Normal live(land,s);
 std::vector<Post> post(n);for(auto& p:post)p[V]=1;
 std::vector<std::string> command(161),movement(161);
 for(int i=0;i<161;++i)assert(std::getline(tr,command[i])&&std::getline(tr,movement[i]));
 std::cout<<std::setprecision(17);
 for(int t=0;t<160;++t){
  Normal base=live;
  State real=s, updated=s;
  Arm stock;
  if(t>=100&&counts[4])stock=run_arm(live,s,t,post,-1);
  else stock.cmd=live.step(s,t);
  assert(stock.cmd==command[t]);
  people_step(real,stock.cmd);updated=real;
  std::vector<latent_public::Steps> seen(n);
  latent_public::State light;
  for(int p=0;p<V;++p)light.walls[p]=real.walls[p];
  std::istringstream ss(movement[t]);
  for(int i=0;i<n;++i){
   std::string token;ss>>token;assert(ss);
   seen[i]=latent_public::decode(s.pets[i].pos,light.walls,token);
   updated.pets[i].pos=seen[i].end;
  }
  if(!stock.events.empty()){
   for(const auto& e:stock.events){
    std::cout<<"A,"<<t<<','<<e.pet<<','<<e.room<<'\n';
    if(e.projected!=real.walls)continue;
    std::cout<<"E,"<<t<<','<<e.pet<<','<<e.room<<','<<e.safe[seen[e.pet].end];
    for(double v:e.pred)std::cout<<','<<v;
    std::cout<<'\n';
   }
   std::array<Normal,3> policies{base,base,base};std::array<Arm,3> arm;
   for(int k=0;k<3;++k)arm[k]=run_arm(policies[k],s,t,post,k);
   for(const auto& a:arm){assert(a.events.size()==stock.events.size());assert(a.samples==stock.samples);}
   std::cout<<"F,"<<t<<','<<(stock.cmd!=arm[0].cmd)<<','<<(arm[0].cmd!=arm[1].cmd)<<','<<(arm[1].cmd!=arm[2].cmd)<<'\n';
   bool changed=arm[1].cmd!=arm[2].cmd;
   bool meaningful=false;
   for(const auto& e:stock.events)meaningful|=selected(arm[1],e)!=selected(arm[2],e);
   if(meaningful&&changed){
    std::array<State,3> after{ s,s,s };
    bool compatible=true;
    for(int k=0;k<3;++k){
     people_step(after[k],arm[k].cmd);
     if(k>=1)compatible&=after[k].walls==real.walls&&dogs_invariant(real,after[k]);
    }
    if(!compatible)std::cout<<"X,"<<t<<'\n';
    else{
     auto normal=live; const auto next=normal.step(updated,t+1);assert(next==command[t+1]);
     State original=updated;people_step(original,next);
     auto real0=isolated(real),real1=isolated(original);
     std::array<State,3> terminal=after;
     for(int k=1;k<=2;++k){
      terminal[k].pets=updated.pets; // identical walls and dogs' relevant human coordinates
      auto nextk=policies[k].step(terminal[k],t+1);
      people_step(terminal[k],nextk);
     }
     auto v1=isolated(terminal[1]),v2=isolated(terminal[2]);
     bool harms=loss(real0,isolated(after[2]))||loss(real1,v2)||split(real,after[2])||split(original,terminal[2]);
     std::set<int> plus,minus;std::set<int> plus_rooms,minus_rooms;
     auto has=[](const std::vector<int>& v,int x){return std::binary_search(v.begin(),v.end(),x);};
     for(const auto& e:stock.events){
      if(e.projected!=real.walls)continue;
      bool u=closed_selected(arm[1],e,updated,terminal[1])&&has(v1,e.pet);
      bool p=closed_selected(arm[2],e,updated,terminal[2])&&has(v2,e.pet);
      if(p&&!u&&!has(v1,e.pet)){plus_rooms.insert(e.room);plus.insert(e.pet);}
      if(u&&!p&&!has(v2,e.pet)){minus_rooms.insert(e.room);minus.insert(e.pet);}
     }
     std::cout<<"C,"<<t<<','<<harms<<','<<plus_rooms.size()<<','<<minus_rooms.size()<<','<<ids(plus)<<','<<ids(minus)<<'\n';
    }
   }
  }
  for(int i=0;i<n;++i)if(s.pets[i].type==5)
   latent_public::cat(light,s.pets[i].pos,seen[i],post[i],true);
  s=std::move(updated);
 }
 return 0;
}
}
int main(int argc,char** argv){
 if(argc!=3)return 2;
 return early_impact::run(argv[1],argv[2]);
}
