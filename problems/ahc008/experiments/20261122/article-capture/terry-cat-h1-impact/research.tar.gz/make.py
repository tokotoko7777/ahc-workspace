"""Generate a detached local executable from pinned exact sources; no run."""
from pathlib import Path
from hashlib import sha256
D=Path(__file__).resolve().parent
W=D.parent
def read(path,sha):
    b=(W/path).read_bytes()
    assert sha256(b).hexdigest()==sha,path
    return b.decode()
stock=read('ahc008_terry_split_bound/solve.private.cpp',
    'f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088')
latent=read('ahc008_terry_target_active275/observer.cpp',
    'd83710cadeeb3f4e88bf5f74f922da3d64a8f2ca0b2322e0a9bba910dac2ebf3')
inc,code=latent.split('constexpr int N=900,M=10;',1)
latent=inc+'\nnamespace latent_public {\nconstexpr int N=900,M=10;'+code.split('\nint main(',1)[0]+'\n}\n'
def stem(src):
    assert src.count('\nint main(')==1
    return src.split('\nint main(',1)[0]
def put(a,b):
    global stock
    assert stock.count(a)==1,a
    stock=stock.replace(a,b)
put('inline Retention retention(', 'inline std::vector<int>* impact_h1_samples=nullptr;\ninline Retention retention(')
put('    result[room][h]+=ids[p.pos]==room;',"""    result[room][h]+=ids[p.pos]==room;
    if(impact_h1_samples&&initial.type==5&&h==1)
       (*impact_h1_samples)[i]+=ids[p.pos]==room;""")
put('struct Normal {',"""using ImpactBefore = void(*)(const State&,const Mask&,const Mask&,const terrain_lib::Rooms&,
    const std::vector<std::optional<char>>&,std::vector<hunt::Room>&);
using ImpactAfter = void(*)(const std::vector<hunt::Candidate>&);
inline ImpactBefore impact_before=nullptr;
inline ImpactAfter impact_after=nullptr;
struct Normal {""")
put('    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));',
"""    if(impact_before)impact_before(s,builds,moves,geometry,booked,rooms);
    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));
    if(impact_after)impact_after(jobs);""")
(D/'observer.private.cpp').write_text(stem(stock)+'\n'+latent+'\n'+(D/'observer.inc').read_text())
