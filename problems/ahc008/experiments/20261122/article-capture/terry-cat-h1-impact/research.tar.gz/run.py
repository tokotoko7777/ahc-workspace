import collections
import csv
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path
D=Path(__file__).resolve().parent
W=D.parent
R=W/'ahc008_terry_hunt_wall_audit'
I=W/'ahc008_terry_incoming_shadow'/'held100'
def sha(b):return hashlib.sha256(b).hexdigest()
def pinned(p,h):
    b=p.read_bytes();assert sha(b)==h,p
    return b
def rows(exe,i,t):
    raw=subprocess.check_output([exe,i,t],text=True,timeout=20)
    return list(csv.reader(raw.splitlines()))
def metrics(events):
    groups=collections.defaultdict(list)
    for c,r in events:
        q=int(r[3]);p=list(map(float,r[4:7]));assert len(p)==3 and all(-1e-12<=a<=1+1e-12 for a in p)
        b=[(z-q)**2 for z in p];n=[-math.log(max(1e-12,z if q else 1-z)) for z in p]
        groups[c].append((b,n))
    N=len(groups)
    if not N:return {'cases':0,'events':0}
    B=[[sum(v[0][i] for v in x)/len(x) for i in range(3)] for x in groups.values()]
    L=[[sum(v[1][i] for v in x)/len(x) for i in range(3)] for x in groups.values()]
    b=[sum(x[i] for x in B)/N for i in range(3)]
    l=[sum(x[i] for x in L)/N for i in range(3)]
    return dict(cases=N,events=len(events),brier=b,nll=l,
        brier_relative=[(b[i]-b[2])/b[i] if b[i]>0 else 0 for i in range(2)],
        nll_gain=[l[i]-l[2] for i in range(2)],
        wins=[sum(x[2]<x[i] for x in B) for i in range(2)])
def main():
    exe=Path(sys.argv[1]).resolve()
    meta=json.loads(pinned(R/'recordings.json','dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'))
    ledger=pinned(I/'confirm.csv','9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2')
    expected={r['case']:r for r in csv.DictReader(ledger.decode().splitlines())if r['arm']=='terry_independent'}
    assert len(expected)==len(meta)==100 and set(expected)=={r['case']for r in meta}
    typed=collections.defaultdict(list)
    for m in meta:
        c=m['case'];i=I/'in'/c;a=(R/'tapes'/c).with_suffix('.actions');t=a.with_suffix('.trace')
        ia=pinned(i,m['input_sha']);aa=pinned(a,m['commands_sha']);ta=pinned(t,m['trace_sha'])
        assert expected[c]['input_sha']==sha(ia) and expected[c]['commands_sha']==sha(aa)
        al,tl=aa.splitlines(),ta.splitlines()
        assert len(al)==300 and len(tl)==600 and tl[::2]==al
        for r in rows(exe,i,t):typed[r[0]].append((c,r[1:]))
    A=typed['A']; E=typed['E']; C=typed['C']; F=typed['F']
    assert len(A)>=len(E)
    def extract(rows,k):
        return {(c,int(p))for c,r in rows for p in r[k].split(';') if p}
    plus=extract(C,4);minus=extract(C,5)
    support={'boards':len({c for c,_ in A}),'cats':len({(c,r[1])for c,r in A}),
             'eligible_rows':len(A),'predictive_rows':len(E)}
    cases=len({c for c,_ in C})
    minus_windows=sum(int(r[3])for c,r in C)
    plus_windows=sum(int(r[2])for c,r in C)
    harm=[(c,r[0])for c,r in C if r[1]=='1']
    m=metrics(E)
    predictive=bool(m and m['events'] and min(m['brier_relative'])>=.08
        and min(m['nll_gain'])>0 and m['wins'][1]>m['cases']/2)
    stats=dict(verified=100,support=support,
        changes={'stock_random':sum(r[1]=='1'for c,r in F),
                 'random_uniform':sum(r[2]=='1'for c,r in F),
                 'uniform_posterior':sum(r[3]=='1'for c,r in F),
                 'incompatible':len(typed['X']),'compatible_informative':len(C),'compatible_cases':cases},
        positive_windows=plus_windows,negative_windows=minus_windows,
        plus_ids=sorted(plus),minus_ids=sorted(minus),harms=harm,predictive=m,
        predictive_pass=predictive,
        pass_gate=(support['boards']>=30 and support['cats']>=60 and len(C)>=18 and cases>=10
         and plus_windows-minus_windows>=6 and len(plus)-len(minus)>=5 and minus_windows<=1 and not harm and predictive))
    print(json.dumps(stats,indent=2))
    if len(sys.argv)>2:Path(sys.argv[2]).write_text(json.dumps(
       {k:typed[k]for k in ('A','E','F','X','C')},separators=(',',':'))+'\n')
if __name__=='__main__':main()
