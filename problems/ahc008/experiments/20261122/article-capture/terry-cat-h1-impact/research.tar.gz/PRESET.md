# t100–159 cat H1 selection impact, detached only

Use exact signed Incoming held100 official input/action/trace identity,
accepted f83 source and verified public-only cat history filter. Reconstruct
every f83 Normal action from t0 through t159 and require byte identity; check
t+1 stock reconstruction separately for every compatible comparison. No tester,
score, source switch or mode run. All non-H1 scores, other pets, construction
walls/moves/booking and RNG draws remain unchanged.

Eligible cat starts in a named intact room with valid mouths, positive stock
H1, stock-booking-aware best physical ETA exactly one on exterior lanes,
and reachable-but-not-certain gate-safe endpoint under random support.
Replace only its recorded stock sampled H1 term by 100 times exact model
safe-endpoint probability, while still executing all original samples and
keeping every other term unchanged. Four arms: stock, exact random-safe,
uniform-target-directed-safe, posterior-directed-safe. Cat probabilities
condition on projected construction walls, not later submitted hunting walls.
Score only prediction rows where that projected board equals factual t walls.
Use case-macro Brier and clipped binary NLL. Require both Brier improvements
at least 8%, both NLL gains positive and more than half the cases improve
Brier vs uniform-directed. This is separate from prior deferred/preempt
screens: no inference from a proposed or illegal wall attempt.

Informative selection change is a different sanitized P/U t command and a
different selection of at least one eligible room. Both projected full t wall
sets must equal factual stock. If any changed human is reachable by any dog
from either factual or changed pose, reject the row: targets may differ.
Same walls and unchanged visible dog submodel permit using actual t animal
motions for the local comparison. Start t+1 from those animal endpoints
and predicted worker poses. Call the unmodified stock Normal on each clone,
using its real t crew and RNG progression. Require each previously selected
mouth legally emitted at t+1, its same body cells still traversable, safe cat
actually newly disconnected. Do not use t+1 animal motions, and use factual
t+1 human command only for independent baseline comparison. Protect every
baseline isolated pet ID and all originally connected worker pairs after
both t and t+1 human actions. No claim of causal policy score.

Frozen gate: at least 30 boards and 60 cats; at least 18 compatible informative
P/U changes over 10 boards; at least six net certified positive windows and
five net distinct new isolated IDs; at most one negative window; zero stock
isolation losses or new worker splits; require calibration gate. Archive and
stop without live tests on failure. A pass is only admission after review
to an independently frozen legal official/independent replay live comparison
requiring score/raw-full/useful nonregression on fresh held and practice,
serial runtime checks and no tuning.

After explicit exclusive clearance:
    D=ahc008_terry_cat_h1_impact
    (cd "$D" && sha256sum -c FROZEN.sha256)
    python "$D/make.py"
    g++ -std=c++23 -O2 "$D/observer.private.cpp" -o "$D/observer"
    python "$D/run.py" "$D/observer" "$D/events.local.json" > "$D/result.json"

Row evidence contains board/turn/cat/room identifiers and summarized
probabilities/certificates, not raw transcripts or private coefficients.
