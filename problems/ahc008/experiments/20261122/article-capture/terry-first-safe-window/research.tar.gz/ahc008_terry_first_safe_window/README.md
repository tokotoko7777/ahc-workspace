# Pure exact passive first-buildable endpoint

No reference source fork, solver, simulator workload or benchmark in
this directory. `first_safe.hpp` is the independent reusable helper.
Natural local integration passes the accepted projected open adjacency
(`table[cell]` has `degree` and `cells`) and a static predicate for
*one* selected original room: current label equals original room and
cell is outside the union of the closed graph-distance-one
geometric neighborhoods of every named gate of that room (one or two actual
mouths; no fabricated second gate). The predicate says only whether
this one animal permits closing. It does not check other animals,
people, paths, separate worker assignments, or present legal gates.
All physical gates remain traversable in this fixed graph unless
already physically walled off by the supplied board. A path can cross
a gate, leave the labeled room and re-enter. A failed predicate
never blocks propagation.

For ETA h∈{1,2,3}, propagate without absorption up to h. The first
endpoint satisfying the predicate at h, h+1, or h+2 contributes
(h+1)/(hit+1); any other trajectory contributes zero. Absorb at these
full-turn checkpoints only, suppressing intermediate visits even if a pet touches a qualifying
square during an earlier substep. Isolated pets make zero spatial
progress but continue to consume their nominal substep count. Prefix
work is shared between queries. Sparse lists never clear entire old
layers between steps; simple cardinal support through 15 substeps
is at most 481 cells even with zero-degree holds. Four layer stores
each have 900 weight slots and a 481-entry support list. Worst-case
one pet uses 9 prefix substep expansions and 18 tail expansions,
each at most 481×4 neighbors; the two suffix turns are never revisited
after absorption.

Use an exact, common numerator with D=60·12^15=924421294475182080.
Each raw integer layer contributes degree factor 12/degree (or
12 for a hold). Raw mass at substep k is at most 12^k; early
first-hit reward rescales by 12^(15−k) and 60·(h+1)/(hit+1).
Each hit bin disjoint, union weighted reward ≤D. Fits uint64 per
pet, including intermediate multiply; 20 animals ×100 sample-equivalent
times D requires the provided unsigned 128-bit type for accumulation.
Directed samples can count weighted first hits in integer units out of
60, multiplied by D/60 in the combined numerator; divide only when
the existing objective consumes that value.

Proposed local unit after exclusive compile clearance:
```
g++ -std=c++23 -O2 -Wall -Wextra unit.cpp -o /tmp/terry-first-safe-unit
/tmp/terry-first-safe-unit
```

Return type `Result` has `immediate[0..2]` (first deposit at h alone,
without discount) and `discounted[0..2]` (full h..h+2). Both share D.
Immediate is the same own-safe endpoint probability under the same
window model, not stock total retention. It is captured before making
any tail advances, so returning both performs no additional
transitions. All arguments are terrain/occupancy-derived, never
timestamps, seeds, or known input-case identifiers.
