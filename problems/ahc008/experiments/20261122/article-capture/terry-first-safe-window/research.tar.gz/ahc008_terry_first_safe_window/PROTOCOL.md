# Detached scope and advancement rule (design, not a scheduled run)

Compare three proposal-only normal evaluators at identical factual
t<275 states: accepted h123; instantaneous same-window model (return
only `immediate` at short h); and filtered first-hit at h…h+2. The last
two must use identical own-blockage geometry, simulated paths, RNG,
room IDs, actor candidates, tie/order, and scoring normalization; only
credit for an admissible later endpoint differs. For dogs and the stock
cat surrogate, use common existing sampled endpoints h…h+2 once,
with separate first-hit flags by h, never change sample consumption.
Keep accepted h=0 and h≥4 scores, complete legal output and all live
policy state. Do not execute an experimental command in this screen.

All replays must match accepted prefix/full scores and legality; verify
the baseline samples and far bins independently. A qualifying changed
first command differs from both accepted h123 and instantaneous-safe
in the same state, after matching and safety cleanup, with at least one
planned physical pair/solo capture explaining the difference. Verify
no detached alternative would displace any immediate genuinely legal
animal ID actually isolated by the stock action on that same snapshot.
Short future observations are evidence, not inputs to the predictor:
credit at most one episode per (board, room, animal-ID, proposed crew)
where the alternative's original protected room stays physically intact
and a factual h+1 or h+2 endpoint allows the same crew to finish an
actual legal all-mouth closure, following a distinct feasible approach
and compatible holds without displacing original nonwait work.
Verify **all** pets and guard/other projected-worker conflicts at the
actual proposed closure; never merely recheck the individual predicate.
A compatible wait borrowing known future observations is not proof
those observations would happen under alternate commands, not proof
the adaptive solver would retain those same workers, and does not
change the factual ledger.

Advance only if unchanged accepted observations; zero lost immediate
stock isolate IDs; at least 20 distinctive changed first commands
across 10 distinct development boards; and at least five deduplicated
compatible later physical opportunities across at least three boards.
Any missing verification, insufficient coverage, or excess runtime:
stop; do not widen window, rank thresholds, species or tap more panels.
This gate does not establish net captures or score. Passing permits
one fixed fresh uniform100 official test then an untouched held100,
not adoption. Each needs legal/replay all, max local <2.95s, no raw or
useful regression and at least +0.1% score. Prior h-only safe passed
instantaneous shadow safety and failed whole-capture live; do not
promote from shadow, or tune with official practice inputs.
