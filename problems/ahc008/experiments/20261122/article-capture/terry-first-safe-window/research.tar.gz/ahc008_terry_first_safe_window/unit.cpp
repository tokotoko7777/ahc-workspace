#include <array>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <random>
#include <vector>
#include "first_safe.hpp"

using T=terry_first_safe::Result;
constexpr uint64_t D=terry_first_safe::denominator;

struct Vertex {
    int degree=0;
    std::array<int,4> cells{};
};
using Graph=std::array<Vertex,900>;
void edge(Graph& graph,int a,int b) {
    assert(std::abs(a/30-b/30)+std::abs(a%30-b%30)==1);
    graph[a].cells[graph[a].degree++]=b;
    graph[b].cells[graph[b].degree++]=a;
}
int md(int a,int b) { return std::abs(a/30-b/30)+std::abs(a%30-b%30); }

// Independent explicit paths: probability is carried as rational 1/divisor
// along an individual tree branch, never merged by cell or by depth.
template<class Legal>
T exhaustive(const Graph& graph,int from,int speed,const Legal& legal) {
    T want;
    for(int first=1;first<=3;++first) {
        auto paths=[&](auto&& self,int p,int depth,uint64_t divisor)->void{
            if(depth%speed==0) {
                const int turn=depth/speed;
                if(first<=turn && legal(p)) {
                    const uint64_t denom=divisor*uint64_t(turn+1);
                    assert(D%denom==0);
                    const uint64_t reward=(D/denom)*(first+1);
                    want.discounted[first-1]+=reward;
                    if(turn==first) want.immediate[first-1]+=reward;
                    return;
                }
                if(turn==first+2) return;
            }
            const auto& n=graph[p];
            if(n.degree==0) self(self,p,depth+1,divisor);
            else for(int j=0;j<n.degree;++j) self(self,n.cells[j],depth+1,divisor*n.degree);
        };
        paths(paths,from,0,1);
        assert(want.immediate[first-1]<=want.discounted[first-1]&&want.discounted[first-1]<=D);
    }
    return want;
}
template<class Legal>
T eq(const Graph& graph,int from,int speed,const Legal& legal) {
    auto a=terry_first_safe::first_hit(graph,from,speed,legal),b=exhaustive(graph,from,speed,legal);
    assert(a.immediate==b.immediate&&a.discounted==b.discounted);
    return a;
}
int main() {
    constexpr auto all=std::array<uint64_t,3>{D,D,D};
    constexpr auto none=std::array<uint64_t,3>{0,0,0};
    Graph g{};
    auto is0=[](int p){return p==0;};
    for(int speed=1;speed<=3;++speed) {
        auto a=eq(g,0,speed,is0),b=eq(g,1,speed,is0);
        assert(a.immediate==all&&a.discounted==all);
        assert(b.immediate==none&&b.discounted==none);
    }
    edge(g,0,1);
    auto cow=eq(g,0,1,is0);
    assert((cow.immediate==std::array<uint64_t,3>{0,D,0}));
    assert((cow.discounted==std::array<uint64_t,3>{D/3*2,D,D/5*4}));
    auto pig=eq(g,0,2,is0);
    assert(pig.immediate==all&&pig.discounted==all);
    // Isolated from eligible end positions by parity, although every odd
    // substep visits the legal square. Re-entry of the cow above IS counted.
    pig=eq(g,1,2,is0);
    assert(pig.immediate==none&&pig.discounted==none);

    Graph line{};
    for(int p=10;p<18;++p) edge(line,p,p+1);
    const auto one=[](int p){ return p>=10&&p<=18&&md(p,11)>1; };
    const auto two=[](int p){ return p>=10&&p<=18&&md(p,11)>1&&md(p,17)>1; };
    auto fromFar=eq(line,16,1,two);
    assert(fromFar.immediate[0]==D/2);
    auto farOne=eq(line,16,1,one);
    assert(farOne.immediate[0]==D&&fromFar.discounted[0]<farOne.discounted[0]);
    for(int speed=1;speed<=3;++speed) for(int p=10;p<=18;++p) eq(line,p,speed,two);

    // Independent fixed random exhaustive paths on small embedded grids,
    // allow degree 3/4 for speeds 1/2 and bound speed-3 to degree <=2.
    std::mt19937 rng(7915123);
    for(int trial=0;trial<300;++trial) {
        Graph small{};
        const int speed=1+(trial%3);
        std::vector<int> nodes;
        for(int r=10;r<13;++r)for(int c=10;c<14;++c)nodes.push_back(30*r+c);
        for(int a:nodes)for(int b:{a+1,a+30}) {
            if(b/30>12||b%30>13||md(a,b)!=1||rng()%4==0) continue;
            if(speed==3&&(small[a].degree>=2||small[b].degree>=2)) continue;
            edge(small,a,b);
        }
        std::array<bool,900> labels{};
        for(int p:nodes) labels[p]=(rng()%3)!=0;
        const auto legal=[&](int p){return labels[p];};
        eq(small,nodes[rng()%nodes.size()],speed,legal);
    }
    std::cout<<"exact immediate and first-hit rewards: all 300 random trees and deterministic edge fixtures agree\n";
}
