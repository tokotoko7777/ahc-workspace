#pragma once
#include <array>
#include <cassert>
#include <cstdint>
#include <utility>

namespace terry_first_safe {
inline constexpr int cells=900;
inline constexpr int max_substeps=15;
inline constexpr std::array<uint64_t,max_substeps+1> powers=[] {
    std::array<uint64_t,max_substeps+1> a{};
    a[0]=1;
    for(int k=1;k<=max_substeps;++k) a[k]=12*a[k-1];
    return a;
}();
inline constexpr uint64_t time_scale=60;
inline constexpr uint64_t denominator=time_scale*powers[max_substeps];
static_assert(denominator==924421294475182080ULL);
using Accumulator=__uint128_t;
static_assert(Accumulator(100)*20*denominator>UINT64_MAX);

namespace detail {
struct Layer {
    std::array<uint64_t,cells> weight{};
    std::array<uint16_t,481> active{};
    int length=0;
    void add(int p,uint64_t gain) {
        assert(gain && p>=0 && p<cells);
        if(weight[p]==0) {
            assert(length<int(active.size()));
            active[length++]=static_cast<uint16_t>(p);
        }
        weight[p]+=gain;
    }
    void clear() {
        for(int i=0;i<length;++i) weight[active[i]]=0;
        length=0;
    }
};

template<class Table>
void advance(const Table& table,Layer*& old,Layer*& next) {
    assert(next->length==0);
    for(int i=0;i<old->length;++i) {
        const int p=old->active[i];
        const auto& n=table[p];
        const uint64_t x=old->weight[p];
        old->weight[p]=0;
        assert(n.degree>=0 && n.degree<=4);
        if(n.degree==0) next->add(p,x*12);
        else for(int k=0;k<n.degree;++k) next->add(n.cells[k],x*(12/n.degree));
    }
    old->length=0;
    std::swap(old,next);
}

template<class Predicate>
uint64_t remove_hits(Layer& layer,const Predicate& legal) {
    uint64_t removed=0;
    int n=0;
    for(int i=0;i<layer.length;++i) {
        const int p=layer.active[i];
        if(legal(p)) {
            removed+=layer.weight[p];
            layer.weight[p]=0;
        } else {
            layer.active[n++]=uint16_t(p);
        }
    }
    layer.length=n;
    return removed;
}
}

// table[p] describes passable orthogonal *physical* neighbors on the fixed
// board, not filtered by rooms/gates/predicates. The static legal predicate
// describes the originally selected room label AND excludes cells that would
// personally block either real gate. Index 0..2 means ETA one..three turns.
struct Result {
    std::array<uint64_t,3> immediate{};
    std::array<uint64_t,3> discounted{};
};

template<class Table,class Predicate>
Result first_hit(const Table& table,int start,int speed,const Predicate& legal) {
    assert(start>=0 && start<cells && speed>=1 && speed<=3);
    detail::Layer prefix[2], tail[2];
    auto *cur=&prefix[0], *next=&prefix[1];
    auto *pending=&tail[0], *work=&tail[1];
    cur->add(start,1);
    Result reward;
    for(int eta=1;eta<=3;++eta) {
        for(int sub=0;sub<speed;++sub) detail::advance(table,cur,next);
        assert(pending->length==0 && work->length==0);
        for(int i=0;i<cur->length;++i) {
            int p=cur->active[i];
            pending->add(p,cur->weight[p]);
        }
        for(int turn=eta;turn<=eta+2;++turn) {
            if(turn>eta) for(int sub=0;sub<speed;++sub) detail::advance(table,pending,work);
            const uint64_t hits=detail::remove_hits(*pending,legal);
            const uint64_t discount=(time_scale/(turn+1))*(eta+1);
            const uint64_t value=hits*powers[max_substeps-turn*speed]*discount;
            if(turn==eta) reward.immediate[eta-1]=value;
            reward.discounted[eta-1]+=value;
        }
        assert(reward.discounted[eta-1]<=denominator);
        pending->clear();
    }
    return reward;
}
}
