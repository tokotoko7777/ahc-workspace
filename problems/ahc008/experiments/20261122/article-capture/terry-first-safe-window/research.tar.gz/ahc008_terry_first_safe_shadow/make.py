"""Detached triple policy audit. Always emits accepted h123 actions."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_split_dp/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='170382b80e4ca1b0d3a5c4f0948527edabfbb43c0549fa8512fbe9dccc59e223'
def put(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
def ap(a,b):
    put(a,a+b)
a='#pragma GCC optimize("O3")'
ap(a,'\n'+(d.parent/'ahc008_terry_first_safe_window/first_safe.hpp').read_text().replace('#pragma once\n',''))
a='namespace terry_exact_root {'
i=s.index(a)+len(a)
s=s[:i]+'\ninline int window_audit_turn=-1;\ninline std::vector<std::string> window_rows;\n'+s[i:]
a='using Retention=std::vector<std::array<int,30>>;'
ap(a,'''
using WinU=terry_first_safe::Accumulator;
constexpr auto WinDen=terry_first_safe::denominator;
struct WindowTap {
 std::array<WinU,3> only{},later{};
};
''')
put('std::vector<ShortTap>* tap=nullptr)',
    'std::vector<ShortTap>* tap=nullptr, std::vector<WindowTap>* win=nullptr, const Mask* veto=nullptr)')
a='  for(int trial=0;trial<100;++trial){\n   Pet p=initial;p.target=-1;'
put(a,'''
  auto safe=[&](int p){return ids[p]==room&&!(*veto)[p];};
  if(win&&passive){
    const auto z=terry_first_safe::first_hit(adjacency.table,initial.pos,initial.type,safe);
    for(int j=0;j<3;++j){
      (*win)[room].only[j]+=WinU(100)*z.immediate[j];
      (*win)[room].later[j]+=WinU(100)*z.discounted[j];
    }
  }
  for(int trial=0;trial<100;++trial){
   Pet p=initial;p.target=-1;
   std::array<bool,3> hit{};
''')
a='    if(passive&&1<=h&&h<=3)(*tap)[room].sampled[h-1]+=ids[p.pos]==room;'
ap(a,'''
    if(win&&!passive&&1<=h&&h<=5&&safe(p.pos)){
      if(h<=3)(*win)[room].only[h-1]+=WinDen;
      for(int eta=std::max(1,h-2);eta<=std::min(3,h);++eta){
        if(hit[eta-1])continue;
        hit[eta-1]=true;
        (*win)[room].later[eta-1]+=WinU(WinDen/(h+1))*(eta+1);
      }
    }
''')
a='    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng,&tap);'
put(a,'''
    const bool record=window_audit_turn>=0;
    std::vector<WindowTap> win(record?geometry.count():0);
    Mask veto;
    if(record){
      for(int k=0;k<geometry.count();++k){
        const auto& room=geometry.rooms[k];
        for(int g:{room.left,room.right})if(g>=0){
          if(geometry.ids[g]==k)veto.set(g);
          for(int p:nb[g])if(p>=0&&geometry.ids[p]==k)veto.set(p);
        }
      }
    }
    auto before_rng=rng;
    auto freqs=retention(s,builds,geometry.ids,geometry.count(),alive,rng,&tap,
                         record?&win:nullptr,record?&veto:nullptr);
    if(record){
      std::vector<ShortTap> stocktap(geometry.count());
      const auto stock=retention(s,builds,geometry.ids,geometry.count(),alive,before_rng,&stocktap);
      assert(stock==freqs&&before_rng.s==rng.s);
      for(size_t k=0;k<tap.size();++k)
        assert(tap[k].exact==stocktap[k].exact&&tap[k].sampled==stocktap[k].sampled);
    }
''')
a='    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));'
ap(a,'''
    if(record){
      const auto open=bits_to_array(actual & ~builds & ~moves);
      auto only=rooms,later=rooms;
      for(int k=0;k<(int)rooms.size();++k)if(rooms[k].area>0){
        for(int j=0;j<3;++j){
          assert(win[k].only[j]<=win[k].later[j]);
          only[k].override_short[j]=double(win[k].only[j])/double(WinDen);
          later[k].override_short[j]=double(win[k].later[j])/double(WinDen);
        }
      }
      auto iJobs=hunt::choose(s.people,booked,only,open);
      auto wJobs=hunt::choose(s.people,booked,later,open);
      auto issue=[&](const auto& js){
        auto q=booked;auto a=action;
        hunt::emit(s.people,js,legal,q);
        for(int i=0;i<m;++i)if(q[i])a[i]=*q[i];
        idle_phase(s,terrain->aisleColumns,a);return sanitize(s,a);
      };
      auto a=issue(jobs),b=issue(iJobs),c=issue(wJobs);
      if(a!=b||a!=c)
        window_rows.push_back("C "+std::to_string(window_audit_turn)+" "+a+" "+b+" "+c);
      if(c!=a&&c!=b){
        auto same=[](const auto& x,const auto& y){
          return std::tie(x.room,x.a,x.b)==std::tie(y.room,y.a,y.b);
        };
        for(const auto& j:wJobs){
          if(std::any_of(iJobs.begin(),iJobs.end(),[&](const auto& z){return same(j,z);}))continue;
          int eta=(j.left>=0&&!open[j.left])||(j.right>=0&&!open[j.right]);
          if(j.left>=0)eta=std::max(eta,std::abs(s.people[j.a]/30-j.left/30));
          if(j.right>=0)eta=std::max(eta,std::abs(s.people[j.b]/30-j.right/30));
          if(eta<1||eta>3)continue;
          std::string row="J "+std::to_string(window_audit_turn)+" "+std::to_string(eta)+
             " "+std::to_string(j.left)+" "+std::to_string(j.right)+" "+std::to_string(j.a)+" "+std::to_string(j.b);
          for(int p=0;p<V;++p)if(geometry.ids[p]==j.room)row+=" "+std::to_string(p);
          window_rows.push_back(std::move(row));
        }
      }
    }
''')
a='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(a,'''  if(turn<275&&std::getenv("AHC008_TERRY_FIRST_SAFE_AUDIT"))window_audit_turn=turn;
'''+a+'''
  window_audit_turn=-1;''')
a=' if(const char* path=std::getenv("AHC008_TERRY_EXACT_LOG")){'
put(a,''' if(const char* path=std::getenv("AHC008_TERRY_FIRST_SAFE_AUDIT")){
   std::ofstream f(path);for(const auto& row:window_rows)f<<row<<'\\n';
 }
'''+a)
(d/'audit.private.cpp').write_text(s)
