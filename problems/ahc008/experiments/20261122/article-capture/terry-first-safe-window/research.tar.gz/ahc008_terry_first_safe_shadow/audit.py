"""Frozen first-window detached evidence. No new actions or real scores."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

D=Path(__file__).resolve().parent; R=D.parent; P=R/'ahc008_terry_chase_cut_ties'
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,flat,flood,near,observed,replay,wave

def project(p,h,w,command):
    ban=bitmask(h+p)|wave(bitmask(p))|w
    nxt=[];new=0
    for x,c in zip(h,command,strict=True):
        q=x if c=='.' else near(x,c.upper())
        if q is None:
            return None
        if c.islower():
            if B[q]&(ban|new):
                return None
            new|=B[q];nxt.append(x)
        else:
            nxt.append(q)
    if bitmask(nxt)&(w|new):
        return None
    return nxt,w|new

def capids(p,h,w,c):
    old=flood(bitmask(h),ALL^w)
    result=project(p,h,w,c)
    assert result is not None
    now=flood(bitmask(result[0]),ALL^result[1])
    return {i for i,x in enumerate(p) if B[x]&old and not B[x]&now}

def vertical(p,stance):
    if p%30!=stance%30:
        return None
    return 'U' if p//30>stance//30 else 'D' if p//30<stance//30 else '.'

def witness(history,kinds,actions,t,eta,gates,roles,region,window):
    gate_mask=bitmask(gates)
    danger=gate_mask|wave(gate_mask)
    region_mask=bitmask(region)
    body=region_mask&~gate_mask
    p,h,w=history[t]
    if not body:
        return []
    eligible={i for i,x in enumerate(p) if int(kinds[i]) in (1,2,3) and bool(B[x]&region_mask)}
    if not eligible:
        return []
    where={person:gate-1 if command=='r' else gate+1 for gate,person,command in roles}
    build={person:command for gate,person,command in roles}
    wins=[]
    for extra in (1,2):
        now=t+eta+extra
        if now>=275:
            continue
        chosen=set(eligible)
        for r in range(t+eta,now):
            pp,_,_=history[r]
            chosen={i for i in chosen if not (B[pp[i]]&body&~danger)}
        if not chosen:
            continue
        hh=h[:]; ww=w
        for turn in range(t,now+1):
            pp,_,actualwalls=history[turn]
            if ww!=actualwalls:
                break
            proposal=list(actions[turn])
            commands={}
            for person,stance in where.items():
                if proposal[person].islower():
                    break # protected original wall job
                c=vertical(hh[person],stance)
                if c is None or (turn==now and c!='.'):
                    break
                if turn==t and c!=window[person]:
                    break # not the proposed first action for this job
                commands[person]=build[person] if turn==now else c
            if len(commands)!=len(where):
                break
            for person,cmd in commands.items():
                proposal[person]=cmd
            out=project(pp,hh,ww,''.join(proposal))
            if out is None:
                break
            if turn==now:
                before=flood(bitmask(hh),ALL^ww)
                after=flood(bitmask(out[0]),ALL^out[1])
                for animal in sorted(chosen):
                    cell=B[pp[animal]]
                    if cell&body&before and not cell&(after|danger):
                        pocket=flood(cell,ALL^out[1])
                        if pocket&~body:
                            continue
                        wins.append(dict(pet=animal,observed_type=int(kinds[animal]),
                                         first_hit_offset=eta+extra, gates=gates, role=sorted(where),
                                         final_command=''.join(proposal), area=pocket.bit_count()))
            hh,ww=out
    return wins

def sha(data):return hashlib.sha256(data).hexdigest()

meta=json.loads((P/'manifest.json').read_text())
ledger={ '%04d.txt'%z['board']:z for z in json.loads((P/'report.json').read_text())['tapes']}
records=[]
for f,hsh in sorted(meta['input'].items()):
    raw=(P/'in'/f).read_bytes()
    a=(P/'tapes'/f).with_suffix('.actions').read_bytes()
    tape=(P/'tapes'/f).with_suffix('.trace').read_bytes()
    ref=ledger[f]
    assert sha(raw)==hsh==ref['input_sha'] and sha(a)==ref['commands_sha'] and sha(tape)==ref['trace_sha']
    actions=a.decode().splitlines(); trace=tape.decode().splitlines()
    assert replay(raw.decode(),trace,actions,detailed=True)[0]==ref['score']
    parts=raw.decode().splitlines(); n=int(parts[0]);m=int(parts[n+1])
    with tempfile.TemporaryDirectory() as tmp:
        out=Path(tmp)/'out'
        z=subprocess.run([str(D/'audit'),'--pairs=0'],
            input='\n'.join(parts[:n+2+m]+trace[1::2])+'\n',text=True,capture_output=True,
            check=True,timeout=10,env=dict(os.environ,AHC008_TERRY_FIRST_SAFE_AUDIT=str(out)))
        assert z.stdout.splitlines()[:275]==actions[:275],f
        lines=out.read_text().splitlines()
    kinds,observed_states,_=observed(raw,trace)
    history=[(list(map(flat,p)),list(map(flat,h)),bitmask(map(flat,w))) for p,h,w in observed_states]
    counts=collections.Counter()
    changed={}; events={}
    for line in lines:
        k,*fields=line.split()
        if k=='C':
            t,old,only,window=fields;t=int(t);assert old==actions[t] and (old!=only or old!=window)
            p,h,w=history[t]
            oc=capids(p,h,w,old);wc=capids(p,h,w,window)
            counts.update(window_vs_stock=old!=window,window_vs_instant=only!=window,
                window_vs_both=(window!=old and window!=only),immediate_lost=len(oc-wc),immediate_gained=len(wc-oc))
            if window!=old and window!=only:
                changed[t]=dict(window=window,old=old,only=only)
        else:
            assert k=='J'
            t,eta,left,right,i,j,*region=map(int,fields)
            assert t in changed
            roles=[]
            if left>=0:roles.append((left,i,'r'))
            if right>=0:roles.append((right,j,'l'))
            gates=tuple(g for g,_,_ in roles)
            for x in witness(history,kinds,actions,t,eta,gates,roles,region,changed[t]['window']):
                key=(t,gates,x['pet'])
                if key not in events:events[key]=dict(t=t,eta=eta,**x)
    # Count distinct actual states as well as deduplicated pet/gate opportunities.
    counts.update(compat_events=len(events),compat_turns=len({z['t'] for z in events.values()}))
    records.append(dict(case=f,counts=counts,events=sorted(events.values(),key=lambda z:(z['t'],z['pet']))))
    print(f,dict(counts),file=sys.stderr,flush=True)

assert len(records)==60
total=collections.Counter()
for z in records:total.update(z['counts'])
boards={x:sum(z['counts'][x]>0 for z in records)for x in total}
gate=total['window_vs_instant']>=20 and boards['window_vs_instant']>=10 and total['immediate_lost']==0 and total['compat_events']>=5 and total['compat_turns']>=5 and boards['compat_events']>=3
print(json.dumps(dict(cases=len(records),total=total,boards=boards,gate=gate,records=records),indent=2))
