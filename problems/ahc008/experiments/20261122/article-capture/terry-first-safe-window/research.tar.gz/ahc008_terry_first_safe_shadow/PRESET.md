# Frozen read-only activation gate for first own-safe endpoint prediction

No operational choices in the audit. Independent accepted h123 fresh60
tapes; all t0 through t274 accepted commands must match, every input,
trace and action digest verified, exact independent score. The faster
split queue fits identically at fixed work and the examined prefix is
before the timed endgame switch. Observe three original-role proposals:
(a) accepted short h123, (b) new model's h-only endpoint, (c) new model's
discounted first safe endpoint h..h+2 for h=1,2,3. A qualifying endpoint
must stay in its initial room at that instant and neither occupy, nor
orthogonally touch, either usable gate. Traveling out and returning is
allowed. Dog and cat surrogate use the already recorded 100 paths
no new draws; passive paths use exact arithmetic. Only substitute
h1–3 in detached data copies; unchanged phase filters, crew, packing,
sanitizer, treatment of current or far jobs, wall clock, PCG and stock
stdout. Audit must verify original paths/sampling untouched.

Admit a new freshly generated live A/B only if:
- c and b full sanitized proposals differ on ≥20 turns across ≥10
  independently generated boards; c and a are reported separately.
- No immediately isolated old animal ID is lost by c relative to a on
  any evaluated factual current state (pure reachability on same state).
- At least five unique accepted-vs-window differing first commands
  carry a delayed h+1/h+2 *passive* same-ID opportunity on ≥3 boards.
  The newly chosen job must be absent from the h-only decision, h
  in 1..3. Started inside, physically outside veto only at a later
  endpoint, actual two original stances can be reached by the proposed
  role moves and held across the extra steps. Use only original future
  walls and preserve all other actors' original moves/walls; if one
  designated role has an original wall action or any protected
  action becomes illegal, reject the hypothetical path. Exact
  stock closure legal under projected same-state occupied cells;
  both physical mouths may close and separate target from all
  projected humans, retaining all protected simultaneous commands.
  This frozen observed movement compatibility is hindsight feasibility,
  not proof of a predictive controller or changed rollout success.
  Dedup (board, start turn, mouths, pet identity), and require ≥5
  independent board/turn opportunities before counting raw repeats.

This is not the earlier failed h-only passive veto, and not waiting to
group multiple animals: no control is commanded to wait and no entrants
are scored. Non-target pets and future potential blockers interact with
real closure and are not captured by its own-safe proxy; joint screen
reduces false activation but does not guarantee good score. If any
part fails archive, do not change window or conditions to chase
these tapes. If passes, separate fresh unfiltered dev100 and locked
fresh held100 using one exact candidate and unchanged budget, ≥0.1%
score with no raw or useful full decline, official and independent
legal max tester <2.95s; only then practice100 under same rule.
