// Valid causal input: only real initial worker locations and the model's
// accepted original map. The dry planner never reads/copies real pet paths.
namespace areaDryChoice {
inline int readiness(const State& observed,int map,Clock::time_point stop){
 State x;
 x.people=observed.people;
 const auto& cfg=terrain_lib::terrain(map);
 Normal n(cfg,x);
 std::vector<int> slots=cfg.aisleColumns;
 std::stable_sort(slots.begin(),slots.end(),[](int a,int b){
  return std::abs(a-15)<std::abs(b-15);
 });
 if(slots.empty())return 999;
 std::array<int,30> required{};
 for(int i=0;i<(int)x.people.size();++i)++required[slots[i%slots.size()]];
 for(int turn=0;turn<133;++turn){
  if(Clock::now()>=stop)return 999;
  people_step(x,n.step(x,turn));
  if((cfg.plannedWalls&~x.walls).any())continue;
  std::array<int,30> actual{};
  for(int h:x.people)++actual[h%30];
  if(actual==required)return turn+1;
 }
 return 999;
}
inline bool shouldTry(const State& s,int original,Clock::time_point start,
                      int& oldTurns,int& newTurns){
 oldTurns=newTurns=-1;
 if(original!=2||s.people.size()<8)return false;
 const auto stop=start+std::chrono::milliseconds(175);
 oldTurns=readiness(s,2,stop);
 if(oldTurns>=999||Clock::now()>=stop)return false;
 newTurns=readiness(s,3,stop);
 return Clock::now()<stop&&newTurns<=oldTurns;
}
}
