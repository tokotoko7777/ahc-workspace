"""Experimental causal original map2->3 using current starting staff only."""
import hashlib
from pathlib import Path
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_incoming_shadow/live.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
def edit(a,b):
    global s
    assert s.count(a)==1,a
    s=s.replace(a,b)
a='\n}\n\nint main(int argc,char** argv){'
edit(a,'\n'+(d/'choose.hpp').read_text()+a)
a=' if(map<0)map=terry_exact_selector::choose(m,counts);'
edit(a,'''
 int original=map, oldTurns=-1, newTurns=-1;
 if(map<0){
  original=map=terry_exact_selector::choose(m,counts);
  if(areaDryChoice::shouldTry(s,map,started,oldTurns,newTurns))map=3;
 }
''')
a="    <<metrics.idle_walks<<' '<<d.pairs<<' '<<d.normal<<' '<<d.chase_sum<<' '<<d.chose<<' '<<score(s)<<'\\n';"
edit(a,a.replace("<<d.chose<<' '<<score","<<d.chose<<' '<<original<<' '<<oldTurns<<' '<<newTurns<<' '<<score"))
(d/'live.private.cpp').write_text(s)
