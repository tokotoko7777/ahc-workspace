# One causal area-layout candidate, fixed before independent official tests

The separate exact zero-rollout atlas found the largest practical
scope among current stock map2 cases choosing original map3, with
no new geometry. This is a discovery hypothesis, not a selection
from scored test inputs. Only consider model's current stock map2
and at least eight people (three spare after staffing five lanes).
Require two true no-pet dry construction profiles from the observed
initial worker locations, original C++ planning and action semantics:
both all planned walls installed and eight or more workers on
their proper nominal aisle quotas by turn133. Pick the fewer-wall
map3 only if its completion is no later; otherwise original. Probe
≤175ms shared program-wall budget, p/h actual not advanced; any
incomplete or cutoff even after gaining a partial advantage reverts
to original. Recreate ordinary game controller from the real input,
do not consume accepted policy RNG or judge sequence to choose.
Clock/future capture and all geometry code unchanged otherwise.

Master tests: new unfiltered generated dev100 then held100 then
actual practice100 only on both passes, original 2670ms overall
including initial dry setup. Need ≥0.1% aggregate improvement,
full and useful full nonlower, and within the actually switched
subset also neither raw nor useful full down. Need ≥4 actual
switches in each 100 and score benefit not merely elsewhere from
clock noise. All passes are exact tester+playback+independent,
max local tester <2.95s. Original accepted set was full practice,
so no missing animals allowed there. On failure save, no response
to thresholds/case numbers/distributions; never conclude whole
goal from the discovered hindsight ceiling.
