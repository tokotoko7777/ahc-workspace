"""Report whole and actually switched paired rollout populations (not a predictor)."""
from pathlib import Path
import csv
import json
import sys
p=Path(sys.argv[1]);a={}
for z in csv.DictReader(p.open()):a.setdefault(z['case'],{})[z['arm']]=z
assert len(a)==100 and all(len(y)==2 for y in a.values())
q=[]
for case,t in sorted(a.items()):
 x,y=t['v25'],t['terry_independent']
 a,b=x['telemetry'].split(),y['telemetry'].split()
 assert len(a)==15 and len(b)==18 and a[0]==b[14] and x['input_sha']==y['input_sha']
 assert a[-1]==x['score'] and b[-1]==y['score']
 z=dict(case=case,unchanged=b[0]==a[0],eligible=int(a[0])==2 and int(x['humans'])>=8,
    original_map=int(a[0]),actual_map=int(b[0]),dry=[int(b[15]),int(b[16])])
 z['ports']=(x,y)
 if not z['unchanged']:assert z['eligible'] and int(b[0])==3
 q.append(z)
def summary(zz):
 s={k:[sum(int(x['ports'][i][k])for x in zz)for i in (0,1)]
    for k in ('score','full','useful300','final_residual')}
 s.update(n=len(zz),max_wall=[max((float(x['ports'][i]['wall'])for x in zz),default=0.0)for i in (0,1)],
   command_changes=sum(x['ports'][0]['commands_sha']!=x['ports'][1]['commands_sha'] for x in zz),
   affected=[dict(case=x['case'],dry=x['dry'],score=[int(y['score'])for y in x['ports']],
        full=[int(y['full'])for y in x['ports']],floor=[float(y['mean_human_area'])for y in x['ports']])for x in zz if not x['unchanged']])
 return s
s0=summary(q);s1=summary([x for x in q if not x['unchanged']]);s2=summary([x for x in q if x['unchanged']]);el=summary([x for x in q if x['eligible']])
judge=lambda bb,ix: bb[ix][0]<=bb[ix][1]
gate=(s1['n']>=4 and 1000*s0['score'][1]>=1001*s0['score'][0] and s1['score'][1]>s1['score'][0] and
      all(judge(r,x) for r in (s0,s1) for x in ('full','useful300')) and max(s0['max_wall'])<2.95)
print(json.dumps(dict(all=s0,switched=s1,unchanged=s2,eligible=el,gate=gate),indent=2))
