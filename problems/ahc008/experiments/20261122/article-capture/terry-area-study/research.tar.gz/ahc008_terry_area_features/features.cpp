#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <optional>
#include <string_view>
#include <tuple>
#include <vector>

namespace initial_area {
using namespace terry_exact_maps;
struct Pet{int p,t;};
struct Instance{
 std::vector<Pet> pets;
 std::vector<int> people;
};
struct RoomView{
 int id=-1;
 int left=-1,right=-1;
 std::vector<int> safe;
};
struct Physical{
 const Terrain* terrain=nullptr;
 Board safe;
 std::vector<RoomView> rooms;
};
int md(int a,int b){return std::abs(a/W-b/W)+std::abs(a%W-b%W);}
std::optional<Instance> parse(std::istream& in){
 Instance x;
 int n,m,r,c,t;
 if(!(in>>n)||n<10||n>20)return std::nullopt;
 for(int i=0;i<n;i++){
  if(!(in>>r>>c>>t)||r<1||r>W||c<1||c>W||t<1||t>5)return std::nullopt;
  x.pets.push_back({cell(r-1,c-1),t});
 }
 if(!(in>>m)||m<5||m>10)return std::nullopt;
 for(int i=0;i<m;i++){
  if(!(in>>r>>c)||r<1||r>W||c<1||c>W)return std::nullopt;
  x.people.push_back(cell(r-1,c-1));
 }
 return x;
}
Physical geometry(int map){
 Physical a;
 const Terrain& t=terrain(map);
 a.terrain=&t;
 int stance=cell(0,t.aisleColumns.front());
 auto rooms=classify(t,t.plannedWalls,{}, {stance});
 auto separate=labels(t.plannedWalls|t.doorCells);
 for(int id=0;id<rooms.count();id++){
  const auto& r=rooms.rooms[id];
  if(r.left<0&&r.right<0)continue;
  RoomView v;
  v.id=id;
  v.left=r.left<0?-1:r.left-1;
  v.right=r.right<0?-1:r.right+1;
  int component=-1;
  for(int p=0;p<V;p++)if(rooms.ids[p]==id&&!t.doorCells[p]&&separate.labels[p]>=0){
   component=separate.labels[p];break;
  }
  if(component<0)continue;
  for(int p=0;p<V;p++)if(separate.labels[p]==component){
   if((r.left<0||md(p,r.left)>=2)&&(r.right<0||md(p,r.right)>=2)){
    v.safe.push_back(p);a.safe.set(p);
   }
  }
  if(!v.safe.empty())a.rooms.push_back(std::move(v));
 }
 return a;
}
std::vector<int> project(const Board& w,int p){
 if(!w[p])return {p};
 std::vector<int> a;
 for(int q:adjacent(p))if(q>=0&&!w[q])a.push_back(q);
 return a;
}
struct Paths {
 std::array<int,V> d;
 std::array<long double,V> total{},hit{};
 bool valid=false;
};
Paths paths(const Board& w,const Board& safe,int src){
 Paths a;
 a.d.fill(-1);
 const auto starts=project(w,src);
 if(starts.empty())return a;
 a.valid=true;
 int n=0;
 std::array<int,V> q;
 for(int s:starts){
  q[n++]=s;
  a.d[s]=w[src]?1:0;
  a.total[s]=1.;
  a.hit[s]=safe[s]?1.:0.;
 }
 for(int i=0;i<n;i++){
  int u=q[i];
  for(int v:adjacent(u))if(v>=0&&!w[v]){
   if(a.d[v]<0){
    a.d[v]=a.d[u]+1;q[n++]=v;
   }
   if(a.d[v]==a.d[u]+1){
    a.total[v]+=a.total[u];
    a.hit[v]+=safe[v]?a.total[u]:a.hit[u];
   }
  }
 }
 return a;
}
using Values=std::array<double,6>;
struct Evaluation{
 std::optional<Values> value;
 std::string_view error;
};
Evaluation measure(const Instance& in,int map){
 const auto shell=geometry(map);
 const auto& w=shell.terrain->plannedWalls;
 std::vector<Paths> animals,crew;
 animals.reserve(in.pets.size());
 crew.reserve(in.people.size());
 for(const auto p:in.pets){
  animals.push_back(paths(w,shell.safe,p.p));
  if(!animals.back().valid)return {{}, "pet_no_open_neighbor"};
 }
 for(int p:in.people){
  crew.push_back(paths(w,shell.safe,p));
  if(!crew.back().valid)return {{}, "person_no_open_neighbor"};
 }
 constexpr int inf=10000;
 int N=in.pets.size(),M=in.people.size();
 int worst=0,nearby=0,slow=0,nd=0,nc=0;
 long double dog=0.,cat=0.;
 Board pressure;
 for(int i=0;i<N;i++){
  const auto pet=in.pets[i];const auto& p=animals[i];
  if(pet.t<=3){
   pressure.set(pet.p);
   for(int z:adjacent(pet.p))if(z>=0)pressure.set(z);
  }
  if(pet.t<=2){
   int d=inf;
   for(int q=0;q<V;q++)if(shell.safe[q]&&p.d[q]>=0&&
      (pet.t==1||((pet.p/W+pet.p%W-q/W-q%W)%2==0)))d=std::min(d,p.d[q]);
   if(d==inf)return {{}, "slow_no_compatible_safe_endpoint"};
   worst=std::max(worst,d);nearby+=(d<=6);++slow;
  }
  if(pet.t==4){
   long double r=0.;
   for(int target:in.people){
    auto ends=project(w,target);
    int count=0;long double v=0.;
    for(int a:ends)if(p.d[a]>=0&&p.total[a]>0.){
     ++count;v+=p.hit[a]/p.total[a];
    }
    if(count)r+=v/count;
   }
   dog+=r/M;++nd;
  }
  if(pet.t==5){
   long double r=0.;int count=0;
   for(int q=0;q<V;q++)if(q!=pet.p&&p.d[q]>=0&&p.total[q]>0.){
    r+=p.hit[q]/p.total[q];++count;
   }
   if(count)cat+=r/count;
   ++nc;
  }
 }
 std::vector<std::tuple<int,int,int>> opportunity;
 for(int j=0;j<int(shell.rooms.size());j++){
  const auto& r=shell.rooms[j];
  if(r.left<0||r.right<0||r.left>=V||r.right>=V||w[r.left]||w[r.right])continue;
  int d=inf;
  for(int p:r.safe)for(const auto& a:animals)if(a.d[p]>=0)d=std::min(d,a.d[p]);
  if(d<inf)opportunity.emplace_back(d,r.id,j);
 }
 std::sort(opportunity.begin(),opportunity.end());
 std::vector<int> times;
 if(opportunity.empty())return {{}, "no_guard_opportunity"};
 opportunity.resize(std::min(std::size_t(8),opportunity.size()));
 for(auto [d,id,j]:opportunity){
  const auto& r=shell.rooms[j];
  int best=inf;
  for(int a=0;a<M;a++)if(crew[a].d[r.left]>=0)
   for(int b=0;b<M;b++)if(b!=a&&crew[b].d[r.right]>=0)
    best=std::min(best,std::max(crew[a].d[r.left],crew[b].d[r.right]));
  if(best==inf)return {{}, "no_two_distinct_guards"};
  times.push_back(best);
 }
 std::sort(times.begin(),times.end());
 int k=times.size();
 Values x{double(worst),slow?double(nearby)/slow:0.,
          nd?double(dog/nd):0.,nc?double(cat/nc):0.,
          double((w&pressure).count())/w.count(),
          .5*(times[(k-1)/2]+times[k/2])};
 for(double z:x)if(!std::isfinite(z))return {{}, "nonfinite"};
 return {x,{}};
}
}
int main(){
 using namespace initial_area;
 std::ios::sync_with_stdio(false);std::cin.tie(nullptr);
 auto input=parse(std::cin);
 if(!input){std::cout<<"abstain\tbad_initial_prefix\n";return 0;}
 if(input->people.size()<8){std::cout<<"abstain\tM_under_8\n";return 0;}
 auto base=measure(*input,2),alt=measure(*input,3);
 if(!base.value||!alt.value){
  std::cout<<"abstain\t"<<(!base.value?"map2_":"map3_")<<(!base.value?base.error:alt.error)<<'\n';
  return 0;
 }
 std::cout<<"ok"<<std::setprecision(17);
 for(int j=0;j<6;j++)std::cout<<'\t'<<(*alt.value)[j]-(*base.value)[j];
 std::cout<<'\n';
}
