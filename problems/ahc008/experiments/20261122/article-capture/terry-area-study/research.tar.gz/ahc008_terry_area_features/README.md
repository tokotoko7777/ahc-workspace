# Frozen two-stock-map initial geometry features (before looking at outcomes)

This cheap causal extractor reads the official position/type + human position
prefix from stdin. It never consumes the tester seed, trace, final score,
or a case ID. Its model population (enforced by analysis caller) is actual
stock-selector map2, M≥8, on separately predeclared generated IDs; the tool
reports abstention on M<8. Geometry is the exact stock map2 and map3 of
`terry_exact_maps`, unrotated, with all planned walls and all doors still
open. All six outputs are **map3 minus map2**, in fixed order below.

Catalog exact planned bodies with at least one named gate by taking the full
connected physical component when all named gates are hypothetically closed.
Retain original classified rooms in the stock-major geometry. A body cell is
*safe* iff its Manhattan distance from every named gate of its own room is ≥2.
Only these cells are interception targets. An initial source on prospective X
starts via **all cardinal open neighbors at distance 1** (all routes count, not
a hidden simulated displacement); a source not on X starts exactly there at
distance 0. A person target on prospective X is assessed equally across its
own open cardinal neighbors. Failure to project any source, absence of a
compatible slow safe endpoint, an unreachable staffed opportunity, or any
nonfinite result causes abstention. No outcomes have been inspected when
freezing these definitions.

1. **Slow worst access**: max over cows/pigs of shortest graph distance to a
   safe cell; a pig's endpoint must have the same board parity as its original
   initial cell. Start-on-X cost counts in distance. No cows/pigs gives 0.
2. **Slow near coverage**: fraction of cows/pigs whose same minimal compatible
   safe distance is at most 6. No cows/pigs gives 0.
3. **Dog traffic interception**: for each original dog and each actual initial
   human target, fraction of shortest graph routes that hit at least one safe
   cell. On prospective-X human targets, average equally among the reachable
   cardinal exit options; a human unreachable from that dog contributes zero
   to its average. Then average equally by human and dog. No dogs gives 0.
4. **Cat traffic interception**: same hit fraction, averaged equally over all
   reachable walkable target cells (exclude the unchanged actual origin, per
   cat targeting rules), then over cats. Zero for a cat with no target to draw.
   No cats gives 0. This is an initial routing proxy, not an inferred target.
5. **Slow brace pressure**: count distinct planned X cells within Manhattan
   distance 0 or 1 of at least one initial cow/pig/rabbit, divided by all
   planned X cells. All three are untargeted-movement species.
6. **Two distinct guard bottleneck**: of cataloged two-mouth rooms with safe
   cells and real open horizontal exterior stances, select the nearest eight
   by min across pets of their distance to a safe cell (no parity constraint
   here), ties by existing stock room ID, fewer if the map offers fewer.
   For each room minimize over ordered distinct human pairs the maximum of
   their prospective graph distances to the two exterior stances. Take the
   ordinary median (mean of middle two when even). No finite bottleneck at an
   opportunity or no opportunity causes abstention.

Shortest-DAG hit probabilities count each route only once, even if it visits
multiple safe cells. Dynamic path counts use long double. No timing, RNG,
features fitted to labels, or solver behavior is part of this tool.

Output a single TSV row: `ok<TAB>six raw numeric differences`, or
`abstain<TAB>reason`. Standard GNU C++23 standalone CLI with the workspace
terrain header; default stderr silent. Before root's timing clearance: source
only, do not compile or run a solver or official tester.
