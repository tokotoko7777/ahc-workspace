"""Glue: geometry extractor -> name plus six numbers in file argument order."""
import argparse
import subprocess
import sys
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument("extractor",type=Path)
p.add_argument("inputs",type=Path,nargs="+")
a=p.parse_args()
seen=set()
for q in a.inputs:
    if q.name in seen or any(c.isspace() for c in q.name):
        raise SystemExit(f"invalid or duplicated name: {q.name!r}")
    seen.add(q.name)
    r=subprocess.run([a.extractor.resolve()],input=q.read_bytes(),stdout=subprocess.PIPE,
                     text=False,check=True,timeout=2)
    z=r.stdout.decode().strip().split("\t")
    if z[0]=="ok" and len(z)==7:
        z=z[1:]
    elif z[0]=="abstain" and len(z)==2:
        print(q.name,z[1],file=sys.stderr)
        z=["nan"]*6
    else:
        raise SystemExit(f"invalid extraction output: {r.stdout!r}")
    print(q.name,*z)
