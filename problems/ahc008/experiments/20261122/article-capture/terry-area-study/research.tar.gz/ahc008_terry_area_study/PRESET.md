# Fixed conditional layout-safety development cohort, not a solver candidate

Learn whether opening human/animal geometry can explain the remaining
map2→3 differences beyond no-pet construction time. Scope is the first
120 qualifying inputs from a new uniform generated stream. Eligibility
only original model map2 and initial M≥8 (all original raw features)
and order, independent of score, shape success or cap. Up to 1536
seeds from a fixed separate namespace. Study only two existing maps
with the same accepted incoming policy, zero late-rollout pairs for
both (actual official tester/official playback/independent scores).
Record all conditional cases and no omitted losses. This is an offline
development corpus; no claim of revised score or real deployment
benefit. Do not fit a policy before freezing feature/model workflow,
select cases by learned outcomes, or reuse this as a held panel. Any
operational map selector must be measured on new unfiltered full-clock
official100 and then separate held100 with robust capture-safe gates.
