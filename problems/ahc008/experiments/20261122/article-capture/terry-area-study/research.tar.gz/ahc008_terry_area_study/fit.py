"""Fixed risk-aware small model; OOF before any additional data."""
import csv
import json
from math import log
from pathlib import Path
import sys
import numpy as np

D=Path(__file__).resolve().parent
data=D/'study.csv'
feat=Path(sys.argv[1])
groups={}
for d in csv.DictReader(data.open()):
 groups.setdefault(d['case'],{})[int(d['map'])]=d
assert len(groups)==120 and all(set(z)=={2,3} for z in groups.values())
zfeat={ }
for l in feat.read_text().splitlines():
 a,*v=l.split()
 assert a not in zfeat
 zfeat[a]=list(map(float,v))
 assert len(v)==6
assert zfeat.keys()==groups.keys()
f=sorted(groups)
features=np.array([zfeat[x]for x in f],dtype=float)
valid=np.all(np.isfinite(features),axis=1)
def field(k,m,dt=int):return np.array([dt(groups[x][m][k])for x in f])
score0,score1=field('score',2),field('score',3)
delta=(score1-score0)/1e6
full0,full1=field('residue',2)==0,field('residue',3)==0
h=field('human_count',2)
floor0,floor1=field('tile',2)/h,field('tile',3)/h
use0,use1=full0&(floor0>=300),full1&(floor1>=300)
harm=full0&~full1
L2=.02
pdim=7
reg=np.eye(pdim); reg[0,0]=0
def sigmoid(x):return 1/(1+np.exp(-np.clip(x,-60,60)))
def train(index):
 X=features[index]
 q1,mid,q3=np.quantile(X,[.25,.5,.75],axis=0)
 scale=q3-q1
 scale=np.where(scale>1e-8,scale,np.std(X,axis=0))
 scale=np.where(scale>1e-8,scale,1.0)
 xx=np.concatenate((np.ones((len(X),1)),(X-mid)/scale),axis=1)
 nn=len(xx)
 w=np.linalg.solve(xx.T@xx/nn+L2*reg,xx.T@delta[index]/nn)
 target=harm[index].astype(float)
 # Constant labels only fall back to conservative abstention (p=1).
 risk=np.zeros(pdim);risk[0]=60.
 if target.min()<target.max():
  pp=target.mean()
  risk[0]=log(pp/(1-pp))
  for _ in range(40):
   prob=sigmoid(xx@risk)
   grad=xx.T@(prob-target)/nn+L2*reg@risk
   hess=(xx.T*(prob*(1-prob)))@xx/nn+L2*reg+1e-10*np.eye(pdim)
   step=np.linalg.solve(hess,grad)
   # Backtracking on fixed loss, not model or threshold selection.
   loss=lambda b:np.mean(np.logaddexp(0,xx@b)-target*(xx@b))+.5*L2*np.dot(b,reg@b)
   initial=loss(risk)
   fac=1.
   while fac>2**-20 and loss(risk-fac*step)>initial:
    fac*=.5
   risk-=fac*step
   if np.linalg.norm(fac*step)<1e-9:break
 return mid,scale,w,risk
pred=np.empty(len(f));pred[:]=float('-inf')
p=np.ones(len(f))
iz=np.arange(len(f))
for q in range(4):
 i=(iz%4!=q)&valid; j=(iz%4==q)&valid
 if np.count_nonzero(i)<30:break
 mid,s,w,r=train(i)
 X=np.column_stack([np.ones(j.sum()),(features[j]-mid)/s])
 pred[j]=X@w;p[j]=sigmoid(X@r)
which=(pred>=2)&(p<=.05)
choice=np.where(which,score1,score0)
both=which&full0&full1
c=dict(conditional_n=len(f),valid=int(valid.sum()),oof_switches=int(which.sum()),
   oof_harms=int((which&harm).sum()),real_oof_score_gain=int((choice-score0).sum()),
   oof_raw=[int(full0.sum()),int(np.where(which,full1,full0).sum())],
   oof_useful=[int(use0.sum()),int(np.where(which,use1,use0).sum())],
   oof_common_full_floor_gain=float((floor1-floor0)[both].sum()),
   predicted_score_eligible=int((pred>=2).sum()),
   predicted_low_risk=int((p<=.05).sum()),
   risk_min=float(np.min(p)))
c['gate']=(c['oof_switches']>=30 and not c['oof_harms'] and c['real_oof_score_gain']>0 and
  c['oof_raw'][1]>=c['oof_raw'][0] and c['oof_useful'][1]>=c['oof_useful'][0] and c['oof_common_full_floor_gain']>0)
print(json.dumps(c,indent=2))
if c['gate']:
 mid,s,w,r=train(valid)
 (D/'frozen_model.json').write_text(json.dumps(dict(preproc_median=mid.tolist(),scale=s.tolist(),
   score_model=w.tolist(),harm_model=r.tolist(),threshold=[2.0,.05],l2=L2),indent=2)+'\n')
