"""Same two stock maps on the exact fixed 120 development cases, literal replay."""
import csv,hashlib,json,re,subprocess,sys,tempfile
from pathlib import Path
D=Path(__file__).resolve().parent; R=D.parent
P=R/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(P),str(P/'experiments/20261122')]
from benchmark_cases import run
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,idx,flood
T=R/'ahc008_focus_assets/tools/target/release/tester'
S=R/'ahc008_terry_incoming_shadow/live'
A=D
M=json.loads((D/'manifest.json').read_text())
manifest={v['selected']:v['sha']for v in M['cases']}
def sha(raw):return hashlib.sha256(raw).hexdigest()
rows=[]
for i,f in enumerate(sorted((A/'in').glob('*.txt'))):
 raw=f.read_bytes(); sha0=sha(raw)
 assert sha0==manifest[f.name]
 ref=2
 assert 0<=ref<5
 for m in ((2,3) if i%2==0 else (3,2)):
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp); acts=d/'actions'; tape=d/'tape'; log=d/'log'
   out,err,rc,wall=run([str(T),'env','AHC008_TERRY_EXACT_LOG='+str(log),str(S),'--pairs=0',f'--map={m}'],raw,4.5)
   p=re.fullmatch(rb'Score = (\d+)\s*',err)
   assert rc==0 and p,(f,m,err,rc)
   acts.write_bytes(out)
   rr,re_,rx,_=run([str(T),sys.executable,str(P/'benchmark_cases.py'),'--playback',str(acts),str(tape)],raw,12)
   assert (rr,re_,rx)==(out,err,rc)
   t=tape.read_text().splitlines();action=out.decode().splitlines()
   score=replay(raw.decode(),t,action,detailed=True)[0]
   assert score==int(p[1])
   k,hist,_=observed(raw,t)
   ps,hs,ws=hist[-1]
   op=ALL^sum(B[idx(q)] for q in ws)
   areas=[flood(B[idx(q)],op)for q in hs]
   live=0
   for x in areas:live|=x
   residue=sum(bool(B[idx(q)]&live)for q in ps)
   tile=sum(x.bit_count() for x in areas)
   tele=log.read_text().split()
   assert int(tele[0])==m and int(tele[10])==0 and int(tele[-1])==score
   rows.append(dict(case=f.name,sha=sha0,ref=ref,map=m,human_count=len(hs),
       command_sha=sha(out),score=score,tile=tile,residue=residue,wall=wall,
       x_built=int(tele[2]),h123_last_mode=int(tele[13])))
 with (D/'study.csv').open('w') as o:
  w=csv.DictWriter(o,rows[0].keys());w.writeheader();w.writerows(rows)
 print(f.name,ref,flush=True,file=sys.stderr)

assert len(rows)==2*len(manifest)==240
by={}
for v in rows:by.setdefault(v['case'],{})[v['map']]=v
both=[a for a in by.values()if a[2]['residue']==a[3]['residue']==0]
print(json.dumps(dict(n=len(by),verified=len(rows),bothfull=len(both),
     base_full=sum(a[2]['residue']==0 for a in by.values()),
     alt_full=sum(a[3]['residue']==0 for a in by.values()),
     both_floorgain=sum((a[3]['tile']-a[2]['tile'])/a[2]['human_count']for a in both),
     baseline_full_only=sum(a[2]['residue']==0<a[3]['residue']for a in by.values()),
     alternative_full_only=sum(a[3]['residue']==0<a[2]['residue']for a in by.values())),indent=2))
