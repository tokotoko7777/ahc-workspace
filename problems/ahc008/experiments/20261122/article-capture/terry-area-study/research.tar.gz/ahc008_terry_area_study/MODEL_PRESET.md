# Model procedure fixed before fitting

Use six fixed map3 minus map2 causal initial geometry features
(see separate pure area_features README; no dry-time feature or
historical practice). Initial worker and pet coordinates/species
are allowed; hidden generator seed, board index and subsequent
observations are never in a feature. Nonfinite/invalid features
automatically retain original by the eventual same rule.

Two fixed small models, both intercept unregularized:
- ridge linear regression for map3 minus map2 true Normal-only official
  score gain in millions;
- ridge logistic regression for harm flag = reference full, alt not full.
Use robust train-only feature median and IQR scaling, then fallback
std, then1 if data degenerate. L2 mean-objective coefficient0.02
for both, no hyperparameter or feature search. Compute predictions from
disjoint training fold splits by fixed manifest-order modulo4, not
from aggregate same-case model. Fixed abstain unless predicted score
gain≥2.0 million and estimated harm≤5.0%. No tuning afterwards.

Require out of fold ≥30 accepted, no baseline full→alternate loss on
ANY accepted even if another gains, strictly added paired score, no
aggregate full/useful decline and strictly positive mean area gain
among switched that are both full. If fails, no calibration or user
score claim; archive model as diagnostics, don't fit other cutoffs.
If passes, fit once on all120 then freeze preprocessing/weights and
test same rules on a separate drawn first120 qualifying calibration
cohort, no practice. Advance only if those independently also pass.
Production qualification would then need two new unfiltered full-clock
100 official panels and final same-worded practice/floor constraints;
no nondecidable branch or close timing fixed case. Aim >=100 switched
independent cases with no full losses as a robustness check (one-sided
upper 95% around3%), else explicitly state limited validation. This
conditional no-Chase label model is not the accepted map selector
and cannot establish behavior under full normal-clock policy.
