from pathlib import Path
import hashlib,json,subprocess
D=Path(__file__).resolve().parent
R=D.parent
G=R/'ahc008_focus_assets/tools/target/release/gen'
S=R/'ahc008_terry_area_map_atlas/selector'
N=120
def sha(b):return hashlib.sha256(b).hexdigest()
z=D/'stream';z.mkdir(exist_ok=True)
ss=z/'seeds.txt'
namespace='ahc008/20261123/terry-area-study-2-3-v1'
seeds=[int.from_bytes(hashlib.sha256(f'{namespace}/{i}'.encode()).digest()[:8],'little')for i in range(1536)]
text=''.join(f'{s}\n' for s in seeds)
if ss.exists():assert ss.read_text()==text
else:ss.write_text(text)
subprocess.run([G,ss],cwd=z,check=True,timeout=25)
x=D/'in';x.mkdir(exist_ok=True)
cohort=[]
for i,f in enumerate(sorted((z/'in').glob('*.txt'))):
 raw=f.read_bytes()
 a=raw.decode().splitlines()
 n=int(a[0]);m=int(a[n+1])
 if m<8:continue
 v=subprocess.run([S],input=raw,capture_output=True,check=True,timeout=1)
 if int(v.stdout)!=2:continue
 q=x/f'{len(cohort):04}.txt'
 if q.exists(): assert q.read_bytes()==raw
 else:q.write_bytes(raw)
 cohort.append(dict(selected=q.name,index=i,seed=seeds[i],sha=sha(raw),m=m,n=n,original_map=2))
 if len(cohort)==N:break
assert len(cohort)==N and len(set(k['sha']for k in cohort))==N
(D/'manifest.json').write_text(json.dumps(dict(namespace=namespace,n=N,
 generator_sha=sha(G.read_bytes()),selector_sha=sha(S.read_bytes()),
 seedlist_sha=sha(ss.read_bytes()),cases=cohort),indent=2)+'\n')
print(N,cohort[-1]['index'],sha((D/'manifest.json').read_bytes()))
