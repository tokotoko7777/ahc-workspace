# Preregistered fixed-work check
Only Normal-retention degree 1–4 draws change implementation. Accepted
if every 300-command byte stream and official score stays identical after
replacing the clock-controlled number of late simulation pairs with the
previously recorded count, and each of the practice and independent held
100 panels has at least 0.75% reduction of total solver CPU measured via
wait4 in alternating pair order. Compare no-rollout subsets separately;
a live score change is neither a success condition nor a speed signal.
If practice fails the threshold, stop without using the held panel for
selection. One million exact draw/rejection/reproducibility checks and
all relevant multiply/acceptance boundaries pass before official runs.
