"""Frozen exact-passive C++ -> equivalent <=4 neighbor RNG in retention."""
import hashlib
from pathlib import Path

d = Path(__file__).resolve().parent
source = (d.parent / 'ahc008_terry_passive_exact_short/live.private.cpp').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == '08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
def edit(a,b):
    global source
    assert source.count(a) == 1, a
    source = source.replace(a,b)
pragma = '#pragma GCC optimize("O3")'
edit(pragma, pragma+'\n'+(d/'choose.hpp').read_text().replace('#pragma once\n',''))
a = 'p.pos=r.cells[choose_small(rng,r.degree)];'
edit(a,'p.pos=r.cells[choose_grid_degree([&]{return uint32_t(rng());},r.degree)];')
a = 'if(count)p.pos=choices[choose_small(rng,count)];'
edit(a,'if(count)p.pos=choices[choose_grid_degree([&]{return uint32_t(rng());},count)];')
(d/'solve.private.cpp').write_text(source)
