#pragma once
#include <cassert>
#include <cstdint>

// Match choose_small's inclusive acceptance rule, including its rejection
// for 1, 2 and 4. This is NOT modulo, pick-one-without-draw, or a faster
// but different rejection sampler.
template<class Next32>
inline int choose_grid_degree(Next32&& next, unsigned n) {
    assert(1 <= n && n <= 4);
    const uint32_t zone = 0x7fffffffU + (uint32_t(n == 3) << 30);
    for (;;) {
        const uint64_t v = uint64_t(next()) * n;
        if (uint32_t(v) <= zone) return int(v >> 32);
    }
}
