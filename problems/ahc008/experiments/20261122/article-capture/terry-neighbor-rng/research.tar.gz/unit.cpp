#include "choose.hpp"
#include <array>
#include <bit>
#include <cstdio>
#include <random>
#include <utility>

template<class Next>
std::pair<int,int> control(Next&& next, uint32_t n) {
    const uint32_t zone = (n << std::countl_zero(n))-1;
    for (int step=1;;++step) {
        const uint64_t v=uint64_t(next())*n;
        if(uint32_t(v)<=zone) return {int(v>>32),step};
    }
}

int main(){
    std::mt19937 aa(908771), bb(908771);
    for(int i=0;i<1000000;++i) {
        const unsigned n=1+(i&3);
        const auto [old,k]=control([&]{return aa();},n);
        int cnt=0;
        const int got=choose_grid_degree([&]{++cnt;return bb();},n);
        assert(old==got&&cnt==k);
    }
    assert(aa==bb);
    // Test first accepted sample boundaries around each point where the
    // multiply's high output or low acceptance can change.
    for (uint64_t n=1;n<=4;++n) {
        const uint64_t z=(uint32_t(n)<<std::countl_zero(uint32_t(n)))-1;
        for (uint64_t out=0;out<n;++out) {
            for (uint64_t boundary : {out*(1ULL<<32)/n,(out*(1ULL<<32)+z)/n}) {
                for (int delta=-3;delta<=3;++delta) {
                    const uint32_t a=uint32_t(boundary+delta);
                    int b=0,c=0;
                    const auto [old,k]=control([&]{return ++b==1?a:0U;},n);
                    const int got=choose_grid_degree([&]{return ++c==1?a:0U;},n);
                    assert(old==got&&b==c&&c==k);
                }
            }
        }
    }
    std::puts("Bound 1..4: all draws, rejection counts and boundary vectors agree");
}
