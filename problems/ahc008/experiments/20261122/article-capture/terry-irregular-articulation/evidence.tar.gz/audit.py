"""Single non-designated articulation closure on exact old Normal tapes."""
import collections,csv,hashlib,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_gates'))
from screen import ALL,B,bitmask,cells,flat,flood,markers,near,observed,replay,wave
lanes=((8,21),(4,14,24),(4,11,18,25),(0,6,13,19,26),(4,11,18,25))
def irregular(mask):
    z=list(cells(mask)); rr=[x//30 for x in z];cc=[x%30 for x in z]
    return len(z)<(max(rr)-min(rr)+1)*(max(cc)-min(cc)+1)
def audit(row,layout):
    f=row['case'];mid=int(row['telemetry'].split()[0])
    x,doors=layout[mid]
    anchors=bitmask(r*30+c for r in range(30) for c in lanes[mid])
    landmarks=x|bitmask(doors)|anchors
    raw=(R/'ahc008_focus_assets/tools/in'/f).read_bytes()
    hp=R/'ahc008_terry_scaffold_audit/tapes'/f
    a=hp.with_suffix('.actions').read_bytes()
    tr=hp.with_suffix('.trace').read_text().splitlines();acts=a.decode().splitlines()
    assert hashlib.sha256(raw).hexdigest()==row['input_sha']
    assert hashlib.sha256(a).hexdigest()==row['commands_sha']
    assert replay(raw.decode(),tr,acts,detailed=True)[0]==int(row['score'])
    kinds,hist,_=observed(raw,tr)
    state=[(list(map(flat,p)),list(map(flat,h)),bitmask(map(flat,w))) for p,h,w in hist]
    caught={i:(t,s) for t,i,k,s in (map(int,e.split(':')) for e in row['captures'].split(';') if e)}
    lp,lh,lw=state[-1]; lhum=flood(bitmask(lh),ALL^lw)
    residual={i for i,p in enumerate(lp) if B[p]&lhum}
    later={}
    for pos in lp:
        if B[pos]&lhum:continue
        comp=flood(B[pos],ALL^lw)
        ids=frozenset(i for i,q in enumerate(lp) if B[q]&comp)
        groups={caught.get(i) for i in ids}
        if None in groups or len(groups)!=1:continue
        tm,sz=next(iter(groups))
        cp,_,cw=state[tm]
        rc=flood(B[cp[min(ids)]],ALL^cw)
        if ids!=frozenset(i for i,p in enumerate(cp) if B[p]&rc):continue
        later[ids]=(tm,comp.bit_count())
    stat=collections.Counter();witness=[];all_caught=set();missed=set();gainmax={}
    for t in range(110,226):
        p,h,w=state[t];_,ah,aw=state[t+1]; stock=acts[t]
        am=bitmask(p); hm=bitmask(h); ahm=bitmask(ah)
        old=flood(hm,ALL^w); oldstock=flood(ahm,ALL^aw)
        protected=old&anchors
        oldids={i for i,q in enumerate(p) if B[q]&old and not B[q]&oldstock}
        ban=w|landmarks|hm|am|wave(am)|aw|ahm
        opts={}
        for i,k in enumerate(stock):
            if k!='.':continue
            for d in 'URDL':
                q=near(h[i],d)
                if q is not None and not B[q]&ban:
                    opts.setdefault(q,(i,d.lower()))
        for q,(i,cmd) in opts.items():
            stat['legal_nonmarker_candidates']+=1
            # First require a real articulation at this instant, independently
            # of all other simultaneously issued constructions.
            cut=flood(hm,ALL^(w|B[q]))
            lost=old&~cut&am
            if not lost:continue
            stat['immediate_articulation_reaches_pet']+=1
            nallowed=ALL^(aw|B[q])
            nh=flood(B[ah[0]],nallowed)
            if nh.bit_count()<300 or ahm&~nh or protected&~nh:continue
            if any(B[p[j]]&nh for j in oldids):continue
            while lost:
                ch=flood(lost&-lost,nallowed)
                lost&=~ch
                if ch&nh or not 2<=ch.bit_count()<=9:continue
                if not irregular(ch):continue
                ids={j for j,v in enumerate(p) if B[v]&ch and B[v]&old and j not in oldids}
                if not ids:continue
                all_caught.update(ids);missed.update(ids&residual)
                stat['candidate_closure_events']+=1
                gs=[]
                for group,(tm,sz) in later.items():
                    if group<=ids and t+1<tm and sz>ch.bit_count():
                        lg=sz-ch.bit_count();gainmax[group]=max(lg,gainmax.get(group,0))
                        gs.append((sorted(group),lg))
                witness.append(dict(t=t,wall=q,actor=i,command=cmd,pen=ch.bit_count(),area=nh.bit_count(),
                                    ids=sorted(ids),otherwise_remaining=sorted(ids&residual),savings=gs,
                                    kinds={j:kinds[j] for j in sorted(ids)}))
    stat['unique_ids']=len(all_caught)
    stat['unique_residual_ids']=len(missed)
    stat['unique_later_caught_ids']=len(all_caught-missed)
    stat['total_floor_hint']=sum(gainmax.values())
    return dict(case=f,stats=stat,witnesses=witness)
def main():
    out=[];tot=collections.Counter();layout=markers()
    for row in csv.DictReader((R/'ahc008_terry_exact_root/practice100.csv').open()):
        if row['arm']!='terry_independent':continue
        r=audit(row,layout);tot.update(r['stats']);out.append(r)
    assert len(out)==100
    print(json.dumps(dict(boards=len(out),total=tot,boards_positive=collections.Counter(
      k for r in out for k,v in r['stats'].items() if v),cases=out),indent=2))
if __name__=='__main__':main()
