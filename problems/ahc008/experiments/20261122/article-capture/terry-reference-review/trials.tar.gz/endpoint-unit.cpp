#include "route_makespan.hpp"
#include <cassert>
#include <random>
#include <functional>
using namespace route_makespan;
int main(){
 std::vector<Cost> w{1,1,1,1},step{2,2,2,0};
 std::vector<std::vector<Cost>> enter{{0,2,4,6},{2,0,2,4}};
 // Both intervals prefer their right endpoint. Mirroring the workers
 // creates the mixed-direction optimum, impossible with a global flip.
 enter={{0,2,4,6},{6,4,2,0}};
 auto z=solve_both(w,step,enter);
 assert(z.makespan==4&&z.segments.size()==2);
 assert(z.segments[0].worker==0&&!z.segments[0].reversed);
 assert(z.segments[1].worker==1&&z.segments[1].reversed);
 assert(solve(w,step,enter).makespan>z.makespan);
 std::vector<Cost> w2{1,1},s2{2,0};
 auto e=solve_both(w2,s2,{{0,2}},{{0,5}});
 assert(e.makespan==6&&e.segments[0].reversed);
 assert(solve_both(w2,s2,{{0,2}},{{0,5}},6).segments.empty());
 std::mt19937 rng(84572);
 for(int rep=0;rep<400;rep++){
  int m=1+rng()%4,n=1+rng()%8;
  std::vector<Cost> p(n),ww(n),ss(n);
  for(int i=0;i<n;i++){ww[i]=rng()%5;if(i)p[i]=p[i-1]+1+rng()%5,ss[i-1]=p[i]-p[i-1];}
  std::vector<std::vector<Cost>> a(m,std::vector<Cost>(n)),b=a;
  for(int h=0;h<m;h++)for(int i=0;i<n;i++)a[h][i]=rng()%20,b[h][i]=rng()%20;
  Cost opt=100000;
  auto rec=[&](auto&& self,int mask,int l,Cost old)->void{
   if(l==n){opt=std::min(opt,old);return;}
   if(old>=opt)return;
   for(int h=0;h<m;h++)if(!(mask>>h&1)){
    Cost work=0;
    for(int r=l;r<n;r++){
     work+=ww[r];
     Cost x=work+p[r]-p[l]+std::min(a[h][l]+b[h][r],a[h][r]+b[h][l]);
     self(self,mask|1<<h,r+1,std::max(old,x));
    }
   }
  };rec(rec,0,0,0);
  auto q=solve_both(ww,ss,a,b);
  assert(q.makespan==opt);
  int at=0,used=0;Cost span=0;
  for(auto [h,l,r,rev]:q.segments){
   assert((used>>h&1)==0&&at==l&&l<r);used|=1<<h;at=r;
   Cost work=0;for(int i=l;i<r;i++)work+=ww[i];
   span=std::max(span,work+p[r-1]-p[l]+a[h][rev?r-1:l]+b[h][rev?l:r-1]);
  }
  assert(at==n&&span==opt);
 }
}
