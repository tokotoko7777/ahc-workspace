"""Keep TERRY's narrow-geometry front end and restore the exact v7 rescue option."""
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
a='''   bankRelease=300;rescueMode=0;
   return;'''
assert s.count(a)==1
s=s.replace(a,'''   bankRelease=225;rescueMode=1;
   return;''')
a='''  if(auto selected=terryLate(ready,service)){
   integratedMode[turn]=6;
   return *selected;
  }'''
assert s.count(a)==1
s=s.replace(a,a+'''
  // Keep the previously verified last-stage fallback. At t275 the
  // article decision above can still choose the new cut before this.
  if(turn>=180&&rem>0&&rem<=2&&!overBudget()){
   vector<lastcap::Pet> alive;
   for(auto p:pets)alive.push_back({p.p,p.t});
   lastcap::Board roads{},retreat{};
   int principal=group[humans.front()];
   for(int c=0;c<=bankN;c++)for(int r=0;r<S;r++){
    int p=bp(r,bankShift+7*c);
    if(group[p]==principal)roads[p]=1;
   }
   for(int r:{0,29})for(int c=bankShift;c<=bankShift+7*bankN;c++)
    if(group[bp(r,c)]==principal)roads[bp(r,c)]=1;
   retreat[humans.front()]=1;
   if(auto q=finalCapture.plan(turn,wall,humans,alive,roads,retreat)){
    integratedMode[turn]=finalCapture.protectionTier==1?3:5;
    return *q;
   }
  }
  if(turn>=bankRelease){integratedMode[turn]=4;dogPhase=9;return plan();}
''')
Path(sys.argv[2]).write_text(s)
