"""One C++ ablation from the authorized source: dynamic lane slots/nearest point."""
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:200]
    s=s.replace(a,b)
a=s.index(' Relay handoff(int turn,const vector<int>& crew,const Mask& walls,')
b=s.index(' vector<int> relayTarget,relayLane;',a)
s=s[:a]+''' Mask cachedHandoffWalls;
 std::unordered_map<int,array<short,V>> cachedDistances;
 // Allocate one slot per worker across real lanes (center-first extras),
 // and re-evaluate bottleneck availability every active turn. Choose a
 // reachable lane point, never a hardcoded row.
 Relay handoff(int turn,const vector<int>& crew,const Mask& walls,const Mask& reserved,
      const vector<vector<int>>& roads,const Mask& ineligible){
  if(!valid||roads.empty())return {};
  const int m=crew.size(),n=roads.size();
  if(m<n)return {};
  const Mask future=walls|reserved|planned;
  if(future!=cachedHandoffWalls){
   cachedHandoffWalls=future;cachedDistances.clear();
  }
  auto dist0=[&](int from,int to){
   auto it=cachedDistances.find(from);
   if(it==cachedDistances.end()){
    Nav nav;nav.run(from,future);
    it=cachedDistances.emplace(from,nav.d).first;
   }
   return int(it->second[to]);
  };
  vector<int> order(n);std::iota(order.begin(),order.end(),0);
  std::stable_sort(order.begin(),order.end(),[&](int a,int b){
   return std::abs(2*a-n+1)<std::abs(2*b-n+1);
  });
  vector<int> slots;
  for(int j=0;j<m;j++)slots.push_back(order[j%n]);
  vector<vector<int>> cost(m,vector<int>(m,INF)),goal(m,vector<int>(m,-1));
  for(int i=0;i<m;i++)if(!ineligible[i]){
   int finish=crew[i],remain=0;bool bad=false;
   if(inConstruction(turn))for(int k=cursor[i];k<int(schedule[i].size());k++){
    const auto& q=schedule[i][k];int jobs=0;
    for(int p:q.walls)jobs+=!walls[p]&&!reserved[p];
    if(!jobs)continue;
    int d=dist0(finish,q.from);
    if(d<0){bad=true;break;}
    remain+=d+jobs;finish=q.from;
   }
   if(bad)continue;
   Mask mask=future|body;
   for(const auto& t:tubes)
    if(std::find(t.body.begin(),t.body.end(),finish)!=t.body.end()){
     for(int p:t.body)if(!future[p])mask.reset(p);
     break;
    }
   Nav nav;nav.run(finish,mask);
   vector<int> best(n,-1);
   for(int l=0;l<n;l++)for(int p:roads[l])
    if(!future[p]&&nav.d[p]>=0&&(best[l]<0||nav.d[p]<nav.d[best[l]]))
     best[l]=p;
   for(int j=0;j<m;j++)if(best[slots[j]]>=0){
    goal[j][i]=best[slots[j]];
    cost[j][i]=remain+nav.d[goal[j][i]];
   }
  }
  const auto match=bottleneck(cost);
  if(match.eta<0)return match;
  if(!relayed){relayed=true;relayTurn=turn;}
  relayCost=match.eta;
  relayArrival.resize(n,-1);
  relayTarget.assign(m,-1);relayLane.assign(m,-1);
  for(int j=0;j<m;j++){
   int i=match.actor[j];relayTarget[i]=goal[j][i];relayLane[i]=slots[j];
  }
  return match;
 }
'''+s[b:]
rep('if(from==to){relayTarget[i]=-1;relayArrival[l]=turn;continue;}',
    'if(from==to){relayTarget[i]=-1;if(relayArrival[l]<0)relayArrival[l]=turn;continue;}')
rep('''    vector<terry_build::Road> roads;
    for(int i=0;i<int(terryRoads.size());i++)if(!wall[terryRoads[i]])roads.push_back({i,terryRoads[i]});
    terryBuild.handoff(turn,humans,walls,build,roads,{});''','''    vector<vector<int>> roads;
    for(int p:terryRoads){
     vector<int> line;
     for(int a=0;a<S;a++)line.push_back(bankRot?pos(p/S,a):pos(a,p%S));
     roads.push_back(std::move(line));
    }
    terryBuild.handoff(turn,humans,walls,build,roads,{});''')
rep('terryBuild.relay(turn,humans,walls,build,moveTo,usedPeople,act,70);',
    'terryBuild.relay(turn,humans,walls,build,moveTo,usedPeople,act,133);')
Path(sys.argv[2]).write_text(s)
