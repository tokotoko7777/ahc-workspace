"""Use spare humans to take existing solo entrances, without preempting pairs."""
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
p=' void parkUnassigned(const vector<int>& ready,const array<BankPath,10>& paths,bitset<V> usedPeople,'
assert s.count(p)==1
s=s.replace(p,''' long long soloDispatch=0;
 void steerSolo(const array<BankPath,10>& paths,bitset<V>& used,const bitset<V>& build,bitset<V>& moveTo){
  struct Offer{int v,actor,ix,step;};
  vector<Offer> choices;
  for(int ix=0;ix<int(soloShapes.size());ix++){
   const auto& x=soloShapes[ix];const int g=x.gate;
   if(wall[g]||build[g]||any_of(x.braces.begin(),x.braces.end(),[&](int p){return !wall[p];})||
    any_of(x.body.begin(),x.body.end(),[&](int p){return wall[p]||build[p];}))continue;
   int heads=0;
   for(auto p:pets)heads+=find(x.body.begin(),x.body.end(),p.p)!=x.body.end();
   if(!heads)continue;
   for(int i=0;i<int(humans.size());i++)if(!used[i]){
    int best=5,step=-1;
    for(int p:nb[g])if(p>=0&&find(x.body.begin(),x.body.end(),p)==x.body.end()){
     int d=paths[i].d[p],hop=paths[i].step[p];
     if(d>=0&&d<best&&(d==0||(hop>=0&&!build[hop]&&hop!=g))){
      best=d;step=hop;
     }
    }
    if(best<5)choices.push_back({100*heads/(1+best),i,ix,step});
   }
  }
  sort(choices.begin(),choices.end(),[](auto a,auto b){
   if(a.v!=b.v)return a.v>b.v;
   return tie(a.ix,a.actor)<tie(b.ix,b.actor);
  });
  vector<bool> assigned(soloShapes.size());
  for(auto v:choices)if(!used[v.actor]&&!assigned[v.ix]){
   used[v.actor]=true;assigned[v.ix]=true;++soloDispatch;
   if(v.step>=0){
    act[v.actor]=MOVE[dir(humans[v.actor],v.step)];
    moveTo[v.step]=true;
   }
  }
 }
''' + p)
a='   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);'
assert s.count(a)==1
s=s.replace(a,'   steerSolo(paths,usedPeople,build,moveTo);\n'+a)
a='<<g.soloCloses<<" "<<g.soloHeads<<'
assert s.count(a)==1
s=s.replace(a,'<<g.soloCloses<<" "<<g.soloHeads<<" "<<g.soloDispatch<<')
Path(sys.argv[2]).write_text(s)
