"""Reclaim genuine single-gate exact 1x4s already present in the adapted map."""
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' int terryMap=-1, terryRotation=0;',''' int terryMap=-1, terryRotation=0;
 struct Solo4{array<int,4> body;vector<int> braces;int gate;};
 vector<Solo4> soloShapes;
 long long soloReadyTurns=0,soloLegalTurns=0,soloCloses=0,soloHeads=0;
 void makeSoloShapes(const bitset<V>& planned){
  for(int p=0;p<V;p++)for(int dir:{1,3}){
   array<int,4> body{};body[0]=p;bool good=!planned[p];
   for(int i=1;i<4&&good;i++){
    body[i]=nb[body[i-1]][dir];
    good=body[i]>=0&&!planned[body[i]];
   }
   if(!good)continue;
   vector<int> braces;int gate=-1;
   for(int p:body)for(int q:nb[p])if(q>=0&&find(body.begin(),body.end(),q)==body.end()){
    if(planned[q])braces.push_back(q);
    else if(gate>=0&&gate!=q)good=false;
    else gate=q;
   }
   if(good&&gate>=0&&any_of(nb[gate].begin(),nb[gate].end(),[&](int q){
    return q>=0&&!planned[q]&&find(body.begin(),body.end(),q)==body.end();
   }))soloShapes.push_back({body,std::move(braces),gate});
  }
 }
 void soloImmediate(bitset<V>& build,const bitset<V>& moveTo,bitset<V>& used){
  struct Job{int ix,heads;};
  vector<Job> jobs;
  for(int ix=0;ix<int(soloShapes.size());ix++){
   const auto& x=soloShapes[ix];int g=x.gate;
   if(wall[g]||build[g]||any_of(x.braces.begin(),x.braces.end(),[&](int p){return !wall[p];}))continue;
   if(any_of(x.body.begin(),x.body.end(),[&](int p){return wall[p]||build[p]||moveTo[p];}))continue;
   ++soloReadyTurns;
   if(block[g]||moveTo[g]||any_of(humans.begin(),humans.end(),[&](int p){
    return find(x.body.begin(),x.body.end(),p)!=x.body.end();
   }))continue;
   int n=0;
   for(auto a:pets)n+=find(x.body.begin(),x.body.end(),a.p)!=x.body.end();
   if(!n)continue;
   ++soloLegalTurns;
   jobs.push_back({ix,n});
  }
  sort(jobs.begin(),jobs.end(),[](Job a,Job b){return tie(a.heads,b.ix)>tie(b.heads,a.ix);});
  for(auto j:jobs){
   const auto& x=soloShapes[j.ix];int g=x.gate;
   if(build[g])continue;
   int a=-1;
   for(int i=0;i<int(humans.size());i++)if(!used[i]&&dir(humans[i],g)>=0){a=i;break;}
   if(a<0)continue;
   lastcap::Board can{};
   for(int p=0;p<V;p++)can[p]=!wall[p]&&!build[p]&&p!=g;
   lastcap::BFS nav;
   if(nav.run(humans[0],can)<300||any_of(humans.begin(),humans.end(),[&](int h){
    return nav.d[h]<0;
   }))continue;
   act[a]=BUILD[dir(humans[a],g)];build[g]=true;used[a]=true;
   ++soloCloses;soloHeads+=j.heads;
  }
 }''')
rep('  terryBuild.initialize(install,humans,{},133,map.walls);','  makeSoloShapes(map.walls);\n  terryBuild.initialize(install,humans,{},133,map.walls);')
rep('  const bool scheduled=turn>=35&&*max_element(local.begin(),local.end())>=5;','  soloImmediate(build,moveTo,usedPeople);\n  const bool scheduled=turn>=35&&*max_element(local.begin(),local.end())>=5;')
rep(' if(const char* p=getenv("AHC008_TERRY_LOG")){',''' if(const char* p=getenv("AHC008_TERRY_SOLO_LOG")){
  ofstream f(p);
  f<<g.soloShapes.size()<<" "<<g.soloReadyTurns<<" "<<g.soloLegalTurns<<" "<<g.soloCloses<<" "<<g.soloHeads<<'\\n';
 }
 if(const char* p=getenv("AHC008_TERRY_LOG")){''')
Path(sys.argv[2]).write_text(s)
