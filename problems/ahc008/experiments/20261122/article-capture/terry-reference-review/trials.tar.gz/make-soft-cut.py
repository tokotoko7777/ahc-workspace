"""Replace just local hard-core search with the clean-room prize cut."""
from pathlib import Path
import sys
p=Path(__file__).resolve().parent
s=Path(sys.argv[1]).read_text()
frag='\n'.join(x for x in (p/'softcut.hpp').read_text().splitlines() if x!='#pragma once' and not x.startswith('#include "'))
head=s.index('namespace terryend {')
end=s.index('namespace terry_mc {',head)
m=s[head:end]
a=' Shape active; Board retreat{};'
assert m.count(a)==1
m=m.replace(a,a+'''
 Shape fullPrize(int turn,const Board& wall,const Board& main,int size,const std::vector<int>& humans,
                 const std::vector<Pet>& pets,const Board& aisle,const Board& protectedRoads);
''')
before='  retreat=protectedNow;'
assert m.count(before)==1
k=m.index(before)+len(before)
stop=m.index('  return best;\n }',k)+len('  return best;')
m=m[:k]+'''
  return fullPrize(turn,wall,main,size,humans,pets,protect,protectedNow);
'''+m[stop:]
impl='''
terryend::Planner::Shape terryend::Planner::fullPrize(int turn,const terryend::Board& wall,
 const terryend::Board& main,int size,const std::vector<int>& humans,const std::vector<terryend::Pet>& pets,
 const terryend::Board& aisle,const terryend::Board& protectedRoads){
 return softcut::search(*this,turn,wall,main,size,humans,pets,aisle,protectedRoads);
}
'''
s=s[:head]+m+frag+'\n'+impl+s[end:]
a='   for(int q:terryRoads)if(!wall[q])protect[q]'
assert s.count(a)==2
s=s.replace(a,'   for(int q:terryRoads)for(int a=0;a<S;a++)\n    if(int p=bankRot?pos(q/S,a):pos(a,q%S); !wall[p])protect[p]')
Path(sys.argv[2]).write_text(s)
