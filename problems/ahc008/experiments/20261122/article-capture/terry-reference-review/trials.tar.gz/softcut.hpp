#pragma once
#include <cmath>
#include "../ahc008_terry_endgame/terry_endgame.hpp"
namespace softcut {
using terryend::Board;using terryend::Pet;using terryend::BFS;using terryend::Planner;
using terryend::V;using terryend::INF;using terryend::neighbors;using terryend::dist1;
struct Options{
 int wallCost=5, core=2, aisleCost=1;
 // Zero means use ceil(count of weighted services / reachable animals).
 std::vector<int> prizes{0,12,24};
};
inline Planner::Shape search(const Planner& owner,int turn,const Board& wall,
 const Board& main,int size,const std::vector<int>& humans,
 const std::vector<Pet>& pets,const Board& aisle,const Board& retreat,
 const Options& opts={}){
 Planner::Shape best;
 if(humans.empty())return best;
 const int h=std::min({300-turn,owner.cfg.maxAttempt,owner.cfg.maxTotal-owner.total});
 if(h<1)return best;
 const Board open=Planner::walkable(wall);
 const Board blocked=Planner::occupied(humans,pets);
 Board hard=retreat;
 for(int p:humans)hard[p]=1;
 std::vector<int> ap;
 for(auto p:pets)if(main[p.p])ap.push_back(p.p);
 if(ap.empty())return best;
 std::vector<BFS> ds(humans.size());
 std::array<int,V> eta;eta.fill(INF);
 for(size_t j=0;j<humans.size();++j)ds[j].run(humans[j],open);
 for(int p=0;p<V;++p)if(main[p])for(int q:neighbors(p))if(q>=0&&main[q])
  for(auto& d:ds)if(d.d[q]>=0)eta[p]=std::min(eta[p],d.d[q]);
 Board isPet{}, soft{};
 for(int p:ap)isPet[p]=1;
 int services=0;
 for(int p=0;p<V;++p)if(main[p]&&aisle[p]){
  bool far=true;
  for(int a:ap)far&=dist1(p,a)>1;
  if(far){soft[p]=1;services+=opts.aisleCost;}
 }
 std::vector<std::vector<int>> cores(ap.size());
 for(size_t j=0;j<ap.size();++j){
  BFS q;q.run(ap[j],open);
  for(int p=0;p<V;++p)if(main[p]&&q.d[p]>=0&&q.d[p]<=opts.core)cores[j].push_back(p);
 }
 const int base=2*V, source=base+ap.size(),sink=source+1;
 std::vector<int> tried;
 for(int prize:opts.prizes){
  if(!prize)prize=std::max(1,(services+int(ap.size())-1)/int(ap.size()));
  if(prize<1||std::find(tried.begin(),tried.end(),prize)!=tried.end())continue;
  tried.push_back(prize);
  terryend::Flow g(sink+1);
  for(int p=0;p<V;++p)if(main[p]){
   const int cap=isPet[p]||hard[p]||eta[p]+1>h||(h==1&&blocked[p])?INF:opts.wallCost;
   g.add(2*p,2*p+1,cap);
   if(hard[p])g.add(source,2*p,INF);
   if(soft[p])g.add(source,2*p,opts.aisleCost);
   for(int q:neighbors(p))if(q>=0&&main[q])g.add(2*p+1,2*q,INF);
  }
  for(int j=0;j<(int)ap.size();++j){
   for(int p:cores[j])g.add(2*p+1,base+j,INF);
   g.add(base+j,sink,prize);
  }
  if(g.maxflow(source,sink)>=INF)continue;
  Planner::Shape z;
  for(int p=0;p<V;++p)if(main[p]&&g.d[2*p]>=0&&g.d[2*p+1]<0)z.cut.push_back(p);
  if(z.cut.empty()||int(z.cut.size())>owner.cfg.maxWalls||!Planner::certify(z,wall,humans,pets,main))continue;
  if(z.kept<std::min(size,owner.cfg.minArea))continue;
  bool keepRetreat=true;
  for(int p=0;p<V;++p)if(main[p]&&retreat[p]&&!z.can[p])keepRetreat=false;
  if(!keepRetreat)continue;
  for(size_t i=0;i<humans.size();++i)ds[i].run(humans[i],z.can);
  int far=0,total=0,blockedN=0;
  for(int p:z.cut){
   int near=INF;
   for(int q:neighbors(p))if(q>=0&&z.can[q])for(auto& d:ds)
    if(d.d[q]>=0)near=std::min(near,d.d[q]);
   far=std::max(far,near);total+=near;blockedN+=blocked[p];
  }
  const int dur=far+int((z.cut.size()+humans.size()-1)/humans.size())+blockedN/2;
  if(dur>h)continue;
  z.cost=dur;
  // Absolute official-score gain in units of the original group's 2^-N.
  const double delta=std::ldexp(double(z.kept),z.trapped)-size;
  if(delta<=0)continue;
  z.value=delta/(1.+.045*dur+.034*z.cut.size()+.012*total);
  if(z.value>best.value)best=std::move(z);
 }
 return best;
}
}
