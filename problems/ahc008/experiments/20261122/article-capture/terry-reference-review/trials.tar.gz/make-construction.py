"""Article-source ablation: explicit installation FIFO before scheduled capture."""
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:150]
 s=s.replace(a,b)
rep('''    bool usable=false;
    for(int p:o.walls)if(!walls[p]&&!reserved[p]&&!moveTo[p]&&canBuild(p))usable=true;
    if(!usable){
     for(int p:o.walls)if(!walls[p]&&!reserved[p])++skipped;
     ++j;continue;
    }''',
'''    bool pending=false;
    for(int p:o.walls)pending|=!walls[p]&&!reserved[p];
    if(!pending){++j;continue;}''')
rep('''    if(paid[i])break;
    ++j;''','''    // At the scheduled stance, wait legally when an animal blocks the
    // pending walls; the task survives to the next observed turn.
    if(!paid[i])paid[i]=true;
    break;''')
rep('''  // Current observed legal walls still take priority over predicted jobs.''',
'''  // Make committed construction actions (including waiting at a blocked
  // stance) before considering either immediate or forecasted rail jobs.
  bitset<V> walls;
  for(int p=0;p<V;p++)walls[p]=wall[p]!=0;
  terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});
  // For remaining workers observed legal walls precede predicted jobs.''')
rep('''  bitset<V> walls;
  for(int p=0;p<V;p++)walls[p]=wall[p]!=0;
  if(turn<133){''','''  if(turn<133){''')
rep('''   terryBuild.relay(turn,humans,walls,build,moveTo,usedPeople,act,70);
   terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});''',
'''   terryBuild.relay(turn,humans,walls,build,moveTo,usedPeople,act,70);''')
Path(sys.argv[2]).write_text(s)
