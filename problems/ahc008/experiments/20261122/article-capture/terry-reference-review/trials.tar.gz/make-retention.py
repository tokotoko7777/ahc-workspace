"""Evaluate room retention rather than predicted simultaneous gate legality."""
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
key="    const auto pathsMC=terry_mc::sample_paths(mcState(),terrySim,64,maxEta,&prior);"
assert s.count(key)==1
point='      auto p=terry_mc::capture_window(pathsMC,terrySim,x.g,x.k,x.inner,h);'
assert s.count(point)==1
s=s.replace(point,'''      // Source-guided ablation: score occupancy by animals already in
      // this room, not stochastic legality at their eventual ETA. A room
      // includes the virtual door cells when predicting retention.
      terry_mc::Window p;
      bitset<V> room;room[x.g]=room[x.k]=true;
      for(int q:x.inner)room[q]=true;
      for(int k=0;k<pathsMC.trials;k++){
       int hit=0;
       const auto& before=pathsMC.at(k,0);
       const auto& after=pathsMC.at(k,h);
       for(int j=0;j<pathsMC.n;j++)hit+=room[before[j]]&&room[after[j]];
       p.expected+=hit;p.any+=hit>0;
      }
      p.expected/=pathsMC.trials;p.any/=pathsMC.trials;''')
Path(sys.argv[2]).write_text(s)
