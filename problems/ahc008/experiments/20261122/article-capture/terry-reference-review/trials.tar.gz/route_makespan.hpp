#pragma once
#include <algorithm>
#include <bit>
#include <cstdint>
#include <limits>
#include <span>
#include <stdexcept>
#include <vector>

namespace route_makespan {
using Cost = std::int64_t;
struct Segment { int worker, first, last; }; // [first,last)
struct Plan { Cost makespan; std::vector<Segment> segments; };

// A fixed directed walk visits every task in order. travel[h][l] is the
// time for worker h to reach the stand for task l before construction.
// Require travel[h][l+1] <= travel[h][l] + next[l], e.g. distances in
// the same open graph in which the prescribed walk is valid. Then a worker
// who could cover [l,r) can start at any later available prefix <=r
// without finishing later, so one furthest reachable prefix per mask suffices.
// No waiting, blocking pets, or dynamic walls are modeled.
inline Plan solve(std::span<const Cost> work, std::span<const Cost> next,
                  const std::vector<std::vector<Cost>>& travel) {
    constexpr auto inf = std::numeric_limits<Cost>::max() / 8;
    int n = static_cast<int>(work.size()), m = static_cast<int>(travel.size());
    if (n == 0) return {0, {}};
    if (next.size()!=work.size() || m<=0 || m>20) throw std::invalid_argument("invalid dimensions");
    std::vector<Cost> before(n+1), through(n);
    for (int j=0;j<n;++j) {
        if (work[j]<0 || next[j]<0 || work[j]>=inf || next[j]>=inf || before[j]>=inf)
            throw std::invalid_argument("invalid or overflowing walk cost");
        through[j]=before[j]+work[j];
        before[j+1]=through[j]+next[j];
    }
    for (const auto& row:travel) {
        if (static_cast<int>(row.size())!=n) throw std::invalid_argument("bad approach size");
        for (int j=0;j<n;++j) {
            if (row[j]<0 || row[j]>=inf ||
                (j && row[j]>row[j-1]+next[j-1]))
                throw std::invalid_argument("approach violates route triangle bound");
        }
    }
    const int states=1<<m;
    auto reachable = [&](Cost budget, bool rebuild) -> std::vector<Segment> {
        std::vector<std::vector<int>> advance(m, std::vector<int>(n));
        for (int h=0;h<m;++h) {
            // The right endpoint cannot decrease as l increases.
            int end=0;
            for (int l=0;l<n;++l) {
                end=std::max(end,l);
                while(end<n && through[end]-before[l]+travel[h][l]<=budget)++end;
                advance[h][l]=end;
            }
        }
        std::vector<int> far(states,-1), prev(states,-1);
        far[0]=0;
        for (int mask=0;mask<states;++mask) {
            if (far[mask]<0) continue;
            if (far[mask]==n) {
                if(!rebuild) return {{-1,0,n}};
                std::vector<Segment> plan;
                while(mask) {
                    int p=prev[mask];
                    plan.push_back({std::countr_zero(static_cast<unsigned>(p^mask)),far[p],far[mask]});
                    mask=p;
                }
                std::reverse(plan.begin(),plan.end());
                return plan;
            }
            const int l=far[mask];
            for (int h=0;h<m;++h) if(!(mask>>h&1)) {
                int nxt=mask|1<<h,r=advance[h][l];
                if (r>l && r>far[nxt]) { far[nxt]=r; prev[nxt]=mask; }
            }
        }
        return {};
    };
    Cost lo=-1, hi=inf+through.back();
    for (auto &row:travel) hi=std::min(hi,row[0]+through.back());
    while(hi-lo>1) {
        Cost mid=lo+(hi-lo)/2;
        if(reachable(mid,false).empty())lo=mid;else hi=mid;
    }
    return {hi,reachable(hi,true)};
}

struct OrientedSegment { int worker, first, last; bool reversed; };
struct OrientedPlan { Cost makespan; std::vector<OrientedSegment> segments; };

// Undirected walk. On an interval, reversed workers enter the right
// endpoint and exit the left; optional egress is charged at the exit.
inline OrientedPlan solve_both(std::span<const Cost> work, std::span<const Cost> next,
 const std::vector<std::vector<Cost>>& enter,
 const std::vector<std::vector<Cost>>& leave = {},
 Cost bound=std::numeric_limits<Cost>::max()/8) {
 constexpr Cost INF=std::numeric_limits<Cost>::max()/8;
 int n=work.size(),m=enter.size();
 if(!n)return {0,{}};
 if(m<1||m>10||next.size()!=work.size()||(!leave.empty()&&int(leave.size())!=m))
  throw std::invalid_argument("invalid oriented dimensions");
 for(auto& v:enter)if(int(v.size())!=n)throw std::invalid_argument("invalid approach size");
 for(auto& v:leave)if(int(v.size())!=n)throw std::invalid_argument("invalid egress size");
 std::vector<Cost> pre(n+1),finish(n);
 for(int i=0;i<n;i++) {
  if(work[i]<0||next[i]<0||work[i]>=INF||next[i]>=INF)
   throw std::invalid_argument("invalid oriented work");
  finish[i]=pre[i]+work[i];
  pre[i+1]=finish[i]+next[i];
  if(pre[i+1]>=INF)throw std::invalid_argument("oversize oriented work");
 }
 const auto exit_at=[&](int h,int p){return leave.empty()?0:leave[h][p];};
 const auto task=[&](int h,int l,int r,bool rev){
  const int a=rev?r:l,b=rev?l:r;
  const Cost x=enter[h][a],y=exit_at(h,b);
  return x<0||y<0||x>=INF||y>=INF?INF:finish[r]-pre[l]+x+y;
 };
 const int states=1<<m, width=n+1;
 struct Parent { int first=-1; unsigned char h=0; bool rev=false; };
 std::vector<Parent> par(states*width);
 std::vector<Cost> dp(states*width,INF);
 dp[0]=0;
 Cost best=bound;int final=-1;
 for(int set=0;set<states;set++)for(int l=0;l<n;l++){
  Cost prior=dp[set*width+l];
  if(prior>=best)continue;
  for(int h=0;h<m;h++)if(!(set>>h&1)){
   const int row=(set|1<<h)*width;
   for(int r=l;r<n&&finish[r]-pre[l]<best;r++){
    Cost f=task(h,l,r,false),b=task(h,l,r,true);
    const Cost z=std::max(prior,std::min(f,b));
    int id=row+r+1;
    if(z>=best||z>=dp[id])continue;
    dp[id]=z;par[id]={l,(unsigned char)h,b<f};
    if(r+1==n)best=z,final=set|1<<h;
   }
  }
 }
 if(final<0)return {INF,{}};
 std::vector<OrientedSegment> out;
 for(int r=n;r>0;){
  const auto x=par[final*width+r];
  out.push_back({x.h,x.first,r,x.rev});
  r=x.first;final^=1<<x.h;
 }
 std::reverse(out.begin(),out.end());
 return {best,out};
}
}
