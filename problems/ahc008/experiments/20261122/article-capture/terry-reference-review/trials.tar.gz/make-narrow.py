"""Controlled A/B: use exactly v7's layout with the entire TERRY runtime."""
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
point=''' void terryLayout(int force){
  terry_maps::Counts cnt{};'''
replacement=''' void terryLayout(int force){
  // Only the map in this diagnostic differs from the full integration.
  // The learned branch (force=-1) and its data are kept in the source,
  // but the treatment, force=5, uses the exact historical v7 geometry.
  if(force==5){
   terryMap=5;
   narrowRescue=true;
   makeBanks();
   vector<terry_build::Tube> install;
   bitset<V> plan;
   for(const auto& x:banks)
    install.push_back({x.b,x.r,x.l,x.h,x.inner,x.side,x.g,x.k});
   for(int p:bankWalls)plan[p]=true;
   for(int j=0;j<=bankN;j++)terryRoads.push_back(bp(15,bankShift+7*j));
   terryBuild.initialize(install,humans,{},133,plan);
   bankRelease=300;rescueMode=0;
   return;
  }
  terry_maps::Counts cnt{};'''
assert s.count(point)==1
s=s.replace(point,replacement)
point=' g.terryLayout(forced);'
assert s.count(point)==1
s=s.replace(point,' g.terryLayout(forced<0?5:forced);')
Path(sys.argv[2]).write_text(s)
