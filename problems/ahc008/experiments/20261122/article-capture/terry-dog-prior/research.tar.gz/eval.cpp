// Detached tape-only observer; never calls the included solver main or a policy.
#define main unused_first_chase_reuse_solver_main
#include "../ahc008_terry_first_chase_reuse/solve.private.cpp"
#undef main
#include <fstream>
#include <iomanip>
#include <sstream>
#include <map>

namespace dog_prior_audit {
using namespace terry_exact_root;
using Pair=std::array<double,2>; // uniform-ID and filtered
using Belief=std::array<double,11>; // sentinel, then person IDs
struct Row {
 int first[4]{};
 std::array<Pair,4> direction{};
 std::array<std::array<Pair,4>,4> sequence{};
 std::map<int,Pair> endpoint;
 Belief next{};
};
Row model(const State& s, int from, const Belief& prior,
          const std::vector<Dist>& dist, int actual1, int actual2){
 Row r; const int n=s.people.size();
 int count=0;
 double reset=prior[0];
 for(int i=0;i<n;++i){
  const int d=dist[i][from];
  if(d>0&&d<INF)++count;
  else reset+=prior[i+1];
 }
 int basic=0;
 for(int x:nb[from])if(x>=0&&!s.walls[x])++basic;
 assert(basic>0);
 if(!count){
  assert(actual2==-1);
  r.next[0]=1;
  for(int j=0;j<4;++j){
   int q=nb[from][j];if(q<0||s.walls[q])continue;
   r.endpoint[q]=r.direction[j]={1./basic,1./basic};
  }
  return r;
 }
 assert(actual1>=0&&actual2>=0);
 for(int i=0;i<n;++i){
  int d=dist[i][from];if(d<=0||d>=INF)continue;
  int first=0;
  for(int q:nb[from])if(q>=0&&dist[i][q]==d-1)++first;
  assert(first>0);
  Pair w{1./count/first,(prior[i+1]+reset/count)/first};
  for(int j=0;j<4;++j){
   const int q=nb[from][j];if(q<0||dist[i][q]!=d-1)continue;
   int second=0;
   for(int x:nb[q])if(x>=0&&!s.walls[x])++second;
   assert(second>0);
   for(int a=0;a<2;++a)r.direction[j][a]+=w[a];
   for(int k=0;k<4;++k){
    const int x=nb[q][k];if(x<0||s.walls[x])continue;
    for(int a=0;a<2;++a){ const double m=w[a]/second; r.endpoint[x][a]+=m; r.sequence[j][k][a]+=m; }
    if(j==actual1&&k==actual2){
     const int dest=(q==s.people[i]||x==s.people[i])?0:i+1;
     r.next[dest]+=w[1]; // dividing by the common second-step degree cancels
    }
   }
  }
 }
 for(int a=0;a<2;++a){double mass=0;for(const auto& e:r.endpoint)mass+=e.second[a];assert(std::abs(mass-1)<1e-9);}
 double z=0;for(double p:r.next)z+=p;
 assert(z>0);
 for(double& p:r.next)p/=z;
 return r;
}
struct Pen {int id,left,right; Mask safe, veto;};
std::vector<Pen> ready(const State& s,const terrain_lib::Rooms& room,const Mask& art) {
 Mask hm;
 for(int p:s.people)hm.set(p);
 std::vector<Pen> out;
 for(int id=0;id<room.count();++id){
  const auto& d=room.rooms[id];
  if(!d.size||(d.left<0&&d.right<0))continue;
  if(d.left>=0&&(s.walls[d.left]||art[d.left]||hm[d.left]||nb[d.left][3]<0))continue;
  if(d.right>=0&&(s.walls[d.right]||art[d.right]||hm[d.right]||nb[d.right][1]<0))continue;
  bool staff=false;
  for(int i=0;i<(int)s.people.size();++i)for(int j=0;j<(int)s.people.size();++j){
   if(d.left>=0&&s.people[i]!=nb[d.left][3])continue;
   if(d.right>=0&&s.people[j]!=nb[d.right][1])continue;
   if(d.left>=0&&d.right>=0&&i==j)continue;
   staff=true;
  }
  if(!staff)continue;
  bool person=false;for(int p:s.people)person|=room.ids[p]==id;
  if(person)continue;
  Pen q{id,d.left,d.right,{},{}};
  for(int p:{d.left,d.right})if(p>=0){
   q.veto.set(p); for(int z:nb[p])if(z>=0)q.veto.set(z);
  }
  for(int p=0;p<V;++p)if(!s.walls[p]&&room.ids[p]==id&&!q.veto[p])q.safe.set(p);
  if(q.safe.any())out.push_back(q);
 }
 return out;
}
int run(std::string id, int map, const char* input, const char* tape) {
 std::ifstream f(input), trace(tape);
 State s;
 int n,m;f>>n;
 s.pets.resize(n);std::vector<Belief> beliefs(n);
 std::vector<int> dogs;
 for(int j=0;j<n;++j){
  int r,c,x;f>>r>>c>>x; s.pets[j]={(r-1)*30+c-1,x,-1};
  if(x==4){dogs.push_back(j);beliefs[j][0]=1;}
 }
 f>>m;s.people.resize(m);
 for(int& p:s.people){int r,c;f>>r>>c;p=(r-1)*30+c-1;}
 assert(f && trace);
 const auto& terrain=terrain_lib::terrain(map);
 TopologyMemo topology;
 std::vector<Dist> dist(m);
 bool distances=false;
 Mask last_walls;std::vector<int> last_people;
 std::cout<<std::setprecision(16);
 for(int t=0;t<=274;++t){
  std::string commands,line;
  if(!std::getline(trace,commands)||!std::getline(trace,line))return 3;
  assert((int)commands.size()==m);
  people_step(s,commands);
  std::vector<std::string> moves(n);
  std::vector<int> end(n);
  std::istringstream ss(line);
  for(int i=0;i<n;++i){
   ss>>moves[i];assert(ss);
   int p=s.pets[i].pos;
   for(char c:moves[i]){ int d=move_dir(c);assert(d>=0);p=nb[p][d];assert(p>=0&&!s.walls[p]); }
   end[i]=p;
  }
  if(!dogs.empty()){
   const auto& room=topology.get(terrain,s.walls,s.walls,s.people);
   if(!distances||last_walls!=s.walls||last_people!=s.people){
    for(int i=0;i<m;++i){
     int k=0;while(k<i&&s.people[i]!=s.people[k])++k;
     if(k<i)dist[i]=dist[k];else bfs(s.walls,s.people[i],dist[i]);
    }
    last_walls=s.walls;last_people=s.people;distances=true;
   }
   auto pens=t>=200?ready(s,room,topology.arts(terrain,s.walls)):std::vector<Pen>{};
   for(int i:dogs){
    int p=s.pets[i].pos, x=move_dir(moves[i][0]), y=moves[i].size()==2?move_dir(moves[i][1]):-1;
    assert(x>=0&&moves[i].size()<=2);
    Row r=model(s,p,beliefs[i],dist,x,y);
    beliefs[i]=r.next;
    if(t<200||!room.participates[p])continue;
    const auto seq=y<0?r.direction[x]:r.sequence[x][y];
    const auto actual=r.endpoint.at(end[i]);Pair brier{1-2*actual[0],1-2*actual[1]};
    for(const auto& [unused,v]:r.endpoint)for(int j=0;j<2;++j)brier[j]+=v[j]*v[j];
    std::cout<<"dog,"<<id<<','<<t<<','<<i<<','<<(y<0);
    for(double z:{r.direction[x][0],r.direction[x][1],seq[0],seq[1],actual[0],actual[1],brier[0],brier[1]})std::cout<<','<<z;
    std::cout<<'\n';
    // For true geometric distance <=2 use the reachable endpoint histogram plus zero/one-step cells;
    // dog dynamics constrain probability but must not constrain cohort selection.
    Mask near; near.set(p);
    for(int a:nb[p])if(a>=0&&!s.walls[a]){
     near.set(a);for(int b:nb[a])if(b>=0&&!s.walls[b])near.set(b);
    }
    for(const auto& q:pens){
     const bool initial=room.ids[p]==q.id;
     if(!initial&&!(q.safe&near).any())continue;
     const bool hit=q.safe[end[i]], wasVeto=q.veto[p];
     bool others=true;for(int j=0;j<n;++j)if(i!=j)others&=!q.veto[end[j]];
     Pair probs{};
     for(const auto& [z,pp]:r.endpoint)if(q.safe[z])for(int j=0;j<2;++j)probs[j]+=pp[j];
     std::cout<<"pen,"<<id<<','<<t<<','<<i<<','<<q.id<<','<<initial<<','<<wasVeto<<','<<hit<<','<<others<<','<<probs[0]<<','<<probs[1]<<'\n';
    }
   }
  }
  for(int i=0;i<n;++i)s.pets[i].pos=end[i];
 }
 return 0;
}
}
int main(int argc,char** argv){
 if(argc!=5)return 2;
 return dog_prior_audit::run(argv[1],std::stoi(argv[2]),argv[3],argv[4]);
}
