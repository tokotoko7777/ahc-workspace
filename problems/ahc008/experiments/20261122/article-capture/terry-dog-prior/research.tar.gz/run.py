"""Verify frozen fixtures, feed the detached evaluator, summarize case clusters."""
import csv
import hashlib
import io
import json
import math
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

D=Path(__file__).resolve().parent
W=D.parent
T=W/'ahc008_terry_hunt_wall_audit'
I=W/'ahc008_terry_incoming_shadow'/'held100'
SOURCE=W/'ahc008_terry_first_chase_reuse'/'solve.private.cpp'
SHA='8f50dda74f578fc8ddbf8176d15172a80df96d23d82c57db8ae51aedce4294b7'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def penalty(p):
    return -math.log(max(1e-12,p))
def average(values):
    return sum(values)/len(values) if values else None
def pairs(rows):
    groups=defaultdict(list)
    for row in rows:
        groups[row[0]].append(row[1:])
    a=average([average([x[0] for x in r]) for r in groups.values()])
    b=average([average([x[1] for x in r]) for r in groups.values()])
    return dict(cases=len(groups),rows=len(rows),uniform=a,filtered=b,
                gain=(a-b if a is not None else None),
                wins=sum(sum(x[1] for x in r)<sum(x[0] for x in r) for r in groups.values()))

def main():
    exe=Path(sys.argv[1]).resolve()
    assert digest(SOURCE.read_bytes())==SHA
    meta=json.loads((T/'recordings.json').read_bytes())
    stock=I/'confirm.csv'
    assert digest(stock.read_bytes())=='9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2'
    rows={r['case']:r for r in csv.DictReader(stock.open()) if r['arm']=='terry_independent'}
    assert len(meta)==len(rows)==100 and {r['case'] for r in meta}==set(rows)
    data=[]; pen=[]
    for r in meta:
        name=r['case']; stem=Path(name).stem
        inp=I/'in'/name; actions=T/'tapes'/f'{stem}.actions'; tape=T/'tapes'/f'{stem}.trace'
        ib=inp.read_bytes(); ab=actions.read_bytes(); tb=tape.read_bytes()
        assert r['input_sha']==rows[name]['input_sha']==digest(ib)
        assert r['commands_sha']==rows[name]['commands_sha']==digest(ab)
        assert r['trace_sha']==digest(tb) and tb.splitlines()[::2]==ab.splitlines()
        output=subprocess.check_output([exe,stem,str(r['map']),inp,tape],text=True,timeout=10)
        for row in csv.reader(io.StringIO(output)):
            (data if row[0]=='dog' else pen).append(row[1:])
    def nll(k):
        return pairs([[r[0],penalty(float(r[k])),penalty(float(r[k+1]))] for r in data])
    seq=nll(6)
    def pen_stats(rows):
        m=pairs([[c,(float(u)-int(y))**2,(float(v)-int(y))**2]
                 for c,t,d,k,i,w,y,o,u,v in rows])
        m['dogs']=len({(r[0],r[2]) for r in rows})
        m['positive']=sum(int(r[6]) for r in rows)
        m['all_pet_legal']=sum(int(r[6])*int(r[7]) for r in rows)
        m['different_prob']=sum(abs(float(r[8])-float(r[9]))>1e-12 for r in rows)
        m['relative_gain']=m['gain']/m['uniform'] if m['uniform'] else None
        return m
    primary=pen_stats(pen)
    report=dict(
        verified=len(meta), exposure=primary,
        sequence_NLL=seq, first_NLL=nll(4), endpoint_NLL=nll(8),
        endpoint_brier=pairs([[r[0],float(r[10]),float(r[11])] for r in data]),
        one_symbol=sum(int(r[3]) for r in data),
        pen_retention=pen_stats([r for r in pen if r[4]=='1']),
        pen_entry=pen_stats([r for r in pen if r[4]=='0']),
        pen_initial_veto=pen_stats([r for r in pen if r[5]=='1']),
        pen_initial_no_veto=pen_stats([r for r in pen if r[5]=='0']),
    )
    report['pass_gate']=bool(primary['cases']>=12 and primary['dogs']>=25 and primary['positive']>=20
        and seq['gain']>=.05 and seq['wins']>seq['cases']/2
        and (primary['relative_gain'] or 0)>=.05)
    print(json.dumps(report,indent=2))
    if len(sys.argv)>2:
        with Path(sys.argv[2]).open('w') as f:
            json.dump(dict(dog=data,pen=pen),f,separators=(',',':'))
if __name__=='__main__': main()
