# AHC008: detached one-turn dog prior calibration (not run)

Scope: current accepted First-Chase Reuse, standalone SHA-256
8f50dda74f578fc8ddbf8176d15172a80df96d23d82c57db8ae51aedce4294b7, unchanged
accepted Incoming held100 tapes at `ahc008_terry_hunt_wall_audit/tapes` with `recordings.json`;
the First-Chase memo is orthogonal and matched the accepted held fixed-work panel,
which lets this detached audit stop at t274. No hidden seed, simulated branch, source change,
new official run, or measurement until explicit clearance.

## Exact conditional model

Official tools `src/lib.rs:252–288`:
after actual human actions, redistribute the posterior sentinel and any mass
on co-located or unreachable target humans uniformly among reachable,
positive-distance *IDs*, even when several IDs share one cell. At positive
distance d, the first move is uniform among open neighbors whose distance to
the selected ID is d−1. The second is uniform among the first cell's open
neighbors. If no ID is eligible at all, emit one uniform basic move and reset.
Otherwise, reset target mass if either observed substep lands on its target;
otherwise preserve that ID. Observe all previous public motion (from initial
sentinel at t0), never infer from observations at or after the prediction.
Use of the actual post-human map and positions is conditional calibration,
not an assertion that decisions know hypothetical future human actions.

Known reusable own helper: `ahc008_integrated_v7/dog-target-filter.hpp`
implements exact updating, including one-symbol case. See archived
`ahc008_cat_lab/dog-bank-steer/README.md` for previous seven-case use on different
geometry and speculative staffing; two residual dogs had plausible named
target steering, zero unchanged legal same-tube windows. It neither verifies
nor refutes forecasting in current ready pens. Own v7 pilot already used
this posterior for its Monte Carlo; current First-Chase Normal room retention
`solve.private.cpp:1283–1338` still restarts target uniform per sampled dog
and explicitly excludes dogs from outside-room additions.

Given BFS per eligible human computed once per factual tick, enumerate the
first/second transition product into a sparse endpoint histogram (≤16 paths
with multiplicity) under both priors. Multiply the second-step likelihood for
joint sequence scoring; it cancels only when updating targets after fixing
the first observed symbol. Contrast with the applicable legacy uniformly
reachable *target ID* initializer, not uniform neighbor steps.
Count deterministic no-target basic motion separately (the two forecasts
coincide). No smoothing except identical fixed 1e-12 clipping for NLL.
A cheap independent crosscheck is first-symbol likelihood, which isolates
the whole logloss difference and has minimal postprocessing.

## Frozen exposure and reports

- All alive dog-turns t200..274 inclusive, no selection by final capture:
  sequence and endpoint NLL separately; Brier for endpoint categorical
  forecast, optional target posterior effective size. Count rows and rough
  CPU; use case-cluster macro averages and case wins.
- Ready pens: use actual configured geometry and accepted room numbering
  **on the post-human factual board**, omit already closed/non-placeable
  structural rooms, and prelabel finite room interiors/door cells. Require
  open configured gate(s), no person inside or on a door, and actual people
  on the correct exterior stance(s); paired stance humans distinct. To avoid
  post-outcome selection, record dog initially in room or within two open
  steps of a safe core, and retention (initially in) and entry (initially out)
  separately. Freeze the room and ready status before observing pet moves.
  Don't conflate available physical staff with unreserved policy actors
  unless an unchanged contemporaneous instrumentation log establishes it.
- Event key case/turn/dog/room. Label endpoint in same numbered room and
  outside the union of gates and their orthogonal neighbors. Marginalize the
  complete dog histogram. This is own-pet safe occupancy, not a completed
  capture. For strict opportunity count only, annotate independently whether
  all other pets' observed endpoints also permit placement. Do not use them
  to choose scoring rows or infer predictive gain. Zero- or one-mass outcomes
  stay in support counts; report the probabilistic subset p differs separately.
- Minimum interpretable ready-pen exposure: at least 12 distinct cases, 25
  distinct dogs, and 20 positive safe endpoint events (totals, not a threshold
  sweep); otherwise stop and record sparse or uncalibrated. Require sequence
  case-average NLL reduction ≥0.05 nat and strict majority case wins, plus
  ready-pen paired Brier gain >0 and relative reduction ≥5%, for evidence of
  prioritizing a future narrow policy shadow. Report ready-window results
  for initially gate-vetoing dog vs already-safe dog separately, without
  added thresholds or decision claims; no line or earlier horizon retuning.

## Prepared evaluator

After exclusive CPU clearance, from workspace root:

```sh
g++ -std=c++23 -O2 ahc008_terry_dog_prior_audit/eval.cpp -o ahc008_terry_dog_prior_audit/eval
python ahc008_terry_dog_prior_audit/run.py ahc008_terry_dog_prior_audit/eval   ahc008_terry_dog_prior_audit/events.local.json
```

The helper reuses accepted room classification without invoking Normal, Chase,
the official tester, or the renamed solver entry point. The input parser stops
after visible human coordinates and never consumes the private seed suffix.
The parent manifest's input/action/tape digests are checked, including exact
action lines within the trace. A case-cluster mean weights boards equally;
many dog-turn/pen rows and even safe positives repeat the same dog, so these
counts are exposure, not independent samples.
