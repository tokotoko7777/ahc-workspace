# Fixed-work multisource Chase speed gate

Evaluate only one frozen base/candidate pair, preferring the split-DP
base if its own gates pass. For each of the two already frozen fixed-work
100-case panels, run both complete arms in alternated serial order and
use the exact previously observed terminal paired cap per input for
both. Compare against the same base, not the older h123 denominator for
a combined result. Require all 200 pairwise complete action transcripts
and official scores equal the frozen reference, same completed pair
counts, and no official/replay mismatch. Any unverified snapshot,
incomplete pair, or timeout fails the exact result.

Do not cherry-pick cases. Positive-rollout subgroup = every member of
the panel whose precommitted fixed cap is strictly positive. Require the
same cutoff on both predeclared subgroups separately: at least 2.0%
reduction in summed solver CPU relative to its own base's
positive-rollout subgroup. Also require each whole panel's total solver
CPU not to rise and both arms within the existing local tester guard.
Show base/new sums, subgroup sizes, per-panel maximum tester wall and
zero-rollout subgroup separately. This is an exact computation
optimization, not an outcome comparison at a different count.
