// Multi-source union of all stock bounded open-cell reachability balls.
inline Board chaseReach(const Board& walls,std::span<const int> crew,int radius,Board& occupied) {
    Board reachable;
    std::array<int,size> q;
    int end=0;
    for(int h:crew) {
        if(!occupied[h]) {
            occupied.set(h);
            if(radius>=0) {
                reachable.set(h);
                q[end++]=h;
            }
        }
    }
    for(int depth=0,head=0;depth<radius&&head<end;++depth) {
        const int stop=end;
        for(;head<stop;++head)
            for(int v:neighbors(q[head])) if(v>=0&&!walls[v]&&!reachable[v]) {
                reachable.set(v);
                q[end++]=v;
            }
    }
    return reachable;
}
