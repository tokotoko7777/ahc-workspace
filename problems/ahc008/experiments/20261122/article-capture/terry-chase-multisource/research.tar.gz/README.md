# Exact bounded multi-source landing mask for Chase

On accepted h123 source only, replace the one crew reach-mask block in
`terry_partition::shape()`; no changed ordered edge, capacity, target
or downstream flow/tie/cut logic. The stock predicate was the union over
crew members of shortest-path balls of radius `meetingRadius`.
Enqueue unique crew origins in layer zero, irrespective of whether their
origin is a wall (matching stock `distances` on even invalid synthetic
starts), then expand only through open cells. Same occupied mask,
including repeated and wall starts. Radius zero visits only the roots;
negative radius returns empty reach, nonempty occupancy. Empty crew
returns two empty masks. A wall origin may leave into open floor but
cannot be entered as an intermediate by another origin.

The source hash is pinned. A generated, shareable test-only fixture
reuses just the public partition code from the accepted private source,
without including its model coefficient bytes. Test against repeated
full BFS and identical graph insertion order, flow score, wall list
and evasion mask; no official/timed run from this tool.
```
python ahc008_terry_chase_multisource/make.py ahc008_terry_passive_exact_short/live.private.cpp
g++ -std=c++23 -Wall -Wextra ahc008_terry_chase_multisource/unit.cpp -o /tmp/chase-multisource-unit
/tmp/chase-multisource-unit
g++ -std=c++23 ahc008_terry_chase_multisource/solve.private.cpp -o ahc008_terry_chase_multisource/solve
```
Keep generated standalone and executable local. The expected gain is
only the eliminated BFS repeats and depth overflow; flow may still
dominate, so time savings are not established by exactness tests.

The generator additionally accepts exact split-DP input SHA
`170382b80e4ca1b0d3a5c4f0948527edabfbb43c0549fa8512fbe9dccc59e223`.
That path rechecks the original partition excerpt byte-for-byte and
writes `split-combined.private.cpp`, leaving `solve.private.cpp`
(original h123 base) untouched. See [GATE.md](GATE.md) for the
predeclared fixed-work CPU comparison.
