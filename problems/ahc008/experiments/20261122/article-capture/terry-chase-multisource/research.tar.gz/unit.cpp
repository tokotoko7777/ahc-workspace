#pragma GCC optimize("O3")
#include <bits/stdc++.h>
#include "../ahc008_focus_solver/library/max-flow.hpp"
#include "../ahc008_terry_exact_partition/partition.hpp"
#include "fixture.inc"

namespace ref=terry_partition;
namespace fast=optimized_partition;
using Board=ref::Board;
using Vec=std::vector<int>;
using Arc=std::array<int,3>;
struct ArcRecorder:MaxFlow<int> {
    static inline std::vector<Arc> arcs;
    explicit ArcRecorder(int n):MaxFlow<int>(n){arcs.clear();}
    int add_edge(int f,int t,int c) {
        arcs.push_back({f,t,c});
        return MaxFlow<int>::add_edge(f,t,c);
    }
};
void equality(const Board& board,const Vec& roots,int r) {
    Board occupied,reference,known;
    for(int h:roots) {
        known.set(h);
        auto d=ref::distances(board,h);
        for(int q=0;q<900;++q) if(d[q]>=0&&d[q]<=r) reference.set(q);
    }
    assert(fast::chaseReach(board,roots,r,occupied)==reference);
    assert(occupied==known);
}
int main() {
    Board w;
    const Vec roots{0,0,29,450,899};
    for(const Board& board : {w,Board{}.set(),Board{}.set(0).set(29).set(450).set(899)})
        for(int radius:{-5,-1,0,1,2,23,899,900,2000}) {
            equality(board,{},radius);
            equality(board,roots,radius);
        }
    std::mt19937 rng(321116);
    for(int i=0;i<5000;++i) {
        Board board;
        const unsigned pct=rng()%101;
        for(int q=0;q<900;++q) if(rng()%100<pct) board.set(q);
        Vec crew(rng()%11);for(int& q:crew)q=rng()%900;
        if(i%3==0&&!crew.empty())crew.back()=crew.front();
        if(i%3==1&&!crew.empty())board.set(crew.front());
        equality(board,crew,int(rng()%61)-17);
        equality(board,crew,ref::deadlineRadius(275+i%25));
        if(i<220) {
            for(int q:crew)board.reset(q);
            Vec targets(rng()%8);
            for(int& q:targets){q=rng()%900;board.reset(q);}
            Board roads;for(int q=0;q<900;++q)if(rng()%5==0)roads.set(q);
            const int t=275+i%25;
            ArcRecorder::arcs.clear();
            auto a=ref::shape<ArcRecorder>(board,roads,crew,targets,t);
            auto before=ArcRecorder::arcs;ArcRecorder::arcs.clear();
            auto b=fast::shape<ArcRecorder>(board,roads,crew,targets,t);
            assert(ArcRecorder::arcs==before);
            assert(a.walls==b.walls&&a.evasion==b.evasion&&a.targetCount==b.targetCount);
            assert(a.sourceMass==b.sourceMass&&a.flowValue==b.flowValue&&a.meetingRadius==b.meetingRadius);
        }
    }
    std::cout<<"10054 reach masks and 220 full flow shapes verified\n";
}
