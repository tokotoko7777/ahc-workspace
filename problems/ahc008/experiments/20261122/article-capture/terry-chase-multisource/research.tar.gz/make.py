"""Exactly replace only the faithful Chase shape's crew reach-mask builder."""
import argparse
import hashlib
import os
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE='08bff3c8aaeb6613b47be82b44b12bf90f63bd80476b69498bb7bc9e63fa375c'
SPLIT='170382b80e4ca1b0d3a5c4f0948527edabfbb43c0549fa8512fbe9dccc59e223'
HOOK='inline std::vector<int> majorityPets('
OLD="""    Board occupied,reachable;
    for(int h:crew) {
        occupied.set(h);
        auto dist=distances(walls,h);
        for(int p=0;p<size;++p)if(dist[p]>=0&&dist[p]<=ans.meetingRadius)
            reachable.set(p);
    }
"""
NEW="""    Board occupied;
    const Board reachable=chaseReach(walls,crew,ans.meetingRadius,occupied);
"""
def change(source):
    assert source.count(HOOK)==source.count(OLD)==1
    return source.replace(HOOK,(HERE/'mask.inc').read_text()+HOOK).replace(OLD,NEW)
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path)
    p.add_argument('--fixture-only',action='store_true')
    a=p.parse_args()
    raw=a.source.read_bytes()
    base=hashlib.sha256(raw).hexdigest()
    assert base in (BASE,SPLIT), base
    src=raw.decode()
    first=src.index('namespace terry_partition {')
    past=src.index('\n}\n\n#include <cmath>\n#include <string>',first)+2
    part=src[first:past]
    (HERE/'fixture.inc').write_text(change(part).replace('namespace terry_partition {','namespace optimized_partition {'))
    stock=(HERE.parent/'ahc008_terry_exact_partition/partition.hpp').read_text()
    assert stock[stock.index('namespace terry_partition {'):].rstrip()==part.rstrip()
    if not a.fixture_only:
        out=HERE/('solve.private.cpp' if base==BASE else 'split-combined.private.cpp')
        fd=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
        with os.fdopen(fd,'w') as f:f.write(change(src))
        out.chmod(0o600)
        print('private source SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
if __name__=='__main__':main()
