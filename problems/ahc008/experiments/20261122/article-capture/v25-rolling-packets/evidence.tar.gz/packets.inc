 struct ShoulderPacket{
  int bank=-1,id=-1,mid=-1;
  vector<int> tubes;
  bitset<V> walls;
  // Ordered snake stances; each wall has exactly one canonical stance.
  vector<terry_build::Order> tasks;
 };
 struct PacketPlan{
  int id=-1,use=0,ready=0,guard=0;
  array<vector<terry_build::Order>,5> q;
 };
 vector<ShoulderPacket> packets;
 array<PacketPlan,2> activePackets;
 int packetMode=0,packetStarts=0,packetDone=0,packetBuilds=0,packetWalks=0,
     packetGuardYields=0,packetNoDispatch=0;
 vector<ShoulderPacket> definePackets()const{
  vector<ShoulderPacket> out;
  for(int b=0;b<2;b++){
   vector<int> all;
   for(int k=0;k<int(banks.size());k++)if(banks[k].b==b)all.push_back(k);
   sort(all.begin(),all.end(),[&](int l,int r){return banks[l].r<banks[r].r;});
   if(all.size()!=13)return {};
   int from=0;
   for(int n:{3,3,3,4}){
    ShoulderPacket p;
    p.bank=b;p.id=out.size();p.mid=all[from+n/2];
    p.tubes.assign(all.begin()+from,all.begin()+from+n);
    for(int k:p.tubes)for(int q:banks[k].side)p.walls[q]=true;
    bitset<V> left=p.walls;
    for(int j=0;j<n;j++){
     const auto& tube=banks[p.tubes[j]];
     auto inner=tube.inner;
     if((j+b)&1)reverse(inner.begin(),inner.end());
     for(int q:inner){
      terry_build::Order task{q,{}};
      for(int k:nb[q])if(k>=0&&left[k]){
       task.walls.push_back(k);left[k]=false;
      }
      if(!task.walls.empty())p.tasks.push_back(move(task));
     }
    }
    assert(left.none());
    out.push_back(move(p));from+=n;
   }
  }
  return out;
 }
 bitset<V> packetReadyBody(const vector<int>& ready)const{
  bitset<V> body;
  for(int i=0;i<int(banks.size());i++)if(ready[i])for(int p:banks[i].inner)body[p]=true;
  return body;
 }
 bitset<V> packetPathMask(int from,bitset<V> flags,const bitset<V>& body)const{
  flags|=body;
  if(body[from])for(auto& x:banks)
   if(find(x.inner.begin(),x.inner.end(),from)!=x.inner.end()){
    for(int p:x.inner)if(!wall[p])flags[p]=false;
    break;
   }
  return flags;
 }
 vector<PacketPlan> proposePacket(const ShoulderPacket& p,const bitset<V>& walls,
                                   const bitset<V>& body,int pool)const{
  vector<terry_build::Order> q;
  for(auto x:p.tasks){
   erase_if(x.walls,[&](int a){return walls[a];});
   if(!x.walls.empty())q.push_back(move(x));
  }
  if(q.empty())return {};
  const int n=q.size();
  const auto base=walls|terryBuild.braces();
  // Typical packet <= 12 stances. Precompute legal one-way walking in the
  // final brace graph, then enumerate contiguous 1-worker/2-worker chunks.
  vector<terry_build::Nav> nav(n);
  array<terry_build::Nav,5> origin;
  for(int i=0;i<n;i++)nav[i].run(q[i].from,packetPathMask(q[i].from,base,body));
  for(int i=0;i<5;i++)origin[i].run(humans[i],packetPathMask(humans[i],base,body));
  auto times=[&](int worker,int l,int r){
   if(l>=r)return 1000;
   int x=origin[worker].d[q[l].from];if(x<0)return 1000;
   for(int j=l;j<r;j++){
    x+=q[j].walls.size();
    if(j+1<r){
     int s=nav[j].d[q[j+1].from];
     if(s<0)return 1000;
     x+=s;
    }
   }
   return x;
  };
  const auto& t=banks[p.mid];
  auto pick=[&](int a,int b,int cut,int ta,int tb){
   PacketPlan z;
   z.id=p.id;z.use=(1<<a)|(b>=0?1<<b:0);z.ready=max(ta,tb);
   auto exit=[&](int person,int stance){
    if(person==a){int d=nav[cut-1].d[stance];return d<0?1000:ta+d;}
    if(person==b){int d=nav[n-1].d[stance];return d<0?1000:tb+d;}
    int d=origin[person].d[stance];return d<0?1000:d;
   };
   z.guard=1000;
   for(int i=0;i<5;i++)for(int j=0;j<5;j++)if(i!=j)
    z.guard=min(z.guard,max({z.ready,exit(i,t.l),exit(j,t.h)}));
   z.q[a].assign(q.begin(),q.begin()+cut);
   if(b>=0)z.q[b].assign(q.begin()+cut,q.end());
   return z;
  };
  array<PacketPlan,32> best;
  auto include=[&](int a,int b,int c,int ta,int tb){
   int eta=max(ta,tb);
   if(eta>=1000||!terryBuild.inConstruction(turn+eta-1))return;
   auto z=pick(a,b,c,ta,tb);
   if(z.guard>=1000)return;
   auto& old=best[z.use];
   if(old.id<0||tie(z.guard,z.ready)<tie(old.guard,old.ready))old=move(z);
  };
  for(int a=0;a<5;a++)if(pool>>a&1){
   include(a,-1,n,times(a,0,n),0);
   for(int b=0;b<5;b++)if(a!=b&&(pool>>b&1))
    for(int c=1;c<n;c++)include(a,b,c,times(a,0,c),times(b,c,n));
  }
  vector<PacketPlan> out;
  for(auto& s:best)if(s.id>=0)out.push_back(move(s));
  return out;
 }
 bool packetConstruction(const bitset<V>& walls,const vector<int>& ready,const vector<int>& count,
          const vector<int>& enabled,bitset<V>& build,bitset<V>& moveTo,bitset<V>& used,
          bitset<terry_lane::MaxTubes> shut){
  if(humans.size()!=5||bankN!=2||packetMode<0||!terryBuild.inConstruction(turn))return false;
  if(packets.empty()){
   packets=definePackets();
   if(packets.empty()){packetMode=-1;return false;}
  }
  auto routes=packetReadyBody(ready);
  bitset<V> guards;
  // Preserve exact current lock availability: reserve actors only in the
  // constructor; production still does the actual unchanged lock selection.
  vector<vector<BankJob>> immediate(banks.size());
  for(int k=0;k<int(banks.size());k++)if(ready[k]&&enabled[k]&&count[k]&&
     !terryRoad.bridge[k]&&!crossing.reserves(k)&&!block[banks[k].g]&&!block[banks[k].k]){
   auto& x=banks[k];
   for(int a=0;a<5;a++)if(!used[a]&&humans[a]==x.l)
   for(int b=0;b<5;b++)if(a!=b&&!used[b]&&humans[b]==x.h)
    immediate[k].push_back({k,a,b,0,double(count[k])});
  }
  for(auto j:packBankJobs(immediate,2))if(terryRoad.protects(j.tube,shut)){
   guards[j.a]=guards[j.b]=true;shut[j.tube]=true;
  }
  // Reserve actors from a still usable previous *pair*, not one human
  // with an invented hold. Recomputed MC/assignment remains authoritative.
  array<terry_build::Nav,5> walk;
  for(int i=0;i<5;i++)walk[i].run(humans[i],packetPathMask(humans[i],walls|build,routes));
  for(int i=0;i<5;i++)if(priorPlan&&!used[i]&&previousTube[i]>=0){
   int k=previousTube[i];
   if(!ready[k]||terryRoad.bridge[k]||crossing.reserves(k)||walls[banks[k].g]||walls[banks[k].k]||shut[k])
    continue;
   auto& x=banks[k];
   if(previousDoor[i]!=x.l||walk[i].d[x.l]<0||walk[i].d[x.l]>Horizon)continue;
   for(int j=0;j<5;j++)if(i!=j&&!used[j]&&previousTube[j]==k&&previousDoor[j]==x.h&&
      walk[j].d[x.h]>=0&&walk[j].d[x.h]<=Horizon){guards[i]=guards[j]=true;break;}
  }
  int busy=0;
  for(auto& s:activePackets)if(s.id>=0){
   if((packets[s.id].walls&~walls).none()){++packetDone;s=PacketPlan{};}
   else busy|=s.use;
  }
  int pool=31&~busy;
  for(int i=0;i<5;i++)if(used[i]||guards[i])pool&=~(1<<i);
  // used/guards exclude all cells >4; explicitly preserve one free actor
  // across concurrent packets when possible by per-packet size at most two.
  array<vector<PacketPlan>,2> offered;
  for(const auto& p:packets)if(activePackets[p.bank].id<0&&(p.walls&~walls).any()){
   auto v=proposePacket(p,walls,routes,pool);
   for(auto& q:v)offered[p.bank].push_back(move(q));
  }
  const PacketPlan *a=nullptr,*b=nullptr;
  tuple<int,int,int,int,int> best{1000,1000,1000,1000,1000};
  for(auto& x:offered[0])for(auto& y:offered[1])if(!(x.use&y.use)){
   auto key=tuple(max(x.guard,y.guard),x.guard+y.guard,x.ready+y.ready,x.id,y.id);
   if(key<best)best=key,a=&x,b=&y;
  }
  if(!a&&!b&&packetMode!=0){
   for(auto& x:offered[0]){
    auto key=tuple(x.guard,x.ready,x.id,x.use,0);
    if(key<best)best=key,a=&x;
   }
   for(auto& y:offered[1]){
    auto key=tuple(y.guard,y.ready,y.id,y.use,1);
    if(key<best)best=key,b=&y,a=nullptr;
   }
  }
  if(packetMode==0&&!a&&!b){packetMode=-1;return false;}
  packetMode=1;
  if(a){activePackets[0]=*a;++packetStarts;}
  if(b){activePackets[1]=*b;++packetStarts;}
  if(!a&&!b&&busy==0){++packetNoDispatch;return false;}
  for(const auto& p:activePackets)if(p.id>=0)for(int i=0;i<5;i++)if(!used[i]&&(p.use>>i&1)){
   if(guards[i]){++packetGuardYields;continue;}
   const auto& q=p.q[i];int from=humans[i];
   // Skip a blocked current closure, not the owned job. Other available
   // stances in the same packet remain useful; skipped jobs are revisited.
   terry_build::Nav nav;
   nav.run(from,packetPathMask(from,walls|build|terryBuild.braces(),routes));
   for(const auto& s:q){
    bool feasible=false;
    for(int w:s.walls)if(!walls[w]&&!build[w]&&!block[w]&&!moveTo[w]){
     if(s.from==from){
      act[i]=BUILD[dir(from,w)];build[w]=true;used[i]=true;++packetBuilds;
      feasible=true;break;
     }
     int step=nav.step[s.from];
     if(step>=0&&!build[step]){
      act[i]=MOVE[dir(from,step)];moveTo[step]=true;used[i]=true;++packetWalks;
      feasible=true;break;
     }
    }
    if(feasible)break;
   }
  }
  return true;
 }
