import csv,json,sys,statistics
a=list(csv.DictReader(open(sys.argv[1])))
for m in ('baseline','article'):
 r=[z for z in a if z['model']==m]
 if not r: continue
 print(m,len(r))
 print({k:sum(int(x[k]) for x in r) for k in ['score','all_clear','exact4_first','residual_turn100','residual_turn160','final_reachable']})
 print("useful",sum(int(x['all_clear']) and float(x['mean_human_floor'])>=300 for x in r),"max",max(float(x['wall_sec']) for x in r))
 for t in (50,75,100,160):
  caps=[tuple(map(int, e.split(':'))) for z in r for e in z['captures'].split(';') if e]
  print(t,"exact4",sum(c[0]<=t and c[3]==4 for c in caps))
  if t!=160:
   s=[json.loads(z['stages'])['milestones'][str(t)] for z in r]
   print({k:sum(x[k] for x in s) for k in ['shells','staffed_tubes','legal_tubes']})
 stages=[json.loads(z['stages']) for z in r]
 for k in ['ready','staff','first_lock']:
  p=[v for x in stages for v in x[k] if v>=0]
  print(k,len(p),statistics.median(p) if p else None)
 d=[list(map(int,x['packets'].split())) for x in r if x['packets']]
 if d:print('packets totals',list(map(sum,zip(*d))),'modes',dict((i,sum(x[0]==i for x in d)) for i in (-1,0,1)))
