#define main original_entry
#include "solve.cpp"
#undef main
int main(){
 for(int p=0;p<900;p++)
  nb[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 Game g;
 g.bankMode=5;
 g.humans={94,101,108,514,528};
 g.workers.resize(5);
 g.terryLayout(5);
 const auto ps=g.definePackets();
 assert(ps.size()==8);
 bitset<900> all;
 for(int i=0;i<8;i++){
  const auto& p=ps[i];
  assert(p.bank==i/4&&p.tubes.size()==size_t(i%4==3?4:3));
  bitset<900> represented;
  for(const auto& order:p.tasks)for(int w:order.walls){
   assert(!represented[w]&&md(order.from,w)==1);
   represented[w]=true;
  }
  assert(represented==p.walls);
  if(i%4)assert((ps[i-1].walls&p.walls).count()==4);
  if(i>=4)for(int j=0;j<4;j++)assert((ps[j].walls&p.walls).none());
  all|=represented;
 }
 assert(all.count()==112&&all==g.terryBuild.braces());
 bool started=false;
 for(int turn=0;turn<18;turn++){
  g.turn=turn;g.prep();
  vector<int> ready(g.banks.size()),enabled(g.banks.size(),1),heads(g.banks.size());
  bitset<900> w,build,to,used;
  vector<terry_lane::Tube> t;
  for(int i=0;i<900;i++)w[i]=g.wall[i];
  for(int i=0;i<int(g.banks.size());i++){
   const auto& x=g.banks[i];
   ready[i]=all_of(x.side.begin(),x.side.end(),[&](int p){return g.wall[p];});
   t.push_back({x.l,x.h,x.g,x.k,x.inner});
  }
  g.terryRoad.rebuild(nb,g.wall,t,ready);
  bool owns=g.packetConstruction(w,ready,heads,enabled,build,to,used,{});
  assert(owns);
  if(g.activePackets[0].id>=0&&g.activePackets[1].id>=0){
   started=true;
   assert((g.activePackets[0].use&g.activePackets[1].use)==0);
   assert(popcount(unsigned(g.activePackets[0].use|g.activePackets[1].use))<=4);
  }
  assert((build&to).none()&&!(build&~all).any()&&!(build&w).any());
  for(int i=0;i<5;i++)if(islower(g.act[i])){
   int p=nb[g.humans[i]][std::string_view("udlr").find(g.act[i])];
   assert(!g.block[p]);g.wall[p]=1;
  }
  for(int i=0;i<5;i++)if(isupper(g.act[i])){
   int q=nb[g.humans[i]][std::string_view("UDLR").find(g.act[i])];
   assert(!g.wall[q]);g.humans[i]=q;
  }
 }
 assert(started&&g.packetBuilds>8);
 // Fixture with an immediately safe occupied two-ended rail: packet
 // construction may not claim the two real guards.
 const auto& x=g.banks[0];
 for(int q:x.side)g.wall[q]=1;
 g.humans[0]=x.l;g.humans[1]=x.h;
 for(int i=2;i<5;i++)if(g.wall[g.humans[i]])g.humans[i]=x.h;
 g.pets={{x.inner[1],1}};
 g.turn=18;g.prep();
 vector<int> ready(g.banks.size()),enabled(g.banks.size(),1),head(g.banks.size());
 bitset<900> known,build,steps,used;
 vector<terry_lane::Tube> tube;
 for(int p=0;p<900;p++)known[p]=g.wall[p];
 for(int k=0;k<int(g.banks.size());k++){
  const auto& b=g.banks[k];
  ready[k]=all_of(b.side.begin(),b.side.end(),[&](int p){return g.wall[p];});
  tube.push_back({b.l,b.h,b.g,b.k,b.inner});
 }
 head[0]=1;
 g.terryRoad.rebuild(nb,g.wall,tube,ready);
 assert(!g.terryRoad.bridge[0]&&!g.block[x.g]&&!g.block[x.k]);
 assert(g.packetConstruction(known,ready,head,enabled,build,steps,used,{}));
 assert(!used[0]&&!used[1]&&g.act[0]=='.'&&g.act[1]=='.');
 g.turn=133;
 vector<int> flags(26);
 bitset<900> blank;
 assert(!g.packetConstruction(blank,flags,flags,flags,blank,blank,blank,{}));
}
