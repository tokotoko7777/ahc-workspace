from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=raw.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' string integratedBankPlan(){',Path(__file__).with_name('packets.inc').read_text()+' string integratedBankPlan(){')
rep('  terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});','''  if(!packetConstruction(walls,ready,count,enabled,build,moveTo,usedPeople,shut))
   terryBuild.build(turn,humans,walls,build,moveTo,usedPeople,act,[&](int q){return !block[q];});''')
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* p=getenv("AHC008_PACKETS_LOG")){
  ofstream f(p);f<<g.packetMode<<' '<<g.packetStarts<<' '<<g.packetDone<<' '<<g.packetBuilds<<' '
                <<g.packetWalks<<' '<<g.packetGuardYields<<' '<<g.packetNoDispatch<<'\\n';
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
