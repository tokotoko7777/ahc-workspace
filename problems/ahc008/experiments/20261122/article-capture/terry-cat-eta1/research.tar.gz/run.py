import collections
import csv
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path
D=Path(__file__).resolve().parent
W=D.parent
R=W/'ahc008_terry_hunt_wall_audit'
I=W/'ahc008_terry_incoming_shadow'/'held100'
def sha(b):return hashlib.sha256(b).hexdigest()
def pinned(p,h):
    b=p.read_bytes();assert sha(b)==h,p
    return b
def rows(exe,i,t,mode):
    raw=subprocess.check_output([exe,i,t,mode],text=True,timeout=8)
    return list(csv.reader(raw.splitlines()))
def metrics(events):
    groups=collections.defaultdict(list)
    for c,r in events:
        q=int(r[5]);p=list(map(float,r[7:10]));assert len(p)==3 and all(-1e-12<=a<=1+1e-12 for a in p)
        b=[(z-q)**2 for z in p];n=[-math.log(max(1e-12,z if q else 1-z)) for z in p]
        groups[c].append((b,n))
    N=len(groups)
    if not N:return {'cases':0,'events':0}
    B=[[sum(v[0][i] for v in x)/len(x) for i in range(3)] for x in groups.values()]
    L=[[sum(v[1][i] for v in x)/len(x) for i in range(3)] for x in groups.values()]
    b=[sum(x[i] for x in B)/N for i in range(3)]
    l=[sum(x[i] for x in L)/N for i in range(3)]
    return dict(cases=N,events=len(events),brier=b,nll=l,
        brier_relative=[(b[i]-b[2])/b[i] if b[i]>0 else 0 for i in range(2)],
        nll_gain=[l[i]-l[2] for i in range(2)],
        wins=[sum(x[2]<x[i] for x in B) for i in range(2)])
def main():
    exe=Path(sys.argv[1]).resolve()
    meta=json.loads(pinned(R/'recordings.json','dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'))
    ledger=pinned(I/'confirm.csv','9b67c75b22320e2cd412aadecf13d71bec3869a8447f77310e14710a1c8a2bb2')
    expected={r['case']:r for r in csv.DictReader(ledger.decode().splitlines())if r['arm']=='terry_independent'}
    assert len(expected)==len(meta)==100 and set(expected)=={r['case']for r in meta}
    locked={}; first={}; allrows=[]
    for m in meta:
        c=m['case'];i=I/'in'/c;a=(R/'tapes'/c).with_suffix('.actions');t=a.with_suffix('.trace')
        ia=pinned(i,m['input_sha']);aa=pinned(a,m['commands_sha']);ta=pinned(t,m['trace_sha'])
        assert expected[c]['input_sha']==sha(ia) and expected[c]['commands_sha']==sha(aa)
        al,tl=aa.splitlines(),ta.splitlines()
        assert len(al)==300 and len(tl)==600 and tl[::2]==al
        locked[c]=(i,t);first[c]=rows(exe,i,t,'exposure')
        allrows.extend((c,r) for r in first[c])
    positives=sum(r[5]=='1' for _,r in allrows)
    exact={(c,r[0],r[2])for c,r in allrows if r[6]=='1'}
    exposure=dict(cases=sum(bool(r)for r in first.values()),
        cats=len({(c,r[1])for c,r in allrows}),rows=len(allrows),
        positive=positives,actual_all_safe_windows=len(exact),
        actual_all_safe_cases=len({c for c,_,_ in exact}))
    passed=exposure['cases']>=15 and exposure['cats']>=30 and positives>=25 and len(exact)>=15 and exposure['actual_all_safe_cases']>=10
    result=dict(verified=100,exposure=exposure,exposure_pass=passed)
    if passed:
        scored=[]
        for c,old in first.items():
            if not old:continue
            new=rows(exe,*locked[c],'score')
            assert [r[:7]for r in new]==old
            scored.extend((c,r)for r in new)
        s=metrics(scored)
        result.update(primary=s,
            actual_staffed=metrics([(c,r)for c,r in scored if r[4]=='1']),
            single=metrics([(c,r)for c,r in scored if r[3]=='0']),
            two=metrics([(c,r)for c,r in scored if r[3]=='1']),
            pass_gate=min(s['brier_relative'])>=.08 and min(s['nll_gain'])>0 and s['wins'][1]>s['cases']/2)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
