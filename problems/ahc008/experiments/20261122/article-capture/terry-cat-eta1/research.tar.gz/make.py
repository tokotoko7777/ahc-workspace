"""Generate a detached local executable from pinned exact sources; no run."""
from pathlib import Path
from hashlib import sha256
D=Path(__file__).resolve().parent
W=D.parent
def read(path,sha):
    b=(W/path).read_bytes()
    assert sha256(b).hexdigest()==sha,path
    return b.decode()
stock=read('ahc008_terry_first_chase_reuse/solve.private.cpp',
    '8f50dda74f578fc8ddbf8176d15172a80df96d23d82c57db8ae51aedce4294b7')
latent=read('ahc008_terry_target_active275/observer.cpp',
    'd83710cadeeb3f4e88bf5f74f922da3d64a8f2ca0b2322e0a9bba910dac2ebf3')
inc,code=latent.split('constexpr int N=900,M=10;',1)
latent=inc+'\nnamespace latent_public {\nconstexpr int N=900,M=10;'+code.split('\nint main(',1)[0]+'\n}\n'
def stem(src):
    assert src.count('\nint main(')==1
    return src.split('\nint main(',1)[0]
(D/'observer.private.cpp').write_text(stem(stock)+'\n'+latent+'\n'+(D/'observer.inc').read_text())
