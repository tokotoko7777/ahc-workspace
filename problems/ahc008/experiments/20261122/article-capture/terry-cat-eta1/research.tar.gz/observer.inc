namespace early_eta {
using namespace terry_exact_root;
using Post=std::array<double,V+1>;
struct Ready {int id,left,right;bool staffed;Mask safe,veto;};
int guard_eta(const State& pre,const State& post,int id,int dest){
 if(dest<0||pre.walls[dest]||post.walls[dest])return 99;
 int p=pre.people[id];
 if(p==dest)return 0;
 if(p%30==dest%30&&std::abs(p/30-dest/30)==1)return 1;
 return 99;
}
std::vector<Ready> rooms(const State& pre,const State& post,const terrain_lib::Rooms& map,const Mask& art){
 Mask human;
 for(int p:post.people)human.set(p);
 std::vector<Ready> result;
 for(int k=0;k<map.count();++k){
  const auto r=map.rooms[k];
  if(!r.size||(r.left<0&&r.right<0))continue;
  bool bad=false;
  for(int p:post.people)bad|=map.ids[p]==k;
  for(int p:{r.left,r.right})if(p>=0)
   bad|=pre.walls[p]||post.walls[p]||art[p]||human[p]||map.ids[p]!=k;
  if(bad)continue;
  const int left=r.left<0?-1:nb[r.left][3],right=r.right<0?-1:nb[r.right][1]; // URDL
  if((r.left>=0&&(left<0||map.ids[left]==k))||(r.right>=0&&(right<0||map.ids[right]==k)))continue;
  bool match=false,now=false;
  for(int i=0;i<(int)pre.people.size();++i)for(int j=0;j<(int)pre.people.size();++j){
   if(r.left>=0&&r.right>=0&&i==j)continue;
   const int a=left<0?0:guard_eta(pre,post,i,left),b=right<0?0:guard_eta(pre,post,j,right);
   match|=std::max(a,b)==1;
   now|=(left<0||post.people[i]==left)&&(right<0||post.people[j]==right);
  }
  // ETA 1 means best physical assignment is exactly 1, never just another slower pair.
  bool pre_now=false;
  for(int i=0;i<(int)pre.people.size();++i)for(int j=0;j<(int)pre.people.size();++j){
   if(r.left>=0&&r.right>=0&&i==j)continue;
   pre_now|=(left<0||pre.people[i]==left)&&(right<0||pre.people[j]==right);
  }
  if(!match||pre_now)continue;
  Ready q{k,r.left,r.right,now,{},{}};
  for(int p:{r.left,r.right})if(p>=0){q.veto.set(p);for(int z:nb[p])if(z>=0)q.veto.set(z);}
  for(int p=0;p<V;++p)if(map.ids[p]==k&&!post.walls[p]&&!q.veto[p])q.safe.set(p);
  if(q.safe.any())result.push_back(std::move(q));
 }
 return result;
}
std::array<double,4> endpoint(const State& post,int p,const Mask& safe){
 std::array<double,4> q;q.fill(-1.);
 for(int d=0;d<4;++d){
  int z=latent_public::nb[p][d];
  if(z<0||post.walls[z])continue;
  int total=0,hit=0;
  for(int x:latent_public::nb[z])if(x>=0&&!post.walls[x]){++total;hit+=safe[x];}
  assert(total>0);
  q[d]=double(hit)/total;
 }
 return q;
}
int evaluate(const char* input,const char* tape,bool score_mode){
 std::ifstream f(input),trace(tape);
 State s;std::array<int,5> counts{};
 int n,m;f>>n;s.pets.resize(n);std::vector<int> cat;
 for(int j=0;j<n;++j){
  int a,b,k;f>>a>>b>>k;s.pets[j]={(a-1)*30+b-1,k,-1};++counts[k-1];
  if(k==5)cat.push_back(j);
 }
 f>>m;s.people.resize(m);
 for(int& p:s.people){int a,b;f>>a>>b;p=(a-1)*30+b-1;}
 assert(f&&trace); // deliberately never parse judge seed suffix
 if(cat.empty())return 0;
 const auto& land=terrain_lib::terrain(terry_exact_selector::choose(m,counts));
 std::vector<Post> posterior(n);
 for(int i:cat)posterior[i][V]=1.;
 TopologyMemo topo;
 std::cout<<std::setprecision(17);
 for(int t=0;t<160;++t){
  State pre=s;std::string cmd,line;
  assert(std::getline(trace,cmd)&&std::getline(trace,line));
  people_step(s,cmd);
  std::vector<std::string> moves(n);
  std::vector<latent_public::Steps> steps(n);
  latent_public::State light;
  for(int p=0;p<V;++p)light.walls[p]=s.walls[p];
  std::istringstream ss(line);
  for(int i=0;i<n;++i){ss>>moves[i];assert(ss);steps[i]=latent_public::decode(s.pets[i].pos,light.walls,moves[i]);}
  if(t>=100){
   const auto& map=topo.get(land,s.walls,s.walls,s.people);
   auto ready=rooms(pre,s,map,topo.arts(land,s.walls));
   for(int i:cat){
    int p=s.pets[i].pos;
    if(!map.participates[p])continue;
    for(const auto& room:ready)if(map.ids[p]==room.id){
     auto e=endpoint(s,p,room.safe);
     double sum=0;int degree=0;
     for(double v:e)if(v>=0){sum+=v;++degree;}
     if(!(sum>0&&sum<degree-1e-12))continue;
     bool hit=room.safe[steps[i].end],other=true;
     for(int j=0;j<n;++j)if(j!=i)other&=!room.veto[steps[j].end];
     const bool legal=hit&&other&&room.staffed;
     std::cout<<t<<','<<i<<','<<room.id<<','<<(room.left>=0&&room.right>=0)<<','
       <<room.staffed<<','<<hit<<','<<legal;
     if(score_mode){
      auto p1=latent_public::cat(light,p,steps[i],posterior[i],false);
      double uniform=0,updated=0;
      for(int d=0;d<4;++d)if(e[d]>=0){uniform+=e[d]*p1.legacy[d];updated+=e[d]*p1.post[d];}
      std::cout<<','<<sum/degree<<','<<uniform<<','<<updated;
     }
     std::cout<<'\n';
    }
   }
  }
  for(int i:cat)if(score_mode)
   latent_public::cat(light,s.pets[i].pos,steps[i],posterior[i],true);
  for(int i=0;i<n;++i)s.pets[i].pos=steps[i].end;
 }
 return 0;
}
}
int main(int argc,char** argv){
 if(argc!=4)return 2;
 const std::string mode=argv[3];assert(mode=="exposure"||mode=="score");
 return early_eta::evaluate(argv[1],argv[2],mode=="score");
}
