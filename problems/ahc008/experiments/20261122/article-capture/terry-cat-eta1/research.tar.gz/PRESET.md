# t100–159 physical ETA1 cat endpoint QA (detached)

Use exactly all signed Incoming held100 tapes and their two accepted hashes:
incoming_shadow/held100/confirm.csv and hunt_wall_audit/recordings.json.
Use 8f50dda74 accepted First-Chase source for geometry only; t<275 equivalent
with accepted Incoming, no official judge or policy calls. Independent of
the enriched t275 target QA. Native role assignments were not recorded, so
ETA means physical staffed/one-step-ready stances, not a chosen hunt job.
All t100–159 are normal mode (switch earliest t275).

Freeze gate geometry on the factual post-human wall map. Require original
named classified room, every mouth open and non-articulation, no current
human in room/on mouths, agreeing room labels, and actual pre-human correct
exterior-column guard assignments with max vertical legal ETA exactly one
(one- or two-mouth jobs, distinct humans for two mouths). Those guard
stances must remain open on the factual post-human board. Exclude closure
during this human phase. Initial cat must be in the named room and safe core
geometrically reachable in two basic substeps. Endpoint ordering official:
after t human action, then cat directed+random motion, then t+1 decides.
Predict from frozen post-human walls and cat posterior through t−1 only.
Post-human human positions are used solely to confirm no enclosure and flag
actually staffed subset. Human actions this turn are factual shared
conditioning, no inputs from future commands and no claim of causal policy.
Exact joint safe annotation uses observed endpoint of every other animal
and actual simultaneous stance accessibility (both gates open, no human on
gate, both placements independent); never drives prediction.

Closure-safe cat endpoint = labeled room minus union of gates and their
orthogonal neighbors. Enumerate all ordered 2-step open paths. Pure
exposure restricts to both safe and unsafe endpoints attainable (equivalent
to stock random probability in (0,1); all directed models have support
contained in random). Require ≥15 boards, ≥30 distinct cats, ≥25 positive
own-safe endpoints, and ≥15 distinct actual all-pet-safe (board, t+1, room)
windows spanning ≥10 boards. Duplicate dogs/cats may share a room-window,
but the window counted once. Log case, pet ID and room—not independent
rows. Stop before predictive metrics if exposure fails.

If exposure passes, compare exact two random substeps versus uniform
reachable coordinate target directed-first+random versus public history
posterior directed-first+random. Do not use uniform neighbor as a stand-in
for uniform latent goal; redistribute invalid/current/reset mass uniformly
over reachable positive-distance cells. No filtering using t+1 pet outcomes.
Binary NLL clipped at 1e-12, case-macro averaging. Required: ≥8% Brier
reduction and strictly positive NLL gain against both comparators and strict
majority of cases improve Brier vs uniform-directed. Report actual stationed
and door count subsets descriptively only. No solver/alternate mode scoring.

Best pre-human physical staffing ETA is exactly one: exclude already staffed
rooms even if another slower matching exists. Observed post-human current
staffing is used to certify exact closure opportunity at next state only.
No archived selected role bit is assumed.

After explicit exclusive CPU clearance only:
```sh
D=ahc008_terry_cat_eta1
(cd "$D" && sha256sum -c FROZEN.sha256)
python "$D/make.py"
g++ -std=c++23 -O2 "$D/observer.private.cpp" -o "$D/observer"
python "$D/run.py" "$D/observer" > "$D/result.json"
```
The compiler source includes authorized own First-Chase exact geometry;
main is replaced and no normal/chase policy is invoked. Guard poses derive
only from actual positions and shape. Estimated compile under 12s, pure
exposure around 1–4s, optional postgate prediction around 2–10s, depending
on machine/cache.
