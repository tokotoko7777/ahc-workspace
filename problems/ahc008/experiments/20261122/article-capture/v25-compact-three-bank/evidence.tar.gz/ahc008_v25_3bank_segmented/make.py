from pathlib import Path
import argparse,hashlib
a=argparse.ArgumentParser()
a.add_argument('original',type=Path);a.add_argument('out',type=Path)
a.add_argument('--dry',action='store_true')
x=a.parse_args(); d=x.original.read_bytes()
assert hashlib.sha256(d).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=d.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:160]
 s=s.replace(a,b)
rep('const Mask& wall,int stop=100,const Mask& extraWalls={}){',
    'const Mask& wall,int stop=100,const Mask& extraWalls={},bool segmentLocal=false){')
rep('''   for(int parity=0;parity<2;parity++)for(int j=l+parity;j<r;j+=2)local.push_back(ids[j]);
   if(tubes[ids[l]].bank&1)''','''   // Same stock parity sweep, but each true contiguous row run finishes
   // before the path crosses the gap to the next run.
   for(int first=l;first<r;){
    int beyond=first+1;
    if(!segmentLocal)beyond=r;
    else while(beyond<r&&tubes[ids[beyond]].row==tubes[ids[beyond-1]].row+2)++beyond;
    for(int parity=0;parity<2;parity++)
     for(int j=first+parity;j<beyond;j+=2)local.push_back(ids[j]);
    first=beyond;
   }
   if(tubes[ids[l]].bank&1)''')
if not x.dry:
    rep('   terryBuild.initialize(install,humans,{},133,plan);',
        '   terryBuild.initialize(install,humans,{},133,plan,humans.size()==5);')
    rep('  if(narrowRescue&&humans.size()<=6)bankN=2;','''  const bool compactThird=narrowRescue&&humans.size()==5;
  if(narrowRescue&&humans.size()<=6)bankN=compactThird?3:2;''')
    rep('   for(int r=3;r<=(bankN==2?27:25);r+=2){\n    TubeBank x',
        '''   for(int r=3;r<=(compactThird||bankN==2?27:25);r+=2){
    if(compactThird){
     const int slot=(r-3)/2,gap=j==1?6:2;
     if(gap<=slot&&slot<gap+4)continue;
    }
    TubeBank x''')
x.out.write_text(s)
