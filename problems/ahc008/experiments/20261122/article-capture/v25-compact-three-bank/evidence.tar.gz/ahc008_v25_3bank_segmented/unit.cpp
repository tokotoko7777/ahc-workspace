#define main old_entry
#include "solve.cpp"
#undef main
int main(){
 for(int p=0;p<900;p++)nb[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 for(int m:{5,6,7}){
  auto g=std::make_unique<Game>();
  g->humans={0,899,222,450,740,380,509};g->humans.resize(m);
  g->workers.resize(m);g->bankMode=5;
  // Different longitudinal starting locations deliberately influence
  // stock's (unchanged) public-position orientation scorer.
  g->pets={{123,1},{206,5},{730,4}};
  g->terryLayout(5);
  assert(g->bankN==(m==6?2:3));
  assert(g->banks.size()==size_t(m==5?27:m==6?26:36));
  assert(g->bankWalls.size()==size_t(m==5?132:m==6?112:156));
  BitGridComponents<30,30>::Rows remaining{};
  for(int r=0;r<30;r++)remaining[r]=(1<<30)-1;
  auto erase=[&](int p){remaining[p/30]&=~(1u<<(p%30));};
  for(int p:g->bankWalls)erase(p);
  vector<terry_build::Tube> tubes;
  vector<array<int,2>> laneCheck;
  for(int i=0;i<int(g->banks.size());i++){
   const auto& t=g->banks[i];
   if(m==5){
    int slot=(t.r-3)/2,gap=(t.b==1?6:2);
    assert(slot<gap||slot>=gap+4);
   }
   tubes.push_back({t.b,t.r,t.l,t.h,t.inner,t.side,t.g,t.k});
   erase(t.g);erase(t.k);
   for(int p:t.inner)erase(p);
  }
  BitGridComponents<30,30>::Rows found{};
  int area=0;
  assert((BitGridComponents<30,30>::pop_first(remaining,found,area)));
  int unused;
  assert((!BitGridComponents<30,30>::pop_first(remaining,found,unused)));
  assert(area==900-int(g->bankWalls.size())-6*int(g->banks.size()));
  terry_build::Planner independent;
  assert(independent.initialize(tubes,g->humans,{},133,g->terryBuild.braces(),m==5));
  assert(independent.nominal==g->terryBuild.nominal);
  const auto& stock=g->terryBuild.tasks();
  const auto& ref=independent.tasks();
  for(int p=0;p<m;p++){
   assert(stock[p].size()==ref[p].size());
   for(int j=0;j<int(stock[p].size());j++)assert(stock[p][j].from==ref[p][j].from&&stock[p][j].walls==ref[p][j].walls);
  }
  assert(g->bankRelease==225&&g->rescueMode==1);
 }
}
