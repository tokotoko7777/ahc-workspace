# Compact three-bank split layout on v25-fast2, M5 only

The single candidate is 132 shoulders, 27 original exact-two-door four-cell cages, four connected service aisles. Across every bank's 13 original odd-row slots, remove exactly four consecutive slots, starting at zero-based (2,6,2). The layout stays physically fixed for each shift/transpose; same original visible orientation scoring with its three-bank horizontal shifts, not score-trained. See the pure topology checks in ahc008_v25_3bank_compact (all-closed exterior606; centered gate-legal central floor Manhattan coverage max12/758 within6).
 
The original FIFO constructor now orders parity independently within each contiguous run for **this map only**. Each pair of runs is contiguous in route order, without interleaving and recrossing its gap on the opposite parity. Existing exact wall dedup/ownership, static route DP and four mirrored options, dynamic blockers, guard commands, 4-lane stock handoff, stop times, and t160 >4 rescue are unchanged. The shift and extra aisle can affect observed starts/residual and therefore policy branches; no forced release. This is not old v20: only two runs per bank and staggered holes (no requirement to make full transverse holes), 132 vs 144 braces, faster current v25 baseline.

Dry fixtures 18 per arm (three visible-generation-independent human placements x three offset slots x both transposes). Stock 112 shoulders: nominal min/median/max 60/63/66, handoff 63/67/71; new 132 segmented nominal 69/70/73, handoff 73/75/77. Paired nominal increase 5/7/12 respects the predeclared median <=12 gate; handoff +5/+8/+14. Every fixture had uniquely assigned complete adjacent wall jobs, no fallback, and real reachability to 3 or 4 aisle job positions with duplicated central ones as applicable. Dry tests ignore actual animal blockers and do not estimate true capture or timing. One live-geometry unit verifies exact serialized walls, phase and original job lists for M5/M6/M7 startup (M6 and higher do not use the alteration). 

    python ahc008_v25_3bank_segmented/make.py ahc008_v25_fast_static/solve.cpp ahc008_v25_3bank_segmented/dry_generated.cpp --dry
    python ahc008_v25_3bank_segmented/make.py ahc008_v25_fast_static/solve.cpp ahc008_v25_3bank_segmented/solve.cpp
    cd ahc008_v25_3bank_segmented
    g++ -std=c++23 dry.cpp -o dry && ./dry > dry.csv
    g++ -std=c++23 solve.cpp -o solve
    g++ -std=c++23 unit.cpp -o unit && ./unit

No official benchmark run here. Existing AHC008_TERRY_LOG, rescue, and integrated stage telemetry can measure actual predeadline brace readiness, first genuine staffing/captures and downstream score. Dry eligibility is not adoption; measure actual useful capture gain and area against only one unchanged control.
