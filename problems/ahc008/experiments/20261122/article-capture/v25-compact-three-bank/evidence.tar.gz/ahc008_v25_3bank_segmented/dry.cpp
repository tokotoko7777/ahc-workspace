#define main dry_hidden
#include "dry_generated.cpp"
#undef main
using namespace terry_build;
int main(){
 int worlds=0;
 for(int alt:{0,1})for(int rot:{0,1})for(int transform=0;transform<3;transform++){
  const int offset=alt?2+2*transform:4+4*transform;
  auto xy=[&](int r,int c){return rot?c*30+r:r*30+c;};
  vector<Tube> tubes;
  Mask walls;
  vector<vector<int>> roads(alt?4:3);
  for(int j=0;j<int(roads.size());j++)for(int r=0;r<30;r++)roads[j].push_back(xy(r,offset+7*j));
  for(int b=0;b<(alt?3:2);b++)for(int i=0;i<13;i++){
   if(alt&&(b==1?6:2)<=i&&i<(b==1?10:6))continue;
   int r=3+2*i,c=offset+7*b;
   Tube t{b,r,xy(r,c),xy(r,c+7),{}, {},xy(r,c+1),xy(r,c+6)};
   for(int k=0;k<4;k++){
    t.body[k]=xy(r,c+2+k);
    for(int d:{-1,1}){int w=xy(r+d,c+2+k);t.brace.push_back(w);walls[w]=1;}
   }
   tubes.push_back(t);
  }
  assert(tubes.size()==(alt?27:26)&&walls.count()==(alt?132:112));
  for(int scenario=0;scenario<3;scenario++){
   const vector<vector<int>> starts={{xy(0,0),xy(0,29),xy(29,0),xy(29,29),xy(15,15)},
                    {xy(2,6),xy(4,10),xy(12,12),xy(14,17),xy(23,29)},
                    {xy(0,14),xy(12,14),xy(23,14),xy(29,14),xy(26,14)}};
   const auto& people=starts[scenario];
   Planner p;
   assert(p.initialize(tubes,people,{},133,walls,alt));
   assert(p.nominal<133&&p.fallbackWalls().none());
   Mask owned;
   for(const auto& tasks:p.tasks())for(const auto& step:tasks)for(int q:step.walls){
    assert(!owned[q]&&walls[q]&&!walls[step.from]);
    auto next=terry_build::neighbors(step.from);
    assert(find(next.begin(),next.end(),q)!=next.end());
    owned[q]=true;
   }
   assert(owned==walls);
   auto hand=p.handoff(35,people,{}, {},roads,{});
   assert(hand.eta>=0&&hand.actor.size()==5);
   auto al=p.relayLane;sort(al.begin(),al.end());
   assert(al==(alt?vector<int>{0,1,1,2,3}:vector<int>{0,0,1,1,2}));
   for(int i=0;i<5;i++)assert(p.relayTarget[i]>=0&&!walls[p.relayTarget[i]]);
   cout<<alt<<','<<rot<<','<<offset<<','<<scenario<<','<<p.nominal<<','<<hand.eta<<'\n';
   ++worlds;
  }
 }
 assert(worlds==36);
}
