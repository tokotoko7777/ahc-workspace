#define main old_main
#include "../ahc008_v25_fast_static/solve.cpp"
#undef main
using namespace terry_build;
int main(){
 int worlds=0;
 for(int split:{0,1})for(int rot:{0,1})for(int offset:{2,4,6}){
  auto xy=[&](int r,int c){return rot?c*30+r:r*30+c;};
  vector<Tube> tubes;
  Mask walls;
  vector<vector<int>> roads(4);
  for(int j=0;j<4;j++)for(int r=0;r<30;r++)roads[j].push_back(xy(r,offset+7*j));
  for(int b=0;b<3;b++)for(int i=0;i<(split?13:9);i++){
   if(split&&(b==1?6:2)<=i&&i<(b==1?10:6))continue;
   int r=3+2*i+(split?0:4*b),c=offset+7*b;
   Tube t{b,r,xy(r,c),xy(r,c+7),{}, {},xy(r,c+1),xy(r,c+6)};
   for(int k=0;k<4;k++){
    t.body[k]=xy(r,c+2+k);
    for(int d:{-1,1}){int w=xy(r+d,c+2+k);t.brace.push_back(w);walls[w]=1;}
   }
   tubes.push_back(t);
  }
  assert(tubes.size()==27&&walls.count()==(split?132:120));
  for(int scenario=0;scenario<3;scenario++){
   vector<int> people={xy(0,0),xy(0,29),xy(29,0),xy(29,29),xy(15,15)};
   if(scenario==1)people={xy(2,offset+2),xy(4,offset+3),xy(12,offset+9),
                          xy(14,offset+17),xy(23,29)};
   if(scenario==2)people={xy(0,offset+7),xy(12,offset+7),xy(23,offset+7),
                          xy(29,offset+7),xy(26,offset+7)};
   Planner p;
   assert(p.initialize(tubes,people,{},133,walls));
   assert(p.nominal<133&&p.fallbackWalls().none());
   Mask owned;
   for(auto& tasks:p.tasks())for(auto& step:tasks)for(int q:step.walls){
    assert(!owned[q]&&walls[q]&&!walls[step.from]);
    auto nb=terry_build::neighbors(step.from);
    assert(find(nb.begin(),nb.end(),q)!=nb.end());
    owned[q]=true;
   }
   assert(owned==walls);
   auto hand=p.handoff(35,people,{}, {},roads,{});
   assert(hand.eta>=0&&hand.actor.size()==5);
   auto al=p.relayLane;sort(al.begin(),al.end());
   assert(al==(vector<int>{0,1,1,2,3}));
   for(int i=0;i<5;i++)assert(p.relayTarget[i]>=0&&!walls[p.relayTarget[i]]);
   cout<<split<<','<<rot<<','<<offset<<','<<scenario<<','<<p.nominal<<','<<hand.eta<<'\n';
   ++worlds;
  }
 }
 assert(worlds==36);
}
