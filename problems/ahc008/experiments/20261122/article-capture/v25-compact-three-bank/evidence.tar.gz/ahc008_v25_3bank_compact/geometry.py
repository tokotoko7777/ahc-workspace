"""Small deterministic exact physical check; no simulated days/solver/tester."""
from collections import deque
from statistics import mean
S=30
BOARD=set((r,c) for r in range(S) for c in range(S))
def adj(p):
    r,c=p
    return tuple(x for x in ((r+1,c),(r-1,c),(r,c+1),(r,c-1)) if x in BOARD)
def dists(src,passable):
    d=dict.fromkeys(src,0)
    q=deque(d)
    while q:
        p=q.popleft()
        for v in adj(p):
            if v in passable and v not in d:
                d[v]=d[p]+1;q.append(v)
    return d
def layout(k,offset,rot,split=False):
    coords=lambda r,c:(c,r) if rot else (r,c)
    rows=[range(3,28,2)]*2 if k==2 else [range(3+4*b,20+4*b,2) for b in range(3)]
    if split:
        rows=[[r for i,r in enumerate(range(3,28,2)) if not (2,6,2)[b]<=i<(2,6,2)[b]+4] for b in range(3)]
    walls=set();traps=[]
    for b,rr in enumerate(rows):
        c=offset+7*b
        for r in rr:
            body={coords(r,j) for j in range(c+2,c+6)}
            brace={coords(r+d,j) for d in (-1,1) for j in range(c+2,c+6)}
            gates={coords(r,c+1),coords(r,c+6)}
            guards={coords(r,c),coords(r,c+7)}
            safe={coords(r,c+3),coords(r,c+4)}
            assert body-{q for v in gates for q in adj(v)}==safe
            assert len(body)==4 and len(safe)==2 and len({sum(q)%2 for q in safe})==2
            assert all(any(gg in adj(q) for gg in guards) for q in gates)
            traps.append((body,gates,guards,safe));walls|=brace
    assert len(traps)==(26 if k==2 else 27)
    assert len(walls)==(112 if k==2 else 132 if split else 120)
    bodies=set().union(*(x[0] for x in traps))
    gates=set().union(*(x[1] for x in traps))
    assert len(bodies)==4*len(traps) and len(gates)==2*len(traps)
    assert not walls&(gates|bodies) and not gates&bodies
    remaining=BOARD-walls-gates-bodies
    assert set(dists({coords(0,0)},remaining))==remaining
    for b,g,h,s in traps:
        assert h<=remaining
        # Only seal this one tube; all other gates remain open.
        assert set(dists({next(iter(b))},BOARD-walls-g))==b
        assert len(dists({next(iter(h))},BOARD-walls-g))==900-len(walls)-6
    src=set().union(*(x[3] for x in traps))
    d=dists(src,BOARD-walls)
    assert len(d)==900-len(walls)
    laneCols=[offset+7*j for j in range(k+1)]
    aisle={}
    sample=[]
    for j in range(k):
        for r in range(S):
            p=coords(r,laneCols[j]);q=coords(r,laneCols[j+1])
            if all(v in remaining for v in (p,q)):
                aisle.setdefault(p,dists({p},remaining))
                sample.append(aisle[p][q])
    dd=[min(abs(r-a)+abs(c-b) for a,b in src) for r,c in BOARD]
    return (len(traps),len(walls),len(remaining),mean(dd),max(dd),sum(x<=6 for x in dd),mean(d.values()),max(d.values()),
            max(d[q] for q in ((0,0),(0,29),(29,0),(29,29))),mean(sample),max(sample))

if __name__=='__main__':
    print('banks,offset,rot,split,traps,shoulders,all-shut-exterior,mean-MD,max-MD,MD-within6,mean-distance-to-safe-floor,max-distance,corner-worst,mean-adjacent-lane-row-distance-all-shut,max-adjacent-lane-row-distance-all-shut')
    for k,choices,split in ((2,(4,8,12),False),(3,(2,4,6),False),(3,(2,4,6),True)):
        for offset in choices:
            baseline=None
            for rot in (0,1):
                result=layout(k,offset,rot,split)
                if baseline: assert result==baseline
                else: baseline=result
                print(k,offset,rot,int(split),*result,sep=',')
