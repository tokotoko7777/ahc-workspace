# Compact third bank topology, no live solver variant

Stock M5 2×13 is compared to two prospective 3×9 geometries only by deterministic fixtures:
* 120 shoulders: continuous rows 3–19 / 7–23 / 11–27.
* 132 shoulders: start with rows 3,5,...,27 in each bank, remove four consecutive slots from each bank with zero-based starts (2,6,2). Outer runs have 2+7 each, middle 6+3. Every longitudinal tube row is still represented. Selected as a fixed prospective candidate for better spatial coverage, not a score-tuned choice.

Run from this directory:
    python geometry.py > geometry.csv
    g++ -std=c++23 constructor_unit.cpp -o constructor_unit && ./constructor_unit > constructor.csv

Both geometries retain 27 exact two-ended four-cell traps, no overlapping physical gates/bodies, both central checkerboard colors, full axial service floors and top/bottom transit. Each original atomic closure was independently exact; all sealed leave a fully connected exterior. 132 layout leaves 606 cells with all 27 sealed (vs 632 stock) and reduces static distances to one of the modeled catchable center cells. These are not pet motion or forecast scores. The split case differs from failed v20's aligned three runs of three and 144 shoulders.

The second fixture exercises unchanged production v25-fast2 parity/FIFO constructor and current minimax handoff. All six shift/transpose combinations per geometry across 3 synthetic starts (corners, future brace cells, clustered one aisle) have fully owned, uniquely assigned legal adjacent brace jobs and valid 4-lane plus one duplicated central lane handoff. Inputs do not use past benchmark outcomes. Maketime and handoff columns are dry initial estimates, not actual pet-blocked completion. No live code or official/timed cases.
