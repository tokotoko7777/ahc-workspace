"""Pair by input hash and pet index; no matching by final position or order."""
import argparse, collections, csv, json, pathlib
p=argparse.ArgumentParser()
p.add_argument('ledger',type=pathlib.Path)
p.add_argument('inputs',type=pathlib.Path)
p.add_argument('--turns',type=int,nargs='+',default=[75,100,120,160,225,300])
a=p.parse_args()
rows=collections.defaultdict(dict)
for r in csv.DictReader(a.ledger.open()):
 assert r['model'] not in rows[r['case']]
 rows[r['case']][r['model']]=r
kname=['','cow','pig','rabbit','dog','cat']
counts={turn:{k:collections.Counter() for k in ('baseline_4','candidate_4','extra_4','lost_4','baseline_same_4_by160','baseline_same_4_by300','baseline_same_any_by300','baseline_accessible','candidate_accessible')} for turn in a.turns}

for case,pair in rows.items():
 if set(pair)!={'baseline','article'}:continue
 old,new=(pair[arm] for arm in ('baseline','article'))
 assert old['input_sha256']==new['input_sha256']
 x=(a.inputs/case).read_text().splitlines()
 kind={i:int(x[i+1].split()[2]) for i in range(int(x[0]))}
 def extract(r):
  ev={}
  for s in filter(None,r['captures'].split(';')):
   t,i,k,ar,_=map(int,s.split(':'))
   assert i not in ev and k==kind[i]
   ev[i]=(t,ar)
  assert len(kind)-len(ev)==int(r['final_reachable'])
  return ev
 v0,v1=extract(old),extract(new)
 for turn,c in counts.items():
  o={i for i,(t,ar) in v0.items() if t<=turn and ar==4}; n={i for i,(t,ar) in v1.items() if t<=turn and ar==4}
  join={
   'baseline_4':o, 'candidate_4':n, 'extra_4':n-o, 'lost_4':o-n,
   'baseline_same_4_by160':{i for i in n-o if i in v0 and v0[i][0]<=160 and v0[i][1]==4},
   'baseline_same_4_by300':{i for i in n-o if i in v0 and v0[i][1]==4},
   'baseline_same_any_by300':{i for i in n-o if i in v0},
   'baseline_accessible':{i for i in kind if i not in v0 or v0[i][0]>turn},
   'candidate_accessible':{i for i in kind if i not in v1 or v1[i][0]>turn},
  }
  for k,ids in join.items():c[k].update(kname[kind[i]] for i in ids)
out={turn:{k:dict(total=sum(v.values()),**v) for k,v in c.items()} for turn,c in counts.items()}
print(json.dumps(out,indent=2))
