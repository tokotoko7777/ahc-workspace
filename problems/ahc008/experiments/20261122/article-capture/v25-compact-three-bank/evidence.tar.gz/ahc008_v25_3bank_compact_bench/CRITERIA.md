# Fixed M5-only compact 3×9 pilot
Single integrated treatment: two-run compact 3-bank M5 layout, gaps (2,6,2)
and a segment-local parity task order compatible with that geometry.
No reserve/commit/late controller parameter changes, no other team sizes.

Run identical historical M5 30 with official tester + independently scored
replay. Development gate: zero legal failures; strictly higher total score;
useful whole improved and raw whole not lower. Report secondary evidence of
actual t75/t100 braces, staffed/first legal captures, exact4 at t100 and t160,
reserve area, final species/IDs and both machine times. A higher number of
local traps or dry preflight are not grounds to pass. If failing on these
blind fixed gates, save outcome and no held. If passing, freeze exact
unchanged implementation and test one new M5 100 seed manifest followed,
if confirmed, by practice100 and general independent100. The branch can
only be promoted to research best after exact broad checks and no serious
performance regression; official original judge ranking remains unverified.
