#define main archived_interactive_main
#include "solve.private.cpp"
#undef main
#include <random>
int main(){
 using namespace terry_exact_root;
 std::mt19937 rng(1960432);
 for(int t=0;t<3000;++t){
  State s;
  for(int p=0;p<V;++p) if(int(rng()%9)<t%9)s.walls.set(p);
  std::vector<int> open;
  for(int p=0;p<V;++p)if(!s.walls[p])open.push_back(p);
  assert(!open.empty());
  for(int i=0;i<t%11+1;++i)s.people.push_back(open[rng()%open.size()]);
  for(int i=0;i<t%21;++i)s.pets.push_back({open[rng()%open.size()],1,-1});
  bool expected=true;
  for(int h:s.people){
   Dist d; bfs(s.walls,h,d);
   for(const auto& p:s.pets)if(d[p.pos]<INF)expected=false;
  }
  assert(globally_clear(s)==expected);
 }
 std::puts("3000 exact multi-worker global isolation predicates match independent BFS");
}
