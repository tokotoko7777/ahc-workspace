"""Read signed old tapes; all predicates use only each current observed state."""
import hashlib
import json
import sys
from fractions import Fraction
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import case_history, mask, B, ALL, flood
signed=R/'ahc008_terry_hunt_wall_audit/recordings.json'
raw=signed.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
cases=json.loads(raw)
assert len(cases)==100
def evidence(st):
    p,h,w=st
    comp=flood(mask(h),ALL^w)
    if comp&mask(p):return None
    look={}
    for s in h:
        if s not in look:look[s]=flood(B[s],ALL^w).bit_count()
    return Fraction(sum(look[x] for x in h),len(h))
results=[]
for x in cases:
    kinds,hist,cmd=case_history(x)
    z=None
    for t,st in enumerate(hist):
        if t>0 and hist[t-1][2]==st[2]: continue
        e=evidence(st)
        if e is not None:
            finale=evidence(hist[-1])
            assert finale is not None and finale<=e
            z=dict(case=x['case'],turn=t,tail=300-t,old_extra_walls=(hist[-1][2]^st[2]).bit_count(),
                   gained_floor=str(e-finale))
            break
    if z:results.append(z)
total=sum(z['tail'] for z in results)
count=sum(z['tail']>0 for z in results)
gain=sum(Fraction(z['gained_floor']) for z in results)
gained=sum(Fraction(z['gained_floor'])>0 for z in results)
data=dict(certificates=len(results),decision_turns_skipped=total,skipped_boards=count,
          safety_area_floor_sum=str(gain),gained_boards=gained,post_walls=sum(z['old_extra_walls']for z in results),
          gate=(total>=2000 and count>=30)or(gain>=25 and gained>=5),boards=results)
print(json.dumps(data,indent=2))
