# Native admission only after both fixed-work CPU gates
The production change is certificate-only; waiting is mathematically
score-nonworsening from the same globally isolated state. Real clock
behavior before closure may still differ through changed setup cost and
completed rollout count; verify separately. Use identical native2670ms,
preexisting official distributed100 and independent locked100, official
test, official playback and independent score/legality for each. Admit
only if total score, full and useful counts are nonlower on both and
each listed local max tester wall <2.95 sec. Compare any changed late mode
explicitly. Standard bench/summarize calculate official scores and capture
counts, not an identical-action goal; 100% all-dot suffixes after the
certificate were verified under fixed work separately. No score gain
claim unless the official distributed total actually rises.
