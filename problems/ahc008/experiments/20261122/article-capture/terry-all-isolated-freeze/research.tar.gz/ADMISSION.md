# Live admission for certified all-isolated tail shortcut
A prior detached gate passed: 7,597 skipped tail turns on 99/100,
zero further factual walls and no geometric score improvement.
Do not claim 25% CPU savings from turn count. Test the exact-wall-change
guard, including rollout clock exposure, as a separate performance change.
Run 3,000 sparse/dense synthetic board checks against independent queue
BFS first. Then try paired fixed work on the same accepted distributed
100, use exact logged cutoff for reproduction only. If action hashes are
unchanged use the standard fixed-work benchmark. If a legitimate first
difference after verified global clearance appears, do not claim hash
identity or adopt until an independent trace validates that each divergent
suffix follows a true global isolation state. No forced pair counts in
real code. Preregister no deterioration in score, full/useful and local
tester wall <2.95s, at least 2% lower fixed-work total CPU both practice
and independent before a regular-clock gate. A larger observed CPU
cost on average before capture is grounds to reject, not rewrite the
detector until after documenting this result.
