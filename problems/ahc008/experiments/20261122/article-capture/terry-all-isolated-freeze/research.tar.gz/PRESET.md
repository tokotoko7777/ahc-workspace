# Stop all wall construction only after global all-head isolation
AHC008 has monotone wall additions, no demolition, no teleportation, no
legal human or pet step through walls. Once no pet is reachable from
the union of all human components, none can become reachable unless a
wall were removed. After observing this, printing all dots is legal and
cannot worsen score: each human's component can only shrink under any
alternative future additions and its reachable-pet factor is already one.
This is stronger than absence of pets from the majority component, and
does not rely on any pet model. Check only following an actual wall
batch; if walls do not change, all prior component memberships persist.
The detector is used on real turns only; the policy, RNG, game replies
and build logic up to the certificate remain untouched.

First detached audited signed incoming held100 t0–299: record for
each original factual tape earliest exact global all-isolated state,
post-certificate wall count, exact scored mean floor then versus the
actual original terminal, skipped Normal/Chase turns, and legality
under changed actual pet RNG not asserted by a replay. Geometry gives
a proof regardless of future replies. Objective pilot gate: ≥2000
decision turns skipped across ≥30 boards, or ≥25 total certified
worker-floor tiles saved (across ≥5 boards) if no changes earlier.
Otherwise don't compile: cost of repeated all-worker flood may dominate
if attained late. If passed, benchmark live candidate sequential official
practice100 and independent100 for strictly nonnegative score/full
(count) and no earlier action changes; report real CPU (with same clock
separate from deterministic trajectory proof), max wall <2.95 sec.
