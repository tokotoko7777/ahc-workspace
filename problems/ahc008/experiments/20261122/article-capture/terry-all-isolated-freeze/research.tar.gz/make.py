"""Exact globally isolated termination of live policy; no private assembled upload."""
from pathlib import Path
import hashlib
d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_split_bound/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='f83fd83450294a9730664fa98a76b0dde95c814cd6fd2cce0bcce3635056c088'
a='struct Decision{int pairs=0;int64_t normal=0,chase_sum=0;bool chose=false;};'
assert s.count(a)==1
s=s.replace(a,(d/'connected.hpp').read_text()+a)
old=''' NormalCount metrics;Decision d;
 const auto stop=started+std::chrono::milliseconds(limit_ms);
 for(int turn=0;turn<300;++turn){
  if(turn==275)d=decide(s,policy,cap,stop);
  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'''
new=''' NormalCount metrics;Decision d;
 const auto stop=started+std::chrono::milliseconds(limit_ms);
 bool isolated=false,wallChanged=false;
 const std::string wait(m,'.');
 for(int turn=0;turn<300;++turn){
  if(!isolated&&wallChanged)isolated=globally_clear(s);
  if(!isolated&&turn==275)d=decide(s,policy,cap,stop);
  auto command=isolated?wait:(d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics));
  wallChanged=std::any_of(command.begin(),command.end(),[](char c){return build_dir(c)>=0;});'''
assert s.count(old)==1
s=s.replace(old,new)
(d/'solve.private.cpp').write_text(s)
