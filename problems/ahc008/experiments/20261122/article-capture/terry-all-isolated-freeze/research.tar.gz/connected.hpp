inline bool globally_clear(const State& s){
 static const Mask left_edge=[]{
  Mask z;for(int r=0;r<N;++r)z.set(r*N);
  return z;
 }();
 static const Mask right_edge=left_edge<<(N-1);
 Mask front,seen,pets;
 for(int p:s.people)front.set(p);
 for(const auto& a:s.pets)pets.set(a.pos);
 const auto pass=~s.walls;
 while(front.any()){
  if((front&pets).any())return false;
  seen|=front;
  front=((front<<N)|(front>>N)|((front&~left_edge)>>1)|((front&~right_edge)<<1))&pass&~seen;
 }
 return true;
}
