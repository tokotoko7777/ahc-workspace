"""After legitimate suffix change, A/B CPU plus independent clearance evidence."""
import argparse
import csv
import hashlib
import json
import re
import sys
import tempfile
from pathlib import Path
p=argparse.ArgumentParser()
for n in ('tester','inputs','ledger','old','new','output'):p.add_argument(n,type=Path)
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
h=root/'ahc008_focus_solver/problems/ahc008'
sys.path[:0]=[str(h),str(h/'experiments/20261122')]
from benchmark_cases import run
from benchmark import replay
from guarded_entry_trace import observed
from stochastic_lock_audit import ALL,B,flood,idx
time=root/'ahc008_terry_speed/time'
samples=[x for x in csv.DictReader(a.ledger.open()) if x['arm']=='terry_independent']
out=[]
assert len(samples)==100
for i,x in enumerate(samples):
    name=x['case']; inp=(a.inputs/name).read_bytes()
    assert hashlib.sha256(inp).hexdigest()==x['input_sha']
    draws=int(x['telemetry'].split()[10])
    arms=[('baseline',a.old),('fast',a.new)]
    data={}
    with tempfile.TemporaryDirectory() as loc:
        d=Path(loc);cpu=d/'cpu'
        for tag,src in (arms if i%2==0 else arms[::-1]):
            args=[str(a.tester.resolve()),str(time),str(cpu),str(src.resolve()),f'--pairs={draws}']
            o,err,rc,wall=run(args,inp,4.5)
            assert rc==0 and (m:=re.fullmatch(rb'Score = (\d+)\s*',err)),(name,tag,rc,err)
            s=int(m[1]); digest=hashlib.sha256(o).hexdigest()
            if tag=='baseline':assert digest==x['commands_sha'] and s==int(x['score']),name
            data[tag]=dict(case=name,arm=tag,draws=draws,action_hash=digest,score=s,wall=wall,
                           cpu_us=int(cpu.read_text()),raw=o,err=err)
        # Time already measured. Validate both official playbacks independently.
        histories={}
        for tag,rec in data.items():
            cmds=d/(tag+'.actions'); tape=d/(tag+'.trace')
            cmds.write_bytes(rec['raw'])
            r,er,ret,_=run([str(a.tester.resolve()),sys.executable,str(h/'benchmark_cases.py'),
                             '--playback',str(cmds),str(tape)],inp,12)
            assert (r,er,ret)==(rec['raw'],rec['err'],0)
            trace=tape.read_text().splitlines()
            actions=rec['raw'].decode().splitlines()
            assert len(actions)==300 and trace[::2]==actions
            s=replay(inp.decode(),trace,actions,detailed=True)[0]
            assert s==rec['score']
            _,states,_=observed(inp,trace)
            def globally_full(st):
                ps,hs,ws=st
                passable=ALL^sum(set(B[idx(q)]for q in ws))
                reachable=flood(sum(set(B[idx(q)]for q in hs)),passable)
                return not (sum(set(B[idx(q)]for q in ps))&reachable)
            rec.update(full=int(globally_full(states[-1])))
            histories[tag]=(actions,states)
        old,ost=histories['baseline'];new,nst=histories['fast']
        diff=next((k for k in range(300) if old[k]!=new[k]),300)
        if diff<300:
            assert ost[diff]==nst[diff] and globally_full(nst[diff]),(name,diff)
            assert all(set(line)=={'.'} for line in new[diff:]),name
        assert data['fast']['score']>=data['baseline']['score'] and data['fast']['full']==data['baseline']['full'],name
        for row in data.values():
            row.pop('raw');row.pop('err');row['first_diff']=diff;out.append(row)
    with a.output.open('w')as f:
        w=csv.DictWriter(f,out[0]);w.writeheader();w.writerows(out)
    print(name,diff,flush=True)
