#!/usr/bin/env bash
set -euo pipefail
D=ahc008_terry_all_isolated_freeze
R=ahc008_terry_split_bound
C=ahc008_terry_first_chase_reuse
P=ahc008_focus_solver/problems/ahc008
T=ahc008_focus_assets/tools/target/release/tester
S=ahc008_terry_split_dp/summarize.py
export PYTHONPATH="$PWD/ahc008_integrated_v11:$PWD/$P/experiments/20261122:$PWD/$P:$PWD/ahc008_bridge_audit"
test -s "$D"/practice.speed.json && test -s "$D"/fresh.speed.json
python ahc008_terry_exact_root/bench.py "$P" "$T" "$R/solve" "$D/solve" ahc008_focus_assets/tools/in "$D/practice.default.csv" --n 100 >"$D/practice.default.log" 2>&1
python "$S" "$D/practice.default.csv" >"$D/practice.default.json"
python ahc008_terry_exact_root/bench.py "$P" "$T" "$R/solve" "$D/solve" "$C/default-fresh100/in" "$D/fresh.default.csv" --n 100 >"$D/fresh.default.log" 2>&1
python "$S" "$D/fresh.default.csv" >"$D/fresh.default.json"
