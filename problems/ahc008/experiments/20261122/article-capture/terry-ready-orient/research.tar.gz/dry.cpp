#pragma GCC optimize("O3")
#include "../ahc008_terry_exact_build/exact_build.hpp"
#include "../ahc008_terry_exact_maps/terrain.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <ctime>
#include <map>
#include <set>
using namespace exact_build;
static constexpr int Cap=150;
struct Room{int id;std::vector<int> body,gates,stands,need;};
std::vector<Room> rooms[5];
void read(const char* path){
 std::ifstream f(path);std::string line;
 while(std::getline(f,line)){
  std::istringstream s(line);int m,r,a,b,p;s>>m>>r>>a>>b;
  Room z;z.id=r;
  if(a>=0){z.gates.push_back(a);z.stands.push_back(a-1);}
  if(b>=0){z.gates.push_back(b);z.stands.push_back(b+1);}
  std::array<bool,V> in{};
  while(s>>p)z.body.push_back(p),in[p]=true;
  if(z.body.empty())continue;
  std::set<int> need;
  for(int x:z.body)for(int q:nb(x))
    if(q>=0&&!in[q]&&std::find(z.gates.begin(),z.gates.end(),q)==z.gates.end())need.insert(q);
  z.need.assign(need.begin(),need.end());rooms[m].push_back(std::move(z));
 }
}
uint64_t step(uint64_t& s){
 uint64_t z=(s+=0x9e3779b97f4a7c15ULL);
 z=(z^(z>>30))*0xbf58476d1ce4e5b9ULL;
 z=(z^(z>>27))*0x94d049bb133111ebULL;
 return z^(z>>31);
}
std::vector<int> spawn(int map,int m){
 uint64_t seed=0x125d12c6b56a194fULL^(map*37+m);
 std::vector<int> out;while((int)out.size()<m){
  int p=step(seed)%V;
  if(std::find(out.begin(),out.end(),p)==out.end())out.push_back(p);
 }
 return out;
}
using WallTimes=std::array<int,V>;
Board required(const Crew& c){
 Board b{};
 for(auto& q:c.q)for(auto a:q){
  auto adj=nb(a.at);for(int d=0;d<4;++d)if(a.mask>>d&1)b[adj[d]]=1;
 }
 return b;
}
struct Nominal{int end=0,total=0;};
Nominal nominal(const Crew& c,const std::vector<int>& h,const std::vector<Room>& rooms){
 WallTimes seen;seen.fill(Cap+1);
 int end=0;
 for(int i=0;i<(int)h.size();++i){
  int p=h[i],t=0;
  for(auto a:c.q[i])if(a.mask){
   t+=md(p,a.at);p=a.at;auto adj=nb(p);
   for(int d=0;d<4;++d)if(a.mask>>d&1){++t;seen[adj[d]]=std::min(seen[adj[d]],t);}
  }
  end=std::max(end,t);
 }
 int sum=0;
 for(auto& room:rooms){
  int t=0;for(int x:room.need)t=std::max(t,seen[x]);sum+=t;
 }
 return {end,sum};
}
struct Trial{
 int last=-1;bool conflict=false,stranded=false;
 WallTimes owner{};
 std::vector<int> ready;
 Trial(){owner.fill(-1);}
};
Trial real(Crew c,std::vector<int> h,const std::vector<Room>& rooms,const Board& req){
 Trial r;r.ready.assign(rooms.size(),Cap+1);
 Board w{};
 int left=0;for(auto x:req)left+=x;
 for(int t=1;t<=Cap;++t){
  auto a=c.act_literal(w,h,{}).action;
  Board moving{},busy{};auto next=h;
  for(int i=0;i<(int)h.size();++i)if(a[i]>='A'&&a[i]<='Z'){
   int d=std::find(Move,Move+4,a[i])-Move;int p=nb(h[i])[d];
   if(p<0||w[p]){r.conflict=true;return r;}
   next[i]=p;moving[p]=1;
  }
  for(int p:h)busy[p]=1;
  bool any=false;
  for(int i=0;i<(int)h.size();++i)if(a[i]>='a'&&a[i]<='z'){
   int d=std::find(Put,Put+4,a[i])-Put;int p=nb(h[i])[d];
   if(p<0||w[p]||moving[p]||busy[p]){r.conflict=true;continue;}
   if(!req[p]){r.conflict=true;return r;}
   w[p]=1;r.owner[p]=i;--left;any=true;
  }
  h=std::move(next);
  BFS b;b.run(h[0],w);
  for(int p:h)if(b.d[p]>=INF)r.stranded=true;
  if(any)for(int i=0;i<(int)c.q.size();++i)for(auto a0:c.q[i])if(a0.mask){
   bool need=false;auto adj=nb(a0.at);
   for(int d=0;d<4;++d)if((a0.mask>>d&1)&&!w[adj[d]])need=true;
   if(need&&(w[a0.at]||b.d[a0.at]>=INF))r.stranded=true;
  }
  Board who{};for(int p:h)who[p]=1;
  for(int k=0;k<(int)rooms.size();++k)if(r.ready[k]>Cap){
   auto& z=rooms[k];
   if(std::any_of(z.body.begin(),z.body.end(),[&](int p){return w[p]||who[p];}))continue;
   if(std::any_of(z.gates.begin(),z.gates.end(),[&](int p){return w[p]||who[p];}))continue;
   if(std::any_of(z.stands.begin(),z.stands.end(),[&](int p){return p<0||p>=V||b.d[p]>=INF;}))continue;
   if(std::any_of(z.need.begin(),z.need.end(),[&](int p){return !w[p];}))continue;
   // The catalog body is connected; every orthogonal boundary not in
   // its gate mask is now an actual wall, exactly certifying shape.
   r.ready[k]=t;
  }
  if(!left&&r.last<0)r.last=t;
  if(r.last>=0&&std::all_of(r.ready.begin(),r.ready.end(),[](int u){return u<=Cap;}))return r;
 }
 return r;
}
struct Candidate{int mask,gain,end;};
void apply(Crew& c,int mask){
 for(int i=0;i<(int)c.q.size();++i)if(mask>>i&1)std::reverse(c.q[i].begin(),c.q[i].end());
}
struct Case{
 int map,m,admissible;
 Layout l;
 std::vector<int> h;
 Crew orig;
 std::vector<Candidate> options;
};
int main(int argc,char** argv){
 if(argc!=2)return 2;
 read(argv[1]);int boards=0,baseBad=0,finalists=0,wins=0,improvements=0, supported=0;
 const auto tick=clock();
 std::cout<<"type,map,workers,mask,allowed_workers,proxy_gain,orig_t,cand_t,improved4,delta_ready,reason,cpu_sec\n";
 std::vector<Case> panel;
 for(int map=0;map<5;++map)for(int m=5;m<=10;++m){
  Case z;z.map=map;z.m=m;const auto& a=terry_exact_maps::terrain(map);
  z.l.aisleRows=a.aisleRows;z.l.aisleCols=a.aisleColumns;
  for(int p=0;p<V;++p)z.l.ascii[p]=char(a.cells[p]);
  z.h=spawn(map,m);if(!z.orig.init(z.l,z.h))return 3;
  const auto n=nominal(z.orig,z.h,rooms[map]);
  int mask=0;
  for(int i=0;i<m;++i)if(z.orig.q[i].size()>1){
   auto c=z.orig;apply(c,1<<i);auto v=nominal(c,z.h,rooms[map]);
   if(v.end<=n.end)mask|=1<<i;
  }
  z.admissible=mask;
  for(int bits=mask;bits;bits=(bits-1)&mask){
   auto c=z.orig;apply(c,bits);auto v=nominal(c,z.h,rooms[map]);
   if(v.end<=n.end&&v.total<n.total)z.options.push_back({bits,n.total-v.total,v.end});
  }
  std::sort(z.options.begin(),z.options.end(),[](auto a,auto b){
   return std::tuple{-a.gain,a.end,std::popcount(unsigned(a.mask)),a.mask}<
          std::tuple{-b.gain,b.end,std::popcount(unsigned(b.mask)),b.mask};
  });
  if(!z.options.empty())++supported;
  std::cout<<"support,"<<map<<','<<m<<','<<mask<<','<<std::popcount(unsigned(mask))<<','
   <<(z.options.empty()?0:z.options.front().gain)<<",,,,,options_"<<z.options.size()<<",0\n";
  panel.push_back(std::move(z));
 }
 if(supported<8){
  std::cerr<<"proxy_supported "<<supported<<" exact_skipped 1 cpu "<<double(clock()-tick)/CLOCKS_PER_SEC<<" go 0\n";
  return 0;
 }
 for(auto& z:panel){
  auto [map,m]=std::pair(z.map,z.m);auto& h=z.h;auto& orig=z.orig;
  auto req=required(orig);
  auto base=real(orig,h,rooms[map],req);
  if(base.last<0){++baseBad;std::cout<<"board,"<<map<<','<<m<<",,,,,-1,-1,0,0,base_unfinished,0\n";continue;}
  bool good=false,improve=false;auto& options=z.options;
  for(int k=0;k<std::min(8,int(options.size()));++k){
   const auto& s=options[k];auto c=orig;apply(c,s.mask);++finalists;
   const auto t0=clock();auto now=real(c,h,rooms[map],req);
   std::string why="ok";int faster=0, v=0;
   if(now.conflict)why="illegal";
   else if(now.stranded)why="stranded";
   else if(now.last<0||now.last>base.last)why="makespan";
   else if(now.owner!=base.owner)why="owner";
   else{
    for(int j=0;j<(int)base.ready.size();++j)if(base.ready[j]<=Cap){
     if(now.ready[j]>Cap)why="lost_room";
     faster+=now.ready[j]+4<=base.ready[j];
     v+=base.ready[j]-now.ready[j];
    }
    for(int goal:{(base.last+2)/3,(base.last*2+2)/3,base.last}){
     auto f=[&](const auto& arr){return std::count_if(arr.begin(),arr.end(),[&](int x){return x<=goal;});};
     if(f(now.ready)<f(base.ready))why="checkpoint";
    }
    if(why=="ok"&&v<=0)why="no_gain";
   }
   improve|=why=="ok";good|=why=="ok"&&faster>=2;
   std::cout<<"trial,"<<map<<','<<m<<','<<s.mask<<','<<std::popcount(unsigned(z.admissible))<<','<<s.gain<<','
      <<base.last<<','<<now.last<<','<<faster<<','<<v<<','<<why<<','<<double(clock()-t0)/CLOCKS_PER_SEC<<'\n';
  }
  ++boards;wins+=good;improvements+=improve;
  std::cout<<"board,"<<map<<','<<m<<",,,,"<<base.last<<",0,0,0,"<<(good?"win":improve?"small":"none")<<",0\n";
 }
 std::cerr<<"proxy_supported "<<supported<<" boards "<<boards<<" base_bad "<<baseBad<<" finalists "<<finalists
  <<" improvements "<<improvements<<" wins "<<wins<<" cpu "<<double(clock()-tick)/CLOCKS_PER_SEC
  <<" go "<<(boards==30&&wins>=8)<<'\n';
}
