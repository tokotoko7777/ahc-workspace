# Frozen whole-queue orientation trial

New deterministic no-pet synthetic panel (five maps × M5…M10), distinct
SplitMix64 namespace salt 0x125d12c6b56a194f. No official inputs, real pets,
live policy, or retuning. Keep the original exact DP assignment unchanged.
Each eligible toggle reverses one entire nontrivial materialized stance
and mask queue, no task or ownership changes. Eligibility is reversed
nominal worker completion within original global nominal bottleneck.

Enumerate every admissible joint mask (≤1024 per board), retaining strictly
positive nominal room ready-time gains and no proxy makespan regression.
Rank aggregate gain, then estimated makespan, fewer reversed owners and
mask ID. Fewer than eight proxy-positive boards is an early NO-GO with
no expensive exact simulation. Otherwise exactly check at most eight
finalists per board, following unchanged ahc008_terry_ready_order exact
validator, nominal room masks, dry horizon 150, no-pet literal crew/relay,
all nominal assigned actual walls and same true original writer, no
additional disconnection/stranded pending tasks or makespan regression,
no lost usable room, no usable counts regression by original thirds,
and better aggregate usable time. Meaningful winning board: two rooms
≥4 turns earlier. GO only ≥8/30 such boards, all original dry controls
complete. No subsequent changes or sequential tuning whichever result.
