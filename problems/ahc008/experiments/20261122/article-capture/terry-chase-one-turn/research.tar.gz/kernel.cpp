// Reuse the independently verified factual shape projector, exact
// distinct-worker matcher, parser, and physical-grid implementation.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wreturn-type"
#define main equal_flow_unused_main
#include "../ahc008_terry_chase_cut_ties/kernel.cpp"
#undef main
#pragma GCC diagnostic pop

using Vec=std::vector<int>;
Vec surviving(const Vec& x,const Board& w) {
    Vec next;
    for(int p:x)if(!w[p])next.push_back(p);
    return next;
}
int main() {
    int board, turn, map, prev_board=-1, prev_turn=-1;
    Vec previous, two_back;
    while(std::cin>>board>>turn>>map) {
        const auto people=read_vec(), pet=read_vec(), closed=read_vec();
        Board wall,blocked;
        for(int v:closed)wall.set(v);
        blocked=wall;
        for(int h:people)blocked.set(h);
        for(int v:pet) {
            blocked.set(v);
            for(int n:p::neighbors(v))if(n>=0)blocked.set(n);
        }
        const auto targets=p::majorityPets(wall,people,pet);
        const auto fresh=p::shape<MaxFlow<int>>(wall,terry_exact_maps::terrain(map).aisleCells,
                                              people,targets,turn).walls;
        if(board!=prev_board) {
            assert(turn==275);
            prev_board=board;prev_turn=turn;previous=fresh;two_back.clear();
            continue;
        }
        assert(turn==prev_turn+1);
        prev_turn=turn;
        const Vec stale=surviving(previous,wall);
        const bool aba=turn>=277 && !fresh.empty() && fresh!=stale && surviving(two_back,wall)==fresh;
        two_back=previous;previous=fresh;
        std::cout<<board<<' '<<turn<<' '<<aba;
        const auto end=[&](std::string_view text){std::cout<<' '<<text<<'\n';};
        if(targets.empty()){end("no_target");continue;}
        if(stale.empty()||fresh.empty()){end("empty_mask");continue;}
        if(stale==fresh){end("equal");continue;}
        const auto blocked_any=[&](const Vec& x) {
            return std::any_of(x.begin(),x.end(),[&](int i){return blocked[i];});
        };
        if(blocked_any(stale)||blocked_any(fresh)){end("blocked");continue;}
        Board sw=wall,fw=wall;
        for(int q:stale)sw.set(q);
        for(int q:fresh)fw.set(q);
        const auto before=evaluate(wall,people,pet);
        const auto n=evaluate(fw,people,pet),o=evaluate(sw,people,pet);
        if(n.ids!=o.ids){end("different_animals");continue;}
        if(!(n.ids&~before.ids)||(before.ids&~n.ids)){end("no_new_capture");continue;}
        bool includes=true;
        for(int i=0;i<int(people.size());++i)if((n.visible[i]&~o.visible[i]).any())includes=false;
        if(o.sum<n.sum||!includes){end("less_retained_floor");continue;}
        const int e0=eta(fw,people,fresh),e1=eta(sw,people,stale);
        if(std::max(e0,e1)+1>300-turn){end("staff_or_deadline");continue;}
        if(e0-e1<1){end("not_faster");continue;}
        std::cout<<" witness "<<e0<<' '<<e1<<' '<<n.sum<<' '<<o.sum<<' '<<people.size()
                 <<' '<<(n.ids&~before.ids)<<' '<<fresh.size();
        for(int z:fresh)std::cout<<' '<<z;
        std::cout<<' '<<stale.size();
        for(int z:stale)std::cout<<' '<<z;
        std::cout<<'\n';
    }
}
