# Compare previous fresh stock Chase shape to current shape
See PRESET.md for the one fixed diagnostic and gate. This is not
the older v24 last-enclosure state machine or the equal-flow residual
extreme proposal: the alternate is drawn only from the preceding actual
fresh stock Chase wall set. The accepted h123 state/action tapes
and source cut routine are unchanged. No chronological slot scans, new
shapes, alternate actual commands, model or scorer runs. Parent snapshot
archive and its official/independent proof are SHA pinned; the audit
operates on precisely t276..299, including unproductive snapshots.

When CPU is cleared, from this directory only:
    g++ -std=c++23 -O2 -Wall -Wextra kernel.cpp -o /tmp/terry-chase-carryover
    python audit.py /tmp/terry-chase-carryover > report.json

The kernel has a fixed 20-second external bound. A timeout or assertion
means incomplete, not failed evidence. All 168 results must be present.
No future factual pet position authorizes the older wall set, and an
earlier idealized closure time does not guarantee animal retention. A
small count should stop the experiment; do not widen the earlier window.
