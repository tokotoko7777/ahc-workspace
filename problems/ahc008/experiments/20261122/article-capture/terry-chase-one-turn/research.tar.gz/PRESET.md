# One-turn Chase cut carryover: one pre-registered detached screen
Use only 175 original factual accepted-h123 Chase snapshots in the
already exact-verified uniform dev60 equal-flow screen: seven boards,
t275 through t299. Compare the immediately preceding freshly computed
stock maximum-flow wall set, minus walls now built, with today's
fresh stock choice. There are 168 comparisons, including when no target
or no cut is available. No new generator, solver or tester execution.
Neither snapshot selection nor evaluator uses a later observed position.

Require both wall masks distinct, nonempty, currently placeable (!wall,
!people, !pet and not orthogonally adjacent to any pet). On today's
actual board, each hypothetical full wall set must isolate the exact
same nonempty subset of currently human-accessible animal indices from
all humans, allowing no originally isolated animal to reconnect.
For each person, the staged prior set must preserve every formerly
retained human cell of the fresh-set projection (including previous
per-person component volume). Compute actual adjacent reachable stances
on each projected final graph, then exact distinct-worker minimax to
cover every new wall on one turn; no walk through a cut cell, extra
builder, reused future command, virtual route, or cached worker order.
Both assignments complete before t300; prior cut at least one turn
faster. Compare ETA after exact distinct assignment, not sum of actor
distance or number placed. Tie always retains stock.

Above is a static staging certificate, not evidence any pet will remain
or future commands can be borrowed. Deduplicate identical (reduced prior
mask, fresh mask, newly separated IDs) per board. Diagnostic A-B-A
recurrence uses raw stock choices reduced to the same factual board and
is only reported; it does not decide eligibility. Advance only with
at least five unique qualifying states across at least three boards,
or stop without widening. Even passing only warrants a separate
single-candidate fresh uniform100, then independently held100, never
adoption from a detached outcome. No stale older shape or matching can
carry over: a possible variant would still compute fresh every turn,
retain only the immediately previous *fresh stock* wall set and verify
all current constraints from scratch. No timing/compilation until
root gives exclusive clearance.
