"""Read only pinned factual cut snapshots; never call solver or tester."""
import collections
import hashlib
import json
import subprocess
import sys
from pathlib import Path
D=Path(__file__).resolve().parent
SRC=D.parent/'ahc008_terry_chase_cut_ties'
SNAP='1ec7caf338bb5d6bdada7f0719ba84600671f6c744043e4864a48ba71cd60a44'
META='5730834c7b03f89d384c5f7809303b2ec74674b991e587b7fc5917fa7c580f3e'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    kernel=Path(sys.argv[1]).resolve()
    raw=SRC/'snapshots.txt'; m=SRC/'report.json'
    assert digest(raw)==SNAP and digest(m)==META
    parent=json.loads(m.read_text())
    boards=[r['board']for r in parent['tapes'] if r['chase']]
    assert len(boards)==parent['chosen_chase']==7 and parent['n']==60
    src=[tuple(map(int,line.split()[:2]))for line in raw.read_text().splitlines()]
    assert src==[(b,t)for b in boards for t in range(275,300)]
    z=subprocess.run([str(kernel)],input=raw.read_bytes(),capture_output=True,check=True,timeout=20)
    rows=[]; reasons=collections.Counter(); boards_with=set(); keys=set(); aba_count=0
    for x in z.stdout.decode().splitlines():
        b,t,aba,reason,*v=x.split()
        b,t,aba=map(int,(b,t,aba))
        r=dict(board=b,turn=t,aba=bool(aba),reason=reason)
        aba_count+=aba;reasons[reason]+=1
        if reason=='witness':
            a,c,af,cf,m,ids,n,*w=map(int,v)
            assert a-c>=1 and cf>=af and m>0 and ids
            fresh=w[:n]; k,*stale=w[n:]
            assert len(stale)==k and fresh!=stale
            boards_with.add(b);keys.add((b,tuple(fresh),tuple(stale),ids))
            r.update(fresh_eta=a,prior_eta=c,eta_gain=a-c,fresh_area_numer=af,
                     prior_area_numer=cf,people=m,new_animal_id_bitset=ids,fresh=fresh,prior=stale)
        else: assert not v
        rows.append(r)
    expected=[(b,t)for b in boards for t in range(276,300)]
    assert len(rows)==168 and [(r['board'],r['turn'])for r in rows]==expected
    info=dict(snapshots=175,boards=len(boards),comparisons=168,reasons=dict(reasons),
              aba_occurrences=aba_count,unique_witnesses=len(keys),boards_with_witnesses=len(boards_with),
              gate=len(keys)>=5 and len(boards_with)>=3,rows=rows)
    print(json.dumps(info,indent=2))
if __name__=='__main__':main()
