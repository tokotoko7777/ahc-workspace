"""Add optional coordinate transpose to the frozen faster faithful solver."""
from pathlib import Path
import hashlib,sys
a,b=map(Path,sys.argv[1:])
d=a.read_bytes()
assert hashlib.sha256(d).hexdigest()=='d14f6471e5f64bf4a936f8cf27a0f585136a53e13f3e4a27af9fa21f6427b49c'
s=d.decode()
def patch(old,new):
 global s
 assert s.count(old)==1,old
 s=s.replace(old,new)
patch(' int map=-1,cap=100000,limit_ms=2670;',
 ''' int map=-1,cap=100000,limit_ms=2670;bool transpose=false;
 auto trans=[](char c){
  switch(c){
   case 'U':return 'L';case 'L':return 'U';case 'R':return 'D';case 'D':return 'R';
   case 'u':return 'l';case 'l':return 'u';case 'r':return 'd';case 'd':return 'r';
   default:return c;
  }
 };''')
patch('  if(s.starts_with("--map="))','  if(s=="--transpose")transpose=true;\n  else if(s.starts_with("--map="))')
patch('  int r,c,k;std::cin>>r>>c>>k;s.pets.push_back','  int r,c,k;std::cin>>r>>c>>k;if(transpose)std::swap(r,c);s.pets.push_back')
patch(' for(int i=0;i<m;++i){int r,c;std::cin>>r>>c;s.people.push_back',
      ' for(int i=0;i<m;++i){int r,c;std::cin>>r>>c;if(transpose)std::swap(r,c);s.people.push_back')
patch("  std::cout<<command<<'\\n'<<std::flush;",
      "  if(transpose)for(char& c:command)c=trans(c);\n  std::cout<<command<<'\\n'<<std::flush;")
patch('for(char ch:str){int k=move_dir(ch);', 'for(char ch:str){int k=move_dir(transpose?trans(ch):ch);')
b.write_text(s)
