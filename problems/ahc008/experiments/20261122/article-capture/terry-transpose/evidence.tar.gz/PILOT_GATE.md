# Predeclared pilot
Faster faithful solver d14f6471 vs exactly the same geometry mapped to
transposed coordinates externally, only on fresh prelude-qualified 30
from README. Actual default time cap 2670 ms for both. Same inputs,
official judge + independent playback and scorer for all 60. Advance
only if score is strictly higher, raw and useful fulls not lower, no
legality/time-limit concerns. Measure actual first normal forecast,
final all-clear human area and states160/225 (dry aisle ETA is not
actual stock performance). Report baseline-vs-candidate score win/loss.
No changing gate or inspecting held set after failure. If pass, freeze
same option and generate committed fresh qualifying100, then a fresh
uniform100 to quantify population coverage before possible adoption.
