"""Check exact orientation involution on known official legal tapes."""
from pathlib import Path
import argparse,csv,hashlib,subprocess
p=argparse.ArgumentParser()
for k in ('solver','inputs','tapes','ledger'):p.add_argument(k,type=Path)
a=p.parse_args()
flip=str.maketrans('ULDRuldr','LURD lurd'.replace(' ',''))
found=set()
for row in csv.DictReader(a.ledger.open()):
 if row['arm']!='terry_independent':continue
 geom,d=*map(int,row['telemetry'].split()[:1]),int(row['telemetry'].split()[10])
 if geom in found or d:continue
 case=row['case'];src=a.inputs/case;raw=src.read_bytes()
 assert hashlib.sha256(raw).hexdigest()==row['input_sha']
 inp=raw.decode().splitlines();n=int(inp[0]);m=int(inp[n+1])
 seen=(a.tapes/Path(case).with_suffix('.trace')).read_text().splitlines()
 expected=(a.tapes/Path(case).with_suffix('.actions')).read_bytes()
 assert hashlib.sha256(expected).hexdigest()==row['commands_sha']
 init=inp[:n+m+2];reply=seen[1::2]
 assert len(reply)==300
 tx=init[:]
 for j in list(range(1,n+1))+list(range(n+2,n+m+2)):
  v=tx[j].split();v[0],v[1]=v[1],v[0];tx[j]=' '.join(v)
 def run(s,opt=[]):return subprocess.check_output([str(a.solver.resolve()),'--pairs=0',*opt],input=('\n'.join(s)+'\n').encode(),timeout=5)
 assert run(init+reply)==expected
 out=run(tx+[x.translate(flip) for x in reply],['--transpose'])
 assert out.decode()==expected.decode().translate(flip)
 found.add(geom)
 print(case,geom)
assert found=={1,2,3,4}
print('four layout involution tapes passed')
