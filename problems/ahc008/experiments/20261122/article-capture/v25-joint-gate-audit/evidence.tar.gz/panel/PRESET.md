Audit-only new T160 gate prevalence, before any outputs are seen. Generate
the first 100 header-M5 inputs in unsigned SHA-256 sequence
ahc008-m5-joint-immediate-gate-prevalence-20261122-v1: + decimal i
for i 0..1199, taking first eight bytes big-endian. No training on scores.
Gate can advance only if at least 10 boards have a legal ready simultaneous
two-ended capture and another physically issued complementary wall at
action t160 in the actual visible shared state. Below screen, reject
without changing threshold/availability/ETA. No counterfactual success
or actual performance measurement of a portfolio made yet.
