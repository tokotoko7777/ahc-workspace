from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:])
d=p.read_bytes();assert hashlib.sha256(d).hexdigest()=='644307bc102fdd9f815960c79c6ebd9cb69e0a817f6398b3fed7e96eb7cbab43'
s=d.decode()
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
rep(' bool jointEnabled=true;',Path(__file__).with_name('audit.inc').read_text()+' bool jointEnabled=true;')
rep('     ++jointTurns;', '''     if(jointGateEnabled&&turn==160)
      jointGateRemember(v.tube,v.a,v.b,v.d,pockets[p],crew);
     ++jointTurns;''')
rep("  cout<<g.act<<'\\n'<<flush;","  if(g.jointGateEnabled&&g.turn==160)g.jointGateSubmitted();\n  cout<<g.act<<'\\n'<<flush;")
rep(' if(const char* p=getenv("AHC008_JOINT_RESCUE_LOG")){',''' if(const char* p=getenv("AHC008_JOINT_GATE_AUDIT")){
  ofstream f(p);f<<g.jointGateSummary.str();
 }
 if(const char* p=getenv("AHC008_JOINT_RESCUE_LOG")){''')
o.write_text(s)
