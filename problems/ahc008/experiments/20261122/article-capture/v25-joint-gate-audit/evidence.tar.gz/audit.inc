 bool jointGateEnabled=getenv("AHC008_JOINT_GATE_AUDIT")!=nullptr;
 int jointGateTube=-1,jointGateA=-1,jointGateB=-1,jointGateEta=-1;
 string jointGatePlan;
 array<int,5> jointGateCrewWall{};
 ostringstream jointGateSummary;
 void jointGateRemember(int k,int a,int b,int eta,const Pen& pen,const vector<bool>& crew){
  jointGateTube=k;jointGateA=a;jointGateB=b;jointGateEta=eta;jointGatePlan=act;
  jointGateCrewWall.fill(-1);
  for(int i=0;i<5;i++)if(crew[i]&&islower(act[i])){
   int q=nb[humans[i]][find(BUILD,BUILD+4,act[i])-BUILD];
   if(q>=0&&!wall[q]&&!block[q]&&find(pen.wall.begin(),pen.wall.end(),q)!=pen.wall.end())
    jointGateCrewWall[i]=q;
  }
 }
 void jointGateSubmitted(){
  if(humans.size()!=5)return;
  int planned=0,actual=0,heads=0;
  bool rail=false;
  if(jointGateTube>=0){
   const auto& x=banks[jointGateTube];
   for(int i=0;i<5;i++)if(jointGateCrewWall[i]>=0){
    ++planned;
    int q=jointGateCrewWall[i];
    if(act[i]==jointGatePlan[i]&&!wall[q]&&!block[q])++actual;
   }
   if(jointGateEta==0){
    rail=humans[jointGateA]==x.l&&humans[jointGateB]==x.h&&
       act[jointGateA]==BUILD[dir(x.l,x.g)]&&act[jointGateB]==BUILD[dir(x.h,x.k)]&&
       !wall[x.g]&&!wall[x.k]&&!block[x.g]&&!block[x.k];
    // Confirm exact isolation geometry under the actually submitted action.
    for(int q:x.side)if(!wall[q])rail=false;
    for(int q:x.inner)if(wall[q])rail=false;
    for(int i=0;i<5;i++){
     int q=humans[i];
     if(act[i]!='.')q=nb[q][find(MOVE,MOVE+4,toupper(act[i]))-MOVE];
     if(humans[i]==x.g||humans[i]==x.k||find(x.inner.begin(),x.inner.end(),humans[i])!=x.inner.end()||
        find(x.inner.begin(),x.inner.end(),q)!=x.inner.end()||
        (isupper(act[i])&&(q==x.g||q==x.k)))rail=false;
    }
    for(auto p:pets)heads+=p.p==x.inner[1]||p.p==x.inner[2];
    rail&=heads>0;
   }
  }
  const char* label=rail?(actual?"qualifying":"rail_only"):
      (jointGateTube<0?"no_joint":(jointGateEta==0?"rail_overridden":"forecast_only"));
  jointGateSummary<<label<<' '<<bankRelease<<' '<<jointGateTube<<' '<<jointGateEta<<' '
    <<jointGateA<<' '<<jointGateB<<' '<<heads<<' '<<planned<<' '<<actual<<' '
    <<(jointGatePlan.empty()?"-":jointGatePlan)<<' '<<act<<'\n';
 }
