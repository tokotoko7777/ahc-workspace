"""Validate actual t160 joint commands on a new non-scoring prevalence panel."""
import collections, csv, hashlib, json, sys, tempfile
from pathlib import Path
P=Path(__file__).resolve().parent; W=P.parent
H=W/'ahc008_focus_solver/problems/ahc008'
sys.path.insert(0,str(H))
from benchmark import replay
from benchmark_cases import run
T=W/'ahc008_focus_assets/tools/target/release/tester'
B=W/'ahc008_v24_standby_early_seam/solve'
C=P/'solve'
manifest=json.loads((P/'panel/manifest.json').read_text())
assert len(manifest)==100
out=[]
for q in manifest:
 n=q['case']; raw=(P/'panel/in'/n).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==q['sha256']
 with tempfile.TemporaryDirectory() as d:
  d=Path(d);log=d/'audit';a=d/'cmd'; tr=d/'trace'
  ba,be,bc,_=run([str(T),str(B)],raw,4.5)
  b,e,c,_=run([str(T),'env','AHC008_JOINT_GATE_AUDIT='+str(log),str(C)],raw,4.5)
  base=ba.decode().splitlines(); cmd=b.decode().splitlines()
  assert bc==0 and c==0 and len(base)==len(cmd)==300,(n,bc,c)
  same=base[:160]==cmd[:160]
  assert same,n
  a.write_bytes(b)
  aa,er,rc,_=run([str(T),sys.executable,str(H/'benchmark_cases.py'),'--playback',a,tr],raw,12.)
  assert (aa,er,rc)==(b,e,0)
  score,*_=replay(raw.decode(),tr.read_text().splitlines(),cmd,detailed=True)
  assert e.decode().strip()==f'Score = {score}'
  row=log.read_text().strip().split()
  assert len(row)==11,(n,row)
  assert row[-1]==cmd[160]
  out.append(dict(case=n,input_sha256=q['sha256'],common_prefix_sha256=hashlib.sha256(('\n'.join(cmd[:160])+'\n').encode()).hexdigest(),
                  label=row[0],bank_release=int(row[1]),tube=int(row[2]),eta=int(row[3]),rail_actors=row[4:6],heads=int(row[6]),
                  proposed_complement_walls=int(row[7]),actual_complement_walls=int(row[8]),intent=row[9],submitted=row[10]))
  print(n,row[0],flush=True)
(P/'prevalence.json').write_text(json.dumps(out,indent=2)+'\n')
print(dict(collections.Counter(x['label'] for x in out)))
