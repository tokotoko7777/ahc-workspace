"""Pure finite geometry; no solver, tester, tape, or game data."""
import itertools as it
import json
from collections import deque

ROWS,COLS=7,9
BOARD=set(it.product(range(ROWS),range(COLS)))
D=((1,0),(-1,0),(0,1),(0,-1))
OUTER={p for p in BOARD if p[0] in (0,6) or p[1] in (0,8)}
def n(p): return {(p[0]+dr,p[1]+dc) for dr,dc in D}
def fill(p,allow):
    if p not in allow:return set()
    out={p}; q=deque([p])
    while q:
        for x in n(q.popleft()):
            if x in allow and x not in out:out.add(x);q.append(x)
    return out

def normalize(s):
    r=min(x[0] for x in s); c=min(x[1] for x in s)
    return tuple(sorted((x-r,y-c) for x,y in s))

def all_shapes():
    s={((0,0),)}
    for _ in range(3):
        s={normalize(set(a)|{q}) for a in s for p in a for q in n(p)-set(a)}
    assert len(s)==19
    return sorted(s)

def template(b,a,c):
    body=frozenset(b)
    gate=frozenset((a,c))
    stance=frozenset(((a[0],a[1]-1),(c[0],c[1]+1)))
    boundary={q for p in body for q in n(p)}-body
    wall=frozenset(boundary-gate)
    if len(stance)!=2 or not gate<=boundary or not stance<=BOARD: return None
    if stance&(body|gate|wall) or (body|gate|wall)&OUTER: return None
    if {sum(p)%2 for p in body-n(a)-n(c)}!={0,1}:return None
    return (body,gate,stance,wall)

def generate():
    types=[]
    for shape in all_shapes():
        for dr,dc in sorted(BOARD):
            b=frozenset((r+dr,c+dc) for r,c in shape)
            if not b<=BOARD or b&OUTER:continue
            left=set();right=set()
            for r,c in b:
                if c in (2,3) and (r,c-1) not in b:
                    left.add((r,c-1))
                if c in (5,6) and (r,c+1) not in b:
                    right.add((r,c+1))
            for a,c in it.product(sorted(left),sorted(right)):
                q=template(b,a,c)
                if q: types.append(q)
    return types

def scope(a,b):
    # Genuine stagger rather than copying 2 aligned rooms while declaring a
    # farther unused aisle: a gate column is occupied by the other body.
    return any({c for r,c in x[1]} & {c for r,c in y[0]} for x,y in ((a,b),(b,a)))

def physical(pair):
    allw=set().union(*(v[3] for v in pair))
    allg=set().union(*(v[1] for v in pair))
    alls=set().union(*(v[2] for v in pair))
    allb=set().union(*(v[0] for v in pair))
    if len(allb)!=8 or len(allg)!=4 or allb&allg:return False
    if (allb|allg)&alls or allw&(allb|allg|alls|OUTER):return False
    if not scope(*pair) or not any(c in (1,7) for r,c in alls):return False
    floor=BOARD-allw;ext=floor-allg-allb
    for b,g,s,w in pair:
        boundary={q for p in b for q in n(p) if q in BOARD}-b
        if boundary!=g|w or fill(min(b),b)!=b:return False
        if any(not n(v)&s or not n(v)&b for v in g):return False
        if not len(s)==2 or {sum(p)%2 for p in b-set().union(*(n(x) for x in g))}!={0,1}:return False
        for r,c in s:
            aisle=(r,0 if c<=1 else 8)
            if (r,c) not in ext or aisle not in ext or abs(c-aisle[1])>1:return False
    for state in (0,1,2,3):
        closed=[v for i,v in enumerate(pair) if state&(1<<i)]
        g=set().union(*(v[1] for v in closed))
        b=set().union(*(v[0] for v in closed))
        free=floor-g
        if fill((0,0),free)!=free-b:return False
        for v in closed:
            if fill(min(v[0]),free)!=v[0]:return False
        if not alls<=free-b:return False
    return True

def exhibit(pair):
    w=set().union(*(v[3] for v in pair))
    canvas=[['.']*COLS for _ in range(ROWS)]
    for r,c in w:canvas[r][c]='#'
    for i,(b,g,s,_) in enumerate(pair):
        for r,c in b:canvas[r][c]=chr(65+i)
        for r,c in g:canvas[r][c]='g'
        for r,c in s:canvas[r][c]='s'
    return dict(walls=len(w),grid=[''.join(r) for r in canvas],
                rooms=[dict(body=sorted(v[0]),gates=sorted(v[1]),stances=sorted(v[2])) for v in pair])

def main():
    a=template({(2,c) for c in range(2,6)},(2,1),(2,6))
    b=template({(4,c) for c in range(3,7)},(4,2),(4,7))
    assert a and b and physical((a,b)) and exhibit((a,b))['walls']==13
    print(json.dumps(dict(control=exhibit((a,b)))))
    r=generate()
    checked=[0,0]; accepted=[0,0]; found=[None,None]
    def straight(v):return len({x[0] for x in v[0]})==1
    for a,b in it.combinations(r,2):
        strat=0 if straight(a) and straight(b) else 1
        if len(a[3]|b[3])>12 or not scope(a,b):continue
        checked[strat]+=1
        if not physical((a,b)):continue
        accepted[strat]+=1
        if found[strat] is None:found[strat]=exhibit((a,b))
    print(json.dumps(dict(templates=len(r),budget_pairs_checked=checked,verified=accepted,witnesses=found)))

if __name__=='__main__':main()
