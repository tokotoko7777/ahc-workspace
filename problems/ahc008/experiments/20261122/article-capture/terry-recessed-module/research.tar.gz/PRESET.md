# Frozen recessed-guard shell test: one 7×9 module

No prior archive edits. Pure static finite exhaustive enumeration, no game
data or stochastic optimization. Domain is exterior border ring, with
permanent side aisles c0 and c8 and full exterior rows 0 and 6. Exactly two
distinct connected size-four private bodies, each a genuine horizontal-role
through room (left mouth and guard outward straight, right mouth and guard
outward straight). A left guard may be in c0 or c1, right guard in c7 or c8;
off-aisle means one step along its row and that step must be open exterior
even with both doors pairs shut. Both stances distinct per room. Require
one actual recessed guard and a gate column of one room occupied by the
other room's body to exclude merely declaring a farther unused aisle for
two aligned tubes. Both pig-safe parities independently required.
Only mandatory body boundary wall cells used, total ≤12. Other cells
open. Distinct body/mouth roles; stances may be shared between rooms on
different turns. No overlap between any body, mouth, stance or wall with
a conflicting role. No distant guard candidate, third room, alterations
to row/column perimeter, or wall-budget adjustment.

Independently check a concrete staggered 13-X control. All 19 connected
tetromino orientations/reflections are generated explicitly, located at
every legal anchor, with every in-scope outward guard and adjoining
gate candidate, then every unordered pair. Classify two horizontal I's
separately from at least one bent body; retain counts for both. Physically
verify base/open, either complete chosen two-door lock, and both complete
locks. Exterior reaches all stances and unoccupied floor with no phantom
component; every closed room retains exact connected four floors and no
workers or stances. A witness only certifies local shell/no-trap roles;
no conclusion on 30×30 or on actual turns. No witness excludes only this
specific side-role stagger scope. Commands after express CPU clearance:

```sh
cd ahc008_terry_recessed_module
timeout -k 1s 10s python3 -u check.py > result.jsonl
```
