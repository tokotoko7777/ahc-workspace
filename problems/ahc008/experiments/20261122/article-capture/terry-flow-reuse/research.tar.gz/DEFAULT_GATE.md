# Normal clock validation of an outcome-equivalent fixed-work speedup
Lock before collecting normal-clock results. After both fixed-work
panels pass, compare default baseline accepted split vs exact flow-arena reuse both with
2670ms on each official distributed100 and an unfiltered fresh100
generated with the named namespace/recorded input SHA. No per-input
pair count or deadline adjustments. Same official exact harness, not
parallel. Default may use different t275 pair counts because reuse accelerates
the paired simulation while the stop remains fixed. Report all
tested official legality/playback/independent results, maximum wall,
scores, raw/useful full, complete streams, late pairs and choice flips.

Keep the speed improvement on both fixed panels separate from claims
about end-to-end scores. To use as the normal-clocks reference both
panels must be legal, tester max <2.95s, raw/useful nonlower and score
nonlower than contemporaneously measured paired control. To claim new
official distributed100 best also require the new score exceeds the
archived best 6,093,833,333. Differences observed on only one input set
are reported as such; if adoption fails keep original score reference
and separately preserve the proven fixed-work speed result.
