# Exact Chase max-flow arena reuse
Profile identified Chase shape/max flow as the largest mixed late cost.
Bounded duplicate reach BFS delivered <2% positive-rollout CPU and
was not promoted. Reuse only MaxFlow storage between shape calls.
Rebuild all arcs in exact old order with exact capacities, reset
all residuals, allow extra vertices if previous arena was larger
but clear them so they are isolated. No selector or RNG changes.
C++23 plain build, 400 matched original-versus-arena
cuts across random changing target counts and overlapping walls.
Then require exact full old actions and scores at fixed work on
two serial paired 100-case sets; positive-rollout subgroup must
use ≥2% less solver CPU on each, whole-panel CPU nonhigher,
tester wall below guard. No held if first fails.
