#define main archive_submission_main
#include "solve.private.cpp"
#undef main
#include <cstdio>
#include <random>
namespace terry_partition {
#include "fresh.hpp"
}
int main(){
 using namespace terry_partition;
 std::mt19937 rng(59001476);
 for(int i=0;i<400;++i){
   Board walls,road;
   std::vector<int> crew,targets;
   for(int p=0;p<size;++p){
    if(rng()%7==0)walls.set(p);
    if(p%side%7==3)road.set(p);
   }
   auto addOpen=[&](std::vector<int>& xs,int n) {
    while((int)xs.size()<n){int p=rng()%size;if(!walls[p])xs.push_back(p);}
   };
   addOpen(crew,5+rng()%6);addOpen(targets,i%21);
   const int turn=275+rng()%25;
   auto a=shape_fresh<MaxFlow<int>>(walls,road,crew,targets,turn);
   auto b=shape<MaxFlow<int>>(walls,road,crew,targets,turn);
   assert(a.targetCount==b.targetCount&&a.meetingRadius==b.meetingRadius&&
          a.sourceMass==b.sourceMass&&a.flowValue==b.flowValue&&
          a.evasion==b.evasion&&a.walls==b.walls);
 }
 std::puts("400 exactly equal target-count-changing grow/reset mincuts and cut masks");
}
