"""Pinned accepted split-DP -> reuse empty Chase max-flow storage only."""
import hashlib
from pathlib import Path

d=Path(__file__).resolve().parent
s=(d.parent/'ahc008_terry_split_dp/solve.private.cpp').read_text()
assert hashlib.sha256(s.encode()).hexdigest()=='170382b80e4ca1b0d3a5c4f0948527edabfbb43c0549fa8512fbe9dccc59e223'
a=s.index('template<class Network>\ninline Shape shape(')
b=s.index('\n}\n}',a)+2
part=s[a:b]
(d/'fresh.hpp').write_text(part.replace('inline Shape shape(', 'inline Shape shape_fresh(', 1)+'\n')
x='    Network f(snk+1);'
assert part.count(x)==1
v='''    // Retain capacity only. Empty residual graph for each solve; extra
    // vertices in a grown arena are isolated and never inherit old arcs.
    static thread_local std::optional<Network> arena;
    static thread_local int reservedVertices=0;
    if(reservedVertices<snk+1){
        arena.emplace(snk+1);
        reservedVertices=snk+1;
    }else{
        arena->clear_edges();
    }
    auto& f=*arena;'''
(d/'solve.private.cpp').write_text(s[:a]+part.replace(x,v)+s[b:])
