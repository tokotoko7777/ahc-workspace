"""Generate a private observation-only C++ file; never run solver/score here."""
from pathlib import Path
import hashlib
D=Path(__file__).resolve().parent
P=D.parent/'ahc008_terry_incoming_shadow/live.private.cpp'
src=P.read_bytes()
assert hashlib.sha256(src).hexdigest()=='6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40'
s=src.decode()
def put(before,after):
    global s
    assert s.count(before)==1,before
    s=s.replace(before,after)
t='    std::sort(jobs.begin(),jobs.end(),[](const Candidate&a,const Candidate&b){return a.key()>b.key();});'
put(t,t+'''
    if(exchange_trace_enabled)exchange_offered=jobs;
''')
t='    auto jobs=hunt::choose(s.people,booked,rooms,bits_to_array(actual & ~builds & ~moves));'
put(t,'''
    const auto exchange_can_next=bits_to_array(actual & ~builds & ~moves);
    auto jobs=hunt::choose(s.people,booked,rooms,exchange_can_next);
    if(hunt::exchange_trace_enabled){
      auto eta=[&](const hunt::Candidate& j){
        int h=(j.left>=0&&!exchange_can_next[j.left])||(j.right>=0&&!exchange_can_next[j.right]);
        if(j.left>=0)h=std::max(h,std::abs(s.people[j.a]/30-j.left/30));
        if(j.right>=0)h=std::max(h,std::abs(s.people[j.b]/30-j.right/30));
        return h;
      };
      auto cmd=[&](const auto& jj){
        auto act=action;auto req=booked;
        hunt::emit(s.people,jj,legal,req);
        for(int i=0;i<m;++i)if(req[i])act[i]=*req[i];
        idle_phase(s,terrain->aisleColumns,act);
        return sanitize(s,act);
      };
      auto encode=[&](const hunt::Candidate& j){
        std::string e=std::to_string(j.room);
        auto add=[&](auto x){e+=","+std::to_string(x);};
        add(j.left);add(j.right);add(j.a);add(j.b);add(eta(j));add(j.score);
        for(int p=0;p<V;++p)if(geometry.ids[p]==j.room&&p!=j.left&&p!=j.right)add(p);
        return e;
      };
      auto crew=[](const hunt::Candidate& j){return (1u<<j.a)|(1u<<j.b);};
      std::string orig;
      unsigned rank=0;
      for(int slot=0;slot<int(jobs.size());++slot){
        const auto& old=jobs[slot];
        if(eta(old)<1||eta(old)>3)continue;
        int tried=0;
        std::vector<int> seen;
        for(const auto& j:hunt::exchange_offered){
          if(j.room==old.room||crew(j)!=crew(old)||eta(j)<1||eta(j)>3)continue;
          if(rooms[j.room].area>=rooms[old.room].area)continue;
          if(std::any_of(jobs.begin(),jobs.end(),[&](auto& x){return x.room==j.room;}))continue;
          if(std::find(seen.begin(),seen.end(),j.room)!=seen.end())continue;
          seen.push_back(j.room);
          if(++tried>3)break;
          ++rank;
          if(orig.empty())orig=cmd(jobs);
          auto repl=jobs;repl[slot]=j;
          const auto alt=cmd(repl);
          if(alt==orig)continue;
          bool untouched=true;
          for(int i=0;i<m;++i)if(!(crew(old)>>i&1)&&alt[i]!=orig[i])untouched=false;
          if(!untouched)continue;
          std::string z=std::to_string(hunt::exchange_turn)+" "+std::to_string(rank)+" "+
             std::to_string(slot)+" "+orig+" "+alt+" "+encode(j);
          for(const auto& jj:jobs)z+=" "+encode(jj);
          hunt::exchange_rows.push_back(std::move(z));
        }
      }
    }
''')
pos=s.index('// unset command = nullopt; a chosen explicit wait')
s=s[:pos]+'''inline int exchange_turn=-1;
inline bool exchange_trace_enabled=false;
inline std::vector<Candidate> exchange_offered;
inline std::vector<std::string> exchange_rows;
'''+s[pos:]
t='  auto command=d.chose?chase(s,cfg,turn):policy.step(s,turn,&metrics);'
put(t,'''
  const char* exchange_path=std::getenv("AHC008_SAMECREW_TRACE");
  if(exchange_path&&turn==275){
      std::ofstream f(exchange_path);
      for(const auto& row:hunt::exchange_rows)f<<row<<'\\n';
      if(!f)return 3;
      return 0;
  }
  hunt::exchange_trace_enabled=exchange_path&&turn<275;
  hunt::exchange_turn=turn;
'''+t+'''
  hunt::exchange_trace_enabled=false;
''')
(D/'observer.private.cpp').write_text(s)
