"""Unexecuted preparation. Stock-tape structure then independent 32+32 passive draw blocks."""
import collections, hashlib, json, os, subprocess, sys, tempfile, time
from pathlib import Path
from typing import NamedTuple
D=Path(__file__).resolve().parent;R=D.parent
sys.path.insert(0,str(R/'ahc008_terry_inward_online'))
from observer import case_history,command_effect,step,B,ALL,mask,cells,flood,wave
LEDGER=R/'ahc008_terry_hunt_wall_audit/recordings.json'
PIN='dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5'
IN=R/'ahc008_terry_incoming_shadow/held100/in'
TAPES=LEDGER.parent/'tapes'
LANES=((8,21),(4,14,24),(4,11,18,25),(0,6,13,19,26),(4,11,18,25))
class Job(NamedTuple):
    rid:int;l:int;r:int;a:int;b:int;eta:int;score:int;body:int
    def roles(q):
        return tuple((g,actor,step(g,d)) for g,actor,d in ((q.l,q.a,'L'),(q.r,q.b,'R')) if g>=0)
    def crew(q):return frozenset(actor for _,actor,_ in q.roles())
    def gates(q):return mask(g for g,_,_ in q.roles())
    def footprint(q):return q.gates()|q.body
def parse(x):
    i,l,r,a,b,e,s,*p=map(int,x.split(','))
    return Job(i,l,r,a,b,e,s,mask(p))
def human_views(w,hs):return [flood(B[x],ALL^w) for x in hs]
def check_geometry(j,w):
    g=j.gates()
    if not j.body or g&w or j.body&w or g&j.body:return False
    v=j.body&-j.body
    if flood(v,ALL^(w|g))!=j.body:return False
    if g.bit_count()==2 and any(flood(v,ALL^(w|B[x]))==j.body for x in cells(g)):return False
    return bool(j.body&~(g|wave(g)))
def projected_route(p,g,e,w):
    route=[]
    for dt in range(1,e+1):
        if p!=g:
            if p%30!=g%30:return None
            p+=30 if p<g else -30
        if w&B[p]:return None
        route.append((dt,p))
    return route if p==g else None
def build_plans(jobs,w,h,anchors):
    # H0 closes now and is already included in w; ETA>=4 kept untouched,
    # but any short fence crossing their near route vetoes the comparison.
    pending=[j for j in jobs if 1<=j.eta<=3]
    later=[j for j in jobs if j.eta>=4]
    union=0;forbid=0;routes=[]
    for j in pending:
        if not check_geometry(j,w) or union&j.footprint():return None
        union|=j.footprint();forbid|=j.gates()
        for _,p,stance in j.roles():
            if stance is None:return None
            rt=projected_route(h[p],stance,j.eta-1,w)
            if rt is None:return None
            # Times in projected route are measured from t+1.
            routes.append((p,rt))
    if (anchors|mask(h))&union:return None
    for j in later:
        if j.footprint()&union:return None
        for _,p,stance in j.roles():
            if stance is None:return None
            rt=projected_route(h[p],stance,j.eta-1,w)
            if rt is None or any(B[q]&forbid for _,q in rt):return None
    # Certify all people and anchors stay mutually accessible under the
    # entire possible short barrier set, not only one favorable ordering.
    last=list(h)
    for j in pending:
        for _,p,st in j.roles():last[p]=st
    if mask(last)&(w|union):return None
    if any(B[x]&union for _,route in routes for _,x in route):return None
    old=flood(mask(h),ALL^w);new=flood(B[last[0]],ALL^(w|forbid))
    if (anchors&old)&~new or mask(last)&~new:return None
    return pending
def structure(rec,lines,state,actual,stats):
    out=collections.defaultdict(list)
    anchor=mask(r*30+c for r in range(30) for c in LANES[rec['map']])
    last=(-1,0)
    for line in lines:
        ts,rank,slot,stock,alt,j,*js=line.split()
        t,rank,slot=map(int,(ts,rank,slot)); assert last<(t,rank) and 0<=t<275 and rank>0
        last=(t,rank)
        assert stock==actual[t] and alt!=stock
        old=list(map(parse,js));new=old.copy();new[slot]=parse(j)
        a,b=old[slot],new[slot]
        assert a.crew()==b.crew() and 1<=a.eta<=3 and 1<=b.eta<=3 and a.rid!=b.rid
        stats['offered_changed']+=1
        if b.footprint().bit_count()>=a.footprint().bit_count():stats['footprint_not_smaller']+=1;continue
        assert all(x==y for i,(x,y) in enumerate(zip(stock,alt,strict=True)) if i not in a.crew())
        pts,people,W=state[t]
        p0=command_effect(people,W,pts,stock);p1=command_effect(people,W,pts,alt)
        assert p0
        if not p1 or p0[0]!=p1[0]:stats['different_walls_or_illegal']+=1;continue
        wall,h0=p0;_,h1=p1
        if human_views(wall,h0)!=human_views(wall,h1):stats['different_unchanged_human_reach']+=1;continue
        # Verify declared first actions actually advance/hold named roles
        # toward their own stance, not idle reassignment or sanitizer loss.
        def compat(h,j):
            for _,i,st in j.roles():
                if st is None:return False
                p=people[i]
                if p%30!=st%30:return False
                q=p+30*((st>p)-(st<p))
                if q!=h[i]:return False
            return True
        if not compat(h0,a) or not compat(h1,b):stats['first_role_move_reject']+=1;continue
        pp0=build_plans(old,wall,h0,anchor);pp1=build_plans(new,wall,h1,anchor)
        if pp0 is None or pp1 is None:stats['stance_room_service_reject']+=1;continue
        stats['structural']+=1
        out[t].append((rank,stock,alt,wall,pp0,pp1))
    return out
def hash01(seed,total):
    # Stable exact uniform selection by rejection, independent of solver RNG.
    limit=(1<<64)-((1<<64)%total)
    for j in range(32):
        x=int.from_bytes(hashlib.sha256(seed+bytes([j])).digest()[:8],'little')
        if x<limit:return x%total
    raise AssertionError('unreachable deterministic rejection bound')
def draw(board,t,pts,kinds,w):
    moves={}; passive={}
    for trial in range(64):
        paths=[]
        for i,(p,k) in enumerate(zip(pts,kinds,strict=True)):
            path=[p]
            for h in range(3*k if k<=3 else 0):
                if p not in moves:moves[p]=tuple(cells(wave(B[p])&~w))
                nb=moves[p]
                if nb:p=nb[hash01(f'ahc008-samecrew-v1:{board}:{t}:{trial}:{i}:{h}'.encode(),len(nb))]
                if (h+1)%k==0:path.append(p)
            paths.append(path)
        passive[trial]=paths
    return passive
def directed_ok(pts,kinds,w,jobs):
    for i,(p,k) in enumerate(zip(pts,kinds,strict=True)):
        if k<4:continue
        reached=[B[p]]
        for s in range(6):reached.append(reached[-1]|(wave(reached[-1])&~w))
        for j in jobs:
            if reached[2*j.eta]&(j.footprint()|wave(j.gates())):return False
    return True
def measure(paths,kinds,jobs):
    caught=set();used=0;dup=0
    scored=sorted(jobs,key=lambda j:(j.eta,j.rid))
    for j in scored:
        g=j.gates();veto=g|wave(g);safe=j.body&~veto
        points={i:p[j.eta] for i,p in enumerate(paths) if kinds[i]<=3}
        if any(B[q]&veto for q in points.values()):continue
        present={i for i,q in points.items() if B[q]&safe}
        dup+=len(present&caught)
        if present-caught:used|=j.footprint();caught|=present
    return len(caught),used.bit_count(),dup
def trial_sums(paths,kinds,a,b,rg):
    h=delta=du=0
    for ix in rg:
        x,y,z=measure(paths[ix],kinds,a)
        u,v,q=measure(paths[ix],kinds,b)
        h+=u-x;delta+=y-v;du+=z-q
    return h,delta,du
def audit(exe):
    started=time.monotonic();s_limit=started+120;f_limit=started+180
    assert hashlib.sha256(LEDGER.read_bytes()).hexdigest()==PIN
    records=json.loads(LEDGER.read_text());assert len(records)==len({q['case'] for q in records})==100
    ready=[];st=collections.Counter();ts=[]
    for ix,q in enumerate(records):
        name=q['case'];k,h,old=case_history(q) # verified signed input/full commands/replies
        raw=(IN/name).read_text().splitlines();n=int(raw[0]);m=int(raw[n+1])
        tr=(TAPES/name).with_suffix('.trace').read_text().splitlines()
        payload='\n'.join(raw[:n+2+m]+tr[1:550:2])+'\n'
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'tr';bef=time.monotonic()
            z=subprocess.run([str(exe.resolve()),'--pairs=0'],input=payload,text=True,capture_output=True,
                check=True,timeout=max(0.001,s_limit-bef),env=dict(os.environ,AHC008_SAMECREW_TRACE=str(f)))
            ts.append(time.monotonic()-bef)
            assert z.stdout.splitlines()==old[:275],name
            pairs=structure(q,f.read_text().splitlines(),h,old,st)
        if pairs:ready.append((ix,name,k,h,pairs))
        if time.monotonic()>s_limit:raise TimeoutError('structural whole-cohort deadline')
    result=dict(verified=100,structural_boards=len(ready),counters=st,first20_seconds=ts[:20])
    if len(ready)<20:return result|dict(phase='structural-stop',passes=False)
    chosen=[]
    for ix,name,k,h,pairs in ready:
        for t,options in pairs.items():
            if time.monotonic()>f_limit:raise TimeoutError('whole audit deadline')
            pts=h[t][0];best=None;paths=None
            for rank,old,new,w,a,b in options:
                if not directed_ok(pts,k,w,a+b):st['directed_veto']+=1;continue
                if paths is None:paths=draw(ix,t,pts,k,w)
                hd,ar,du=trial_sums(paths,k,a,b,range(32))
                if hd<0 or ar<=0:continue
                key=(ar,hd,-rank)
                if best is None or best[0]<key:best=(key,rank,old,new,a,b,du)
            if best:
                key,rank,old,new,a,b,du=best
                hh,ha,ds=trial_sums(paths,k,a,b,range(32,64))
                chosen.append(dict(case=name,t=t,rank=rank,old=old,new=new,
                     discovery=key[:2],held=(ha,hh),overlap_removed=(du,ds),
                     held_pass=ha>0 and hh>=0))
                break
    if time.monotonic()>f_limit:raise TimeoutError('whole audit deadline')
    check=[q for q in chosen if q['held_pass']]
    gain=sum(q['held'][0] for q in check)/32
    return result|dict(phase='hold',choices=chosen,held_supported=len(check),saved=gain,
        held_heads=sum(q['held'][1] for q in check)/32,passes=len(check)>=20 and gain>=100)
if __name__=='__main__':
    try:
        print(json.dumps(audit(Path(sys.argv[1])),indent=2))
    except (AssertionError,TimeoutError,subprocess.SubprocessError,OSError) as exc:
        raise SystemExit(f'incomplete: {type(exc).__name__}: {exc}') from exc
