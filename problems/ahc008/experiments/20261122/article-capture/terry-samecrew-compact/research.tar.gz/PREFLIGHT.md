# Detached same-crew compact room exchange (preregistration, not run)

**Source/cohort.** One cohort only: accepted incoming held100 recordings
from ahc008_terry_hunt_wall_audit/recordings.json, ledger SHA256
dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5.
Exact same source as inward_online:
ahc008_terry_incoming_shadow/live.private.cpp SHA256
6c59f0145870fe050f0528938ebd037342791073f6fa04c4870a01e34cbc6b40.
Existing tapes and public prelude only. Integrity: validate full original
input/action/reply hashes and independent original replay, and instrumented
action equality on t0–274. Feed no hidden seed or factual future inputs
to an alternative-selection kernel. Stock implementation, original RNG,
selector inputs, actions and both traces stay unchanged. Offline instrument
uses --pairs=0 and should stop reading/evaluating at t275. A separate
optional check could use current best cohort later; no mixing now.
The existing ETA1 job logs are selected-only. They cannot establish
same-crew unused alternatives, and must not be mined for that purpose.

## A. Structural support before forecasts

Add one detached call at the actual Normal choose/emit site, after
constructor/handoff masks and final room filters. Expose the actual
ordered candidates immediately before stock packing: room, old int64
weight, first-arrival ETA from the original can-next and actor row distances,
actual role→actor IDs, left/right gates and current projected room label
mask, including exact kept phase1/2 reservations. Log selected jobs
(including H0) separately. Copy same command prefix into the existing
emit/idle/sanitize for wholly formed old and alternate proposals; do not
attempt to recover unsubmitted jobs by observing movement.

Take one selected ETA 1–3 slot at a time. Its replacement must already
exist in that exact candidate vector, have the same distinct crew mask,
and use one strictly smaller named footprint (body plus open mouths
that must become walls), with no change to any other selected job or
reservations. Preserve candidate direction and explicit waits; respect
one/two mouth cardinalities. Keep at most three alternate rooms per
selected crew, sorted by original integer score then original tie key,
and at most one substitution in one alternate full plan. Skip candidates
whose safe body is empty, share any body/mouth with kept jobs, have
blocked stances, or where stock and substitute full sanitized first
commands have different wall sets. Require real first-command delta
within the replaced crew only; untouched workers' bytes, including
phase4, constructors, holds, and H0 seals, must stay exact. Confirm
planning / command emission actually uses every nominated actor.

On the exact common post-current-action walls, all prospective jobs must
have the correct outward mouth positions, and closing their set must
detach just the intended currently open physical body with no human in
it. For a two-mouth job, neither gate alone detaches the body. Closures
in the plan must not disconnect any other kept actor's vertical route or
the configured service anchors. Validate the next 1–3 projected vertical
moves/holds of named staff on that common board; require true scheduled
ETA (do not silently stretch original ETA and do not synthesize new
workers). Keep the same unaffected humans' t post-command positions in
both models. Also verify actual currently submitted immediate capture IDs
and human components are the same across the two t commands. Structural
count separates no alternative, role/route rejection, no genuine first
delta, and safe full-state alternatives. If fewer than 20 boards have
any feasible alternative, stop without stochastic work.

## B. Detached common short scenarios

For each surviving t, sample all passive animals, including any outside
numbered rooms and all possible gate blockers. Sample 64 independent
scenarios from one fixed public-state seed namespace using keys
(case manifest ordinal, t, trial index, pet index, substep) in this
offline audit only; publish exact fixed implementation/hash before
execution. Use truly uniform neighbor choice, fixed graph, speed 1/2/3
and stay when degree 0. Pair both plans on the very same scenario paths
and reuse a sampled path at every ETA, up to three. No old RNG draws
removed or reused asymmetrically. The audit keyed seed is not a proposed
live feature and is unrelated to official private randomness. Any
directed animal (dog/cat) that could reach a gate's closed neighborhood
or any involved body disqualifies that comparison; conservative exact
BFS support up to 2x its applicable ETA, including stay, on common
open graph. Include other kept ETA0–3 jobs in both safety and coverage;
leave ETA>=4 plans fixed but do not extrapolate their catches. Report
directed-exclusion recurrence separately (no assumption unsampled safe).

Per plan/trial, at each job ETA an occupied, exact legal seal exists
only if all pets are absent from the closed neighborhoods of its gates.
Use the specific currently safe body's actual animal IDs, not expected
heads as a fractional proxy. Credit a pet only at its first simulated
legal seal; later repetitions earn no second catch. Charge the union of
filled body + newly closed gate cells across productive rooms once.
Keep H0 outcome invariant and include no negative credit for an empty
unbuilt gate. First-event attribution removes double credit, but this
is *not* a full trajectory under subsequent closures or moved humans;
report that paths are frozen and none of these modeled later commands
is executed. Mark per job whether events screened out were pure support,
gate veto, same-ID overlap or changed attractive room size. Confirm
integer arithmetic at mask/union and original score order so no sampling
roundoff can change a submitted original command.

## C. Fixed decision and acceptance

Use trials 0..31 only for selection. Eligible substitute must not reduce
aggregate unique caught heads across the short horizon and must improve
retained-area proxy by saving strictly positive occupied room/gate cells.
Among eligible substitutes pick maximum area saved, then maximum net
unique heads, then original stock weight/tie order. No attempt if none.
One independent witness max per board; select earliest qualifying
board turn using only structural + first-block results, never the
held block or observed future. Evaluate that selected move with the same
criteria on trials 32..63. No peeking to choose a later witness if it fails.
Count changed first commands, held-block support, per-board expected
area/unique head differences, distinct target IDs and temporal overlap,
and the reasons that deny safety. Precise advance bar: at least 20 boards
with held-block supported changes, at least 100 total retained proxy cells
(sum /32), and no aggregate unique head loss on the held block (no slate
may be kept with negative within-board held unique head delta). Observed
future t+eta can be attached as descriptive labels only after fixation.
If structural coverage, stochastic replication, or area fails, stop.
The gate does not assert full isolation or field improvement.

## Minimum artifact and budget

A source-pin code generator should emit only a detached observer,
candidate/stock-role trace row and computed prospective counts. Existing
inward_online observer/materializer establishes state and digest handling;
do not use official tester or generate cases. Minimal text schema for
interesting turns:
- board hash, t, stock full command, alternate full command;
- per job stock/alternate, room label, both gate/stance coordinates,
  worker IDs, ETA, old exact integer score, named body mask, disposition;
- affected immediate stock IDs, kept reservation validation status;
- first and held block unique heads, charged-cell totals, overlap count,
  directed exclusion count; never the hidden source seed.

Avoid dumping full paths or duplicating solver runs. Early cutoff:
structural support pass completed in <=120 elapsed seconds to reserve
60 seconds for the short model; absolute 180 seconds for the assessment,
no half-result acceptance. Log first 20 actual per-board stock prefix
wall times; forecast work is at most 64x20 petsx9 substeps per surviving
turn and up to 3 substitutes per selected crew, advancing at most one
witness per board. If count or deadline prevents completion, mark the
panel incomplete and do not adapt cohorts/parameters. No build/replay
was launched for this plan. No live or official scoring authorized here.

## Prepared source (unexecuted)

- make.py generates the local private observation-only source from the
  pinned parent. It copies pre-packing stock offered order only in real
  t0–274, clones one eligible forecast command batch on detached copies
  and never submits it. Before doing any future experiment, inspect the
  generated derivative and compile once under exclusive approval.
- validate.py checks signed ledger/trace/input digests and every original
  selected command of the entire observed prefix for all 100 cases, no
  score program. It certifies exact role, route and enclosure geometry;
  only then draws fixed indexed passive worlds using SHA256 rejection.
  There is no alternative fallback membership on data failure.
- Runtime cap is per whole audit including tape-prefix processes and
  structural proof, excluding build. Incomplete replay, mismatch,
  timeout or caught error exits unsuccessfully rather than outputting a
  partial decision. The loaded subprocesses see only the public prelude
  and genuine factual replies through t274.
- Later approved command sequence (not invoked in prep): run make.py,
  compile observer.private.cpp with GNU C++23, then call validate.py
  with the binary path. No official generator/scorer and no baseline edits.
