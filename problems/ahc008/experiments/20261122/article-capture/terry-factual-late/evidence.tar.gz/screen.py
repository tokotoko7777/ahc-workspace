"""Exact same-turn wall assignment on six faithful failure transcripts."""
import csv,hashlib,itertools,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'ahc008_terry_scaffold_audit'))
from audit import B,area,bitmask,observed,replay,wave

def near(p,d):
    r,c=divmod(p,30)
    dr,dc={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1)}[d]
    r+=dr;c+=dc
    return r*30+c if 0<=r<30 and 0<=c<30 else None

def board(path,tapes,row):
    original=path.read_bytes();ap=(tapes/path.with_suffix('.actions').name).read_bytes()
    assert hashlib.sha256(original).hexdigest()==row['input_sha']
    assert hashlib.sha256(ap).hexdigest()==row['commands_sha']
    commands=ap.decode().splitlines()
    trace=(tapes/path.with_suffix('.trace').name).read_text().splitlines()
    got,*_=replay(original.decode(),trace,commands,detailed=True)
    assert got==int(row['score'])
    _,history,_=observed(original,trace)
    chase=bool(int(row['telemetry'].split()[13]))
    stats={}
    witnesses=[]
    for t in range(220,300):
        which='chase' if chase and t>=275 else 'normal'
        c=stats.setdefault(which,dict(turns=0,sets=0,full_stock=0,full_alt=0,useful_alt=0,free_useful=0,useful_turns=0,free_turns=0))
        c['turns']+=1
        pets,people,walls=history[t]
        people=[p[0]*30+p[1] for p in people];wall=bitmask(p[0]*30+p[1] for p in walls)
        animal=bitmask(p[0]*30+p[1] for p in pets);n=len(people)
        assert not area(wall,people,animal)[0]
        forbidden=wall|bitmask(people)|animal|wave(animal)
        choices=[]
        old=commands[t]
        for i,p in enumerate(people):
            for d in 'URDL':
                q=near(p,d)
                if q is not None and not (B[q]&forbidden):
                    choices.append((i,d.lower(),q))
        def verify(cmd):
            after=[];new=0
            for p,d in zip(people,cmd,strict=True):
                q=p if d=='.' else near(p,d.upper())
                assert q is not None
                if d.islower():
                    if B[q]&forbidden:return None
                    new|=B[q]
                    after.append(p)
                else:after.append(q)
            if (wall|new)&bitmask(after):return None
            return new,tuple(after)
        past=verify(old)
        assert past is not None
        assert not area(wall|past[0],past[1],animal)[0]
        seen={}
        for k in [1,2]:
            for combo in itertools.combinations(choices,k):
                if len({v[0] for v in combo})<k or len({v[2] for v in combo})<k:continue
                cmd=list(old)
                for i,d,q in combo:cmd[i]=d
                cmd=''.join(cmd)
                if cmd==old:continue
                s=verify(cmd)
                if s is None or s==past:continue
                old_move=sum(a.isupper() and a!=b for a,b in zip(old,cmd))
                old_build=sum(a.islower() and a!=b for a,b in zip(old,cmd))
                rank=(old_move+old_build,old_build,cmd)
                if s not in seen or rank<seen[s][0]:seen[s]=(rank,old_move,old_build)
        c['sets']+=len(seen)
        found=free=False
        for (nw,after),(r,mv,build) in seen.items():
            safe,total,*_=area(wall|nw,after,animal)
            if not safe:continue
            c['full_alt']+=1
            useful=total>=300*n
            if useful:
                c['useful_alt']+=1;found=True
                if not mv+build:c['free_useful']+=1;free=True
            witnesses.append(dict(t=t,mode=which,old=old,new=r[2],mean=total/n,moves_displaced=mv,builds_displaced=build))
        c['useful_turns']+=found;c['free_turns']+=free
    return dict(case=row['case'],stock_score=got,stock_residual=int(row['final_residual']),m=len(commands[0]),stats=stats,witnesses=witnesses)

def main():
    all_={}
    for name,cases,inputs,tapes in [
        ('practice',['0084','0093'],'ahc008_focus_assets/tools/in','ahc008_terry_scaffold_audit/tapes'),
        ('independent',['0015','0035','0065','0079'],'ahc008-article-bench/full-capture-independent100/in','ahc008_terry_factual_late/tapes')]:
        led={z['case']:z for z in csv.DictReader((ROOT/f'ahc008_terry_exact_root/{name}100.csv').open()) if z['arm']=='terry_independent' and z['full']=='0'}
        assert set(led)=={case+'.txt' for case in cases}
        all_[name]=[board(ROOT/inputs/k,ROOT/tapes,row) for k,row in sorted(led.items())]
    print(json.dumps(all_,indent=2))
if __name__=='__main__':main()
