# No permanent connector: necessary column-profile capacity

No game data, time measurements, wall budget, code assimilation or tester.
Retain direct horizontal mouths from whole-height adjacent guard lanes.
A room spans contiguous body columns; column counts form positive
compositions of 4. Its occupied counts are charged +1 in each used
column. Different rooms in the same column need a separating solid cell
(gates are not in body columns), so counts + room incidences ≤31 per
column across 30 rows: at worst one fewer separator than room incidences.
No permanent exterior reservation. Both edge row positions are allowed.

Allow every composition, even if its gates/parity/exterior cannot be
realized jointly. Paired profiles touch both sides; solo touches left or
right (edge, one side only). No actual wall placement, ingress,
connectivity or casing restrictions, so this is a necessary upper bound.
Shared same-column brace can pay for the inter-room separation once,
already allowed. Bound mixed whole-board requirement ≥45 paired and
≥75 total. No implication about ≤223 X or existence from a pass.

n interior body columns charge n+3 physical width; edge with n body
columns charges n+1. Pay one initial aisle, then convolve width ≤29.
Wider edge than width5 can be compressed to width5 in relaxed profile
space: max 15 from its shared mouth-adjacent body column and width5
has room for 15 profiles (1,1,1,1). Wider interior than n=8 can be
compressed to n=8: no paired room can span >4 cols, and each solo side
has ≤15; two disjoint four-column blocks attain these profile counts.
Unused widths allowed. Empty edges width0. Single-column interior
upper bound R≤6; two-column edge width3 cap 10: vertical-only A and
span-two B require 5A+2B≤31 and 5A+6B≤62, ruling out A+B≥11.

Enumerate one fixed sorted multiset search per queried (P,S), tracking
residual 31 slots per column. Flat branch-node cap 50,000 each. Binary
search monotone S for each fixed P and strip width, keep best known
feasible S and conservative optimistic S; on capped query immediately
stop that strip/P search and keep unresolved interval. Exact DP
convolution computes global lower/upper over those intervals. “Lower”
is only feasible in the profile relaxation. “Upper <75” is a no-go for
the stated direct-lane strip class (including cap). Otherwise report
inconclusive or relaxation feasible, and no automatic retries.
Only run once after CPU clearance:

```sh
cd ahc008_terry_finite_strip_bound
timeout -k 1s 12s g++ -std=gnu++23 profile.cpp -o profile &&
timeout -k 1s 15s ./profile
```
