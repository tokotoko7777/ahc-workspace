#pragma GCC optimize("O3,unroll-loops")
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
using V=array<int,8>;
constexpr int NODE_CAP=50000;
int nodes;
int cols;
enum Outcome { NO, YES, CAPPED };
vector<V> singleton, paired;
// Enumerate multiplicities in a fixed order; identical profile vectors have
// no geometry identity and can be merged safely in this necessary model.
Outcome pick(int P,int S,int first,V& cap){
 if(P==0&&S==0)return YES;
 if(++nodes>NODE_CAP)return CAPPED;
 int total=0;for(int j=0;j<cols;j++)total+=cap[j];
 if((4+cols)*P+5*S>total)return NO;
 auto &a=P?paired:singleton;
 for(int i=first;i<(int)a.size();i++){
  auto &v=a[i];bool ok=true;
  for(int j=0;j<cols;j++)ok &= v[j]<=cap[j];
  if(!ok)continue;
  for(int j=0;j<cols;j++)cap[j]-=v[j];
  int follow=P==1?0:i;
  auto ans=pick(P>0?P-1:0,P>0?S:S-1,follow,cap);
  for(int j=0;j<cols;j++)cap[j]+=v[j];
  if(ans!=NO)return ans;
 }
 return NO;
}
void gen(int c,bool edge){
 cols=c;singleton.clear();paired.clear();
 for(int m=0;m<8;m++){
  vector<int> p{1};
  for(int i=0;i<3;i++) if(m&(1<<i))p.push_back(1);else p.back()++;
  int s=p.size();if(s>c)continue;
  for(int z=0;z+s<=c;z++){
   V v{};for(int j=0;j<s;j++)v[z+j]=p[j]+1;
   if((z==0||(!edge&&z+s==c)))singleton.push_back(v);
   if(!edge&&s==c)paired.push_back(v);
  }
 }
 for(auto q:{&singleton,&paired}){
  sort(q->begin(),q->end());q->erase(unique(q->begin(),q->end()),q->end());
 }
}
struct Bound {int low,up, unknown;};
Bound ceiling(int P,int Smax){
 int lo=P==0?0:-1,hi=Smax+1,stop=0;
 while(hi-lo>1){
  int S=(lo+hi)/2;V cap{};cap.fill(31);nodes=0;
  auto x=pick(P,S,0,cap);
  if(x==CAPPED){++stop;break;}
  if(x==YES)lo=S;else hi=S;
 }
 return {lo,hi-1,stop};
}
using Table=array<array<int,46>,30>;
constexpr int NA=-1000;
Table empty_table(){Table d;for(auto &v:d)v.fill(NA);d[0][0]=0;return d;}
void assign(int& d,int n){d=max(d,n);}
int compute(const vector<vector<Bound>>& ints,const vector<Bound>& ed,bool upper){
 Table dp=empty_table();
 auto value=[&](Bound b){return upper?b.up:b.low;};
 for(int w=0;w<30;w++)for(int P=0;P<=45;P++)if(dp[w][P]>=0)
  for(int c=1;c<=8;c++)if(w+c+3<30)
   for(int p=0;p<(int)ints[c].size();p++){
    int S=value(ints[c][p]);if(S<0)continue;
    assign(dp[w+c+3][min(45,P+p)],dp[w][P]+p+S);
   }
 int best=NA;
 for(int w=0;w<30;w++)if(dp[w][45]>=0)
  for(int a:{0,2,3,4,5})for(int b:{0,2,3,4,5})if(w+a+b<30)
   assign(best,dp[w][45]+value(ed[a])+value(ed[b]));
 return best;
}
int main(){
 vector<vector<Bound>> in(9);vector<Bound> ed(6);
 for(int c=1;c<=8;c++){
  gen(c,false);
  int pmax=c<=4?min(15,31*c/(4+c)):0;
  for(int p=0;p<=pmax;p++){
   int smax=min((31*c-(4+c)*p)/5,30-2*p);
   if(c==1)smax=min(smax,6-p);
   auto v=ceiling(p,smax);in[c].push_back(v);
   cout<<"I "<<c<<" "<<p<<" "<<v.low<<" "<<v.up<<" "<<v.unknown<<"\n";
  }
 }
 for(int w=2;w<=5;w++){
  gen(w-1,true);
  int ub=w==2?6:(w==3?10:15);
  ed[w]=ceiling(0,ub);
  cout<<"E "<<w<<" "<<ed[w].low<<" "<<ed[w].up<<" "<<ed[w].unknown<<"\n";
 }
 int low=compute(in,ed,false),high=compute(in,ed,true);
 assert(low<=high);
 cout<<"PROFILE_LOWER "<<low<<" PROFILE_UPPER "<<high
     <<" EXCLUDES_75 "<<(high<75)<<"\n";
}
