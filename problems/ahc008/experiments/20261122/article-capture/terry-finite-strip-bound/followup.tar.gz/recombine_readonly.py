"""Recombine the frozen cap output; never invoke profile.cpp or another solver."""
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import json

p=Path(__file__).with_name("output.txt")
s=p.read_bytes()
assert sha256(s).hexdigest()=="490feecdec484519f67cd7c2eaab91b058245c24d6ade6d086a06e2bc21e52e9"
rows=[line.split() for line in s.decode().splitlines()]
I=tuple(tuple(map(int,x[1:])) for x in rows if x[0]=="I")
E={0:0}|{int(x[1]):int(x[3]) for x in rows if x[0]=="E"}
assert len({(x[0],x[1]) for x in I})==len(I)==52
assert len(E)==5 and b"PROFILE_LOWER 71 PROFILE_UPPER 75 EXCLUDES_75 0" in s
assert b"PROCESS_EXIT=0" in s

@lru_cache(None)
def recombine(width,paired,last=0):
    best=-1000
    paths=[]
    def consider(value,path):
        nonlocal best,paths
        if value>best: best=value;paths=[]
        if value==best: paths.append(path)
    if paired==0:
        for a in sorted(E):
            for b in sorted(E):
                if a<=b and a+b<=width: consider(E[a]+E[b],((a,b),))
    for j in range(last,len(I)):
        body,P,low,high,capped=I[j]
        if body+3>width: continue
        val,tail=recombine(width-body-3,max(0,paired-P),j)
        for path in tail: consider(P+high+val,(I[j],)+path)
    return best,tuple(paths)

answer=recombine(29,45)
assert answer==(75,(((4,15,0,0,0),(4,15,0,0,0),(4,15,0,0,0),
                     (5,0,15,30,1),(0,0)),))
# This sole maximizer has 15 solos facing each side. Each side body
# column leaves at most 16 body tiles after the 15 per-room charges.
# One four-tile span-1 body would use (14+4)>16, so every span >=2.
assert 14+4>31-15 and 30*(4+2)>31*5
print(json.dumps({"frozen_output_sha":sha256(s).hexdigest(),"frozen_upper":answer[0],
                  "all_maximizers":answer[1],"contradicted_upper":75,
                  "new_upper":74},indent=2))
