"""Pure submitted-projection lifecycle screen for first installed X cells."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import json,sys
R=Path(__file__).resolve().parent.parent
T=R/'ahc008_terry_hunt_wall_audit'
I=R/'ahc008_terry_incoming_shadow/held100/in'
C=R/'ahc008_terry_small_rooms/catalog.tsv'
sys.path.insert(0,str(T))
from analyze import terrain,snapshot,cells,mask
from guarded_entry_trace import observed,STEPS
from stochastic_lock_audit import B,ALL,flood,wave
PINS={T/'recordings.json':'dde3b2186e2c5d94b46623bda51b37206fb458cec92787ca5b939793531c25c5',
 T/'analyze.py':'8c8ec5d472ae8af00416cb7a8e6297bc3d509b056fff66d7a6eb2bcdb0e7b964',
 R/'ahc008_terry_exact_maps/terrain_data.inc':'8d1f703d67b9d16fb0ba6d3b20cd2bb4a2cf20aea33e4a7351d45fd129e256cf',
 C:'2d697e1b2cbf0cd9d754d38a18059e2fbcd484b7440868da8016f8310132ba06'}
from stochastic_lock_audit import idx
def sha(b):return sha256(b).hexdigest()
def step(p,c):
    u,v=STEPS[c.upper()]
    x,y=divmod(p,30)
    assert 0<=x+u<30 and 0<=y+v<30
    return p+u*30+v
def make_catalog():
    sets=terrain(); rs=[[] for _ in sets]
    for line in C.read_text().splitlines():
        k,i,l,r,*u=map(int,line.split())
        body=mask(u)
        if l>=0: assert l%30>=1 and B[l+1]&body
        if r>=0: assert r%30<29 and B[r-1]&body
        near=[]; mouths=[]
        if l>=0: near.append(l-1);mouths.append(l)
        if r>=0: near.append(r+1);mouths.append(r)
        rs[k].append((i,body,mask(mouths),mask(near),tuple((g,d) for g,d in ((l,1),(r,-1)) if g>=0)))
    output=[]
    for (x,g),rooms in zip(sets,rs):
        rmap={}
        missing=g
        for a,b,m,s,inside in rooms:
            assert m and not m&~missing
            missing&=~m
            for p in cells(x&(wave(b|m|s)|b|m|s)):
                tags=(int(bool(B[p]&(b|wave(b)))) + 2*int(bool(B[p]&(m|wave(m)))) +
                      4*int(bool(B[p]&(s|wave(s)))))
                rmap.setdefault(p,[]).append((m,tags))
        output.append((x,g,rooms,rmap,missing))
    return output

def shape_cap(w,g,rooms,crew):
    # Capacity signature, not stock hunt-emitter recreation. Characters
    # are factual submitted locks, not recovered constructor proposals.
    av=ALL^(w|g)
    human=mask(crew)
    ret=[]
    # Every configured open gate not already retired in projected walls
    # announces the exact (possibly dynamically malformed) body inside.
    for i,b,m,s,inside in rooms:
        if m&w:continue
        footprints=[]
        for gate,d in inside:
            tile=B[gate+d]
            reg=flood(tile,av) if tile&av else 0
            footprints.append((gate,reg, bool(reg&human), bool(reg&b)))
        ret.append((i,tuple(footprints)))
    return tuple(ret)

def board(rec,data):
    k=rec['map']; x,g,rooms,rmap,missing=data[k]; case=rec['case']
    f=I/case; a=(T/'tapes'/case).with_suffix('.actions')
    b=[p.read_bytes() for p in (f,a,a.with_suffix('.trace'))]
    assert [sha(p) for p in b]==[rec[j] for j in ('input_sha','commands_sha','trace_sha')]
    cmd=b[1].decode().splitlines();tr=b[2].decode().splitlines()
    assert len(cmd)==300 and len(tr)==600 and tr[::2]==cmd
    _,hist,_=observed(b[0],tr)
    H=[(list(map(idx,p)),list(map(idx,h)),mask(map(idx,w))) for p,h,w in hist]
    pp,hh,ww=H[-1];assert bool(snapshot(ww,hh,pp)[0]==(1<<len(pp))-1)==bool(rec['actual_full'])
    count=Counter(); rows=[]
    for t,act in enumerate(cmd):
        p,h,w=H[t]; _,h1,w1=H[t+1]
        moves=[step(f,c) if c.isupper() else f for f,c in zip(h,act)]
        targets=mask(step(f,c) for f,c in zip(h,act) if c.islower())
        assert len(act)==len(h) and moves==h1 and w|targets==w1 and not mask(moves)&w1
        added=(w1&~w)&x
        phase='early' if t<160 else 'mid' if t<275 else 'late'
        for q in cells(added):
            count[phase,'installed']+=1
            incidence=rmap.get(q)
            if missing or not incidence:
                count[phase,'ambiguous']+=1;continue
            if not all(m&w for m,tags in incidence):
                count[phase,'incident_live_pre']+=1;continue
            label='complete' if all(m&w==m for m,tags in incidence) else 'partial'
            count[phase,label+'_retired_pre']+=1
            skip=w1^B[q]
            if shape_cap(w1,g,rooms,h1)!=shape_cap(skip,g,rooms,h1):
                count[phase,'changed_capacity']+=1;continue
            before,_,_=snapshot(w,h,p)
            old,oc,ou=snapshot(w1,h1,p)
            new,nc,nu=snapshot(skip,h1,p)
            if new!=old or before&~new:
                count[phase,'lost_isolated_id']+=1;continue
            pairs=tuple((i,j) for i in range(len(h1)) for j in range(i) if B[h1[i]]&oc[j])
            pairs2=tuple((i,j) for i in range(len(h1)) for j in range(i) if B[h1[i]]&nc[j])
            if pairs!=pairs2:
                count[phase,'changed_crew_partition']+=1;continue
            count[phase,'candidate']+=1
            rows.append(dict(t=t,phase=phase,q=q,kind=label,
               incident_tags=[t for m,t in incidence],directly_reached=bool(B[q]&nu),
               union_delta=(nu&~ou).bit_count()))
    assert sum(n for (p,k),n in count.items() if k=='installed')==(ww&x).bit_count()
    return dict(case=case,map=k,counts={':'.join(p):n for p,n in count.items()},rows=rows)

def main():
    for p,d in PINS.items():assert sha(p.read_bytes())==d
    geom=make_catalog()
    records=json.loads((T/'recordings.json').read_text())
    assert len(records)==len({r['case'] for r in records})==100
    res=[board(r,geom[r['map']]) for r in records]
    stats=Counter()
    for r in res:stats.update(r['counts'])
    amount=sum(len(r['rows']) for r in res)
    boards=sum(bool(r['rows']) for r in res)
    print(json.dumps(dict(signed=len(res),candidate_cells=amount,candidate_boards=boards,
        phase_stats=dict(stats),unmapped_gates=[m.bit_count() for x,g,r,b,m in geom],
        gate=amount>=5 and boards>=5,rows=res),indent=2))
if __name__=='__main__':main()
