# Per-fence retirement observed before first build

Older accepted Incoming held100 action/trace/input hashes, not current
f83. One static pass; no scoring runs, solver, tester, materialization,
new data or nominal outcome-driven exclusions. The original 300 actions
are replayed against factual pre/post walls and human moves, and known
final full flag; no alternative pet motion is generated.

Every first installed planned X is examined exactly once. Conservative
incidence means touching nominal footprint, either signed original mouth,
or its canonical outward guard position (including overlap). Unknown
configured gate ownership or empty incident set is ambiguous and rejected.
Candidate trigger uses pre-action current installed wall mask only:
EVERY incident nominal room must already have at least one stock mouth
physically closed, not proposed the same turn. Complete means all their
mouths installed; partial means at least one two-mouth incident room is
retired for the stock job by only one installed mouth. Do not infer
physical full isolation from the partial label. Include actual per-turn
placement phase early t<160, mid 160≤t<275, late t≥275.

Hold every unrelated submitted action fixed. Require equal room capacity
signatures after projected stock vs projected omit-X. Capacity signature
tracks, for every configured room whose nominal mouths are all still
open, its exact per-door inside footprint with all configured mouths
virtually blocked, and occupation by projected humans. This retains even
physically malformed/merged surviving door footprints conservatively.
No classifier uses a future pet position. This is a **submitted-projection
certificate**, not the stock constructor-only proposal classifier (which
would use pre-hunt bookings and additional model filters). Require
same exact global isolated IDs, no loss of a previously isolated ID,
and exact equality of pairwise crew connectivity. Result can store
strictly local reachable union delta as a description, not a summed
score or evidence paths remain the same after an alternative action.

Locked support gate: ≥5 distinct candidate cells across ≥5 boards.
Only a support gate; not a safe production change or a proof of future
dynamics. No final labels used to select candidates or looser retries.
Run once when separately cleared:

```sh
timeout -k 1s 29s python3 -u ahc008_terry_x_lifecycle/audit.py > ahc008_terry_x_lifecycle/result.json
```
