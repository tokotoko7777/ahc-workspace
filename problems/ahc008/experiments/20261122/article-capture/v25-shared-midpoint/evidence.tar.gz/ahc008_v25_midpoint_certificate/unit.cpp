#pragma GCC optimize("O3")
#include "midpoint.hpp"
#include <cassert>
#include <iostream>
using namespace ahc008_midpoint;
int main(){
 Adj adj;
 for(int p=0;p<900;p++)adj[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 int cases=0,locations=0;
 for(int rot:{0,1})for(int o:{4,8,12}){
  auto xy=[&](int x,int y){return rot?y*30+x:x*30+y;};
  Mask allwalls,aisles;
  for(int j=0;j<3;j++)for(int r=0;r<30;r++)aisles[xy(r,o+7*j)]=true;
  std::vector<Tube> tube;
  for(int b=0;b<2;b++)for(int r=3;r<=27;r+=2){
   int a=o+7*b;
   Tube z{b,r,xy(r,a),xy(r,a+1),xy(r,a+6),xy(r,a+7),{},{}};
   for(int j=0;j<4;j++){
    z.inner[j]=xy(r,a+2+j);
    for(int d:{-1,1}){
     int u=xy(r+d,a+2+j);z.shoulder.push_back(u);allwalls[u]=true;
    }
   }
   tube.push_back(z);
  }
  const auto pairs=derive(adj,tube);
  assert(pairs.size()==24&&allwalls.count()==112);
  ++cases;locations+=pairs.size();
  for(auto p:pairs){
   auto& x=tube[p.a];auto& y=tube[p.b];
   assert(p.l==xy(x.row+1,o+7*x.bank+1)&&p.r==xy(x.row+1,o+7*x.bank+6));
   std::vector<int> h{p.l,p.r,xy(0,0),xy(29,29),xy(0,29)};
   std::vector<int> pets{x.inner[1],y.inner[2]};
   for(auto* z:{&x,&y}){
    auto good=certify(adj,*z,allwalls,{},aisles,h,pets,p.l,p.r,0,1,false);
    assert(good.certified&&good.heads==1);
    assert(!certify(adj,*z,allwalls,{},aisles,h,pets,p.l,p.r,0,1,true).certified);
    Mask doomed;doomed[p.l]=true;
    assert(!certify(adj,*z,allwalls,doomed,aisles,h,pets,p.l,p.r,0,1,false).certified);
   }
   // Same actors moved to the axial positions can only close x.
   h[0]=x.l;h[1]=x.h;
   assert(certify(adj,x,allwalls,{},aisles,h,pets,x.l,x.h,0,1,false).certified);
   assert(!certify(adj,y,allwalls,{},aisles,h,pets,x.l,x.h,0,1,false).certified);
   Mask forbidden;forbidden[p.l]=true;
   assert(derive(adj,tube,forbidden).size()==23);
  }
 }
 std::cout<<cases<<" layouts, "<<locations<<" independently certified stations\n";
}
