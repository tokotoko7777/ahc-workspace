#pragma once
#include <algorithm>
#include <array>
#include <bitset>
#include <cstdint>
#include <vector>
namespace ahc008_midpoint {
constexpr int N=900;
using Mask=std::bitset<N>;
using Adj=std::array<std::array<int,4>,N>;
struct Tube{int bank,row,l,g,k,h; std::array<int,4> inner; std::vector<int> shoulder;};
struct Pair{int a,b,l,r;};
inline bool hasNeighbor(const Adj& nb,int u,int v){
 return u>=0&&u<N&&v>=0&&v<N&&std::find(nb[u].begin(),nb[u].end(),v)!=nb[u].end();
}
inline std::vector<Pair> derive(const Adj& nb,const std::vector<Tube>& tubes,Mask forbidden={}){
 for(const auto& t:tubes){
  forbidden[t.g]=forbidden[t.k]=true;
  for(int x:t.inner)forbidden[x]=true;
  for(int x:t.shoulder)forbidden[x]=true;
 }
 auto common=[&](int u,int v){
  std::vector<int> out;
  for(int p:nb[u])if(p>=0&&!forbidden[p]&&hasNeighbor(nb,v,p))out.push_back(p);
  return out;
 };
 std::vector<Pair> out;
 for(int a=0;a<int(tubes.size());a++)for(int b=0;b<int(tubes.size());b++)
  if(tubes[a].bank==tubes[b].bank&&tubes[b].row==tubes[a].row+2){
   for(int l:common(tubes[a].g,tubes[b].g))
    for(int r:common(tubes[a].k,tubes[b].k))
     if(l!=r)out.push_back({a,b,l,r});
  }
 return out;
}
inline Mask flood(const Adj& nb,const Mask& walls,int start){
 Mask reach;
 if(start<0||start>=N||walls[start])return reach;
 std::array<int,N> queue;
 int n=1;queue[0]=start;reach[start]=true;
 for(int i=0;i<n;i++)for(int q:nb[queue[i]])if(q>=0&&!walls[q]&&!reach[q]){
  reach[q]=true;queue[n++]=q;
 }
 return reach;
}
struct Lock{bool certified=false;int heads=0;Mask outside;};
inline Lock certify(const Adj& nb,const Tube& t,const Mask& actual,
           const Mask& reservedWalls,const Mask& protectedExterior,
           const std::vector<int>& h,const std::vector<int>& pets,
           int l,int r,int leftActor,int rightActor,bool bridgeReserved){
 if(bridgeReserved||leftActor==rightActor||leftActor<0||rightActor<0||
    leftActor>=int(h.size())||rightActor>=int(h.size())||
    h[leftActor]!=l||h[rightActor]!=r||l==r||
    !hasNeighbor(nb,l,t.g)||!hasNeighbor(nb,r,t.k))return {};
 Mask before=actual|reservedWalls;
 if(before[l]||before[r]||before[t.g]||before[t.k])return {};
 Mask inside;
 for(int p:t.inner){if(before[p])return {};inside[p]=true;}
 for(int p:t.shoulder)if(!actual[p])return {}; // physically complete now
 for(int i:h)if(before[i]||inside[i]||i==t.g||i==t.k)return {};
 int heads=0;
 for(int p:pets){
  if(p==t.g||p==t.k||hasNeighbor(nb,p,t.g)||hasNeighbor(nb,p,t.k))return {};
  heads+=inside[p];
 }
 if(!heads)return {};
 before[t.g]=before[t.k]=true;
 const auto room=flood(nb,before,t.inner.front());
 if(room!=inside)return {};
 const auto exterior=flood(nb,before,h.front());
 if((protectedExterior&~exterior).any())return {};
 for(int p:h)if(!exterior[p])return {};
 return {true,heads,exterior};
}
}
