from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);d=p.read_bytes()
assert hashlib.sha256(d).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=d.decode();wd=Path(__file__).parent
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
header=(wd.parent/'ahc008_v25_midpoint_certificate/midpoint.hpp').read_text().replace('#pragma once\n','')
rep('struct Game {',header+'\nstruct Game {')
rep(' string integratedBankPlan(){',(wd/'live.inc').read_text()+' string integratedBankPlan(){')
rep('  const bool scheduled=turn>=35&&*max_element(local.begin(),local.end())>=5;', '''  const bool midpointEligible=humans.size()==5&&!terryBuild.inConstruction(turn);
  if(midpointEligible)midpointImmediate(walls,ready,enabled,build,moveTo,usedPeople,shut);
  const bool scheduled=turn>=35&&*max_element(local.begin(),local.end())>=5;''')
rep('   if(maxEta&&!overBudget()){','''   vector<MidpointJob> midpointJobs;
   if(midpointEligible)midpointPaths(ready,enabled,build,moveTo,usedPeople,shut,midpointJobs,maxEta);
   if(maxEta&&!overBudget()){''')
rep('     for(auto [a,b,d]:pairInfo[k]){const int mask=(1<<a)|(1<<b);auto& j=best[mask];\n      if(j.value>=0){jobs[k].push_back(j);j.value=-1;}}\n    }','''     for(auto [a,b,d]:pairInfo[k]){const int mask=(1<<a)|(1<<b);auto& j=best[mask];
      if(j.value>=0){jobs[k].push_back(j);j.value=-1;}}
    }
    if(!midpointJobs.empty())midpointValues(pathsMC,midpointJobs);''')
rep('   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;\n   if(any_of(jobs.begin(),jobs.end(),[](const auto& x){return !x.empty();})){\n    for(auto j:packBankJobs(jobs,partial?1:m/2)){','''   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;
   if(midpointEligible){midLastGroup.fill(-1);midLastGoal.fill(-1);}
   vector<BankJob> oldPack;
   if(any_of(jobs.begin(),jobs.end(),[](const auto& x){return !x.empty();}))
    oldPack=packBankJobs(jobs,partial?1:m/2);
   if(midpointEligible&&!partial&&!midpointJobs.empty())
    midpointSelect(jobs,paths,shut,oldPack,midpointJobs,usedPeople,moveTo,pairedTubes);
   {
    for(auto j:oldPack){''')
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* p=getenv("AHC008_MIDPOINT_LOG")){
  ofstream f(p);f<<g.midOpportunities<<' '<<g.midDispatchTurns<<' '<<g.midDispatchJobs<<' '
                <<g.midLocks<<' '<<g.midHeads<<' '<<g.midFirstLock<<'\\n';
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
