 struct MidpointJob{int group,a,b,eta,s,t;double value=0.;};
 vector<ahc008_midpoint::Tube> midTubes;
 vector<ahc008_midpoint::Pair> midGroups;
 array<int,5> midLastGroup{-1,-1,-1,-1,-1},midLastGoal{-1,-1,-1,-1,-1};
 int midLastTurn=-1;
 int midOpportunities=0,midDispatchTurns=0,midDispatchJobs=0,midLocks=0,midHeads=0,midFirstLock=-1;
 void midpointInit(){
  if(!midTubes.empty())return;
  for(auto& x:banks)midTubes.push_back({x.b,x.r,x.l,x.g,x.k,x.h,x.inner,x.side});
  midGroups=ahc008_midpoint::derive(nb,midTubes,terryBuild.braces());
 }
 bool midpointOpen(int k,const vector<int>& ready,const vector<int>& enabled,
       const bitset<V>& build,const bitset<V>& moveTo,const bitset<terry_lane::MaxTubes>& shut)const{
  const auto& x=banks[k];
  if(!ready[k]||!enabled[k]||shut[k]||crossing.reserves(k)||!terryRoad.protects(k,shut)||
     wall[x.g]||wall[x.k]||build[x.g]||build[x.k]||moveTo[x.g]||moveTo[x.k])return false;
  for(int p:x.inner)if(wall[p]||build[p]||moveTo[p])return false;
  return find(humans.begin(),humans.end(),x.g)==humans.end()&&
         find(humans.begin(),humans.end(),x.k)==humans.end();
 }
 void midpointImmediate(const bitset<V>& walls,const vector<int>& ready,const vector<int>& enabled,
      bitset<V>& build,const bitset<V>& moveTo,bitset<V>& used,bitset<terry_lane::MaxTubes>& shut){
  midpointInit();
  vector<int> heads;for(auto p:pets)heads.push_back(p.p);
  bitset<V> roads;
  for(int l=0;l<=bankN;l++)for(int r=0;r<S;r++)
   if(!wall[bp(r,bankShift+7*l)])roads[bp(r,bankShift+7*l)]=true;
  for(int iteration=0;iteration<2;iteration++){
   int bi=-1,bj=-1,bk=-1,best=0;
   for(auto p:midGroups)if(!walls[p.l]&&!walls[p.r]&&!build[p.l]&&!build[p.r]&&!moveTo[p.l]&&!moveTo[p.r]){
    if(!midpointOpen(p.a,ready,enabled,build,moveTo,shut)||
       !midpointOpen(p.b,ready,enabled,build,moveTo,shut))continue;
    for(int i=0;i<5;i++)if(!used[i]&&humans[i]==p.l)
     for(int j=0;j<5;j++)if(i!=j&&!used[j]&&humans[j]==p.r)
      for(int k:{p.a,p.b}){
       if(block[banks[k].g]||block[banks[k].k])continue;
       auto c=ahc008_midpoint::certify(nb,midTubes[k],walls,build,roads,humans,heads,
                                      p.l,p.r,i,j,crossing.reserves(k));
       if(c.certified&&c.heads>best)best=c.heads,bi=i,bj=j,bk=k;
      }
   }
   if(bk<0)return;
   const auto& x=banks[bk];
   act[bi]=BUILD[dir(humans[bi],x.g)];act[bj]=BUILD[dir(humans[bj],x.k)];
   build[x.g]=build[x.k]=true;used[bi]=used[bj]=true;shut[bk]=true;
   ++midLocks;midHeads+=best;integratedLocks[turn]+=best;
   if(midFirstLock<0)midFirstLock=turn;
  }
 }
 void midpointPaths(const vector<int>& ready,const vector<int>& enabled,const bitset<V>& build,
            const bitset<V>& moveTo,const bitset<V>& used,const bitset<terry_lane::MaxTubes>& shut,
            vector<MidpointJob>& jobs,int& maxEta){
  if(midGroups.empty())return;
  bitset<V> block=build;
  array<int,V> body;body.fill(-1);
  for(int x=0;x<V;x++)if(wall[x])block[x]=true;
  for(int k=0;k<int(banks.size());k++)if(ready[k]){
   auto& z=banks[k];
   block[z.g]=block[z.k]=true;
   for(int q:z.inner)body[q]=k;
  }
  array<BankPath,5> paths;
  for(int i=0;i<5;i++)if(!used[i]&&!block[humans[i]]&&body[humans[i]]<0)
   paths[i].run(humans[i],block,body);
  for(int k=0;k<int(midGroups.size());k++){
   const auto& x=midGroups[k];
   if(block[x.l]||block[x.r]||moveTo[x.l]||moveTo[x.r]||
      !midpointOpen(x.a,ready,enabled,build,moveTo,shut)||
      !midpointOpen(x.b,ready,enabled,build,moveTo,shut))continue;
   for(int i=0;i<5;i++)if(!used[i]&&!block[humans[i]]&&body[humans[i]]<0)
    for(int j=0;j<5;j++)if(i!=j&&!used[j]&&!block[humans[j]]&&body[humans[j]]<0){
     const int a=paths[i].d[x.l],b=paths[j].d[x.r];
     if(min(a,b)<0||max(a,b)>Horizon)continue;
     const int s=paths[i].step[x.l],t=paths[j].step[x.r];
     if((s>=0&&moveTo[s])||(t>=0&&moveTo[t])||(s>=0&&s==t))continue;
     int d=max({1,a,b});maxEta=max(maxEta,d);
     jobs.push_back({k,i,j,d,s,t});
    }
  }
  midOpportunities+=!jobs.empty();
 }
 static pair<int,int> midpointReward(const array<uint8_t,128>& a,const array<uint8_t,128>& b,int n){
  int total=0,any=0;
  for(int i=0;i<n;i++){int z=max(a[i],b[i]);total+=z;any+=z>0;}
  return {total,any};
 }
 void midpointValues(const terry_mc::Paths& sample,vector<MidpointJob>& jobs){
  struct Row{array<uint8_t,128> hits{};bool computed=false;};
  vector<array<Row,Horizon+1>> cache(banks.size());
  auto hits=[&](int k,int horizon)->const auto&{
   auto& r=cache[k][horizon];
   if(r.computed)return r.hits;
   r.computed=true;
   const auto& t=banks[k];
   bitset<V> bad,inside;
   for(int p:{t.g,t.k}){bad[p]=true;for(int q:nb[p])if(q>=0)bad[q]=true;}
   for(int p:t.inner)inside[p]=true;
   for(int i=0;i<sample.trials;i++){
    auto& p=sample.at(i,horizon);
    int n=0;
    for(int j=0;j<sample.n;j++){if(bad[p[j]]){n=0;break;}n+=inside[p[j]];}
    r.hits[i]=n;
   }
   return r.hits;
  };
  vector<array<double,Horizon+1>> saved(midGroups.size());
  for(auto& r:saved)r.fill(-1.);
  for(auto& z:jobs){
   const auto& p=midGroups[z.group];
   auto& val=saved[z.group][z.eta];
   if(val<0){
    auto [sum,any]=midpointReward(hits(p.a,z.eta),hits(p.b,z.eta),sample.trials);
    val=(sample.trials&&double(any)/sample.trials>=.025)?
        (double(sum)/sample.trials)/(4.*(1.+z.eta)):0.;
   }
   z.value=val;
   if(midLastTurn==turn-1&&midLastGroup[z.a]==z.group&&midLastGroup[z.b]==z.group&&
      midLastGoal[z.a]==p.l&&midLastGoal[z.b]==p.r)z.value*=1.10;
  }
  erase_if(jobs,[](auto x){return x.value<=0.;});
 }
 void midpointSelect(const vector<vector<BankJob>>& axial,const array<BankPath,10>& paths,
      const bitset<terry_lane::MaxTubes>& shut,vector<BankJob>& old,
      const vector<MidpointJob>& options,bitset<V>& used,bitset<V>& moveTo,bitset<V>& paired){
  struct Job{int k,a,b,s,t,alt;double value;};
  vector<Job> all;
  for(const auto& row:axial)for(auto z:row){
   auto& p=banks[z.tube];
   all.push_back({z.tube,z.a,z.b,paths[z.a].step[p.l],paths[z.b].step[p.h],-1,z.value});
  }
  sort(all.begin(),all.end(),[](auto a,auto b){return tuple(-a.value,a.k,a.a,a.b)<tuple(-b.value,b.k,b.a,b.b);});
  const int numAxial=all.size();
  for(int i=0;i<int(options.size());i++){
   const auto& z=options[i];
   all.push_back({midGroups[z.group].a,z.a,z.b,z.s,z.t,i,z.value});
  }
  auto tubes=[&](const Job& a){
   return array<int,2>{a.k,a.alt<0?-1:midGroups[options[a.alt].group].b};
  };
  auto hit=[&](int q,int k){
   return q>=0&&(q==banks[k].g||q==banks[k].k||
    find(banks[k].inner.begin(),banks[k].inner.end(),q)!=banks[k].inner.end());
  };
  auto compatible=[&](const Job& a,const Job& b){
   if(((1<<a.a)|(1<<a.b))&((1<<b.a)|(1<<b.b)))return false;
   if((a.s>=0&&(a.s==b.s||a.s==b.t))||(a.t>=0&&(a.t==b.s||a.t==b.t)))return false;
   for(int u:tubes(a))if(u>=0)for(int v:tubes(b))if(v>=0){
    if(u==v||hit(a.s,v)||hit(a.t,v)||hit(b.s,u)||hit(b.t,u))return false;
    auto removed=shut;
    if(!terryRoad.protects(u,removed))return false;
    removed[u]=true;
    if(!terryRoad.protects(v,removed))return false;
   }
   return true;
  };
  double val=0;
  for(const auto& z:old)val+=z.value;
  int first=-1,second=-1;
  for(int i=numAxial;i<int(all.size());i++){
   const auto& a=all[i];
   if(a.value>val+1e-12)val=a.value,first=i,second=-1;
   for(int j=0;j<int(all.size());j++){
    if(j==i||(j>=numAxial&&j<i))continue;
    if(a.value+all[j].value<=val+1e-12){if(j<numAxial)break;continue;}
    if(compatible(a,all[j]))val=a.value+all[j].value,first=i,second=j;
   }
  }
  if(first<0)return;
  ++midDispatchTurns;midLastTurn=turn;old.clear();
  for(int i:{first,second})if(i>=0){
   const auto& job=all[i];
   if(job.alt<0){
    for(auto z:axial[job.k])if(z.a==job.a&&z.b==job.b){old.push_back(z);break;}
   }else{
    const auto& z=options[job.alt];
    const auto& p=midGroups[z.group];
    ++midDispatchJobs;
    paired[p.a]=paired[p.b]=true;
    midLastGroup[z.a]=midLastGroup[z.b]=z.group;
    midLastGoal[z.a]=p.l;midLastGoal[z.b]=p.r;
    for(auto [i,q]:{pair{z.a,z.s},pair{z.b,z.t}}){
     used[i]=true;
     if(q>=0){act[i]=MOVE[dir(humans[i],q)];moveTo[q]=true;}
    }
   }
  }
 }
