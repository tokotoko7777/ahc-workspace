#define main original_entry
#include "solve.cpp"
#undef main
int main(){
 for(int p=0;p<900;p++)nb[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 Game g;g.bankMode=5;g.humans={94,101,108,514,528};g.workers.resize(5);
 g.terryLayout(5);
 g.midpointInit();
 assert(g.midGroups.size()==24);
 g.turn=140;
 auto p=g.midGroups[0];
 const auto& a=g.banks[p.a];const auto& b=g.banks[p.b];
 g.humans={p.l,p.r,0,899,870};
 g.pets={{a.inner[2],1},{b.inner[1],3}};
 std::vector<int> ready(26,1),enabled(26,1);
 std::vector<terry_lane::Tube> shape;
 for(auto& x:g.banks){
  shape.push_back({x.l,x.h,x.g,x.k,x.inner});
  for(int q:x.side)g.wall[q]=1;
 }
 g.terryRoad.rebuild(nb,g.wall,shape,ready);
 g.prep();
 bitset<900> walls,build,moved,used;
 for(int i=0;i<900;i++)walls[i]=g.wall[i];
 bitset<terry_lane::MaxTubes> shut;
 g.midpointImmediate(walls,ready,enabled,build,moved,used,shut);
 assert(g.midLocks==1&&g.midHeads==1&&build[a.g]&&build[a.k]&&!build[b.g]&&!build[b.k]);
 assert(used[0]&&used[1]);
 g.prep();build.reset();moved.reset();used.reset();shut.reset();
 used[0]=true; // a higher-priority axial worker cannot be claimed
 g.midpointImmediate(walls,ready,enabled,build,moved,used,shut);
 assert(g.midLocks==1&&build.none());
 std::array<uint8_t,128> x{0,1,2,3},y{4,0,1,3};
 assert(g.midpointReward(x,y,4)==std::pair(10,4));
 g.prep();used.reset();
 vector<vector<Game::BankJob>> axial(26);
 vector<Game::BankJob> pack;
 vector<Game::MidpointJob> alt{{0,0,1,1,-1,-1,1.0}};
 array<Game::BankPath,10> paths;
 bitset<900> pair;
 g.midpointSelect(axial,paths,shut,pack,alt,used,moved,pair);
 assert(g.midDispatchJobs==1&&pack.empty()&&used[0]&&used[1]&&pair[p.a]&&pair[p.b]);
 axial[p.a].push_back({p.a,0,1,1,1.0});pack=axial[p.a];
 used.reset();pair.reset();
 g.midpointSelect(axial,paths,shut,pack,alt,used,moved,pair);
 assert(g.midDispatchJobs==1&&pack.size()==1&&used.none());
}
