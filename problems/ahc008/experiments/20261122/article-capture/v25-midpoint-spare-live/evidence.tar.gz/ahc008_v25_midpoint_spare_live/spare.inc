 vector<MidpointJob> spareMidMoving,spareMidAligned;
 bitset<V> spareMidEndBusy;
 string spareMidStock;
 int spareMidTurn=-1,spareMidSeen=0,spareMidDispatch=0,spareMidMoves=0,
   spareMidLocks=0,spareMidHeads=0,spareMidFirstLock=-1;
 bool spareMidOn=getenv("AHC008_NO_MIDPOINT_SPARE")==nullptr;

 void spareMidRemember(const vector<vector<BankJob>>& bank,const array<BankPath,10>& path,
      const vector<int>& ready,const vector<int>& enabled,const bitset<V>& build,
      const bitset<V>& moved,const bitset<V>& used,const bitset<terry_lane::MaxTubes>& shut){
  if(!spareMidOn)return;
  auto packed=packBankJobs(bank,2);
  if(packed.size()>1)return;
  auto available=used,now=moved;
  optional<BankJob> base;
  spareMidStock=act;
  if(!packed.empty()){
   base=packed.front();auto z=*base;
   available[z.a]=available[z.b]=true;
   const auto& t=banks[z.tube];
   for(auto [i,goal]:{pair{z.a,t.l},pair{z.b,t.h}}){
    int p=path[i].step[goal];
    if(p>=0&&!build[p])now[p]=true,spareMidStock[i]=MOVE[dir(humans[i],p)];
   }
  }
  if(priorPlan)for(int a=0;a<5;a++){
   int k=previousTube[a];
   if(k<0||!midpointOpen(k,ready,enabled,build,now,shut))continue;
   auto& x=banks[k];
   if(previousDoor[a]!=x.l)continue;
   for(int b=0;b<5;b++)if(a!=b&&previousTube[b]==k&&previousDoor[b]==x.h)
    available[a]=available[b]=true; // preserve the still-open previous axial pair
  }
  if(available.count()>3)return;
  midpointInit();
  vector<MidpointJob> options;
  int hi=0;
  midpointPaths(ready,enabled,build,now,available,shut,options,hi);
  auto in=[&](int p,int k){
   const auto& x=banks[k];
   return p>=0&&(p==x.g||p==x.k||find(x.inner.begin(),x.inner.end(),p)!=x.inner.end());
  };
  if(base){
   const auto z=*base;auto& x=banks[z.tube];
   int a=path[z.a].step[x.l],b=path[z.b].step[x.h];
   erase_if(options,[&](auto u){
    auto g=midGroups[u.group];auto gone=shut;
    if(!terryRoad.protects(z.tube,gone))return true;
    gone[z.tube]=true;
    for(int k:{g.a,g.b})
     if(k==z.tube||in(a,k)||in(b,k)||in(u.s,z.tube)||in(u.t,z.tube)||
        !terryRoad.protects(k,gone))return true;
    return false;
   });
  }
  if(options.empty())return;
  spareMidAligned.clear();spareMidMoving.clear();
  for(const auto& z:options){
   if(z.s<0&&z.t<0)spareMidAligned.push_back(z);
   else spareMidMoving.push_back(z);
  }
  // Sample forecasts only after the stock plan exists; no sampled values
  // feed back to the original axial pack.
  if(!spareMidMoving.empty()&&!overBudget()){
   hi=0;for(auto z:spareMidMoving)hi=max(hi,z.eta);
   const auto prior=mcDogs();
   const auto sample=terry_mc::sample_paths(mcState(),terrySim,64,hi,&prior);
   midpointValues(sample,spareMidMoving);
  }else spareMidMoving.clear();
  if(spareMidAligned.empty()&&spareMidMoving.empty())return;
  ++spareMidSeen;spareMidTurn=turn;
 }
 struct SparePhysical{bitset<V> walls,placed;vector<int> after;};
 optional<SparePhysical> sparePhysical(string_view q)const{
  if(q.size()!=humans.size())return nullopt;
  SparePhysical cert;cert.after=humans;
  for(int p=0;p<V;p++)if(wall[p])cert.walls[p]=true;
  for(int i=0;i<int(q.size());i++)if(q[i]!='.'){
   const size_t s=string_view("UDLR").find(toupper(q[i]));
   if(s>=4)return nullopt;
   int x=nb[humans[i]][s];
   if(x<0||wall[x])return nullopt;
   if(islower(q[i])){
    if(find(humans.begin(),humans.end(),x)!=humans.end())return nullopt;
    for(auto p:pets)if(md(p.p,x)<=1)return nullopt;
    cert.placed[x]=cert.walls[x]=true;
   }else cert.after[i]=x;
  }
  for(int x:cert.after)if(cert.walls[x])return nullopt;
  auto service=ahc008_midpoint::flood(nb,cert.walls,cert.after.front());
  for(int x:cert.after)if(!service[x])return nullopt;
  return cert;
 }
 string spareMidApply(const string& base){
  if(spareMidTurn!=turn||humans.size()!=5)return base;
  // main() has already sanitized the original command; require the
  // original work to survive byte-for-byte, and independently validate
  // any addition against the exact compound end-of-turn board.
  for(int i=0;i<5;i++)if(spareMidStock[i]!='.'&&base[i]!=spareMidStock[i])return base;
  auto old=sparePhysical(base);
  if(!old)return base;
  bitset<V> guessedWalls=old->walls&~old->placed;
  auto compatible=[&](const MidpointJob& z){
   if(spareMidEndBusy[z.a]||spareMidEndBusy[z.b]||base[z.a]!='.'||base[z.b]!='.')return false;
   const auto& p=midGroups[z.group];
   for(int i=0;i<5;i++)if(base[i]!='.'){
    int q=nb[humans[i]][string_view("UDLR").find(toupper(base[i]))];
    if(q==z.s||q==z.t||q==p.l||q==p.r)return false;
    for(int k:{p.a,p.b}){
     const auto& x=banks[k];
     if(q==x.g||q==x.k||find(x.inner.begin(),x.inner.end(),q)!=x.inner.end())return false;
    }
   }
   return true;
  };
  vector<int> petPos;for(const auto& x:pets)petPos.push_back(x.p);
  bitset<V> roads;
  for(int a=0;a<=bankN;a++)for(int r=0;r<S;r++){
   int x=bp(r,bankShift+7*a);if(!guessedWalls[x])roads[x]=true;
  }
  string best=base;
  int heads=0;
  for(const auto& z:spareMidAligned)if(compatible(z)){
   auto& p=midGroups[z.group];
   for(int k:{p.a,p.b}){
    auto c=ahc008_midpoint::certify(nb,midTubes[k],guessedWalls,old->placed,roads,old->after,
        petPos,p.l,p.r,z.a,z.b,crossing.reserves(k));
    if(c.certified&&c.heads>heads){
     string q=base;q[z.a]=BUILD[dir(p.l,banks[k].g)];q[z.b]=BUILD[dir(p.r,banks[k].k)];
     if(sparePhysical(q))best=move(q),heads=c.heads;
    }
   }
  }
  if(heads){
   ++spareMidLocks;spareMidHeads+=heads;integratedLocks[turn]+=heads;
   if(spareMidFirstLock<0)spareMidFirstLock=turn;
   return best;
  }
  const MidpointJob* bestMove=nullptr;
  for(const auto& z:spareMidMoving)if(z.value>0&&compatible(z)&&(!bestMove||z.value>bestMove->value)){
   auto q=base;
   if(z.s>=0)q[z.a]=MOVE[dir(humans[z.a],z.s)];
   if(z.t>=0)q[z.b]=MOVE[dir(humans[z.b],z.t)];
   if(sparePhysical(q))best=move(q),bestMove=&z;
  }
  if(bestMove){
   const auto z=*bestMove;const auto& p=midGroups[z.group];
   ++spareMidDispatch;spareMidMoves+=(z.s>=0)+(z.t>=0);
   midLastTurn=turn;midLastGroup.fill(-1);midLastGoal.fill(-1);
   midLastGroup[z.a]=midLastGroup[z.b]=z.group;
   midLastGoal[z.a]=p.l;midLastGoal[z.b]=p.r;
  }
  return best;
 }
