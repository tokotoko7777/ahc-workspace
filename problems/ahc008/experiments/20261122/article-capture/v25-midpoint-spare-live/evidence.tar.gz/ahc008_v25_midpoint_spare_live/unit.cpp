#define main original_entry
#include "solve.cpp"
#undef main
int main(){
 for(int p=0;p<900;p++)nb[p]={p>=30?p-30:-1,p<870?p+30:-1,p%30?p-1:-1,p%30<29?p+1:-1};
 Game g;g.bankMode=5;g.humans={94,101,108,514,528};g.workers.resize(5);
 g.terryLayout(5);g.midpointInit();
 assert(g.midGroups.size()==24);
 const auto p=g.midGroups.front();
 const auto& x=g.banks[p.a];const auto& y=g.banks[p.b];
 g.turn=140;g.spareMidTurn=g.turn;
 g.humans={p.l,p.r,0,898,870};
 for(const auto& z:g.banks)for(int q:z.side)g.wall[q]=1;
 g.pets={{x.inner[1],1},{y.inner[2],2}};
 g.spareMidStock="..R..";
 g.spareMidAligned={{0,0,1,1,-1,-1,0.}};
 const string baseline="..R..";
 auto a=g.spareMidApply(baseline);
 auto checked=g.sparePhysical(a);
 assert(a[2]=='R'&&a[3]=='.'&&a[4]=='.'&&checked&&checked->placed[x.g]&&checked->placed[x.k]);
 assert(checked->placed.count()==2&&g.spareMidLocks==1&&g.spareMidHeads==1);
 g.spareMidEndBusy[0]=true;
 assert(g.spareMidApply(baseline)==baseline);
 g.spareMidEndBusy.reset();
 assert(g.spareMidApply("..D..")==string("..D..")); // stock postprocessing is never changed
 g.spareMidAligned.clear();
 const int r=g.bankRot?p.l%30:p.l/30,c=g.bankRot?p.l/30:p.l%30;
 g.humans[0]=g.bp(r,c-1);
 g.spareMidMoving={{0,0,1,1,p.l,-1,1.}};
 a=g.spareMidApply(baseline);
 assert(a[0]!='.'&&isupper(a[0])&&a[2]=='R'&&g.spareMidDispatch==1&&g.spareMidMoves==1);
 auto cert=g.sparePhysical(a);
 assert(cert&&cert->after[0]==p.l&&cert->placed.none());
 g.turn++;
 assert(g.spareMidApply(baseline)==baseline);
}
