from pathlib import Path
import hashlib,sys
p,o=map(Path,sys.argv[1:]);raw=p.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='333f5177eebb5ca6f4a7cac4c0da5aae72e7aa82266803f97abfc06580b82345'
s=raw.decode();wd=Path(__file__).resolve().parent
def rep(a,b):
 global s
 assert s.count(a)==1,a[:120]
 s=s.replace(a,b)
h=(wd.parent/'ahc008_v25_midpoint_certificate/midpoint.hpp').read_text().replace('#pragma once\n','')
rep('struct Game {',h+'\nstruct Game {')
f=(wd.parent/'ahc008_v25_midpoint_live/live.inc').read_text()
parts=f[:f.index(' void midpointImmediate(')]+f[f.index(' void midpointPaths('):f.index(' void midpointSelect(')]
rep(' string integratedBankPlan(){',parts+(wd/'spare.inc').read_text()+' string integratedBankPlan(){')
rep('   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;', '''   if(m==5&&!terryBuild.inConstruction(turn)&&!partial)
    spareMidRemember(jobs,paths,ready,enabled,build,moveTo,usedPeople,shut);
   previousTube.fill(-1);previousDoor.fill(-1);priorPlan=true;''')
rep('   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);\n  }\n  return act;','''   parkUnassigned(ready,paths,usedPeople,build,moveTo,service);
  }
  if(spareMidTurn==turn)spareMidEndBusy=usedPeople;
  return act;''')
rep('    g.act=std::move(proposal);','''    if(g.spareMidTurn==g.turn)proposal=g.spareMidApply(proposal);
    g.act=std::move(proposal);''')
rep(' if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){',''' if(const char* p=getenv("AHC008_MIDPOINT_SPARE_LIVE_LOG")){
  ofstream f(p);f<<g.spareMidSeen<<' '<<g.spareMidDispatch<<' '<<g.spareMidMoves<<' '
    <<g.spareMidLocks<<' '<<g.spareMidHeads<<' '<<g.spareMidFirstLock<<'\\n';
 }
 if(const char* p=getenv("AHC008_LOCAL_STANDBY_LOG")){''')
o.write_text(s)
